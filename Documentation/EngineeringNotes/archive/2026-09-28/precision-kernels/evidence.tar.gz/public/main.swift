import Foundation
if CommandLine.arguments[1] == "--anova-bench" {
    var sink=0.0
    for n in [32,1024,65536,1048576] {
        let groups=(0..<3).map { g in (0..<n).map { 1e12+Double($0%5-2)+Double(g) } }
        var samples=[Double]()
        for r in 0..<11 {
            let start=DispatchTime.now().uptimeNanoseconds
            let value=try Stats.oneWayANOVA(groups:groups).fStatistic
            sink+=value
            if r>1 { samples.append(Double(DispatchTime.now().uptimeNanoseconds-start)/1e6) }
        }
        let row:[String:Any]=["group_size":n,"value":try Stats.oneWayANOVA(groups:groups).fStatistic,"milliseconds":samples,"median_ms":samples.sorted()[4]]
        print(String(data:try JSONSerialization.data(withJSONObject:row,options:[.sortedKeys]),encoding:.utf8)!)
    }
    fputs("checksum=\(sink)\n",stderr)
} else if CommandLine.arguments[1] == "--memory" {
    let n = 8_388_608
    let a = (0..<n).map { 1e12 + Double($0 % 1021 - 510)/128 }
    let result = CommandLine.arguments[2] == "before" ? baselineVariance(a) : try Stats.variance(a)
    print(result)
} else if CommandLine.arguments[1] == "--bench" {
    var sink = 0.0
    for n in [32,1024,65536,1048576,8388608] {
        for offset in [0.0,1e12] {
            let a=(0..<n).map { offset + Double($0 % 1021 - 510)/128 }
            let repetitions=max(1,100_000/n)
            var samples=[[Double](),[Double]()]
            for r in 0..<11 {
                for step in 0..<2 {
                    let candidate=(r+step)%2
                    let start=DispatchTime.now().uptimeNanoseconds
                    for _ in 0..<repetitions { sink += candidate == 0 ? baselineVariance(a) : try Stats.variance(a) }
                    let elapsed=Double(DispatchTime.now().uptimeNanoseconds-start)/Double(repetitions)/1e6
                    if r > 1 { samples[candidate].append(elapsed) }
                }
            }
            for c in 0..<2 {
                let value = c == 0 ? baselineVariance(a) : try Stats.variance(a)
                let row:[String:Any]=["n":n,"offset":offset,"candidate":c == 0 ? "production-before" : "public-after","value":value,"median_ms":samples[c].sorted()[4],"milliseconds":samples[c]]
                print(String(data:try JSONSerialization.data(withJSONObject:row,options:[.sortedKeys]),encoding:.utf8)!)
            }
        }
    }
    fputs("checksum=\(sink)\n",stderr)
} else {
let cases = try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))) as! [[String:Any]]
for c in cases {
 let op=c["op"] as! String
 if op == "sum" { continue }
 let value:Double
 if op == "anova" { value=try Stats.oneWayANOVA(groups:c["groups"] as! [[Double]]).fStatistic }
 else if op == "variance" { value=try Stats.variance(c["a"] as! [Double]) }
 else { value=try Stats.dotProduct(c["a"] as! [Double],c["b"] as! [Double]) }
 let record:[String:Any] = ["case":c["id"]!,"op":op,"candidate":"public-api","value":value.isFinite ? String(value):"nonfinite"]
 print(String(data:try JSONSerialization.data(withJSONObject:record,options:[.sortedKeys]),encoding:.utf8)!)
}

}
