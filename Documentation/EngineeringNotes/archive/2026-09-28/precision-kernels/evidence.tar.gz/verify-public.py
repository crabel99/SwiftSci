import contextlib,importlib.util,io,json,math
from fractions import Fraction as F
from pathlib import Path
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('references',p/'check.py');mod=importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):spec.loader.exec_module(mod)
cases={c['id']:c for c in mod.cases};results={}
for stage in ['before','after']:
 stats={}
 for line in (p/f'public-{stage}.jsonl').read_text().splitlines():
  r=json.loads(line);ref=mod.reference(cases[r['case']]);value=float(r['value']) if r['value']!='nonfinite' else math.nan
  error=abs(F(value)-ref) if math.isfinite(value) else None
  s=stats.setdefault(r['op'],{'cases':0,'failed':[]});s['cases']+=1
  if error is None or error>abs(ref)*F(1,10**12)+8*F(math.ulp(0.0)):s['failed'].append(r['case'])
 results[stage]=stats
assert not results['after']['variance']['failed']
assert not results['after']['anova']['failed']
assert results['before']['dot']==results['after']['dot']
(p/'public-summary.json').write_text(json.dumps(results,indent=2))
print(json.dumps({stage:{op:{'cases':s['cases'],'failures':len(s['failed'])} for op,s in stats.items()} for stage,stats in results.items()},indent=2))
