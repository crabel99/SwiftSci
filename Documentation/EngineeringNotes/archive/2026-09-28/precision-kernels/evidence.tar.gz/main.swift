import Foundation
import Accelerate
let candidates: [(String,String,([Double],[Double])->Double)] = [
 ("sum","vdsp",{a,_ in vDSP.sum(a)}), ("sum","scalar-compensated",{a,_ in scalarSum(a)}), ("sum","simd-compensated",{a,_ in laneSum(a)}),
 ("dot","vdsp",{a,b in vDSP.dot(a,b)}), ("dot","scalar-fma",scalarDot), ("dot","simd-fma",{a,b in laneDot(a,b,compensated:false)}), ("dot","simd-compensated",{a,b in laneDot(a,b,compensated:true)}),
 ("variance","blocked-fma",{a,_ in blockedVariance(a)}),
 ("variance","production-snapshot",{a,_ in baselineVariance(a)}), ("variance","simd-fma",{a,_ in laneVariance(a,compensated:false)}), ("variance","simd-compensated",{a,_ in laneVariance(a,compensated:true)})]
func emit(_ obj: [String:Any]) { print(String(data: try! JSONSerialization.data(withJSONObject:obj,options:[.sortedKeys]),encoding:.utf8)!) }
if CommandLine.arguments.count > 1 {
 let cases = try! JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))) as! [[String:Any]]
 for c in cases {
  if let groups=c["groups"] as? [[Double]] {
   for optimized in [false,true] {
    let result=anova(groups,optimized:optimized)
    emit(["case":c["id"]!,"candidate":optimized ? "simd-compensated" : "production-snapshot","op":"anova","value":result.isFinite ? String(result):"nonfinite"])
   }
   continue
  }
  let a=c["a"] as! [Double], b=c["b"] as? [Double] ?? a
  for (op,name,run) in candidates where op == c["op"] as! String {
   let result=run(a,b)
   emit(["case":c["id"]!,"candidate":name,"op":op,"value":result.isFinite ? String(result):"nonfinite"])
  }
 }
} else {
 var sink = 0.0
 for n in [32,1024,65536,1048576,8388608] {
  for shape in ["ordinary","offset"] {
   let a=(0..<n).map { (shape == "offset" ? 1e12 : 0) + Double(($0*73)%1021-510)/128 }
   let b=(0..<n).map { Double(($0*37)%509-254)/64 }
   for (_,_,run) in candidates { sink += run(a,b) }
   var samples=Array(repeating:[Double](),count:candidates.count)
   for repeatIndex in 0..<7 {
    for index in 0..<candidates.count {
     let k=(index+repeatIndex)%candidates.count, start=DispatchTime.now().uptimeNanoseconds
     let value=candidates[k].2(a,b)
     let elapsed=Double(DispatchTime.now().uptimeNanoseconds-start)/1e6
     sink += value; samples[k].append(elapsed)
    }
   }
   for (i,c) in candidates.enumerated() { emit(["n":n,"shape":shape,"op":c.0,"candidate":c.1,"milliseconds":samples[i],"median_ms":samples[i].sorted()[3]]) }
  }
 }
 fputs("checksum=\(sink)\n",stderr)
}
