from pathlib import Path
import hashlib,json,sys,shutil
root=Path('/Users/crabel/Documents/src/SwiftSci');sys.path.insert(0,str(root/'Benchmarks/Tools'))
import runner
snapshot=Path(Path('/private/tmp/swiftsci-precision-trial/snapshot.txt').read_text())
source=runner.source_identity(root)
for name,expected in source['files'].items():
 assert hashlib.sha256((snapshot/name).read_bytes()).hexdigest()==expected,name
log=Path('/private/tmp/swiftsci-precision-trial/anova-tests.log')
assert '** TEST SUCCEEDED **' in log.read_text()
worker=Path('/Users/crabel/Library/Caches/SwiftSci/standardized-benchmarks/derived/Build/Products/Release/SwiftSciBenchmarkWorker')
runner.verify_uninstrumented(worker)
record=dict(schema_version=1,source=source,binary_sha256=hashlib.sha256(worker.read_bytes()).hexdigest(),coverage_instrumentation='absent',environment=runner.environment(),snapshot=str(snapshot),log=str(log),producer='Existing xcodebuild test run, all recorded source bytes checked against its snapshot',command=['xcodebuild','test','-scheme','SwiftSci-Package','-configuration','Release','-destination','platform=macOS,arch=arm64','-derivedDataPath','/Users/crabel/Library/Caches/SwiftSci/standardized-benchmarks/derived','-clonedSourcePackagesDirPath','/Users/crabel/Library/Caches/SwiftSci/xcode-packages','-onlyUsePackageVersionsFromResolvedFile','-skipPackagePluginValidation','-parallel-testing-enabled','NO','-enableCodeCoverage','NO','ENABLE_TESTABILITY=YES','SWIFT_ENABLE_CODE_COVERAGE=NO','CLANG_ENABLE_CODE_COVERAGE=NO','-only-testing:SwiftStatsTests','-only-testing:SwiftForecastTests','-resultBundlePath','/private/tmp/swiftsci-precision-trial/anova-tests.xcresult'])
path=Path(str(worker)+'.build.json')
if path.exists():shutil.copyfile(path,'/private/tmp/swiftsci-precision-trial/previous-worker-build.json')
path.write_text(json.dumps(record,indent=2)+'\n')
Path('/private/tmp/swiftsci-precision-trial/worker-build.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified source files:',len(source['files']),'fingerprint:',source['tree_sha256'])
