import json, math, random, subprocess
from fractions import Fraction as F
from pathlib import Path
root=Path('/Users/crabel/Documents/src/SwiftSci')
out=Path(__file__).parent
rng=random.Random(8127)
cases=[]
def add(op,a,b=None,name=None):
 c=dict(id=name or f'{op}-{len(cases)}',op=op,a=a)
 if b is not None:c['b']=b
 cases.append(c)
for n in [2,3,4,5,7,8,9,15,16,17,31,32,33,63,64,65,257]:
 for exponent in [-50,0,50]:
  a=[math.ldexp(rng.randint(-1000,1000),exponent-10) for _ in range(n)]
  b=[rng.randint(-100,100)/64 for _ in a]
  for op in ['sum','dot','variance']:add(op,a,b)
 for offset in [0,1e8,1e12,1e15]:
  a=[offset+rng.randint(-50,50)/8 for _ in range(n)]
  add('variance',a)
for n in [1,2,7,64,1024]:
 a=[1e16,1.0,-1e16,1.0]*n
 for order in [a,a[::-1],sorted(a)]:
  add('sum',order);add('dot',order,[1.0]*len(order))
delta=2**-27
for n in [1,4,16]:add('dot',[1+delta,-1.0]*n,[1-delta,1.0]*n,name=f'product-rounding-{n}')
for n in [2,4,9,32]:
 for a in [[1e12]*n,[math.ulp(0.0)]*n,[1e-150,-1e-150]*(n//2)]:
  add('sum',a);add('variance',a)
for path in sorted((root/'Benchmarks/Fixtures/nist-models/inputs').glob('*.json')):
 c=json.loads(path.read_text())
 if 'groups' in c:cases.append(dict(id=path.stem,op='anova',groups=c['groups']))
def reference(c):
 op=c['op']
 if op=='anova':
  gs=[[F(x) for x in g] for g in c['groups']];n=sum(map(len,gs));means=[sum(g)/len(g) for g in gs];m=sum(map(sum,gs))/n
  return sum(len(g)*(mu-m)**2 for g,mu in zip(gs,means))/(len(gs)-1)/(sum(sum((x-mu)**2 for x in g) for g,mu in zip(gs,means))/(n-len(gs)))
 a=list(map(F,c['a']))
 if op=='sum':return sum(a)
 if op=='dot':return sum(x*F(y) for x,y in zip(a,c['b']))
 m=sum(a)/len(a);return sum((x-m)**2 for x in a)/(len(a)-1)
(out/'cases.json').write_text(json.dumps(cases))
raw=subprocess.check_output([str(out/'probe'),str(out/'cases.json')],text=True)
(out/'accuracy.jsonl').write_text(raw)
byid={c['id']:c for c in cases}; summary={}; failures=[]
for line in raw.splitlines():
 r=json.loads(line);ref=reference(byid[r['case']]);key=r['op']+'/'+r['candidate'];s=summary.setdefault(key,dict(cases=0,failed=0,max_relative_error=0));s['cases']+=1
 actual=float(r['value']) if r['value']!='nonfinite' else float('nan')
 error=abs(F(actual)-ref) if math.isfinite(actual) else None
 # 1e-12 relative plus eight minimum subnormal units, no blanket absolute tolerance.
 tolerance=abs(ref)*F(1,10**12)+F(math.ulp(0.0))*8
 failed=error is None or error>tolerance
 if ref and error is not None:s['max_relative_error']=max(s['max_relative_error'],float(error/abs(ref)))
 if failed:s['failed']+=1;failures.append(dict(**r,reference=str(float(ref)),absolute_error=str(float(error)) if error is not None else 'nonfinite'))
(out/'accuracy-summary.json').write_text(json.dumps(dict(policy='abs error <= abs exact binary64 reference * 1e-12 + 8 minimum subnormal units; exploratory qualification, not production certification',summary=summary,failures=failures),indent=2))
print(json.dumps(summary,indent=2))
