import Accelerate

struct Compensated {
    var sum = 0.0
    var correction = 0.0
    mutating func add(_ x: Double) {
        let t = sum + x
        correction += abs(sum) >= abs(x) ? (sum - t) + x : (x - t) + sum
        sum = t
    }
    var value: Double { sum + correction }
}
struct LaneSum {
    var sum = SIMD4<Double>(repeating: 0)
    var correction = SIMD4<Double>(repeating: 0)
    mutating func add(_ x: SIMD4<Double>) {
        let t = sum + x
        let b = t - sum
        correction += (sum - (t - b)) + (x - b)
        sum = t
    }
    var value: Double {
        var result = Compensated()
        for i in 0..<4 { result.add(sum[i]); result.add(correction[i]) }
        return result.value
    }
}
@inline(__always) func load(_ p: UnsafeBufferPointer<Double>, _ i: Int) -> SIMD4<Double> {
    SIMD4(p[i],p[i+1],p[i+2],p[i+3])
}
@inline(never) func scalarSum(_ a: [Double]) -> Double {
    var s = Compensated(); for x in a { s.add(x) }; return s.value
}
@inline(never) func laneSum(_ a: [Double], origin: Double = 0) -> Double {
    a.withUnsafeBufferPointer { p in
        var s = LaneSum(), s1 = LaneSum(), s2 = LaneSum(), s3 = LaneSum(); var i = 0
        let shift = SIMD4<Double>(repeating: origin)
        while i + 16 <= p.count {
            s.add(load(p,i)-shift); s1.add(load(p,i+4)-shift)
            s2.add(load(p,i+8)-shift); s3.add(load(p,i+12)-shift); i += 16
        }
        for other in [s1,s2,s3] { s.add(other.sum); s.add(other.correction) }
        while i + 4 <= p.count { s.add(load(p,i) - SIMD4(repeating: origin)); i += 4 }
        var tail = Compensated(); tail.add(s.value)
        while i < p.count { tail.add(p[i] - origin); i += 1 }
        return tail.value
    }
}
@inline(never) func scalarDot(_ a: [Double], _ b: [Double]) -> Double {
    var s = 0.0; for i in a.indices { s = s.addingProduct(a[i],b[i]) }; return s
}
@inline(never) func laneDot(_ a: [Double], _ b: [Double], compensated: Bool) -> Double {
    a.withUnsafeBufferPointer { p in b.withUnsafeBufferPointer { q in
        var s = LaneSum(); var f = SIMD4<Double>(repeating: 0); var i = 0
        while i + 4 <= p.count {
            let x = load(p,i), y = load(q,i)
            if compensated {
                let product = x * y
                s.add(product)
                s.correction += (-product).addingProduct(x,y)
            } else { f = f.addingProduct(x,y) }
            i += 4
        }
        var tail = Compensated()
        if compensated { tail.add(s.value) } else { for j in 0..<4 { tail.add(f[j]) } }
        while i < p.count {
            let product = p[i] * q[i]
            tail.add(product)
            if compensated { tail.add((-product).addingProduct(p[i],q[i])) }
            i += 1
        }
        return tail.value
    }}
}
@inline(never) func baselineVariance(_ a: [Double]) -> Double {
    var mean = 0.0; vDSP_meanvD(a,1,&mean,vDSP_Length(a.count))
    var negative = -mean, centered = [Double](repeating: 0,count: a.count)
    vDSP_vsaddD(a,1,&negative,&centered,1,vDSP_Length(a.count))
    return max(0,vDSP.sumOfSquares(centered)/Double(a.count-1))
}
@inline(never) func laneVariance(_ a: [Double], compensated: Bool) -> Double {
    let origin = a[0], mean = laneSum(a,origin: origin)/Double(a.count)
    let squares = a.withUnsafeBufferPointer { p in
        var s = LaneSum(), d = LaneSum(); var f = SIMD4<Double>(repeating: 0); var i = 0
        while i + 4 <= p.count {
            let x = (load(p,i) - SIMD4(repeating: origin)) - SIMD4(repeating: mean)
            d.add(x)
            if compensated { let product = x*x; s.add(product); s.correction += (-product).addingProduct(x,x) }
            else { f = f.addingProduct(x,x) }
            i += 4
        }
        var tail = Compensated(), deviations = Compensated()
        deviations.add(d.value)
        if compensated { tail.add(s.value) } else { for j in 0..<4 { tail.add(f[j]) } }
        while i < p.count { let x = (p[i]-origin)-mean; deviations.add(x); tail.add(x*x); i += 1 }
        return tail.value.addingProduct(-deviations.value/Double(a.count),deviations.value)
    }
    return max(0,squares/Double(a.count-1))
}
@inline(never) func anova(_ groups: [[Double]], optimized: Bool) -> Double {
    func sum<S: Sequence>(_ values: S) -> Double where S.Element == Double {
        var s = Compensated(); for x in values { s.add(x) }; return s.value
    }
    let origin = groups[0][0]
    let means = groups.map { g in
        (optimized ? laneSum(g,origin:origin) : sum(g.lazy.map { $0-origin }))/Double(g.count)
    }
    let n = groups.reduce(0) { $0+$1.count }
    let grandMean = sum(zip(groups,means).lazy.map { Double($0.0.count)*$0.1 })/Double(n)
    let between = sum(zip(groups,means).lazy.map { g,m in Double(g.count)*(m-grandMean)*(m-grandMean) })
    let within = sum(groups.lazy.map { g -> Double in
        if g.count == 1 { return 0 }
        if optimized { return laneVariance(g,compensated:true)*Double(g.count-1) }
        let o=g[0], m=sum(g.lazy.map { $0-o })/Double(g.count)
        return sum(g.lazy.map { let d=($0-o)-m; return d*d })
    })
    return (between/Double(groups.count-1))/(within/Double(n-groups.count))
}
@inline(never) func blockedVariance(_ a: [Double]) -> Double {
    let origin = a[0], mean = laneSum(a,origin: origin)/Double(a.count)
    return a.withUnsafeBufferPointer { p in
        var total = Compensated(), error = Compensated(); var i = 0
        let o = SIMD4<Double>(repeating:origin), m = SIMD4<Double>(repeating:mean)
        while i + 16 <= p.count {
            let end = min(i+256, p.count-p.count%16)
            var s0=SIMD4<Double>(repeating:0),s1=s0,s2=s0,s3=s0
            var d0=s0,d1=s0,d2=s0,d3=s0
            while i < end {
                let x0=(load(p,i)-o)-m,x1=(load(p,i+4)-o)-m,x2=(load(p,i+8)-o)-m,x3=(load(p,i+12)-o)-m
                s0=s0.addingProduct(x0,x0); s1=s1.addingProduct(x1,x1)
                s2=s2.addingProduct(x2,x2); s3=s3.addingProduct(x3,x3)
                d0+=x0; d1+=x1; d2+=x2; d3+=x3
                i+=16
            }
            for j in 0..<4 { total.add(s0[j]);total.add(s1[j]);total.add(s2[j]);total.add(s3[j]);error.add(d0[j]);error.add(d1[j]);error.add(d2[j]);error.add(d3[j]) }
        }
        while i < p.count { let x=(p[i]-origin)-mean; total.add(x*x);error.add(x);i+=1 }
        return max(0,total.value.addingProduct(-error.value/Double(p.count),error.value)/Double(p.count-1))
    }
}
