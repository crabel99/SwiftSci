import json,random,math,struct,subprocess,sys,statistics
from fractions import Fraction as F
from pathlib import Path
out=Path(__file__).parent
rng=random.Random(284019)
cases=[]
def add(family,a,b,name=None):
 cases.append(dict(id=name or f'{family}-{len(cases)}',family=family,a=a,b=b))
def power(e):return math.ldexp(1.,e)
for n in [1,2,3,4,7,15,16,17,31,32,33,63,64,65,127,128,129,384,768,1536,4096]:
 for repeat in range(6):
  add('ordinary',[rng.uniform(-1,1) for _ in range(n)],[rng.uniform(-1,1) for _ in range(n)])
  add('positive',[rng.uniform(0,1) for _ in range(n)],[rng.uniform(0,1) for _ in range(n)])
  a=[rng.uniform(-1,1)*power(rng.randint(-450,450)) for _ in range(n)]
  b=[rng.uniform(-1,1)*power(rng.randint(-450,450)) for _ in range(n)]
  add('wide-range',a,b)
for repeat in range(120):
 n=rng.choice([2,7,15,16,17,32,63,128])
 a=[rng.uniform(-1,1) for _ in range(n)];b=[rng.uniform(-1,1) for _ in range(n)]
 products=sum(F(x)*F(y) for x,y in zip(a,b))
 a+=[-float(products)];b+=[1.]
 for order in [list(range(n+1)),rng.sample(range(n+1),n+1)]:add('cancellation',[a[i] for i in order],[b[i] for i in order])
for n in [1,4,17,257,4096]:
 a=[1e16,1.,-1e16,1.]*n
 for a in [a,a[::-1],sorted(a)]:add('sum-rounding',a,[1.]*len(a))
for k in [26,27,30,40,52]:
 e=power(-k)
 for n in [1,2,8,17,257]:add('product-rounding',[1+e,-1.]*n,[1-e,1.]*n)
for n in [2,16,256,4096]:
 add('underflow',[power(-537)]*n,[power(-538)]*n)
 add('underflow',[power(-537)]*n,[power(-537)]*n)
 add('subnormal-input',[power(-1074)]*n,[1.]*n)
add('intermediate-overflow',[power(1023),-power(1023),1.],[2.,2.,1.])
add('intermediate-overflow',[sys.float_info.max,sys.float_info.max,-sys.float_info.max],[1.,1.,1.])
add('result-overflow',[sys.float_info.max]*2,[2.]*2)
add('zero',[1.,-1.],[1.,1.])
add('zero',[0.,-0.,0.],[1.,2.,3.])
# More than two working precisions of cancellation: a two-component accumulator has limits.
for n in [4,16,64]:
 a=[power(100),1.,power(-100),-power(100),-1.]*n
 add('beyond-double-double',a,[1.]*len(a))
for c in cases:
 for key in ['a','b']:c[key+'_bits']=[str(struct.unpack('Q',struct.pack('d',x))[0]) for x in c[key]]
(out/'cases.json').write_text(json.dumps(cases))
raw=subprocess.check_output([str(out/'probe'),str(out/'cases.json')],text=True)
(out/'results.jsonl').write_text(raw)
refs={}
for c in cases:
 terms=[F(x)*F(y) for x,y in zip(c['a'],c['b'])]
 exact=sum(terms);mag=sum(map(abs,terms))
 try:rounded=float(exact)
 except OverflowError:rounded=math.copysign(math.inf,1 if exact>0 else -1)
 refs[c['id']]=(c['family'],exact,mag,rounded)
summary={};fails=[]
for line in raw.splitlines():
 r=json.loads(line);family,exact,mag,rounded=refs[r['case']];value=float(r['value'])
 s=summary.setdefault(r['candidate'],{}).setdefault(family,dict(cases=0,within_one_ulp=0,within_relative_1e12=0,max_ulp=0))
 s['cases']+=1
 if math.isinf(rounded):ok=value==rounded;relativeok=ok;ulp=0 if ok else math.inf
 elif not math.isfinite(value):ok=relativeok=False;ulp=math.inf
 else:
  error=abs(F(value)-exact)
  ulp=float(abs(F(value)-F(rounded))/F(math.ulp(rounded)))
  ok=ulp<=1
  relativeok=error<=abs(exact)*F(1,10**12)+F(math.ulp(0.0))/2
 s['within_one_ulp']+=int(ok);s['within_relative_1e12']+=int(relativeok)
 s['max_ulp']=max(s['max_ulp'],ulp)
 if not relativeok:fails.append(dict(**r,family=family,rounded_reference=str(rounded),ulp=str(ulp)))
# Store exact reference representations; no Decimal precision assumption.
(out/'references.json').write_text(json.dumps({key:dict(family=v[0],numerator=str(v[1].numerator),denominator=str(v[1].denominator),rounded=str(v[3])) for key,v in refs.items()},indent=2))
(out/'summary.json').write_text(json.dumps(dict(summary=summary,failures=fails),indent=2))
for name,families in summary.items():
 print(name, 'relative misses', {f:s['cases']-s['within_relative_1e12'] for f,s in families.items() if s['within_relative_1e12']<s['cases']},'one-ULP misses',sum(s['cases']-s['within_one_ulp'] for s in families.values()))
print('cases',len(cases))
