import json,struct,re,subprocess
from decimal import Decimal
from pathlib import Path
p=Path(__file__).parent;r=Path('/Users/LOCAL_USER/Documents/src/SwiftSci/Benchmarks/Fixtures/nist-models')
def bits(x):return str(struct.unpack('Q',struct.pack('d',x))[0])
cases=[];details=[]
for name in ['SmLs07','SmLs08','SmLs09']:
 groups={}
 for line in (r/'originals'/f'{name}.dat').read_text().splitlines():
  m=re.fullmatch(r'\s*(\d+)\s+(\d+\.\d+)\s*',line)
  if m:groups.setdefault(m[1],[]).append(Decimal(m[2]))
 origin=next(iter(groups.values()))[0]
 ref=json.loads((r/'references'/f'{name}.json').read_text())
 details.append(dict(name=name,origin=str(origin),groups=len(groups),observations=sum(map(len,groups.values())),decimal_expected=ref['nistCertifiedValues'][0],binary_expected=ref['binary64InputDiagnostic']['values'][0]))
 for mode in ['direct','center-after-conversion','center-before-conversion']:
  vals=[[float(x) if mode=='direct' else float(x)-float(origin) if mode=='center-after-conversion' else float(x-origin) for x in g] for g in groups.values()]
  cases.append(dict(id=name+'-'+mode,op='anova',groups_bits=[[bits(x) for x in g] for g in vals]))
(p/'smls-inputs.json').write_text(json.dumps(cases));(p/'smls-details.json').write_text(json.dumps(details,indent=2))
raw=subprocess.check_output([str(p/'public/probe'),str(p/'smls-inputs.json')],text=True);(p/'smls-results.jsonl').write_text(raw);print(raw)
