import Foundation
struct Fixture:Decodable {let id:String;let a:[Double];let b:[Double];let a_bits:[String];let b_bits:[String]}
let cases=try JSONDecoder().decode([Fixture].self,from:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1])))
var mismatches=0,total=0
for c in cases {for (xs,bs) in [(c.a,c.a_bits),(c.b,c.b_bits)] {for (x,b) in zip(xs,bs) {total+=1;if x.bitPattern != UInt64(b)! {mismatches+=1}}}}
print("JSONDecoder values checked: \(total); bit mismatches: \(mismatches)")
