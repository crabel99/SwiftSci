import Foundation
import Accelerate
let candidates: [(String,([Double],[Double])->Double)] = [
    ("vdsp", {vDSP.dot($0,$1)}),
    ("blas", {cblas_ddot(Int32($0.count),$0,1,$1,1)}),
    ("scalar-fma",scalarFMA),("scalar-dot2",scalarDot2),("simd-fma16",simdFMA16),
    ("simd-dot4",simdDot4),("simd-dot16",simdDot16),("simd-dot32",simdDot32),("simd-dot3x16",simdDot3x16)]
func emit(_ row:[String:Any]) {print(String(data:try! JSONSerialization.data(withJSONObject:row,options:[.sortedKeys]),encoding:.utf8)!)}

var state:UInt64=284019
func next()->Int64 {state=state &* 6364136223846793005 &+ 1442695040888963407;return Int64(state >> 47)}
var sink=0.0
for n in [32,128,384,768,1536,4096,65536,1048576,8388608] {
 for family in ["mixed","positive","product-cancellation"] {
  var a=[Double](),b=[Double]();a.reserveCapacity(n);b.reserveCapacity(n)
  var exactNumerator:Int64=0
  let denominator=4294967296.0
  for i in 0..<n {
   if family == "product-cancellation" {
    let e=0x1p-27
    a.append(i%2==0 ? 1+e : -1);b.append(i%2==0 ? 1-e : 1)
   } else {
    let x=next()-(family == "mixed" ? 65536 : 0),y=next()-(family == "mixed" ? 65536 : 0)
    a.append(Double(x)/65536);b.append(Double(y)/65536);exactNumerator+=x*y
   }
  }
  let reference=family == "product-cancellation" ? -Double(n/2)*0x1p-54 : Double(exactNumerator)/denominator
  let batch=max(1,262144/n)
  var times=Array(repeating:[Double](),count:candidates.count)
  for round in 0..<17 {
   for offset in 0..<candidates.count {
    let i=(offset+round)%candidates.count
    let t=DispatchTime.now().uptimeNanoseconds
    for _ in 0..<batch {sink+=candidates[i].1(a,b)}
    let elapsed=Double(DispatchTime.now().uptimeNanoseconds-t)/Double(batch)
    if round>3 {times[i].append(elapsed)}
   }
  }
  for (i,c) in candidates.enumerated() {
   let r=c.1(a,b)
   emit(["family":family,"n":n,"candidate":c.0,"value":String(r),"reference":String(reference),"reference_bits":String(reference.bitPattern),"value_bits":String(r.bitPattern),"absolute_error":abs(r-reference),"median_ns":times[i].sorted()[6],"ns":times[i]])
  }
 }
}
fputs("checksum=\(sink)\n",stderr)
