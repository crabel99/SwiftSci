import Foundation
let cases=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))) as! [[String:Any]]
for c in cases {for key in ["a","b"] {let values=c[key] as! [Double]; print(String(data:try JSONSerialization.data(withJSONObject:["case":c["id"]!,"key":key,"bits":values.map {String($0.bitPattern)}]),encoding:.utf8)!)}}
