"""Check the recorded qualification; unresolved arithmetic failures stay explicit."""
import json,math
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(x) for x in (p/'results.jsonl').read_text().splitlines()]
refs=json.loads((p/'references.json').read_text())
assert len(refs)==678 and len(rows)==678*9
core={k for k,v in refs.items() if v['family'] not in ['underflow','intermediate-overflow','result-overflow']}
assert len(core)==667
strong={r['case']:r for r in rows if r['candidate']=='simd-dot3x16'}
assert all(float(strong[k]['value'])==float(refs[k]['rounded']) for k in core)
s=json.loads((p/'summary.json').read_text())['summary']
assert s['vdsp']['cancellation']['within_relative_1e12']==0
assert s['simd-dot4']['cancellation']['within_relative_1e12']==240
assert s['simd-dot3x16']['underflow']['within_relative_1e12']==4
assert s['simd-dot3x16']['intermediate-overflow']['within_relative_1e12']==0
assert s['simd-dot3x16']['result-overflow']['within_relative_1e12']==0
public={r['case']:r for r in map(json.loads,(p/'public/results.jsonl').read_text().splitlines())}
assert all(public[r['case']]['bits']==r['bits'] for r in rows if r['candidate']=='vdsp')
assert 'bit mismatches: 0' in (p/'decoder-check.txt').read_text()
for run in ['results.jsonl','single-thread-results.jsonl']:
 timed=list(map(json.loads,(p/'bench'/run).read_text().splitlines()))
 assert len(timed)==27*9
 assert all(len(r['ns'])==13 and r['median_ns']>0 for r in timed)
 assert all(r['absolute_error']==0 for r in timed if r['candidate'] in ['simd-dot4','simd-dot16','simd-dot32','simd-dot3x16'])
records={r['case']:r for r in map(json.loads,(p/'smls-results.jsonl').read_text().splitlines())}
for name,expected in [('SmLs07',21),('SmLs08',201),('SmLs09',2001)]:
 direct=float(records[name+'-direct']['value']);after=float(records[name+'-center-after-conversion']['value']);before=float(records[name+'-center-before-conversion']['value'])
 assert direct==after and not math.isclose(direct,expected,rel_tol=1e-9,abs_tol=1e-10)
 assert math.isclose(before,expected,rel_tol=1e-9,abs_tol=1e-10)
earlier=json.loads((p/'earlier-summary.json').read_text())
assert earlier['variance']==dict(cases=131,passed=131)
assert earlier['anova']==dict(cases=11,passed=11)
exceptional={r['case']:r for r in map(json.loads,(p/'exceptional-results.jsonl').read_text().splitlines())}
assert all('error' in exceptional[n] for n in ['empty','empty-left','mismatch'])
assert math.isinf(float(exceptional['positive-infinity']['value']))
assert all(math.isnan(float(exceptional[n]['value'])) for n in ['nan','opposite-infinities','zero-times-infinity'])
print('PASS: qualification records consistent; 667 core cases match the rounded exact result for the three-component candidate.')
print('UNRESOLVED: 7 range cases fail the relative/absolute criterion for that candidate. Production dot still loses cancellation residuals.')
