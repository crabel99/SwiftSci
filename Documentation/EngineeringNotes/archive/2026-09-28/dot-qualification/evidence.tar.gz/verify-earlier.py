import json,math
from fractions import Fraction as F
from pathlib import Path
p=Path(__file__).parent
cases={c['id']:c for c in json.loads((p/'earlier-inputs.json').read_text())}
summary={}
for line in (p/'earlier-results.jsonl').read_text().splitlines():
 r=json.loads(line);c=cases[r['case']];op=c['op']
 if op=='anova':
  gs=[[F(x) for x in g] for g in c['groups']];n=sum(map(len,gs));means=[sum(g)/len(g) for g in gs];m=sum(map(sum,gs))/n
  ref=sum(len(g)*(mu-m)**2 for g,mu in zip(gs,means))/(len(gs)-1)/(sum(sum((x-mu)**2 for x in g) for g,mu in zip(gs,means))/(n-len(gs)))
 elif op=='variance':
  a=list(map(F,c['a']));m=sum(a)/len(a);ref=sum((x-m)**2 for x in a)/(len(a)-1)
 else:ref=sum(F(x)*F(y) for x,y in zip(c['a'],c['b']))
 v=float(r['value']);ok=math.isfinite(v) and abs(F(v)-ref)<=abs(ref)*F(1,10**12)+F(math.ulp(0.0))*8
 s=summary.setdefault(op,dict(cases=0,passed=0));s['cases']+=1;s['passed']+=int(ok)
(p/'earlier-summary.json').write_text(json.dumps(summary,indent=2));print(summary)
