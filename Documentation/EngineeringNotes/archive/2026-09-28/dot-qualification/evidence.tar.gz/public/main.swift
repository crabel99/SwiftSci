import Foundation
func values(_ x:[String])->[Double] {x.map {Double(bitPattern:UInt64($0)!)}}
let cases=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))) as! [[String:Any]]
for c in cases {
 do {
  let op=c["op"] as? String ?? "dot"
  let result=op == "anova" ? try Stats.oneWayANOVA(groups:(c["groups_bits"] as! [[String]]).map(values)).fStatistic : op == "variance" ? try Stats.variance(values(c["a_bits"] as! [String])) : try Stats.dotProduct(values(c["a_bits"] as! [String]),values(c["b_bits"] as! [String]))
  print(String(data:try JSONSerialization.data(withJSONObject:["case":c["id"]!,"value":String(result),"bits":String(result.bitPattern)]),encoding:.utf8)!)
 } catch {print(String(data:try JSONSerialization.data(withJSONObject:["case":c["id"]!,"error":String(describing:error)]),encoding:.utf8)!)}
}
