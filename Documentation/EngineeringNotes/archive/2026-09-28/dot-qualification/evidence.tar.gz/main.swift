import Foundation
import Accelerate
let candidates: [(String,([Double],[Double])->Double)] = [
    ("vdsp", {vDSP.dot($0,$1)}),
    ("blas", {cblas_ddot(Int32($0.count),$0,1,$1,1)}),
    ("scalar-fma",scalarFMA),("scalar-dot2",scalarDot2),("simd-fma16",simdFMA16),
    ("simd-dot4",simdDot4),("simd-dot16",simdDot16),("simd-dot32",simdDot32),("simd-dot3x16",simdDot3x16)]
func emit(_ row:[String:Any]) {print(String(data:try! JSONSerialization.data(withJSONObject:row,options:[.sortedKeys]),encoding:.utf8)!)}
func values(_ c:[String:Any], _ key:String) -> [Double] { (c[key+"_bits"] as! [String]).map { Double(bitPattern:UInt64($0)!) } }
let cases=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))) as! [[String:Any]]
if CommandLine.arguments.count>2 && CommandLine.arguments[2]=="--bench" {
    var sink=0.0
    for c in cases {
        let a=values(c,"a"),b=values(c,"b")
        let batch=max(1,65536/a.count)
        var times=Array(repeating:[Double](),count:candidates.count)
        for round in 0..<13 {
            for offset in 0..<candidates.count {
                let i=(offset+round)%candidates.count
                let t=DispatchTime.now().uptimeNanoseconds
                for _ in 0..<batch {sink+=candidates[i].1(a,b)}
                let elapsed=Double(DispatchTime.now().uptimeNanoseconds-t)/Double(batch)
                if round>1 {times[i].append(elapsed)}
            }
        }
        for (i,candidate) in candidates.enumerated() {
            let r=candidate.1(a,b)
            emit(["case":c["id"]!,"n":a.count,"candidate":candidate.0,"value":r.isFinite ? String(r):String(describing:r),"median_ns":times[i].sorted()[5],"ns":times[i]])
        }
    }
    fputs("checksum=\(sink)\n",stderr)
} else {
    for c in cases {
        let a=values(c,"a"),b=values(c,"b")
        for (name,run) in candidates {
            let r=run(a,b)
            emit(["case":c["id"]!,"candidate":name,"value":r.isFinite ? String(r):String(describing:r),"bits":String(r.bitPattern)])
        }
    }
}
