import Accelerate

struct ScalarDot2 {
    var high = 0.0
    var low = 0.0
    mutating func add(_ product: Double, residual: Double = 0) {
        let next = high + product
        let recovered = next - high
        let error = (high - (next - recovered)) + (product - recovered)
        low += error + residual
        high = next
    }
    mutating func product(_ x: Double, _ y: Double) {
        let p = x * y
        add(p,residual: (-p).addingProduct(x,y))
    }
    var value: Double { high + low }
}
struct VectorDot2 {
    var high = SIMD4<Double>(repeating: 0)
    var low = SIMD4<Double>(repeating: 0)
    @inline(__always) mutating func product(_ x: SIMD4<Double>, _ y: SIMD4<Double>) {
        let p = x * y
        let r = (-p).addingProduct(x,y)
        let next = high + p
        let recovered = next - high
        let error = (high - (next - recovered)) + (p - recovered)
        low += error + r
        high = next
    }
    @inline(__always) func merge(into total: inout ScalarDot2) {
        for lane in 0..<4 { total.add(high[lane]); total.add(low[lane]) }
    }
}
@inline(__always) func load4(_ a: UnsafeBufferPointer<Double>, _ i: Int) -> SIMD4<Double> {
    SIMD4(a[i],a[i+1],a[i+2],a[i+3])
}
@inline(never) func scalarFMA(_ a: [Double], _ b: [Double]) -> Double {
    var s=0.0; for i in a.indices { s=s.addingProduct(a[i],b[i]) };return s
}
@inline(never) func scalarDot2(_ a: [Double], _ b: [Double]) -> Double {
    var s=ScalarDot2();for i in a.indices { s.product(a[i],b[i]) };return s.value
}
@inline(never) func simdFMA16(_ a:[Double],_ b:[Double])->Double {
    a.withUnsafeBufferPointer { p in b.withUnsafeBufferPointer { q in
        var s0=SIMD4<Double>(repeating:0),s1=s0,s2=s0,s3=s0;var i=0
        while i+16<=p.count {
            s0=s0.addingProduct(load4(p,i),load4(q,i));s1=s1.addingProduct(load4(p,i+4),load4(q,i+4))
            s2=s2.addingProduct(load4(p,i+8),load4(q,i+8));s3=s3.addingProduct(load4(p,i+12),load4(q,i+12));i+=16
        }
        var s=ScalarDot2()
        for j in 0..<4 {s.add(s0[j]);s.add(s1[j]);s.add(s2[j]);s.add(s3[j])}
        while i<p.count {s.add(p[i]*q[i]);i+=1};return s.value
    }}
}

@inline(never) func simdDot4(_ a:[Double],_ b:[Double])->Double {
 a.withUnsafeBufferPointer { p in b.withUnsafeBufferPointer { q in
var s0=VectorDot2();var i=0
while i+4<=p.count {
s0.product(load4(p,i+0),load4(q,i+0))
i+=4
}
var s=ScalarDot2()
s0.merge(into:&s)
while i<p.count {s.product(p[i],q[i]);i+=1};return s.value
 }}
}

@inline(never) func simdDot16(_ a:[Double],_ b:[Double])->Double {
 a.withUnsafeBufferPointer { p in b.withUnsafeBufferPointer { q in
var s0=VectorDot2();var s1=VectorDot2();var s2=VectorDot2();var s3=VectorDot2();var i=0
while i+16<=p.count {
s0.product(load4(p,i+0),load4(q,i+0))
s1.product(load4(p,i+4),load4(q,i+4))
s2.product(load4(p,i+8),load4(q,i+8))
s3.product(load4(p,i+12),load4(q,i+12))
i+=16
}
var s=ScalarDot2()
s0.merge(into:&s)
s1.merge(into:&s)
s2.merge(into:&s)
s3.merge(into:&s)
while i<p.count {s.product(p[i],q[i]);i+=1};return s.value
 }}
}

@inline(never) func simdDot32(_ a:[Double],_ b:[Double])->Double {
 a.withUnsafeBufferPointer { p in b.withUnsafeBufferPointer { q in
var s0=VectorDot2();var s1=VectorDot2();var s2=VectorDot2();var s3=VectorDot2();var s4=VectorDot2();var s5=VectorDot2();var s6=VectorDot2();var s7=VectorDot2();var i=0
while i+32<=p.count {
s0.product(load4(p,i+0),load4(q,i+0))
s1.product(load4(p,i+4),load4(q,i+4))
s2.product(load4(p,i+8),load4(q,i+8))
s3.product(load4(p,i+12),load4(q,i+12))
s4.product(load4(p,i+16),load4(q,i+16))
s5.product(load4(p,i+20),load4(q,i+20))
s6.product(load4(p,i+24),load4(q,i+24))
s7.product(load4(p,i+28),load4(q,i+28))
i+=32
}
var s=ScalarDot2()
s0.merge(into:&s)
s1.merge(into:&s)
s2.merge(into:&s)
s3.merge(into:&s)
s4.merge(into:&s)
s5.merge(into:&s)
s6.merge(into:&s)
s7.merge(into:&s)
while i<p.count {s.product(p[i],q[i]);i+=1};return s.value
 }}
}

struct ScalarDot3 {
 var high=0.0, middle=0.0, low=0.0
 @inline(__always) mutating func add(_ x:Double) {
  let a=high+x;let b=a-high;let e=(high-(a-b))+(x-b);high=a
  let c=middle+e;let d=c-middle;low+=(middle-(c-d))+(e-d);middle=c
 }
 @inline(__always) mutating func product(_ x:Double,_ y:Double) {
  let p=x*y;add(p);add((-p).addingProduct(x,y))
 }
 var value:Double {
  let a=high+middle;let b=a-high;let e=(high-(a-b))+(middle-b)
  return a+(e+low)
 }
}
struct VectorDot3 {
 var high=SIMD4<Double>(repeating:0),middle=SIMD4<Double>(repeating:0),low=SIMD4<Double>(repeating:0)
 @inline(__always) mutating func add(_ x:SIMD4<Double>) {
  let a=high+x;let b=a-high;let e=(high-(a-b))+(x-b);high=a
  let c=middle+e;let d=c-middle;low+=(middle-(c-d))+(e-d);middle=c
 }
 @inline(__always) mutating func product(_ x:SIMD4<Double>,_ y:SIMD4<Double>) {
  let p=x*y;add(p);add((-p).addingProduct(x,y))
 }
 @inline(__always) func merge(into total:inout ScalarDot3) {
  for j in 0..<4 { total.add(high[j]);total.add(middle[j]);total.add(low[j]) }
 }
}
@inline(never) func simdDot3x16(_ a:[Double],_ b:[Double])->Double {
 a.withUnsafeBufferPointer { p in b.withUnsafeBufferPointer { q in
  var s0=VectorDot3(),s1=s0,s2=s0,s3=s0;var i=0
  while i+16<=p.count {
   s0.product(load4(p,i),load4(q,i));s1.product(load4(p,i+4),load4(q,i+4))
   s2.product(load4(p,i+8),load4(q,i+8));s3.product(load4(p,i+12),load4(q,i+12));i+=16
  }
  var s=ScalarDot3();s0.merge(into:&s);s1.merge(into:&s);s2.merge(into:&s);s3.merge(into:&s)
  while i<p.count {s.product(p[i],q[i]);i+=1};return s.value
 }}
}
