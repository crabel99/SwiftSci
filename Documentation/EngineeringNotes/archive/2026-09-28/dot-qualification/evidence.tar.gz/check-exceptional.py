import struct,json,subprocess,math
from pathlib import Path
p=Path(__file__).parent
def bits(x):return str(struct.unpack('Q',struct.pack('d',x))[0])
cases=[]
for name,a,b in [('empty',[],[]),('empty-left',[],[1.]),('mismatch',[1.],[1.,2.]),('nan',[math.nan,1.],[1.,2.]),('positive-infinity',[math.inf,1.],[1.,2.]),('opposite-infinities',[math.inf,-math.inf],[1.,1.]),('zero-times-infinity',[0.],[math.inf]),('negative-zero',[-0.],[1.])]:cases.append(dict(id=name,a_bits=list(map(bits,a)),b_bits=list(map(bits,b))))
(p/'exceptional-inputs.json').write_text(json.dumps(cases))
raw=subprocess.check_output([str(p/'public/probe'),str(p/'exceptional-inputs.json')],text=True);(p/'exceptional-results.jsonl').write_text(raw);print(raw)
rows=[json.loads(l) for l in (p/'bench/single-thread-results.jsonl').read_text().splitlines()]
for n in [32,384,1536,65536,1048576,8388608]:
 d={r['candidate']:r for r in rows if r['family']=='mixed' and r['n']==n}
 print(n,'ns',[(k,round(d[k]['median_ns'],2)) for k in ['vdsp','blas','simd-dot4','simd-dot3x16']])
