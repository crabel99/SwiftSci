	.build_version macos, 27, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
; %bb.0:
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4highSdvpfi ; -- Begin function $s7Kernels10ScalarDot2V4highSdvpfi
	.globl	_$s7Kernels10ScalarDot2V4highSdvpfi
	.p2align	2
_$s7Kernels10ScalarDot2V4highSdvpfi:    ; @"$s7Kernels10ScalarDot2V4highSdvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4highSdvg ; -- Begin function $s7Kernels10ScalarDot2V4highSdvg
	.globl	_$s7Kernels10ScalarDot2V4highSdvg
	.p2align	2
_$s7Kernels10ScalarDot2V4highSdvg:      ; @"$s7Kernels10ScalarDot2V4highSdvg"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4highSdvs ; -- Begin function $s7Kernels10ScalarDot2V4highSdvs
	.globl	_$s7Kernels10ScalarDot2V4highSdvs
	.p2align	2
_$s7Kernels10ScalarDot2V4highSdvs:      ; @"$s7Kernels10ScalarDot2V4highSdvs"
; %bb.0:
	str	d0, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4highSdvM ; -- Begin function $s7Kernels10ScalarDot2V4highSdvM
	.globl	_$s7Kernels10ScalarDot2V4highSdvM
	.p2align	2
_$s7Kernels10ScalarDot2V4highSdvM:      ; @"$s7Kernels10ScalarDot2V4highSdvM"
; %bb.0:
	mov	x1, x20
Lloh0:
	adrp	x0, _$s7Kernels10ScalarDot2V4highSdvM.resume.0@PAGE
Lloh1:
	add	x0, x0, _$s7Kernels10ScalarDot2V4highSdvM.resume.0@PAGEOFF
	ret
	.loh AdrpAdd	Lloh0, Lloh1
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot2V4highSdvM.resume.0
_$s7Kernels10ScalarDot2V4highSdvM.resume.0: ; @"$s7Kernels10ScalarDot2V4highSdvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V3lowSdvpfi ; -- Begin function $s7Kernels10ScalarDot2V3lowSdvpfi
	.globl	_$s7Kernels10ScalarDot2V3lowSdvpfi
	.p2align	2
_$s7Kernels10ScalarDot2V3lowSdvpfi:     ; @"$s7Kernels10ScalarDot2V3lowSdvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V3lowSdvg ; -- Begin function $s7Kernels10ScalarDot2V3lowSdvg
	.globl	_$s7Kernels10ScalarDot2V3lowSdvg
	.p2align	2
_$s7Kernels10ScalarDot2V3lowSdvg:       ; @"$s7Kernels10ScalarDot2V3lowSdvg"
; %bb.0:
	mov.16b	v0, v1
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V3lowSdvs ; -- Begin function $s7Kernels10ScalarDot2V3lowSdvs
	.globl	_$s7Kernels10ScalarDot2V3lowSdvs
	.p2align	2
_$s7Kernels10ScalarDot2V3lowSdvs:       ; @"$s7Kernels10ScalarDot2V3lowSdvs"
; %bb.0:
	str	d0, [x20, #8]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V3lowSdvM ; -- Begin function $s7Kernels10ScalarDot2V3lowSdvM
	.globl	_$s7Kernels10ScalarDot2V3lowSdvM
	.p2align	2
_$s7Kernels10ScalarDot2V3lowSdvM:       ; @"$s7Kernels10ScalarDot2V3lowSdvM"
; %bb.0:
Lloh2:
	adrp	x0, _$s7Kernels10ScalarDot2V3lowSdvM.resume.0@PAGE
Lloh3:
	add	x0, x0, _$s7Kernels10ScalarDot2V3lowSdvM.resume.0@PAGEOFF
	add	x1, x20, #8
	ret
	.loh AdrpAdd	Lloh2, Lloh3
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot2V3lowSdvM.resume.0
_$s7Kernels10ScalarDot2V3lowSdvM.resume.0: ; @"$s7Kernels10ScalarDot2V3lowSdvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V3add_8residualySd_SdtFfA0_ ; -- Begin function $s7Kernels10ScalarDot2V3add_8residualySd_SdtFfA0_
	.globl	_$s7Kernels10ScalarDot2V3add_8residualySd_SdtFfA0_
	.p2align	2
_$s7Kernels10ScalarDot2V3add_8residualySd_SdtFfA0_: ; @"$s7Kernels10ScalarDot2V3add_8residualySd_SdtFfA0_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V3add_8residualySd_SdtF ; -- Begin function $s7Kernels10ScalarDot2V3add_8residualySd_SdtF
	.globl	_$s7Kernels10ScalarDot2V3add_8residualySd_SdtF
	.p2align	2
_$s7Kernels10ScalarDot2V3add_8residualySd_SdtF: ; @"$s7Kernels10ScalarDot2V3add_8residualySd_SdtF"
; %bb.0:
	ldp	d2, d3, [x20]
	fadd	d4, d0, d2
	fsub	d5, d4, d2
	fsub	d6, d4, d5
	fsub	d2, d2, d6
	fsub	d0, d0, d5
	fadd	d0, d0, d2
	fadd	d0, d1, d0
	fadd	d0, d3, d0
	stp	d4, d0, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V7productyySd_SdtF ; -- Begin function $s7Kernels10ScalarDot2V7productyySd_SdtF
	.globl	_$s7Kernels10ScalarDot2V7productyySd_SdtF
	.p2align	2
_$s7Kernels10ScalarDot2V7productyySd_SdtF: ; @"$s7Kernels10ScalarDot2V7productyySd_SdtF"
; %bb.0:
	fmul	d2, d0, d1
	fnmsub	d0, d0, d1, d2
	ldp	d1, d3, [x20]
	fadd	d4, d2, d1
	fsub	d5, d4, d1
	fsub	d6, d4, d5
	fsub	d1, d1, d6
	fsub	d2, d2, d5
	fadd	d1, d2, d1
	fadd	d0, d0, d1
	fadd	d0, d3, d0
	stp	d4, d0, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V5valueSdvg ; -- Begin function $s7Kernels10ScalarDot2V5valueSdvg
	.globl	_$s7Kernels10ScalarDot2V5valueSdvg
	.p2align	2
_$s7Kernels10ScalarDot2V5valueSdvg:     ; @"$s7Kernels10ScalarDot2V5valueSdvg"
; %bb.0:
	fadd	d0, d0, d1
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2VACycfC ; -- Begin function $s7Kernels10ScalarDot2VACycfC
	.globl	_$s7Kernels10ScalarDot2VACycfC
	.p2align	2
_$s7Kernels10ScalarDot2VACycfC:         ; @"$s7Kernels10ScalarDot2VACycfC"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA_ ; -- Begin function $s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA_
	.globl	_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA_
	.p2align	2
_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA_: ; @"$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA0_ ; -- Begin function $s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA0_
	.globl	_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA0_
	.p2align	2
_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA0_: ; @"$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfcfA0_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfC ; -- Begin function $s7Kernels10ScalarDot2V4high3lowACSd_SdtcfC
	.globl	_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfC
	.p2align	2
_$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfC: ; @"$s7Kernels10ScalarDot2V4high3lowACSd_SdtcfC"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvpfi ; -- Begin function $s7Kernels10VectorDot2V4highs5SIMD4VySdGvpfi
	.globl	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvpfi
	.p2align	2
_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvpfi: ; @"$s7Kernels10VectorDot2V4highs5SIMD4VySdGvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvg ; -- Begin function $s7Kernels10VectorDot2V4highs5SIMD4VySdGvg
	.globl	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvg
	.p2align	2
_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvg: ; @"$s7Kernels10VectorDot2V4highs5SIMD4VySdGvg"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvs ; -- Begin function $s7Kernels10VectorDot2V4highs5SIMD4VySdGvs
	.globl	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvs
	.p2align	2
_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvs: ; @"$s7Kernels10VectorDot2V4highs5SIMD4VySdGvs"
; %bb.0:
	stp	q0, q1, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM ; -- Begin function $s7Kernels10VectorDot2V4highs5SIMD4VySdGvM
	.globl	_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM
	.p2align	2
_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM: ; @"$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM"
; %bb.0:
	mov	x1, x20
Lloh4:
	adrp	x0, _$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM.resume.0@PAGE
Lloh5:
	add	x0, x0, _$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM.resume.0@PAGEOFF
	ret
	.loh AdrpAdd	Lloh4, Lloh5
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot2V4highs5SIMD4VySdGvM.resume.0
_$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM.resume.0: ; @"$s7Kernels10VectorDot2V4highs5SIMD4VySdGvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvpfi ; -- Begin function $s7Kernels10VectorDot2V3lows5SIMD4VySdGvpfi
	.globl	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvpfi
	.p2align	2
_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvpfi: ; @"$s7Kernels10VectorDot2V3lows5SIMD4VySdGvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvg ; -- Begin function $s7Kernels10VectorDot2V3lows5SIMD4VySdGvg
	.globl	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvg
	.p2align	2
_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvg: ; @"$s7Kernels10VectorDot2V3lows5SIMD4VySdGvg"
; %bb.0:
	mov.16b	v1, v3
	mov.16b	v0, v2
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvs ; -- Begin function $s7Kernels10VectorDot2V3lows5SIMD4VySdGvs
	.globl	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvs
	.p2align	2
_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvs: ; @"$s7Kernels10VectorDot2V3lows5SIMD4VySdGvs"
; %bb.0:
	stp	q0, q1, [x20, #32]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM ; -- Begin function $s7Kernels10VectorDot2V3lows5SIMD4VySdGvM
	.globl	_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM
	.p2align	2
_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM: ; @"$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM"
; %bb.0:
Lloh6:
	adrp	x0, _$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM.resume.0@PAGE
Lloh7:
	add	x0, x0, _$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM.resume.0@PAGEOFF
	add	x1, x20, #32
	ret
	.loh AdrpAdd	Lloh6, Lloh7
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot2V3lows5SIMD4VySdGvM.resume.0
_$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM.resume.0: ; @"$s7Kernels10VectorDot2V3lows5SIMD4VySdGvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V7productyys5SIMD4VySdG_AGtF ; -- Begin function $s7Kernels10VectorDot2V7productyys5SIMD4VySdG_AGtF
	.globl	_$s7Kernels10VectorDot2V7productyys5SIMD4VySdG_AGtF
	.p2align	2
_$s7Kernels10VectorDot2V7productyys5SIMD4VySdG_AGtF: ; @"$s7Kernels10VectorDot2V7productyys5SIMD4VySdG_AGtF"
; %bb.0:
	ldp	q4, q5, [x20]
	ldp	q6, q7, [x20, #32]
	fmul.2d	v16, v1, v3
	fmul.2d	v17, v0, v2
	movi.2d	v18, #0000000000000000
	fsub.2d	v19, v18, v17
	fsub.2d	v18, v18, v16
	fmla.2d	v18, v3, v1
	fmla.2d	v19, v2, v0
	fadd.2d	v0, v16, v5
	fadd.2d	v1, v17, v4
	fsub.2d	v2, v1, v4
	fsub.2d	v3, v0, v5
	fsub.2d	v20, v0, v3
	fsub.2d	v21, v1, v2
	fsub.2d	v4, v4, v21
	fsub.2d	v5, v5, v20
	fsub.2d	v2, v17, v2
	fsub.2d	v3, v16, v3
	fadd.2d	v3, v3, v5
	fadd.2d	v2, v2, v4
	fadd.2d	v2, v19, v2
	fadd.2d	v3, v18, v3
	fadd.2d	v3, v7, v3
	fadd.2d	v2, v6, v2
	stp	q2, q3, [x20, #32]
	stp	q1, q0, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V5merge4intoyAA06ScalarC0Vz_tF ; -- Begin function $s7Kernels10VectorDot2V5merge4intoyAA06ScalarC0Vz_tF
	.globl	_$s7Kernels10VectorDot2V5merge4intoyAA06ScalarC0Vz_tF
	.p2align	2
_$s7Kernels10VectorDot2V5merge4intoyAA06ScalarC0Vz_tF: ; @"$s7Kernels10VectorDot2V5merge4intoyAA06ScalarC0Vz_tF"
; %bb.0:
	ldp	d5, d4, [x0]
	fadd	d6, d0, d5
	fsub	d7, d6, d5
	fsub	d16, d6, d7
	fsub	d5, d5, d16
	fsub	d7, d0, d7
	fadd	d5, d7, d5
	movi.2d	v7, #0000000000000000
	fadd	d5, d5, d7
	fadd	d4, d4, d5
	fadd	d5, d2, d6
	fsub	d16, d5, d6
	fsub	d17, d5, d16
	fsub	d6, d6, d17
	fsub	d16, d2, d16
	fadd	d6, d16, d6
	fadd	d6, d6, d7
	fadd	d4, d4, d6
	mov	d0, v0[1]
	fadd	d6, d0, d5
	fsub	d16, d6, d5
	fsub	d17, d6, d16
	fsub	d5, d5, d17
	fsub	d0, d0, d16
	fadd	d0, d0, d5
	fadd	d0, d0, d7
	fadd	d0, d4, d0
	mov	d2, v2[1]
	fadd	d4, d2, d6
	fsub	d5, d4, d6
	fsub	d16, d4, d5
	fsub	d6, d6, d16
	fsub	d2, d2, d5
	fadd	d2, d2, d6
	fadd	d2, d2, d7
	fadd	d0, d0, d2
	fadd	d2, d1, d4
	fsub	d5, d2, d4
	fsub	d6, d2, d5
	fsub	d4, d4, d6
	fsub	d5, d1, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d7
	fadd	d0, d0, d4
	fadd	d4, d3, d2
	fsub	d5, d4, d2
	fsub	d6, d4, d5
	fsub	d2, d2, d6
	fsub	d5, d3, d5
	fadd	d2, d5, d2
	fadd	d2, d2, d7
	fadd	d0, d0, d2
	mov	d1, v1[1]
	fadd	d2, d1, d4
	fsub	d5, d2, d4
	fsub	d6, d2, d5
	fsub	d4, d4, d6
	fsub	d1, d1, d5
	fadd	d1, d1, d4
	fadd	d1, d1, d7
	fadd	d0, d0, d1
	mov	d1, v3[1]
	fadd	d3, d1, d2
	fsub	d4, d3, d2
	fsub	d5, d3, d4
	fsub	d2, d2, d5
	fsub	d1, d1, d4
	fadd	d1, d1, d2
	fadd	d1, d1, d7
	fadd	d0, d0, d1
	str	d3, [x0]
	str	d0, [x0, #8]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2VACycfC ; -- Begin function $s7Kernels10VectorDot2VACycfC
	.globl	_$s7Kernels10VectorDot2VACycfC
	.p2align	2
_$s7Kernels10VectorDot2VACycfC:         ; @"$s7Kernels10VectorDot2VACycfC"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA_ ; -- Begin function $s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA_
	.globl	_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA_
	.p2align	2
_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA_: ; @"$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA0_ ; -- Begin function $s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA0_
	.globl	_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA0_
	.p2align	2
_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA0_: ; @"$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfcfA0_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfC ; -- Begin function $s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfC
	.globl	_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfC
	.p2align	2
_$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfC: ; @"$s7Kernels10VectorDot2V4high3lowACs5SIMD4VySdG_AHtcfC"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels5load4ys5SIMD4VySdGSRySdG_SitF ; -- Begin function $s7Kernels5load4ys5SIMD4VySdGSRySdG_SitF
	.globl	_$s7Kernels5load4ys5SIMD4VySdGSRySdG_SitF
	.p2align	2
_$s7Kernels5load4ys5SIMD4VySdGSRySdG_SitF: ; @"$s7Kernels5load4ys5SIMD4VySdGSRySdG_SitF"
; %bb.0:
	mov	x8, #9223372036854775804        ; =0x7ffffffffffffffc
	cmp	x2, x8
	b.gt	LBB35_2
; %bb.1:
	add	x8, x0, x2, lsl #3
	ldp	q0, q1, [x8]
	ret
LBB35_2:
	brk	#0x1
                                        ; -- End function
	.private_extern	_$s7Kernels9scalarFMAySdSaySdG_ACtF ; -- Begin function $s7Kernels9scalarFMAySdSaySdG_ACtF
	.globl	_$s7Kernels9scalarFMAySdSaySdG_ACtF
	.p2align	2
_$s7Kernels9scalarFMAySdSaySdG_ACtF:    ; @"$s7Kernels9scalarFMAySdSaySdG_ACtF"
; %bb.0:
	ldr	x8, [x0, #16]
	cbz	x8, LBB36_5
; %bb.1:
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hi	LBB36_6
; %bb.2:
	add	x9, x0, #32
	add	x10, x1, #32
	movi.2d	v0, #0000000000000000
LBB36_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	d1, [x9], #8
	ldr	d2, [x10], #8
	fmadd	d0, d1, d2, d0
	subs	x8, x8, #1
	b.ne	LBB36_3
; %bb.4:
	ret
LBB36_5:
	movi.2d	v0, #0000000000000000
	ret
LBB36_6:
	brk	#0x1
                                        ; -- End function
	.private_extern	_$s7Kernels10scalarDot2ySdSaySdG_ACtF ; -- Begin function $s7Kernels10scalarDot2ySdSaySdG_ACtF
	.globl	_$s7Kernels10scalarDot2ySdSaySdG_ACtF
	.p2align	2
_$s7Kernels10scalarDot2ySdSaySdG_ACtF:  ; @"$s7Kernels10scalarDot2ySdSaySdG_ACtF"
; %bb.0:
	ldr	x8, [x0, #16]
	cbz	x8, LBB37_5
; %bb.1:
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hi	LBB37_6
; %bb.2:
	add	x9, x0, #32
	add	x10, x1, #32
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
LBB37_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	d2, [x9], #8
	ldr	d3, [x10], #8
	mov.16b	v4, v1
	fmul	d5, d2, d3
	fnmsub	d2, d2, d3, d5
	fadd	d1, d1, d5
	fsub	d3, d1, d4
	fsub	d6, d1, d3
	fsub	d4, d4, d6
	fsub	d3, d5, d3
	fadd	d3, d3, d4
	fadd	d2, d2, d3
	fadd	d0, d0, d2
	subs	x8, x8, #1
	b.ne	LBB37_3
; %bb.4:
	fadd	d0, d0, d1
	ret
LBB37_5:
	movi.2d	v0, #0000000000000000
	ret
LBB37_6:
	brk	#0x1
                                        ; -- End function
	.private_extern	_$s7Kernels9simdFMA16ySdSaySdG_ACtF ; -- Begin function $s7Kernels9simdFMA16ySdSaySdG_ACtF
	.globl	_$s7Kernels9simdFMA16ySdSaySdG_ACtF
	.p2align	2
_$s7Kernels9simdFMA16ySdSaySdG_ACtF:    ; @"$s7Kernels9simdFMA16ySdSaySdG_ACtF"
; %bb.0:
	ldr	x8, [x0, #16]
	cmp	x8, #16
	b.lo	LBB38_5
; %bb.1:
	mov	x9, #0                          ; =0x0
	movi.2d	v7, #0000000000000000
	movi.2d	v3, #0000000000000000
	add	x10, x0, #32
	add	x11, x1, #32
	mov	w12, #32                        ; =0x20
	mov	w13, #16                        ; =0x10
	movi.2d	v16, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v0, #0000000000000000
LBB38_2:                                ; =>This Inner Loop Header: Depth=1
	lsl	x14, x9, #3
	mov	x9, x13
	add	x13, x14, #64
	add	x15, x10, x13
	add	x13, x11, x13
	ldp	q4, q17, [x15]
	ldp	q18, q19, [x13]
	fmla.2d	v1, v19, v17
	fmla.2d	v6, v18, v4
	add	x13, x14, #32
	add	x15, x10, x13
	add	x13, x11, x13
	ldp	q4, q17, [x15]
	ldp	q18, q19, [x13]
	fmla.2d	v2, v19, v17
	fmla.2d	v16, v18, v4
	add	x13, x10, x14
	add	x15, x11, x14
	ldp	q4, q17, [x13]
	ldp	q18, q19, [x15]
	fmla.2d	v3, v19, v17
	fmla.2d	v7, v18, v4
	add	x13, x14, #96
	add	x14, x10, x13
	add	x13, x11, x13
	ldp	q4, q17, [x14]
	ldp	q18, q19, [x13]
	fmla.2d	v0, v19, v17
	fmla.2d	v5, v18, v4
	cmp	x8, x12
	b.lt	LBB38_6
; %bb.3:                                ;   in Loop: Header=BB38_2 Depth=1
	mov	x13, x12
	adds	x12, x12, #16
	b.vc	LBB38_2
; %bb.4:
	brk	#0x1
LBB38_5:
	mov	x9, #0                          ; =0x0
	movi.2d	v5, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v3, #0000000000000000
LBB38_6:
	movi.2d	v4, #0000000000000000
	fadd	d17, d7, d4
	fsub	d18, d17, d17
	fsub	d19, d7, d17
	fadd	d18, d18, d19
	fadd	d19, d16, d17
	fsub	d20, d19, d17
	fsub	d21, d20, d19
	fadd	d17, d17, d21
	fsub	d20, d16, d20
	fadd	d17, d20, d17
	fadd	d17, d18, d17
	fadd	d18, d6, d19
	fsub	d20, d18, d19
	fsub	d21, d20, d18
	fadd	d19, d19, d21
	fsub	d20, d6, d20
	fadd	d19, d20, d19
	fadd	d17, d17, d19
	fadd	d19, d5, d18
	fsub	d20, d19, d18
	fsub	d21, d20, d19
	fadd	d18, d18, d21
	fsub	d20, d5, d20
	fadd	d18, d20, d18
	fadd	d17, d17, d18
	mov	d7, v7[1]
	fadd	d18, d7, d19
	fsub	d20, d18, d19
	fsub	d21, d20, d18
	fadd	d19, d19, d21
	fsub	d7, d7, d20
	fadd	d7, d7, d19
	fadd	d7, d17, d7
	mov	d16, v16[1]
	fadd	d17, d16, d18
	fsub	d19, d17, d18
	fsub	d20, d19, d17
	fadd	d18, d18, d20
	fsub	d16, d16, d19
	fadd	d16, d16, d18
	fadd	d16, d16, d4
	fadd	d7, d7, d16
	mov	d6, v6[1]
	fadd	d16, d6, d17
	fsub	d18, d16, d17
	fsub	d19, d18, d16
	fadd	d17, d17, d19
	fsub	d6, d6, d18
	fadd	d6, d6, d17
	fadd	d6, d6, d4
	fadd	d6, d7, d6
	mov	d5, v5[1]
	fadd	d7, d5, d16
	fsub	d17, d7, d16
	fsub	d18, d7, d17
	fsub	d16, d16, d18
	fsub	d5, d5, d17
	fadd	d5, d5, d16
	fadd	d5, d5, d4
	fadd	d5, d6, d5
	fadd	d6, d3, d7
	fsub	d16, d6, d7
	fsub	d17, d6, d16
	fsub	d7, d7, d17
	fsub	d16, d3, d16
	fadd	d7, d16, d7
	fadd	d7, d7, d4
	fadd	d5, d5, d7
	fadd	d7, d2, d6
	fsub	d16, d7, d6
	fsub	d17, d7, d16
	fsub	d6, d6, d17
	fsub	d16, d2, d16
	fadd	d6, d16, d6
	fadd	d6, d6, d4
	fadd	d5, d5, d6
	fadd	d6, d1, d7
	fsub	d16, d6, d7
	fsub	d17, d6, d16
	fsub	d7, d7, d17
	fsub	d16, d1, d16
	fadd	d7, d16, d7
	fadd	d7, d7, d4
	fadd	d5, d5, d7
	fadd	d7, d0, d6
	fsub	d16, d7, d6
	fsub	d17, d7, d16
	fsub	d6, d6, d17
	fsub	d16, d0, d16
	fadd	d6, d16, d6
	fadd	d6, d6, d4
	fadd	d5, d5, d6
	mov	d3, v3[1]
	fadd	d6, d3, d7
	fsub	d16, d6, d7
	fsub	d17, d6, d16
	fsub	d7, d7, d17
	fsub	d3, d3, d16
	fadd	d3, d3, d7
	fadd	d3, d3, d4
	fadd	d3, d5, d3
	mov	d2, v2[1]
	fadd	d5, d2, d6
	fsub	d7, d5, d6
	fsub	d16, d5, d7
	fsub	d6, d6, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d6
	fadd	d2, d2, d4
	fadd	d2, d3, d2
	mov	d1, v1[1]
	fadd	d3, d1, d5
	fsub	d6, d3, d5
	fsub	d7, d3, d6
	fsub	d5, d5, d7
	fsub	d1, d1, d6
	fadd	d1, d1, d5
	fadd	d1, d1, d4
	fadd	d2, d2, d1
	mov	d0, v0[1]
	fadd	d1, d0, d3
	fsub	d5, d1, d3
	fsub	d6, d1, d5
	fsub	d3, d3, d6
	fsub	d0, d0, d5
	fadd	d0, d0, d3
	fadd	d0, d0, d4
	fadd	d0, d2, d0
	subs	x8, x8, x9
	b.le	LBB38_10
; %bb.7:
	lsl	x9, x9, #3
	add	x10, x9, #32
	add	x9, x1, x10
	add	x10, x0, x10
LBB38_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	d2, [x10], #8
	ldr	d3, [x9], #8
	fmul	d3, d2, d3
	fadd	d2, d1, d3
	fsub	d5, d2, d1
	fsub	d6, d2, d5
	fsub	d1, d1, d6
	fsub	d3, d3, d5
	fadd	d1, d3, d1
	fadd	d1, d1, d4
	fadd	d0, d0, d1
	mov.16b	v1, v2
	subs	x8, x8, #1
	b.ne	LBB38_8
; %bb.9:
	fadd	d0, d0, d2
	ret
LBB38_10:
	mov.16b	v2, v1
	fadd	d0, d0, d2
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels8simdDot4ySdSaySdG_ACtF ; -- Begin function $s7Kernels8simdDot4ySdSaySdG_ACtF
	.globl	_$s7Kernels8simdDot4ySdSaySdG_ACtF
	.p2align	2
_$s7Kernels8simdDot4ySdSaySdG_ACtF:     ; @"$s7Kernels8simdDot4ySdSaySdG_ACtF"
; %bb.0:
	ldr	x8, [x0, #16]
	cmp	x8, #4
	b.lo	LBB39_5
; %bb.1:
	mov	x9, #0                          ; =0x0
	add	x10, x0, #32
	add	x11, x1, #32
	movi.2d	v4, #0000000000000000
	mov	w12, #8                         ; =0x8
	movi.2d	v3, #0000000000000000
	mov	w13, #4                         ; =0x4
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
LBB39_2:                                ; =>This Inner Loop Header: Depth=1
	mov.16b	v5, v1
	mov.16b	v6, v3
	lsl	x14, x9, #3
	mov	x9, x13
	add	x13, x10, x14
	add	x14, x11, x14
	ldp	q16, q7, [x13]
	ldp	q18, q17, [x14]
	fmul.2d	v19, v16, v18
	fmul.2d	v20, v7, v17
	fadd.2d	v1, v1, v20
	fadd.2d	v3, v3, v19
	fsub.2d	v21, v3, v6
	fsub.2d	v22, v1, v5
	fsub.2d	v23, v1, v22
	fsub.2d	v24, v3, v21
	fsub.2d	v6, v6, v24
	fsub.2d	v5, v5, v23
	fsub.2d	v21, v19, v21
	fsub.2d	v22, v20, v22
	fadd.2d	v5, v22, v5
	fadd.2d	v6, v21, v6
	fsub.2d	v19, v4, v19
	fsub.2d	v20, v4, v20
	fmla.2d	v20, v17, v7
	fmla.2d	v19, v18, v16
	fadd.2d	v6, v19, v6
	fadd.2d	v5, v20, v5
	fadd.2d	v0, v0, v5
	fadd.2d	v2, v2, v6
	cmp	x8, x12
	b.lt	LBB39_6
; %bb.3:                                ;   in Loop: Header=BB39_2 Depth=1
	mov	x13, x12
	adds	x12, x12, #4
	b.vc	LBB39_2
; %bb.4:
	brk	#0x1
LBB39_5:
	mov	x9, #0                          ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
LBB39_6:
	movi.2d	v4, #0000000000000000
	fadd	d5, d3, d4
	fsub	d6, d5, d5
	fsub	d7, d3, d5
	fadd	d6, d6, d7
	fadd	d7, d2, d5
	fsub	d16, d7, d5
	fsub	d17, d16, d7
	fadd	d5, d5, d17
	fsub	d16, d2, d16
	fadd	d5, d16, d5
	fadd	d5, d6, d5
	mov	d3, v3[1]
	fadd	d6, d3, d7
	fsub	d16, d6, d7
	fsub	d17, d16, d6
	fadd	d7, d7, d17
	fsub	d3, d3, d16
	fadd	d3, d3, d7
	fadd	d3, d5, d3
	mov	d2, v2[1]
	fadd	d5, d2, d6
	fsub	d7, d5, d6
	fsub	d16, d7, d5
	fadd	d6, d6, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d6
	fadd	d2, d3, d2
	fadd	d3, d1, d5
	fsub	d6, d3, d5
	fsub	d7, d6, d3
	fadd	d5, d5, d7
	fsub	d6, d1, d6
	fadd	d5, d6, d5
	fadd	d2, d2, d5
	fadd	d5, d0, d3
	fsub	d6, d5, d3
	fsub	d7, d6, d5
	fadd	d3, d3, d7
	fsub	d6, d0, d6
	fadd	d3, d6, d3
	fadd	d3, d3, d4
	fadd	d2, d2, d3
	mov	d1, v1[1]
	fadd	d3, d1, d5
	fsub	d6, d3, d5
	fsub	d7, d6, d3
	fadd	d5, d5, d7
	fsub	d1, d1, d6
	fadd	d1, d1, d5
	fadd	d1, d1, d4
	fadd	d2, d2, d1
	mov	d0, v0[1]
	fadd	d1, d0, d3
	fsub	d5, d1, d3
	fsub	d6, d1, d5
	fsub	d3, d3, d6
	fsub	d0, d0, d5
	fadd	d0, d0, d3
	fadd	d0, d0, d4
	fadd	d0, d2, d0
	subs	x8, x8, x9
	b.le	LBB39_10
; %bb.7:
	lsl	x9, x9, #3
	add	x10, x9, #32
	add	x9, x1, x10
	add	x10, x0, x10
LBB39_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	d3, [x10], #8
	ldr	d4, [x9], #8
	fmul	d5, d3, d4
	fadd	d2, d1, d5
	fsub	d6, d2, d1
	fsub	d7, d2, d6
	fsub	d1, d1, d7
	fsub	d6, d5, d6
	fadd	d1, d6, d1
	fnmsub	d3, d3, d4, d5
	fadd	d1, d3, d1
	fadd	d0, d0, d1
	mov.16b	v1, v2
	subs	x8, x8, #1
	b.ne	LBB39_8
; %bb.9:
	fadd	d0, d0, d2
	ret
LBB39_10:
	mov.16b	v2, v1
	fadd	d0, d0, d2
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels9simdDot16ySdSaySdG_ACtF ; -- Begin function $s7Kernels9simdDot16ySdSaySdG_ACtF
	.globl	_$s7Kernels9simdDot16ySdSaySdG_ACtF
	.p2align	2
_$s7Kernels9simdDot16ySdSaySdG_ACtF:    ; @"$s7Kernels9simdDot16ySdSaySdG_ACtF"
; %bb.0:
	stp	d13, d12, [sp, #-48]!           ; 16-byte Folded Spill
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	ldr	x8, [x0, #16]
	cmp	x8, #16
	b.lo	LBB40_5
; %bb.1:
	mov	x9, #0                          ; =0x0
	movi.2d	v20, #0000000000000000
	movi.2d	v24, #0000000000000000
	add	x10, x0, #32
	movi.2d	v23, #0000000000000000
	add	x11, x1, #32
	movi.2d	v22, #0000000000000000
	mov	w12, #32                        ; =0x20
	movi.2d	v19, #0000000000000000
	mov	w14, #16                        ; =0x10
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
LBB40_2:                                ; =>This Inner Loop Header: Depth=1
	mov.16b	v25, v5
	mov.16b	v26, v16
	mov.16b	v28, v3
	mov.16b	v29, v6
	mov.16b	v27, v18
	mov.16b	v30, v21
	mov.16b	v5, v23
	mov.16b	v16, v24
	lsl	x13, x9, #3
	mov	x9, x14
	add	x14, x13, #64
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q18, q21, [x15]
	ldp	q23, q24, [x14]
	fmul.2d	v31, v21, v24
	fmul.2d	v8, v18, v23
	fadd.2d	v6, v6, v8
	fadd.2d	v3, v3, v31
	fsub.2d	v9, v20, v8
	fsub.2d	v10, v20, v31
	fmla.2d	v10, v24, v21
	fmla.2d	v9, v23, v18
	fsub.2d	v18, v3, v28
	fsub.2d	v21, v6, v29
	fsub.2d	v23, v8, v21
	fsub.2d	v24, v31, v18
	fsub.2d	v18, v3, v18
	fsub.2d	v21, v6, v21
	fsub.2d	v21, v29, v21
	fsub.2d	v18, v28, v18
	fadd.2d	v18, v24, v18
	fadd.2d	v21, v23, v21
	fadd.2d	v21, v9, v21
	fadd.2d	v18, v10, v18
	fadd.2d	v2, v2, v18
	fadd.2d	v4, v4, v21
	add	x14, x13, #32
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q23, q24, [x15]
	ldp	q28, q29, [x14]
	fmul.2d	v31, v24, v29
	fmul.2d	v8, v23, v28
	fadd.2d	v21, v30, v8
	fadd.2d	v18, v27, v31
	fsub.2d	v9, v20, v8
	fsub.2d	v10, v20, v31
	fmla.2d	v10, v29, v24
	fmla.2d	v9, v28, v23
	fsub.2d	v23, v18, v27
	fsub.2d	v24, v21, v30
	fsub.2d	v28, v8, v24
	fsub.2d	v29, v31, v23
	fsub.2d	v23, v18, v23
	fsub.2d	v24, v21, v24
	fsub.2d	v24, v30, v24
	fsub.2d	v23, v27, v23
	fadd.2d	v23, v29, v23
	fadd.2d	v24, v28, v24
	fadd.2d	v24, v9, v24
	fadd.2d	v23, v10, v23
	fadd.2d	v7, v7, v23
	fadd.2d	v17, v17, v24
	add	x14, x10, x13
	add	x15, x11, x13
	ldp	q27, q28, [x14]
	ldp	q29, q30, [x15]
	fmul.2d	v31, v28, v30
	fmul.2d	v8, v27, v29
	fadd.2d	v24, v16, v8
	fadd.2d	v23, v5, v31
	fsub.2d	v9, v20, v8
	fsub.2d	v10, v20, v31
	fmla.2d	v10, v30, v28
	fmla.2d	v9, v29, v27
	fsub.2d	v27, v23, v5
	fsub.2d	v28, v24, v16
	fsub.2d	v29, v8, v28
	fsub.2d	v30, v31, v27
	fsub.2d	v27, v23, v27
	fsub.2d	v28, v24, v28
	fsub.2d	v16, v16, v28
	fsub.2d	v5, v5, v27
	fadd.2d	v5, v30, v5
	fadd.2d	v16, v29, v16
	fadd.2d	v16, v9, v16
	fadd.2d	v5, v10, v5
	fadd.2d	v19, v19, v5
	fadd.2d	v22, v22, v16
	add	x13, x13, #96
	add	x14, x10, x13
	add	x13, x11, x13
	ldp	q28, q27, [x14]
	ldp	q30, q29, [x13]
	fmul.2d	v31, v28, v30
	fmul.2d	v8, v27, v29
	fadd.2d	v5, v25, v8
	fadd.2d	v16, v26, v31
	fsub.2d	v9, v16, v26
	fsub.2d	v10, v5, v25
	fsub.2d	v11, v5, v10
	fsub.2d	v12, v16, v9
	fsub.2d	v26, v26, v12
	fsub.2d	v25, v25, v11
	fsub.2d	v9, v31, v9
	fsub.2d	v10, v8, v10
	fadd.2d	v25, v10, v25
	fadd.2d	v26, v9, v26
	fsub.2d	v31, v20, v31
	fsub.2d	v8, v20, v8
	fmla.2d	v8, v29, v27
	fmla.2d	v31, v30, v28
	fadd.2d	v26, v31, v26
	fadd.2d	v25, v8, v25
	fadd.2d	v0, v0, v25
	fadd.2d	v1, v1, v26
	cmp	x8, x12
	b.lt	LBB40_6
; %bb.3:                                ;   in Loop: Header=BB40_2 Depth=1
	mov	x14, x12
	adds	x12, x12, #16
	b.vc	LBB40_2
; %bb.4:
	brk	#0x1
LBB40_5:
	mov	x9, #0                          ; =0x0
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB40_6:
	movi.2d	v20, #0000000000000000
	fadd	d25, d24, d20
	fsub	d26, d25, d25
	fsub	d27, d24, d25
	fadd	d26, d26, d27
	fadd	d27, d22, d25
	fsub	d28, d27, d25
	fsub	d29, d28, d27
	fadd	d25, d25, d29
	fsub	d28, d22, d28
	fadd	d25, d28, d25
	fadd	d25, d26, d25
	mov	d24, v24[1]
	fadd	d26, d24, d27
	fsub	d28, d26, d27
	fsub	d29, d28, d26
	fadd	d27, d27, d29
	fsub	d24, d24, d28
	fadd	d24, d24, d27
	fadd	d24, d25, d24
	mov	d22, v22[1]
	fadd	d25, d22, d26
	fsub	d27, d25, d26
	fsub	d28, d27, d25
	fadd	d26, d26, d28
	fsub	d22, d22, d27
	fadd	d22, d22, d26
	fadd	d22, d24, d22
	fadd	d24, d23, d25
	fsub	d26, d24, d25
	fsub	d27, d26, d24
	fadd	d25, d25, d27
	fsub	d26, d23, d26
	fadd	d25, d26, d25
	fadd	d22, d22, d25
	fadd	d25, d19, d24
	fsub	d26, d25, d24
	fsub	d27, d26, d25
	fadd	d24, d24, d27
	fsub	d26, d19, d26
	fadd	d24, d26, d24
	fadd	d24, d24, d20
	fadd	d22, d22, d24
	mov	d23, v23[1]
	fadd	d24, d23, d25
	fsub	d26, d24, d25
	fsub	d27, d26, d24
	fadd	d25, d25, d27
	fsub	d23, d23, d26
	fadd	d23, d23, d25
	fadd	d23, d23, d20
	fadd	d22, d22, d23
	mov	d19, v19[1]
	fadd	d23, d19, d24
	fsub	d25, d23, d24
	fsub	d26, d23, d25
	fsub	d24, d24, d26
	fsub	d19, d19, d25
	fadd	d19, d19, d24
	fadd	d19, d19, d20
	fadd	d19, d22, d19
	fadd	d22, d21, d23
	fsub	d24, d22, d23
	fsub	d25, d22, d24
	fsub	d23, d23, d25
	fsub	d24, d21, d24
	fadd	d23, d24, d23
	fadd	d23, d23, d20
	fadd	d19, d19, d23
	fadd	d23, d17, d22
	fsub	d24, d23, d22
	fsub	d25, d23, d24
	fsub	d22, d22, d25
	fsub	d24, d17, d24
	fadd	d22, d24, d22
	fadd	d22, d22, d20
	fadd	d19, d19, d22
	mov	d21, v21[1]
	fadd	d22, d21, d23
	fsub	d24, d22, d23
	fsub	d25, d22, d24
	fsub	d23, d23, d25
	fsub	d21, d21, d24
	fadd	d21, d21, d23
	fadd	d21, d21, d20
	fadd	d19, d19, d21
	mov	d17, v17[1]
	fadd	d21, d17, d22
	fsub	d23, d21, d22
	fsub	d24, d21, d23
	fsub	d22, d22, d24
	fsub	d17, d17, d23
	fadd	d17, d17, d22
	fadd	d17, d17, d20
	fadd	d17, d19, d17
	fadd	d19, d18, d21
	fsub	d22, d19, d21
	fsub	d23, d19, d22
	fsub	d21, d21, d23
	fsub	d22, d18, d22
	fadd	d21, d22, d21
	fadd	d21, d21, d20
	fadd	d17, d17, d21
	fadd	d21, d7, d19
	fsub	d22, d21, d19
	fsub	d23, d21, d22
	fsub	d19, d19, d23
	fsub	d22, d7, d22
	fadd	d19, d22, d19
	fadd	d19, d19, d20
	fadd	d17, d17, d19
	mov	d18, v18[1]
	fadd	d19, d18, d21
	fsub	d22, d19, d21
	fsub	d23, d19, d22
	fsub	d21, d21, d23
	fsub	d18, d18, d22
	fadd	d18, d18, d21
	fadd	d18, d18, d20
	fadd	d17, d17, d18
	mov	d7, v7[1]
	fadd	d18, d7, d19
	fsub	d21, d18, d19
	fsub	d22, d18, d21
	fsub	d19, d19, d22
	fsub	d7, d7, d21
	fadd	d7, d7, d19
	fadd	d7, d7, d20
	fadd	d7, d17, d7
	fadd	d17, d6, d18
	fsub	d19, d17, d18
	fsub	d21, d17, d19
	fsub	d18, d18, d21
	fsub	d19, d6, d19
	fadd	d18, d19, d18
	fadd	d18, d18, d20
	fadd	d7, d7, d18
	fadd	d18, d4, d17
	fsub	d19, d18, d17
	fsub	d21, d18, d19
	fsub	d17, d17, d21
	fsub	d19, d4, d19
	fadd	d17, d19, d17
	fadd	d17, d17, d20
	fadd	d7, d7, d17
	mov	d6, v6[1]
	fadd	d17, d6, d18
	fsub	d19, d17, d18
	fsub	d21, d17, d19
	fsub	d18, d18, d21
	fsub	d6, d6, d19
	fadd	d6, d6, d18
	fadd	d6, d6, d20
	fadd	d6, d7, d6
	mov	d4, v4[1]
	fadd	d7, d4, d17
	fsub	d18, d7, d17
	fsub	d19, d7, d18
	fsub	d17, d17, d19
	fsub	d4, d4, d18
	fadd	d4, d4, d17
	fadd	d4, d4, d20
	fadd	d4, d6, d4
	fadd	d6, d3, d7
	fsub	d17, d6, d7
	fsub	d18, d6, d17
	fsub	d7, d7, d18
	fsub	d17, d3, d17
	fadd	d7, d17, d7
	fadd	d7, d7, d20
	fadd	d4, d4, d7
	fadd	d7, d2, d6
	fsub	d17, d7, d6
	fsub	d18, d7, d17
	fsub	d6, d6, d18
	fsub	d17, d2, d17
	fadd	d6, d17, d6
	fadd	d6, d6, d20
	fadd	d4, d4, d6
	mov	d3, v3[1]
	fadd	d6, d3, d7
	fsub	d17, d6, d7
	fsub	d18, d6, d17
	fsub	d7, d7, d18
	fsub	d3, d3, d17
	fadd	d3, d3, d7
	fadd	d3, d3, d20
	fadd	d3, d4, d3
	mov	d2, v2[1]
	fadd	d4, d2, d6
	fsub	d7, d4, d6
	fsub	d17, d4, d7
	fsub	d6, d6, d17
	fsub	d2, d2, d7
	fadd	d2, d2, d6
	fadd	d2, d2, d20
	fadd	d2, d3, d2
	fadd	d3, d16, d4
	fsub	d6, d3, d4
	fsub	d7, d3, d6
	fsub	d4, d4, d7
	fsub	d6, d16, d6
	fadd	d4, d6, d4
	fadd	d4, d4, d20
	fadd	d2, d2, d4
	fadd	d4, d1, d3
	fsub	d6, d4, d3
	fsub	d7, d4, d6
	fsub	d3, d3, d7
	fsub	d6, d1, d6
	fadd	d3, d6, d3
	fadd	d3, d3, d20
	fadd	d2, d2, d3
	mov	d3, v16[1]
	fadd	d6, d3, d4
	fsub	d7, d6, d4
	fsub	d16, d6, d7
	fsub	d4, d4, d16
	fsub	d3, d3, d7
	fadd	d3, d3, d4
	fadd	d3, d3, d20
	fadd	d2, d2, d3
	mov	d1, v1[1]
	fadd	d3, d1, d6
	fsub	d4, d3, d6
	fsub	d7, d3, d4
	fsub	d6, d6, d7
	fsub	d1, d1, d4
	fadd	d1, d1, d6
	fadd	d1, d1, d20
	fadd	d1, d2, d1
	fadd	d2, d5, d3
	fsub	d4, d2, d3
	fsub	d6, d2, d4
	fsub	d3, d3, d6
	fsub	d4, d5, d4
	fadd	d3, d4, d3
	fadd	d3, d3, d20
	fadd	d1, d1, d3
	fadd	d3, d0, d2
	fsub	d4, d3, d2
	fsub	d6, d3, d4
	fsub	d2, d2, d6
	fsub	d4, d0, d4
	fadd	d2, d4, d2
	fadd	d2, d2, d20
	fadd	d1, d1, d2
	mov	d2, v5[1]
	fadd	d4, d2, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d2, d2, d5
	fadd	d2, d2, d3
	fadd	d2, d2, d20
	fadd	d2, d1, d2
	mov	d0, v0[1]
	fadd	d1, d0, d4
	fsub	d3, d1, d4
	fsub	d5, d1, d3
	fsub	d4, d4, d5
	fsub	d0, d0, d3
	fadd	d0, d0, d4
	fadd	d0, d0, d20
	fadd	d0, d2, d0
	subs	x8, x8, x9
	b.le	LBB40_9
; %bb.7:
	lsl	x9, x9, #3
	add	x10, x9, #32
	add	x9, x1, x10
	add	x10, x0, x10
LBB40_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	d3, [x10], #8
	ldr	d4, [x9], #8
	fmul	d5, d3, d4
	fadd	d2, d1, d5
	fsub	d6, d2, d1
	fsub	d7, d2, d6
	fsub	d1, d1, d7
	fsub	d6, d5, d6
	fadd	d1, d6, d1
	fnmsub	d3, d3, d4, d5
	fadd	d1, d3, d1
	fadd	d0, d0, d1
	mov.16b	v1, v2
	subs	x8, x8, #1
	b.ne	LBB40_8
	b	LBB40_10
LBB40_9:
	mov.16b	v2, v1
LBB40_10:
	fadd	d0, d0, d2
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp], #48             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels9simdDot32ySdSaySdG_ACtF ; -- Begin function $s7Kernels9simdDot32ySdSaySdG_ACtF
	.globl	_$s7Kernels9simdDot32ySdSaySdG_ACtF
	.p2align	2
_$s7Kernels9simdDot32ySdSaySdG_ACtF:    ; @"$s7Kernels9simdDot32ySdSaySdG_ACtF"
; %bb.0:
	sub	sp, sp, #384
	stp	d15, d14, [sp, #304]            ; 16-byte Folded Spill
	stp	d13, d12, [sp, #320]            ; 16-byte Folded Spill
	stp	d11, d10, [sp, #336]            ; 16-byte Folded Spill
	stp	d9, d8, [sp, #352]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	ldr	x8, [x0, #16]
	cmp	x8, #32
	b.lo	LBB41_5
; %bb.1:
	mov	x9, #0                          ; =0x0
	movi.2d	v31, #0000000000000000
	movi.2d	v0, #0000000000000000
	add	x10, x0, #32
	movi.2d	v15, #0000000000000000
	add	x11, x1, #32
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #64]               ; 32-byte Folded Spill
	mov	w12, #64                        ; =0x40
	mov	w13, #32                        ; =0x20
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	stp	q1, q1, [sp, #96]               ; 32-byte Folded Spill
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
	stp	q1, q1, [sp, #144]              ; 32-byte Folded Spill
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	stp	q1, q1, [sp, #176]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #208]              ; 32-byte Folded Spill
	str	q1, [sp, #128]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #240]              ; 32-byte Folded Spill
	str	q1, [sp, #288]                  ; 16-byte Folded Spill
	movi.2d	v12, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v22, #0000000000000000
LBB41_2:                                ; =>This Inner Loop Header: Depth=1
	stp	q23, q22, [sp, #32]             ; 32-byte Folded Spill
	lsl	x9, x9, #3
	add	x14, x9, #192
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q19, q21, [x15]
	ldp	q27, q29, [x14]
	fmul.2d	v9, v21, v29
	fmul.2d	v10, v19, v27
	mov.16b	v13, v8
	fadd.2d	v20, v8, v10
	fadd.2d	v18, v28, v9
	fsub.2d	v17, v31, v9
	fmla.2d	v17, v29, v21
	fsub.2d	v29, v31, v10
	fmla.2d	v29, v27, v19
	fsub.2d	v21, v18, v28
	fsub.2d	v27, v20, v8
	fsub.2d	v10, v10, v27
	fsub.2d	v9, v9, v21
	mov.16b	v19, v1
	str	q18, [sp, #272]                 ; 16-byte Folded Spill
	fsub.2d	v1, v18, v21
	mov.16b	v21, v2
	mov.16b	v8, v20
	fsub.2d	v2, v20, v27
	ldr	q18, [sp, #288]                 ; 16-byte Folded Reload
	fsub.2d	v2, v13, v2
	ldr	q20, [sp, #256]                 ; 16-byte Folded Reload
	fsub.2d	v1, v28, v1
	fadd.2d	v1, v9, v1
	fadd.2d	v2, v10, v2
	fadd.2d	v2, v29, v2
	fadd.2d	v1, v17, v1
	fadd.2d	v26, v26, v1
	fadd.2d	v30, v30, v2
	add	x14, x9, #160
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q1, q2, [x15]
	ldp	q17, q10, [x14]
	fmul.2d	v22, v2, v10
	ldr	q23, [sp, #128]                 ; 16-byte Folded Reload
	fmul.2d	v24, v1, v17
	ldr	q25, [sp, #192]                 ; 16-byte Folded Reload
	fadd.2d	v28, v20, v24
	mov.16b	v27, v16
	fadd.2d	v16, v18, v22
	mov.16b	v29, v7
	fsub.2d	v7, v31, v22
	mov.16b	v9, v5
	fmla.2d	v7, v10, v2
	mov.16b	v10, v6
	fsub.2d	v5, v31, v24
	mov.16b	v13, v3
	fmla.2d	v5, v17, v1
	mov.16b	v14, v4
	fsub.2d	v3, v16, v18
	mov.16b	v1, v15
	fsub.2d	v4, v28, v20
	mov.16b	v2, v0
	fsub.2d	v0, v24, v4
	fsub.2d	v6, v22, v3
	str	q16, [sp, #288]                 ; 16-byte Folded Spill
	fsub.2d	v3, v16, v3
	str	q28, [sp, #256]                 ; 16-byte Folded Spill
	fsub.2d	v4, v28, v4
	fsub.2d	v4, v20, v4
	fsub.2d	v3, v18, v3
	fadd.2d	v3, v6, v3
	fadd.2d	v0, v0, v4
	fadd.2d	v0, v5, v0
	fadd.2d	v3, v7, v3
	fadd.2d	v11, v11, v3
	fadd.2d	v12, v12, v0
	add	x14, x9, #128
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q0, q3, [x15]
	ldp	q4, q5, [x14]
	fmul.2d	v6, v3, v5
	fmul.2d	v7, v0, v4
	fadd.2d	v18, v25, v7
	fadd.2d	v17, v23, v6
	fsub.2d	v16, v31, v6
	fmla.2d	v16, v5, v3
	fsub.2d	v3, v31, v7
	fmla.2d	v3, v4, v0
	fsub.2d	v0, v17, v23
	fsub.2d	v4, v18, v25
	fsub.2d	v5, v7, v4
	fsub.2d	v6, v6, v0
	str	q17, [sp, #128]                 ; 16-byte Folded Spill
	fsub.2d	v0, v17, v0
	str	q18, [sp, #192]                 ; 16-byte Folded Spill
	fsub.2d	v4, v18, v4
	fsub.2d	v4, v25, v4
	fsub.2d	v0, v23, v0
	fadd.2d	v0, v6, v0
	fadd.2d	v4, v5, v4
	fadd.2d	v3, v3, v4
	fadd.2d	v0, v16, v0
	ldr	q4, [sp, #240]                  ; 16-byte Folded Reload
	fadd.2d	v4, v4, v0
	ldr	q0, [sp, #224]                  ; 16-byte Folded Reload
	fadd.2d	v0, v0, v3
	stp	q0, q4, [sp, #224]              ; 32-byte Folded Spill
	add	x14, x9, #96
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q0, q3, [x15]
	ldp	q4, q5, [x14]
	fmul.2d	v6, v3, v5
	fmul.2d	v17, v0, v4
	fadd.2d	v20, v29, v17
	fadd.2d	v16, v27, v6
	fsub.2d	v18, v31, v6
	fmla.2d	v18, v5, v3
	fsub.2d	v3, v31, v17
	fmla.2d	v3, v4, v0
	fsub.2d	v0, v16, v27
	fsub.2d	v4, v20, v29
	fsub.2d	v5, v17, v4
	fsub.2d	v6, v6, v0
	fsub.2d	v0, v16, v0
	mov.16b	v7, v20
	fsub.2d	v4, v20, v4
	fsub.2d	v4, v29, v4
	fsub.2d	v0, v27, v0
	fadd.2d	v0, v6, v0
	fadd.2d	v4, v5, v4
	fadd.2d	v3, v3, v4
	fadd.2d	v0, v18, v0
	ldr	q4, [sp, #208]                  ; 16-byte Folded Reload
	fadd.2d	v4, v4, v0
	str	q4, [sp, #208]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #176]                  ; 16-byte Folded Reload
	fadd.2d	v0, v0, v3
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
	add	x14, x9, #64
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q0, q3, [x15]
	ldp	q4, q17, [x14]
	fmul.2d	v18, v3, v17
	fmul.2d	v20, v0, v4
	fadd.2d	v6, v10, v20
	fadd.2d	v5, v9, v18
	fsub.2d	v22, v31, v18
	fmla.2d	v22, v17, v3
	fsub.2d	v3, v31, v20
	fmla.2d	v3, v4, v0
	fsub.2d	v0, v5, v9
	fsub.2d	v4, v6, v10
	fsub.2d	v17, v20, v4
	fsub.2d	v18, v18, v0
	fsub.2d	v0, v5, v0
	fsub.2d	v4, v6, v4
	fsub.2d	v4, v10, v4
	fsub.2d	v0, v9, v0
	fadd.2d	v0, v18, v0
	fadd.2d	v4, v17, v4
	fadd.2d	v3, v3, v4
	fadd.2d	v0, v22, v0
	ldr	q4, [sp, #160]                  ; 16-byte Folded Reload
	fadd.2d	v4, v4, v0
	ldr	q0, [sp, #144]                  ; 16-byte Folded Reload
	fadd.2d	v0, v0, v3
	stp	q0, q4, [sp, #144]              ; 32-byte Folded Spill
	add	x14, x9, #32
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q0, q17, [x15]
	ldp	q18, q20, [x14]
	fmul.2d	v22, v17, v20
	fmul.2d	v23, v0, v18
	fadd.2d	v4, v14, v23
	fadd.2d	v3, v13, v22
	fsub.2d	v24, v31, v22
	fmla.2d	v24, v20, v17
	fsub.2d	v17, v31, v23
	fmla.2d	v17, v18, v0
	fsub.2d	v0, v3, v13
	fsub.2d	v18, v4, v14
	fsub.2d	v20, v23, v18
	fsub.2d	v22, v22, v0
	fsub.2d	v0, v3, v0
	fsub.2d	v18, v4, v18
	fsub.2d	v18, v14, v18
	fsub.2d	v0, v13, v0
	fadd.2d	v0, v22, v0
	fadd.2d	v18, v20, v18
	fadd.2d	v17, v17, v18
	fadd.2d	v0, v24, v0
	ldr	q18, [sp, #112]                 ; 16-byte Folded Reload
	fadd.2d	v18, v18, v0
	ldr	q0, [sp, #96]                   ; 16-byte Folded Reload
	fadd.2d	v0, v0, v17
	stp	q0, q18, [sp, #96]              ; 32-byte Folded Spill
	add	x14, x10, x9
	add	x15, x11, x9
	ldp	q17, q18, [x14]
	ldp	q20, q22, [x15]
	fmul.2d	v23, v18, v22
	fmul.2d	v24, v17, v20
	fadd.2d	v0, v2, v24
	fadd.2d	v15, v15, v23
	fsub.2d	v25, v31, v23
	fmla.2d	v25, v22, v18
	fsub.2d	v18, v31, v24
	fmla.2d	v18, v20, v17
	fsub.2d	v17, v15, v1
	fsub.2d	v20, v0, v2
	fsub.2d	v22, v24, v20
	fsub.2d	v23, v23, v17
	fsub.2d	v17, v15, v17
	fsub.2d	v20, v0, v20
	fsub.2d	v2, v2, v20
	fsub.2d	v1, v1, v17
	fadd.2d	v1, v23, v1
	fadd.2d	v2, v22, v2
	fadd.2d	v2, v18, v2
	fadd.2d	v1, v25, v1
	ldr	q17, [sp, #80]                  ; 16-byte Folded Reload
	fadd.2d	v17, v17, v1
	ldr	q1, [sp, #64]                   ; 16-byte Folded Reload
	fadd.2d	v1, v1, v2
	stp	q1, q17, [sp, #64]              ; 32-byte Folded Spill
	add	x9, x9, #224
	add	x14, x10, x9
	add	x9, x11, x9
	ldp	q18, q17, [x14]
	ldp	q22, q20, [x9]
	fmul.2d	v23, v18, v22
	fmul.2d	v24, v17, v20
	fadd.2d	v1, v19, v24
	fadd.2d	v2, v21, v23
	fsub.2d	v25, v31, v24
	fmla.2d	v25, v20, v17
	fsub.2d	v17, v2, v21
	fsub.2d	v20, v31, v23
	fmla.2d	v20, v22, v18
	fsub.2d	v18, v1, v19
	fsub.2d	v22, v2, v17
	fsub.2d	v21, v21, v22
	fsub.2d	v22, v1, v18
	fsub.2d	v19, v19, v22
	fsub.2d	v17, v23, v17
	ldp	q23, q22, [sp, #32]             ; 32-byte Folded Reload
	fsub.2d	v18, v24, v18
	fadd.2d	v18, v18, v19
	fadd.2d	v17, v17, v21
	fadd.2d	v17, v20, v17
	fadd.2d	v18, v25, v18
	fadd.2d	v22, v22, v18
	fadd.2d	v23, v23, v17
	mov	x9, x13
	cmp	x8, x12
	b.lt	LBB41_6
; %bb.3:                                ;   in Loop: Header=BB41_2 Depth=1
	mov	x13, x12
	adds	x12, x12, #32
	ldr	q28, [sp, #272]                 ; 16-byte Folded Reload
	b.vc	LBB41_2
; %bb.4:
	brk	#0x1
LBB41_5:
	mov	x9, #0                          ; =0x0
	movi.2d	v23, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #32]               ; 32-byte Folded Spill
	stp	q0, q0, [sp]                    ; 32-byte Folded Spill
	stp	q0, q0, [sp, #272]              ; 32-byte Folded Spill
	movi.2d	v30, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v15, #0000000000000000
	b	LBB41_7
LBB41_6:
	stp	q30, q26, [sp, #32]             ; 32-byte Folded Spill
	stp	q11, q8, [sp]                   ; 32-byte Folded Spill
	mov.16b	v30, v12
	ldp	q9, q8, [sp, #240]              ; 32-byte Folded Reload
	ldp	q12, q10, [sp, #208]            ; 32-byte Folded Reload
	ldp	q11, q24, [sp, #128]            ; 32-byte Folded Reload
	ldp	q14, q13, [sp, #176]            ; 32-byte Folded Reload
	ldr	q25, [sp, #160]                 ; 16-byte Folded Reload
	ldp	q27, q26, [sp, #96]             ; 32-byte Folded Reload
	ldp	q29, q28, [sp, #64]             ; 32-byte Folded Reload
LBB41_7:
	movi.2d	v31, #0000000000000000
	fadd	d17, d0, d31
	fsub	d18, d17, d17
	fsub	d19, d0, d17
	fadd	d18, d18, d19
	fadd	d19, d29, d17
	fsub	d20, d19, d17
	fsub	d21, d20, d19
	fadd	d17, d17, d21
	fsub	d20, d29, d20
	fadd	d17, d20, d17
	fadd	d17, d18, d17
	mov	d0, v0[1]
	fadd	d18, d0, d19
	fsub	d20, d18, d19
	fsub	d21, d20, d18
	fadd	d19, d19, d21
	fsub	d0, d0, d20
	fadd	d0, d0, d19
	fadd	d0, d17, d0
	mov	d17, v29[1]
	fadd	d19, d17, d18
	fsub	d20, d19, d18
	fsub	d21, d20, d19
	fadd	d18, d18, d21
	fsub	d17, d17, d20
	fadd	d17, d17, d18
	fadd	d0, d0, d17
	fadd	d17, d15, d19
	fsub	d18, d17, d19
	fsub	d20, d18, d17
	fadd	d19, d19, d20
	fsub	d18, d15, d18
	fadd	d18, d18, d19
	fadd	d0, d0, d18
	fadd	d18, d28, d17
	fsub	d19, d18, d17
	fsub	d20, d19, d18
	fadd	d17, d17, d20
	fsub	d19, d28, d19
	fadd	d17, d19, d17
	fadd	d17, d17, d31
	fadd	d0, d0, d17
	mov	d17, v15[1]
	fadd	d19, d17, d18
	fsub	d20, d19, d18
	fsub	d21, d20, d19
	fadd	d18, d18, d21
	fsub	d17, d17, d20
	fadd	d17, d17, d18
	fadd	d17, d17, d31
	fadd	d0, d0, d17
	mov	d17, v28[1]
	fadd	d18, d17, d19
	fsub	d20, d18, d19
	fsub	d21, d18, d20
	fsub	d19, d19, d21
	fsub	d17, d17, d20
	fadd	d17, d17, d19
	fadd	d17, d17, d31
	fadd	d0, d0, d17
	fadd	d17, d4, d18
	fsub	d19, d17, d18
	fsub	d20, d17, d19
	fsub	d18, d18, d20
	fsub	d19, d4, d19
	fadd	d18, d19, d18
	fadd	d18, d18, d31
	fadd	d0, d0, d18
	fadd	d18, d27, d17
	fsub	d19, d18, d17
	fsub	d20, d18, d19
	fsub	d17, d17, d20
	fsub	d19, d27, d19
	fadd	d17, d19, d17
	fadd	d17, d17, d31
	fadd	d0, d0, d17
	mov	d4, v4[1]
	fadd	d17, d4, d18
	fsub	d19, d17, d18
	fsub	d20, d17, d19
	fsub	d18, d18, d20
	fsub	d4, d4, d19
	fadd	d4, d4, d18
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	mov	d4, v27[1]
	fadd	d18, d4, d17
	fsub	d19, d18, d17
	fsub	d20, d18, d19
	fsub	d17, d17, d20
	fsub	d4, d4, d19
	fadd	d4, d4, d17
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d3, d18
	fsub	d17, d4, d18
	fsub	d19, d4, d17
	fsub	d18, d18, d19
	fsub	d17, d3, d17
	fadd	d17, d17, d18
	fadd	d17, d17, d31
	fadd	d0, d0, d17
	fadd	d17, d26, d4
	fsub	d18, d17, d4
	fsub	d19, d17, d18
	fsub	d4, d4, d19
	fsub	d18, d26, d18
	fadd	d4, d18, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	mov	d3, v3[1]
	fadd	d4, d3, d17
	fsub	d18, d4, d17
	fsub	d19, d4, d18
	fsub	d17, d17, d19
	fsub	d3, d3, d18
	fadd	d3, d3, d17
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v26[1]
	fadd	d17, d3, d4
	fsub	d18, d17, d4
	fsub	d19, d17, d18
	fsub	d4, d4, d19
	fsub	d3, d3, d18
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d6, d17
	fsub	d4, d3, d17
	fsub	d18, d3, d4
	fsub	d17, d17, d18
	fsub	d4, d6, d4
	fadd	d4, d4, d17
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d24, d3
	fsub	d17, d4, d3
	fsub	d18, d4, d17
	fsub	d3, d3, d18
	fsub	d17, d24, d17
	fadd	d3, d17, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v6[1]
	fadd	d6, d3, d4
	fsub	d17, d6, d4
	fsub	d18, d6, d17
	fsub	d4, d4, d18
	fsub	d3, d3, d17
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v24[1]
	fadd	d4, d3, d6
	fsub	d17, d4, d6
	fsub	d18, d4, d17
	fsub	d6, d6, d18
	fsub	d3, d3, d17
	fadd	d3, d3, d6
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d5, d4
	fsub	d6, d3, d4
	fsub	d17, d3, d6
	fsub	d4, d4, d17
	fsub	d6, d5, d6
	fadd	d4, d6, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d25, d3
	fsub	d6, d4, d3
	fsub	d17, d4, d6
	fsub	d3, d3, d17
	fsub	d6, d25, d6
	fadd	d3, d6, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v5[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d17, d5, d6
	fsub	d4, d4, d17
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v25[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d17, d4, d6
	fsub	d5, d5, d17
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d7, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d7, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d14, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d14, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v7[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v14[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d16, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d16, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d12, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d12, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v16[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v12[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d13, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d13, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d10, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d10, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v13[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v10[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d11, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d11, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d9, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d9, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v11[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v9[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d8, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d8, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d30, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d30, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v8[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v30[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	fadd	d3, d7, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d7, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	ldr	q16, [sp]                       ; 16-byte Folded Reload
	fadd	d4, d16, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d16, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v7[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v16[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	ldp	q7, q16, [sp, #16]              ; 32-byte Folded Reload
	fadd	d3, d7, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d7, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d16, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d16, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v7[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v16[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	fadd	d3, d7, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d7, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	ldr	q16, [sp, #48]                  ; 16-byte Folded Reload
	fadd	d4, d16, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d16, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v7[1]
	fadd	d5, d3, d4
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d3, v16[1]
	fadd	d4, d3, d5
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d5
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d2, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d5, d2, d5
	fadd	d4, d5, d4
	fadd	d4, d4, d31
	fadd	d0, d0, d4
	fadd	d4, d23, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d5, d23, d5
	fadd	d3, d5, d3
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	mov	d2, v2[1]
	fadd	d3, d2, d4
	fsub	d5, d3, d4
	fsub	d6, d3, d5
	fsub	d4, d4, d6
	fsub	d2, d2, d5
	fadd	d2, d2, d4
	fadd	d2, d2, d31
	fadd	d0, d0, d2
	mov	d2, v23[1]
	fadd	d4, d2, d3
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d2, d2, d5
	fadd	d2, d2, d3
	fadd	d2, d2, d31
	fadd	d0, d0, d2
	fadd	d2, d1, d4
	fsub	d3, d2, d4
	fsub	d5, d2, d3
	fsub	d4, d4, d5
	fsub	d3, d1, d3
	fadd	d3, d3, d4
	fadd	d3, d3, d31
	fadd	d0, d0, d3
	fadd	d3, d22, d2
	fsub	d4, d3, d2
	fsub	d5, d3, d4
	fsub	d2, d2, d5
	fsub	d4, d22, d4
	fadd	d2, d4, d2
	fadd	d2, d2, d31
	fadd	d0, d0, d2
	mov	d1, v1[1]
	fadd	d2, d1, d3
	fsub	d4, d2, d3
	fsub	d5, d2, d4
	fsub	d3, d3, d5
	fsub	d1, d1, d4
	fadd	d1, d1, d3
	fadd	d1, d1, d31
	fadd	d0, d0, d1
	mov	d3, v22[1]
	fadd	d1, d3, d2
	fsub	d4, d1, d2
	fsub	d5, d1, d4
	fsub	d2, d2, d5
	fsub	d3, d3, d4
	fadd	d2, d3, d2
	fadd	d2, d2, d31
	fadd	d0, d0, d2
	subs	x8, x8, x9
	b.le	LBB41_10
; %bb.8:
	lsl	x9, x9, #3
	add	x10, x9, #32
	add	x9, x1, x10
	add	x10, x0, x10
LBB41_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	d3, [x10], #8
	ldr	d4, [x9], #8
	fmul	d5, d3, d4
	fadd	d2, d1, d5
	fsub	d6, d2, d1
	fsub	d7, d2, d6
	fsub	d1, d1, d7
	fsub	d6, d5, d6
	fadd	d1, d6, d1
	fnmsub	d3, d3, d4, d5
	fadd	d1, d3, d1
	fadd	d0, d0, d1
	mov.16b	v1, v2
	subs	x8, x8, #1
	b.ne	LBB41_9
	b	LBB41_11
LBB41_10:
	mov.16b	v2, v1
LBB41_11:
	fadd	d0, d0, d2
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #352]              ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #336]            ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #320]            ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4highSdvpfi ; -- Begin function $s7Kernels10ScalarDot3V4highSdvpfi
	.globl	_$s7Kernels10ScalarDot3V4highSdvpfi
	.p2align	2
_$s7Kernels10ScalarDot3V4highSdvpfi:    ; @"$s7Kernels10ScalarDot3V4highSdvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V6middleSdvpfi ; -- Begin function $s7Kernels10ScalarDot3V6middleSdvpfi
	.globl	_$s7Kernels10ScalarDot3V6middleSdvpfi
	.p2align	2
_$s7Kernels10ScalarDot3V6middleSdvpfi:  ; @"$s7Kernels10ScalarDot3V6middleSdvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V3lowSdvpfi ; -- Begin function $s7Kernels10ScalarDot3V3lowSdvpfi
	.globl	_$s7Kernels10ScalarDot3V3lowSdvpfi
	.p2align	2
_$s7Kernels10ScalarDot3V3lowSdvpfi:     ; @"$s7Kernels10ScalarDot3V3lowSdvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4highSdvg ; -- Begin function $s7Kernels10ScalarDot3V4highSdvg
	.globl	_$s7Kernels10ScalarDot3V4highSdvg
	.p2align	2
_$s7Kernels10ScalarDot3V4highSdvg:      ; @"$s7Kernels10ScalarDot3V4highSdvg"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4highSdvs ; -- Begin function $s7Kernels10ScalarDot3V4highSdvs
	.globl	_$s7Kernels10ScalarDot3V4highSdvs
	.p2align	2
_$s7Kernels10ScalarDot3V4highSdvs:      ; @"$s7Kernels10ScalarDot3V4highSdvs"
; %bb.0:
	str	d0, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4highSdvM ; -- Begin function $s7Kernels10ScalarDot3V4highSdvM
	.globl	_$s7Kernels10ScalarDot3V4highSdvM
	.p2align	2
_$s7Kernels10ScalarDot3V4highSdvM:      ; @"$s7Kernels10ScalarDot3V4highSdvM"
; %bb.0:
	mov	x1, x20
Lloh8:
	adrp	x0, _$s7Kernels10ScalarDot3V4highSdvM.resume.0@PAGE
Lloh9:
	add	x0, x0, _$s7Kernels10ScalarDot3V4highSdvM.resume.0@PAGEOFF
	ret
	.loh AdrpAdd	Lloh8, Lloh9
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot3V4highSdvM.resume.0
_$s7Kernels10ScalarDot3V4highSdvM.resume.0: ; @"$s7Kernels10ScalarDot3V4highSdvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V6middleSdvg ; -- Begin function $s7Kernels10ScalarDot3V6middleSdvg
	.globl	_$s7Kernels10ScalarDot3V6middleSdvg
	.p2align	2
_$s7Kernels10ScalarDot3V6middleSdvg:    ; @"$s7Kernels10ScalarDot3V6middleSdvg"
; %bb.0:
	mov.16b	v0, v1
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V6middleSdvs ; -- Begin function $s7Kernels10ScalarDot3V6middleSdvs
	.globl	_$s7Kernels10ScalarDot3V6middleSdvs
	.p2align	2
_$s7Kernels10ScalarDot3V6middleSdvs:    ; @"$s7Kernels10ScalarDot3V6middleSdvs"
; %bb.0:
	str	d0, [x20, #8]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V6middleSdvM ; -- Begin function $s7Kernels10ScalarDot3V6middleSdvM
	.globl	_$s7Kernels10ScalarDot3V6middleSdvM
	.p2align	2
_$s7Kernels10ScalarDot3V6middleSdvM:    ; @"$s7Kernels10ScalarDot3V6middleSdvM"
; %bb.0:
Lloh10:
	adrp	x0, _$s7Kernels10ScalarDot3V6middleSdvM.resume.0@PAGE
Lloh11:
	add	x0, x0, _$s7Kernels10ScalarDot3V6middleSdvM.resume.0@PAGEOFF
	add	x1, x20, #8
	ret
	.loh AdrpAdd	Lloh10, Lloh11
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot3V6middleSdvM.resume.0
_$s7Kernels10ScalarDot3V6middleSdvM.resume.0: ; @"$s7Kernels10ScalarDot3V6middleSdvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V3lowSdvg ; -- Begin function $s7Kernels10ScalarDot3V3lowSdvg
	.globl	_$s7Kernels10ScalarDot3V3lowSdvg
	.p2align	2
_$s7Kernels10ScalarDot3V3lowSdvg:       ; @"$s7Kernels10ScalarDot3V3lowSdvg"
; %bb.0:
	mov.16b	v0, v2
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V3lowSdvs ; -- Begin function $s7Kernels10ScalarDot3V3lowSdvs
	.globl	_$s7Kernels10ScalarDot3V3lowSdvs
	.p2align	2
_$s7Kernels10ScalarDot3V3lowSdvs:       ; @"$s7Kernels10ScalarDot3V3lowSdvs"
; %bb.0:
	str	d0, [x20, #16]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V3lowSdvM ; -- Begin function $s7Kernels10ScalarDot3V3lowSdvM
	.globl	_$s7Kernels10ScalarDot3V3lowSdvM
	.p2align	2
_$s7Kernels10ScalarDot3V3lowSdvM:       ; @"$s7Kernels10ScalarDot3V3lowSdvM"
; %bb.0:
Lloh12:
	adrp	x0, _$s7Kernels10ScalarDot3V3lowSdvM.resume.0@PAGE
Lloh13:
	add	x0, x0, _$s7Kernels10ScalarDot3V3lowSdvM.resume.0@PAGEOFF
	add	x1, x20, #16
	ret
	.loh AdrpAdd	Lloh12, Lloh13
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot3V3lowSdvM.resume.0
_$s7Kernels10ScalarDot3V3lowSdvM.resume.0: ; @"$s7Kernels10ScalarDot3V3lowSdvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V3addyySdF ; -- Begin function $s7Kernels10ScalarDot3V3addyySdF
	.globl	_$s7Kernels10ScalarDot3V3addyySdF
	.p2align	2
_$s7Kernels10ScalarDot3V3addyySdF:      ; @"$s7Kernels10ScalarDot3V3addyySdF"
; %bb.0:
	ldp	d1, d2, [x20]
	fadd	d3, d0, d1
	fsub	d4, d3, d1
	fsub	d5, d3, d4
	fsub	d1, d1, d5
	fsub	d0, d0, d4
	fadd	d0, d0, d1
	fadd	d1, d2, d0
	fsub	d4, d1, d2
	fsub	d5, d1, d4
	fsub	d2, d2, d5
	fsub	d0, d0, d4
	fadd	d0, d0, d2
	ldr	d2, [x20, #16]
	fadd	d0, d2, d0
	stp	d1, d0, [x20, #8]
	str	d3, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V7productyySd_SdtF ; -- Begin function $s7Kernels10ScalarDot3V7productyySd_SdtF
	.globl	_$s7Kernels10ScalarDot3V7productyySd_SdtF
	.p2align	2
_$s7Kernels10ScalarDot3V7productyySd_SdtF: ; @"$s7Kernels10ScalarDot3V7productyySd_SdtF"
; %bb.0:
	fmul	d2, d0, d1
	ldp	d3, d4, [x20]
	fadd	d5, d2, d3
	fsub	d6, d5, d3
	fsub	d7, d5, d6
	fsub	d3, d3, d7
	fsub	d6, d2, d6
	fadd	d3, d6, d3
	fadd	d6, d4, d3
	fsub	d7, d6, d4
	fsub	d16, d6, d7
	fsub	d4, d4, d16
	fsub	d3, d3, d7
	fadd	d3, d3, d4
	ldr	d4, [x20, #16]
	fadd	d3, d4, d3
	fnmsub	d0, d0, d1, d2
	fadd	d1, d0, d5
	fsub	d2, d1, d5
	fsub	d4, d1, d2
	fsub	d4, d5, d4
	fsub	d0, d0, d2
	fadd	d0, d0, d4
	fadd	d2, d6, d0
	fsub	d4, d2, d6
	fsub	d5, d2, d4
	fsub	d5, d6, d5
	fsub	d0, d0, d4
	fadd	d0, d0, d5
	fadd	d0, d3, d0
	stp	d2, d0, [x20, #8]
	str	d1, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V5valueSdvg ; -- Begin function $s7Kernels10ScalarDot3V5valueSdvg
	.globl	_$s7Kernels10ScalarDot3V5valueSdvg
	.p2align	2
_$s7Kernels10ScalarDot3V5valueSdvg:     ; @"$s7Kernels10ScalarDot3V5valueSdvg"
; %bb.0:
	fadd	d3, d0, d1
	fsub	d4, d3, d0
	fsub	d5, d3, d4
	fsub	d0, d0, d5
	fsub	d1, d1, d4
	fadd	d0, d1, d0
	fadd	d0, d2, d0
	fadd	d0, d3, d0
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3VACycfC ; -- Begin function $s7Kernels10ScalarDot3VACycfC
	.globl	_$s7Kernels10ScalarDot3VACycfC
	.p2align	2
_$s7Kernels10ScalarDot3VACycfC:         ; @"$s7Kernels10ScalarDot3VACycfC"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA_ ; -- Begin function $s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA_
	.globl	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA_
	.p2align	2
_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA_: ; @"$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA0_ ; -- Begin function $s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA0_
	.globl	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA0_
	.p2align	2
_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA0_: ; @"$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA0_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA1_ ; -- Begin function $s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA1_
	.globl	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA1_
	.p2align	2
_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA1_: ; @"$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfcfA1_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfC ; -- Begin function $s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfC
	.globl	_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfC
	.p2align	2
_$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfC: ; @"$s7Kernels10ScalarDot3V4high6middle3lowACSd_S2dtcfC"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvpfi ; -- Begin function $s7Kernels10VectorDot3V4highs5SIMD4VySdGvpfi
	.globl	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvpfi
	.p2align	2
_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvpfi: ; @"$s7Kernels10VectorDot3V4highs5SIMD4VySdGvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvpfi ; -- Begin function $s7Kernels10VectorDot3V6middles5SIMD4VySdGvpfi
	.globl	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvpfi
	.p2align	2
_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvpfi: ; @"$s7Kernels10VectorDot3V6middles5SIMD4VySdGvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvpfi ; -- Begin function $s7Kernels10VectorDot3V3lows5SIMD4VySdGvpfi
	.globl	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvpfi
	.p2align	2
_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvpfi: ; @"$s7Kernels10VectorDot3V3lows5SIMD4VySdGvpfi"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvg ; -- Begin function $s7Kernels10VectorDot3V4highs5SIMD4VySdGvg
	.globl	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvg
	.p2align	2
_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvg: ; @"$s7Kernels10VectorDot3V4highs5SIMD4VySdGvg"
; %bb.0:
	ldp	q0, q1, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvs ; -- Begin function $s7Kernels10VectorDot3V4highs5SIMD4VySdGvs
	.globl	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvs
	.p2align	2
_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvs: ; @"$s7Kernels10VectorDot3V4highs5SIMD4VySdGvs"
; %bb.0:
	stp	q0, q1, [x20]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM ; -- Begin function $s7Kernels10VectorDot3V4highs5SIMD4VySdGvM
	.globl	_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM
	.p2align	2
_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM: ; @"$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM"
; %bb.0:
	mov	x1, x20
Lloh14:
	adrp	x0, _$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM.resume.0@PAGE
Lloh15:
	add	x0, x0, _$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM.resume.0@PAGEOFF
	ret
	.loh AdrpAdd	Lloh14, Lloh15
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot3V4highs5SIMD4VySdGvM.resume.0
_$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM.resume.0: ; @"$s7Kernels10VectorDot3V4highs5SIMD4VySdGvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvg ; -- Begin function $s7Kernels10VectorDot3V6middles5SIMD4VySdGvg
	.globl	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvg
	.p2align	2
_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvg: ; @"$s7Kernels10VectorDot3V6middles5SIMD4VySdGvg"
; %bb.0:
	ldp	q0, q1, [x20, #32]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvs ; -- Begin function $s7Kernels10VectorDot3V6middles5SIMD4VySdGvs
	.globl	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvs
	.p2align	2
_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvs: ; @"$s7Kernels10VectorDot3V6middles5SIMD4VySdGvs"
; %bb.0:
	stp	q0, q1, [x20, #32]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM ; -- Begin function $s7Kernels10VectorDot3V6middles5SIMD4VySdGvM
	.globl	_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM
	.p2align	2
_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM: ; @"$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM"
; %bb.0:
Lloh16:
	adrp	x0, _$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM.resume.0@PAGE
Lloh17:
	add	x0, x0, _$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM.resume.0@PAGEOFF
	add	x1, x20, #32
	ret
	.loh AdrpAdd	Lloh16, Lloh17
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot3V6middles5SIMD4VySdGvM.resume.0
_$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM.resume.0: ; @"$s7Kernels10VectorDot3V6middles5SIMD4VySdGvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvg ; -- Begin function $s7Kernels10VectorDot3V3lows5SIMD4VySdGvg
	.globl	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvg
	.p2align	2
_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvg: ; @"$s7Kernels10VectorDot3V3lows5SIMD4VySdGvg"
; %bb.0:
	ldp	q0, q1, [x20, #64]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvs ; -- Begin function $s7Kernels10VectorDot3V3lows5SIMD4VySdGvs
	.globl	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvs
	.p2align	2
_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvs: ; @"$s7Kernels10VectorDot3V3lows5SIMD4VySdGvs"
; %bb.0:
	stp	q0, q1, [x20, #64]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM ; -- Begin function $s7Kernels10VectorDot3V3lows5SIMD4VySdGvM
	.globl	_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM
	.p2align	2
_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM: ; @"$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM"
; %bb.0:
Lloh18:
	adrp	x0, _$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM.resume.0@PAGE
Lloh19:
	add	x0, x0, _$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM.resume.0@PAGEOFF
	add	x1, x20, #64
	ret
	.loh AdrpAdd	Lloh18, Lloh19
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot3V3lows5SIMD4VySdGvM.resume.0
_$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM.resume.0: ; @"$s7Kernels10VectorDot3V3lows5SIMD4VySdGvM.resume.0"
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V3addyys5SIMD4VySdGF ; -- Begin function $s7Kernels10VectorDot3V3addyys5SIMD4VySdGF
	.globl	_$s7Kernels10VectorDot3V3addyys5SIMD4VySdGF
	.p2align	2
_$s7Kernels10VectorDot3V3addyys5SIMD4VySdGF: ; @"$s7Kernels10VectorDot3V3addyys5SIMD4VySdGF"
; %bb.0:
	ldp	q2, q3, [x20]
	fadd.2d	v4, v1, v3
	fadd.2d	v5, v0, v2
	stp	q5, q4, [x20]
	ldp	q7, q6, [x20, #32]
	ldp	q16, q17, [x20, #64]
	fsub.2d	v18, v5, v2
	fsub.2d	v19, v4, v3
	fsub.2d	v4, v4, v19
	fsub.2d	v5, v5, v18
	fsub.2d	v2, v2, v5
	fsub.2d	v3, v3, v4
	fsub.2d	v0, v0, v18
	fsub.2d	v1, v1, v19
	fadd.2d	v1, v1, v3
	fadd.2d	v0, v0, v2
	fadd.2d	v2, v7, v0
	fadd.2d	v3, v6, v1
	fsub.2d	v4, v3, v6
	fsub.2d	v5, v2, v7
	fsub.2d	v18, v2, v5
	fsub.2d	v19, v3, v4
	fsub.2d	v6, v6, v19
	fsub.2d	v7, v7, v18
	fsub.2d	v1, v1, v4
	fsub.2d	v0, v0, v5
	fadd.2d	v0, v0, v7
	fadd.2d	v1, v1, v6
	fadd.2d	v1, v17, v1
	fadd.2d	v0, v16, v0
	stp	q0, q1, [x20, #64]
	stp	q2, q3, [x20, #32]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V7productyys5SIMD4VySdG_AGtF ; -- Begin function $s7Kernels10VectorDot3V7productyys5SIMD4VySdG_AGtF
	.globl	_$s7Kernels10VectorDot3V7productyys5SIMD4VySdG_AGtF
	.p2align	2
_$s7Kernels10VectorDot3V7productyys5SIMD4VySdG_AGtF: ; @"$s7Kernels10VectorDot3V7productyys5SIMD4VySdG_AGtF"
; %bb.0:
	ldp	q5, q4, [x20]
	ldp	q6, q7, [x20, #32]
	ldp	q17, q16, [x20, #64]
	fmul.2d	v18, v1, v3
	fmul.2d	v19, v0, v2
	fadd.2d	v20, v19, v5
	fadd.2d	v21, v18, v4
	movi.2d	v22, #0000000000000000
	fsub.2d	v23, v22, v18
	fsub.2d	v22, v22, v19
	fmla.2d	v22, v2, v0
	fmla.2d	v23, v3, v1
	fadd.2d	v0, v23, v21
	fadd.2d	v1, v22, v20
	stp	q1, q0, [x20]
	fsub.2d	v2, v21, v4
	fsub.2d	v3, v20, v5
	fsub.2d	v24, v20, v3
	fsub.2d	v25, v21, v2
	fsub.2d	v4, v4, v25
	fsub.2d	v5, v5, v24
	fsub.2d	v2, v18, v2
	fsub.2d	v3, v19, v3
	fadd.2d	v3, v3, v5
	fadd.2d	v2, v2, v4
	fadd.2d	v4, v7, v2
	fadd.2d	v5, v6, v3
	fsub.2d	v18, v5, v6
	fsub.2d	v19, v4, v7
	fsub.2d	v24, v4, v19
	fsub.2d	v25, v5, v18
	fsub.2d	v6, v6, v25
	fsub.2d	v7, v7, v24
	fsub.2d	v3, v3, v18
	fsub.2d	v2, v2, v19
	fadd.2d	v2, v2, v7
	fadd.2d	v3, v3, v6
	fadd.2d	v3, v17, v3
	fadd.2d	v2, v16, v2
	fsub.2d	v6, v1, v20
	fsub.2d	v7, v0, v21
	fsub.2d	v0, v0, v7
	fsub.2d	v1, v1, v6
	fsub.2d	v1, v20, v1
	fsub.2d	v0, v21, v0
	fsub.2d	v6, v22, v6
	fsub.2d	v7, v23, v7
	fadd.2d	v0, v7, v0
	fadd.2d	v1, v6, v1
	fadd.2d	v6, v5, v1
	fadd.2d	v7, v4, v0
	fsub.2d	v16, v7, v4
	fsub.2d	v17, v6, v5
	fsub.2d	v18, v6, v17
	fsub.2d	v19, v7, v16
	fsub.2d	v4, v4, v19
	fsub.2d	v5, v5, v18
	fsub.2d	v0, v0, v16
	fsub.2d	v1, v1, v17
	fadd.2d	v1, v1, v5
	fadd.2d	v0, v0, v4
	fadd.2d	v0, v2, v0
	fadd.2d	v1, v3, v1
	stp	q1, q0, [x20, #64]
	stp	q6, q7, [x20, #32]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V5merge4intoyAA06ScalarC0Vz_tF ; -- Begin function $s7Kernels10VectorDot3V5merge4intoyAA06ScalarC0Vz_tF
	.globl	_$s7Kernels10VectorDot3V5merge4intoyAA06ScalarC0Vz_tF
	.p2align	2
_$s7Kernels10VectorDot3V5merge4intoyAA06ScalarC0Vz_tF: ; @"$s7Kernels10VectorDot3V5merge4intoyAA06ScalarC0Vz_tF"
; %bb.0:
	ldp	d6, d4, [x0, #8]
	ldr	d5, [x0]
	ldp	q7, q2, [x20]
	ldp	q16, q1, [x20, #32]
	ldp	q3, q0, [x20, #64]
	fadd	d17, d5, d7
	fsub	d18, d17, d5
	fsub	d19, d17, d18
	fsub	d5, d5, d19
	fsub	d18, d7, d18
	fadd	d5, d18, d5
	fadd	d18, d6, d5
	fsub	d19, d18, d6
	fsub	d20, d18, d19
	fsub	d6, d6, d20
	fsub	d5, d5, d19
	fadd	d5, d5, d6
	fadd	d4, d4, d5
	fadd	d5, d17, d16
	fsub	d6, d5, d17
	fsub	d19, d5, d6
	fsub	d17, d17, d19
	fsub	d6, d16, d6
	fadd	d6, d6, d17
	fadd	d17, d18, d6
	fsub	d19, d17, d18
	fsub	d20, d17, d19
	fsub	d18, d18, d20
	fsub	d6, d6, d19
	fadd	d6, d6, d18
	fadd	d4, d4, d6
	fadd	d6, d5, d3
	fsub	d18, d6, d5
	fsub	d19, d6, d18
	fsub	d5, d5, d19
	fsub	d18, d3, d18
	fadd	d5, d18, d5
	fadd	d18, d17, d5
	fsub	d19, d18, d17
	fsub	d20, d18, d19
	fsub	d17, d17, d20
	fsub	d5, d5, d19
	fadd	d5, d5, d17
	fadd	d4, d4, d5
	mov	d5, v7[1]
	fadd	d7, d5, d6
	fsub	d17, d7, d6
	fsub	d19, d7, d17
	fsub	d6, d6, d19
	fsub	d5, d5, d17
	fadd	d5, d5, d6
	fadd	d6, d18, d5
	fsub	d17, d6, d18
	fsub	d19, d6, d17
	fsub	d18, d18, d19
	fsub	d5, d5, d17
	fadd	d5, d5, d18
	fadd	d4, d4, d5
	mov	d5, v16[1]
	fadd	d16, d5, d7
	fsub	d17, d16, d7
	fsub	d18, d16, d17
	fsub	d7, d7, d18
	fsub	d5, d5, d17
	fadd	d5, d5, d7
	fadd	d7, d6, d5
	fsub	d17, d7, d6
	fsub	d18, d7, d17
	fsub	d6, d6, d18
	fsub	d5, d5, d17
	fadd	d5, d5, d6
	fadd	d4, d4, d5
	mov	d3, v3[1]
	fadd	d5, d3, d16
	fsub	d6, d5, d16
	fsub	d17, d5, d6
	fsub	d16, d16, d17
	fsub	d3, d3, d6
	fadd	d3, d3, d16
	fadd	d6, d7, d3
	fsub	d16, d6, d7
	fsub	d17, d6, d16
	fsub	d7, d7, d17
	fsub	d3, d3, d16
	fadd	d3, d3, d7
	fadd	d3, d4, d3
	fadd	d4, d2, d5
	fsub	d7, d4, d5
	fsub	d16, d4, d7
	fsub	d5, d5, d16
	fsub	d7, d2, d7
	fadd	d5, d7, d5
	fadd	d7, d6, d5
	fsub	d16, d7, d6
	fsub	d17, d7, d16
	fsub	d6, d6, d17
	fsub	d5, d5, d16
	fadd	d5, d5, d6
	fadd	d3, d3, d5
	fadd	d5, d1, d4
	fsub	d6, d5, d4
	fsub	d16, d5, d6
	fsub	d4, d4, d16
	fsub	d6, d1, d6
	fadd	d4, d6, d4
	fadd	d6, d7, d4
	fsub	d16, d6, d7
	fsub	d17, d6, d16
	fsub	d7, d7, d17
	fsub	d4, d4, d16
	fadd	d4, d4, d7
	fadd	d3, d3, d4
	fadd	d4, d0, d5
	fsub	d7, d4, d5
	fsub	d16, d4, d7
	fsub	d5, d5, d16
	fsub	d7, d0, d7
	fadd	d5, d7, d5
	fadd	d7, d6, d5
	fsub	d16, d7, d6
	fsub	d17, d7, d16
	fsub	d6, d6, d17
	fsub	d5, d5, d16
	fadd	d5, d5, d6
	fadd	d3, d3, d5
	mov	d2, v2[1]
	fadd	d5, d2, d4
	fsub	d6, d5, d4
	fsub	d16, d5, d6
	fsub	d4, d4, d16
	fsub	d2, d2, d6
	fadd	d2, d2, d4
	fadd	d4, d7, d2
	fsub	d6, d4, d7
	fsub	d16, d4, d6
	fsub	d7, d7, d16
	fsub	d2, d2, d6
	fadd	d2, d2, d7
	fadd	d2, d3, d2
	mov	d1, v1[1]
	fadd	d3, d1, d5
	fsub	d6, d3, d5
	fsub	d7, d3, d6
	fsub	d5, d5, d7
	fsub	d1, d1, d6
	fadd	d1, d1, d5
	fadd	d5, d4, d1
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d1, d1, d6
	fadd	d1, d1, d4
	fadd	d1, d2, d1
	mov	d0, v0[1]
	fadd	d2, d0, d3
	fsub	d4, d2, d3
	fsub	d6, d2, d4
	fsub	d3, d3, d6
	fsub	d0, d0, d4
	fadd	d0, d0, d3
	fadd	d3, d5, d0
	fsub	d4, d3, d5
	fsub	d6, d3, d4
	fsub	d5, d5, d6
	fsub	d0, d0, d4
	fadd	d0, d0, d5
	str	d3, [x0, #8]
	fadd	d0, d1, d0
	str	d0, [x0, #16]
	str	d2, [x0]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3VACycfC ; -- Begin function $s7Kernels10VectorDot3VACycfC
	.globl	_$s7Kernels10VectorDot3VACycfC
	.p2align	2
_$s7Kernels10VectorDot3VACycfC:         ; @"$s7Kernels10VectorDot3VACycfC"
; %bb.0:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA_ ; -- Begin function $s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA_
	.globl	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA_
	.p2align	2
_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA_: ; @"$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA0_ ; -- Begin function $s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA0_
	.globl	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA0_
	.p2align	2
_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA0_: ; @"$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA0_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA1_ ; -- Begin function $s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA1_
	.globl	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA1_
	.p2align	2
_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA1_: ; @"$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfcfA1_"
; %bb.0:
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfC ; -- Begin function $s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfC
	.globl	_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfC
	.p2align	2
_$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfC: ; @"$s7Kernels10VectorDot3V4high6middle3lowACs5SIMD4VySdG_A2ItcfC"
; %bb.0:
	stp	q0, q1, [x8]
	stp	q2, q3, [x8, #32]
	stp	q4, q5, [x8, #64]
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels11simdDot3x16ySdSaySdG_ACtF ; -- Begin function $s7Kernels11simdDot3x16ySdSaySdG_ACtF
	.globl	_$s7Kernels11simdDot3x16ySdSaySdG_ACtF
	.p2align	2
_$s7Kernels11simdDot3x16ySdSaySdG_ACtF: ; @"$s7Kernels11simdDot3x16ySdSaySdG_ACtF"
; %bb.0:
	sub	sp, sp, #96
	stp	d15, d14, [sp, #32]             ; 16-byte Folded Spill
	stp	d13, d12, [sp, #48]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #64]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #80]               ; 16-byte Folded Spill
	ldr	x8, [x0, #16]
	cmp	x8, #16
	b.lo	LBB88_5
; %bb.1:
	mov	x9, #0                          ; =0x0
	movi.2d	v31, #0000000000000000
	add	x10, x0, #32
	movi.2d	v29, #0000000000000000
	add	x11, x1, #32
	movi.2d	v8, #0000000000000000
	mov	w12, #32                        ; =0x20
	movi.2d	v30, #0000000000000000
	mov	w13, #16                        ; =0x10
	movi.2d	v26, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v12, #0000000000000000
LBB88_2:                                ; =>This Inner Loop Header: Depth=1
	stp	q13, q12, [sp]                  ; 32-byte Folded Spill
	lsl	x9, x9, #3
	add	x14, x9, #64
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q9, q10, [x15]
	ldp	q11, q12, [x14]
	fmul.2d	v13, v10, v12
	fmul.2d	v14, v9, v11
	fadd.2d	v15, v16, v14
	movi.2d	v2, #0000000000000000
	fsub.2d	v0, v2, v14
	fmla.2d	v0, v11, v9
	fadd.2d	v9, v5, v13
	fsub.2d	v11, v2, v13
	fmla.2d	v11, v12, v10
	fsub.2d	v10, v9, v5
	fsub.2d	v12, v9, v10
	fsub.2d	v12, v5, v12
	fadd.2d	v5, v9, v11
	fsub.2d	v10, v13, v10
	fsub.2d	v13, v15, v16
	fsub.2d	v14, v14, v13
	fsub.2d	v13, v15, v13
	fsub.2d	v13, v16, v13
	fadd.2d	v16, v15, v0
	fadd.2d	v10, v10, v12
	fadd.2d	v12, v14, v13
	fadd.2d	v13, v19, v12
	fsub.2d	v14, v5, v9
	fsub.2d	v11, v11, v14
	fsub.2d	v14, v5, v14
	fsub.2d	v9, v9, v14
	fsub.2d	v14, v16, v15
	fsub.2d	v0, v0, v14
	fsub.2d	v14, v16, v14
	fsub.2d	v14, v15, v14
	fadd.2d	v15, v7, v10
	fadd.2d	v0, v0, v14
	fadd.2d	v9, v11, v9
	fsub.2d	v11, v15, v7
	fsub.2d	v14, v15, v11
	fsub.2d	v14, v7, v14
	fadd.2d	v7, v15, v9
	fsub.2d	v10, v10, v11
	fsub.2d	v11, v13, v19
	fsub.2d	v12, v12, v11
	fsub.2d	v11, v13, v11
	fsub.2d	v11, v19, v11
	fadd.2d	v19, v13, v0
	fadd.2d	v10, v10, v14
	fadd.2d	v11, v12, v11
	fadd.2d	v6, v6, v11
	fadd.2d	v4, v28, v10
	fsub.2d	v10, v19, v13
	fsub.2d	v11, v7, v15
	fsub.2d	v9, v9, v11
	fsub.2d	v0, v0, v10
	fsub.2d	v10, v19, v10
	fsub.2d	v11, v7, v11
	fsub.2d	v11, v15, v11
	fsub.2d	v10, v13, v10
	fadd.2d	v0, v0, v10
	fadd.2d	v9, v9, v11
	fadd.2d	v28, v4, v9
	fadd.2d	v6, v6, v0
	add	x14, x9, #32
	add	x15, x10, x14
	add	x14, x11, x14
	ldp	q0, q9, [x15]
	ldp	q10, q11, [x14]
	fmul.2d	v12, v9, v11
	fmul.2d	v13, v0, v10
	fadd.2d	v14, v25, v13
	fsub.2d	v15, v2, v13
	fmla.2d	v15, v10, v0
	fadd.2d	v0, v22, v12
	fsub.2d	v10, v2, v12
	fmla.2d	v10, v11, v9
	fsub.2d	v9, v0, v22
	fsub.2d	v11, v0, v9
	fsub.2d	v11, v22, v11
	fadd.2d	v22, v0, v10
	fsub.2d	v9, v12, v9
	fsub.2d	v12, v14, v25
	fsub.2d	v13, v13, v12
	fsub.2d	v12, v14, v12
	fsub.2d	v12, v25, v12
	fadd.2d	v25, v14, v15
	fadd.2d	v9, v9, v11
	fadd.2d	v11, v13, v12
	fadd.2d	v12, v27, v11
	fsub.2d	v13, v22, v0
	fsub.2d	v10, v10, v13
	fsub.2d	v13, v22, v13
	fsub.2d	v0, v0, v13
	fsub.2d	v13, v25, v14
	fsub.2d	v15, v15, v13
	fsub.2d	v13, v25, v13
	fsub.2d	v13, v14, v13
	fadd.2d	v14, v23, v9
	fadd.2d	v13, v15, v13
	fadd.2d	v0, v10, v0
	fsub.2d	v10, v14, v23
	fsub.2d	v15, v14, v10
	fsub.2d	v15, v23, v15
	fadd.2d	v23, v14, v0
	fsub.2d	v9, v9, v10
	fsub.2d	v10, v12, v27
	fsub.2d	v11, v11, v10
	fsub.2d	v10, v12, v10
	fsub.2d	v10, v27, v10
	fadd.2d	v27, v12, v13
	fadd.2d	v9, v9, v15
	fadd.2d	v10, v11, v10
	fadd.2d	v21, v21, v10
	fadd.2d	v18, v18, v9
	fsub.2d	v9, v27, v12
	fsub.2d	v10, v23, v14
	fsub.2d	v0, v0, v10
	fsub.2d	v11, v13, v9
	fsub.2d	v9, v27, v9
	fsub.2d	v10, v23, v10
	fsub.2d	v10, v14, v10
	fsub.2d	v9, v12, v9
	fadd.2d	v9, v11, v9
	fadd.2d	v0, v0, v10
	fadd.2d	v18, v18, v0
	fadd.2d	v21, v21, v9
	add	x14, x10, x9
	add	x15, x11, x9
	ldp	q0, q9, [x14]
	ldp	q10, q11, [x15]
	fmul.2d	v12, v9, v11
	fmul.2d	v13, v0, v10
	fadd.2d	v14, v31, v13
	fsub.2d	v15, v2, v13
	fmla.2d	v15, v10, v0
	fadd.2d	v0, v29, v12
	fsub.2d	v10, v2, v12
	fmla.2d	v10, v11, v9
	fsub.2d	v9, v0, v29
	fsub.2d	v11, v0, v9
	fsub.2d	v11, v29, v11
	fadd.2d	v29, v0, v10
	fsub.2d	v9, v12, v9
	fsub.2d	v12, v14, v31
	fsub.2d	v13, v13, v12
	fsub.2d	v12, v14, v12
	fsub.2d	v12, v31, v12
	fadd.2d	v31, v14, v15
	fadd.2d	v9, v9, v11
	fadd.2d	v11, v13, v12
	fadd.2d	v12, v8, v11
	fsub.2d	v13, v29, v0
	fsub.2d	v10, v10, v13
	fsub.2d	v13, v29, v13
	fsub.2d	v0, v0, v13
	fsub.2d	v13, v31, v14
	fsub.2d	v15, v15, v13
	fsub.2d	v13, v31, v13
	fsub.2d	v13, v14, v13
	fadd.2d	v14, v30, v9
	fadd.2d	v13, v15, v13
	fadd.2d	v0, v10, v0
	fsub.2d	v10, v14, v30
	fsub.2d	v15, v14, v10
	fsub.2d	v15, v30, v15
	fadd.2d	v30, v14, v0
	fsub.2d	v9, v9, v10
	fsub.2d	v10, v12, v8
	fsub.2d	v11, v11, v10
	fsub.2d	v10, v12, v10
	fsub.2d	v10, v8, v10
	fadd.2d	v8, v12, v13
	fadd.2d	v9, v9, v15
	fadd.2d	v10, v11, v10
	fadd.2d	v26, v26, v10
	fadd.2d	v24, v24, v9
	fsub.2d	v9, v8, v12
	fsub.2d	v10, v30, v14
	fsub.2d	v0, v0, v10
	fsub.2d	v11, v13, v9
	fsub.2d	v9, v8, v9
	fsub.2d	v10, v30, v10
	fsub.2d	v10, v14, v10
	fsub.2d	v9, v12, v9
	fadd.2d	v9, v11, v9
	fadd.2d	v0, v0, v10
	fadd.2d	v24, v24, v0
	fadd.2d	v26, v26, v9
	add	x9, x9, #96
	add	x14, x10, x9
	add	x9, x11, x9
	ldp	q0, q9, [x14]
	ldp	q10, q11, [x9]
	fmul.2d	v12, v9, v11
	fmul.2d	v13, v0, v10
	fadd.2d	v14, v20, v13
	fsub.2d	v15, v2, v13
	fmla.2d	v15, v10, v0
	fadd.2d	v0, v17, v12
	fsub.2d	v10, v2, v12
	fmla.2d	v10, v11, v9
	fsub.2d	v9, v0, v17
	fsub.2d	v11, v0, v9
	fsub.2d	v11, v17, v11
	fsub.2d	v2, v14, v20
	fsub.2d	v17, v14, v2
	fsub.2d	v4, v20, v17
	fsub.2d	v9, v12, v9
	fadd.2d	v17, v0, v10
	fsub.2d	v2, v13, v2
	fadd.2d	v20, v14, v15
	fadd.2d	v2, v2, v4
	fadd.2d	v4, v9, v11
	fsub.2d	v9, v20, v14
	fsub.2d	v11, v20, v9
	fsub.2d	v11, v14, v11
	fsub.2d	v12, v17, v0
	fsub.2d	v13, v17, v12
	fsub.2d	v0, v0, v13
	fsub.2d	v9, v15, v9
	fadd.2d	v13, v1, v4
	fsub.2d	v10, v10, v12
	fadd.2d	v12, v3, v2
	fadd.2d	v0, v10, v0
	fadd.2d	v9, v9, v11
	fsub.2d	v10, v12, v3
	fsub.2d	v11, v12, v10
	fsub.2d	v11, v3, v11
	fsub.2d	v3, v13, v1
	fsub.2d	v14, v13, v3
	fsub.2d	v1, v1, v14
	fsub.2d	v2, v2, v10
	fsub.2d	v4, v4, v3
	fadd.2d	v3, v12, v9
	fadd.2d	v4, v4, v1
	fadd.2d	v1, v13, v0
	fadd.2d	v2, v2, v11
	ldr	q10, [sp]                       ; 16-byte Folded Reload
	fadd.2d	v2, v10, v2
	ldr	q10, [sp, #16]                  ; 16-byte Folded Reload
	fadd.2d	v4, v10, v4
	fsub.2d	v10, v1, v13
	fsub.2d	v11, v3, v12
	fsub.2d	v14, v1, v10
	fsub.2d	v13, v13, v14
	fsub.2d	v14, v3, v11
	fsub.2d	v12, v12, v14
	fsub.2d	v0, v0, v10
	fsub.2d	v9, v9, v11
	fadd.2d	v9, v9, v12
	fadd.2d	v0, v0, v13
	fadd.2d	v12, v4, v0
	fadd.2d	v13, v2, v9
	mov	x9, x13
	cmp	x8, x12
	b.lt	LBB88_6
; %bb.3:                                ;   in Loop: Header=BB88_2 Depth=1
	mov	x13, x12
	adds	x12, x12, #16
	b.vc	LBB88_2
; %bb.4:
	brk	#0x1
LBB88_5:
	mov	x9, #0                          ; =0x0
	movi.2d	v13, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v29, #0000000000000000
	b	LBB88_7
LBB88_6:
	mov.16b	v14, v28
LBB88_7:
	movi.2d	v0, #0000000000000000
	fadd	d2, d31, d0
	fsub	d4, d2, d2
	fsub	d28, d31, d2
	fadd	d4, d4, d28
	fsub	d28, d4, d4
	fsub	d0, d0, d28
	fadd	d0, d28, d0
	fadd	d28, d8, d2
	fsub	d9, d28, d2
	fsub	d10, d9, d28
	fadd	d2, d2, d10
	fsub	d9, d8, d9
	fadd	d2, d9, d2
	fadd	d9, d4, d2
	fsub	d10, d9, d4
	fsub	d11, d10, d9
	fadd	d4, d4, d11
	fsub	d2, d2, d10
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	fadd	d2, d26, d28
	fsub	d4, d2, d28
	fsub	d10, d4, d2
	fadd	d28, d28, d10
	fsub	d4, d26, d4
	fadd	d4, d4, d28
	fadd	d28, d9, d4
	fsub	d10, d28, d9
	fsub	d11, d10, d28
	fadd	d9, d9, d11
	fsub	d4, d4, d10
	fadd	d4, d4, d9
	fadd	d0, d0, d4
	mov	d4, v31[1]
	fadd	d31, d4, d2
	fsub	d9, d31, d2
	fsub	d10, d9, d31
	fadd	d2, d2, d10
	fsub	d4, d4, d9
	fadd	d2, d4, d2
	fadd	d4, d28, d2
	fsub	d9, d4, d28
	fsub	d10, d9, d4
	fadd	d28, d28, d10
	fsub	d2, d2, d9
	fadd	d2, d2, d28
	fadd	d0, d0, d2
	mov	d2, v8[1]
	fadd	d28, d2, d31
	fsub	d8, d28, d31
	fsub	d9, d8, d28
	fadd	d31, d31, d9
	fsub	d2, d2, d8
	fadd	d2, d2, d31
	fadd	d31, d4, d2
	fsub	d8, d31, d4
	fsub	d9, d8, d31
	fadd	d4, d4, d9
	fsub	d2, d2, d8
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v26[1]
	fadd	d4, d2, d28
	fsub	d26, d4, d28
	fsub	d8, d26, d4
	fadd	d28, d28, d8
	fsub	d2, d2, d26
	fadd	d2, d2, d28
	fadd	d26, d31, d2
	fsub	d28, d26, d31
	fsub	d8, d26, d28
	fsub	d31, d31, d8
	fsub	d2, d2, d28
	fadd	d2, d2, d31
	fadd	d0, d0, d2
	fadd	d2, d29, d4
	fsub	d28, d2, d4
	fsub	d31, d28, d2
	fadd	d4, d4, d31
	fsub	d28, d29, d28
	fadd	d4, d28, d4
	fadd	d28, d26, d4
	fsub	d31, d28, d26
	fsub	d8, d28, d31
	fsub	d26, d26, d8
	fsub	d4, d4, d31
	fadd	d4, d4, d26
	fadd	d0, d0, d4
	fadd	d4, d30, d2
	fsub	d26, d4, d2
	fsub	d31, d4, d26
	fsub	d2, d2, d31
	fsub	d26, d30, d26
	fadd	d2, d26, d2
	fadd	d26, d28, d2
	fsub	d31, d26, d28
	fsub	d8, d26, d31
	fsub	d28, d28, d8
	fsub	d2, d2, d31
	fadd	d2, d2, d28
	fadd	d0, d0, d2
	fadd	d2, d24, d4
	fsub	d28, d2, d4
	fsub	d31, d2, d28
	fsub	d4, d4, d31
	fsub	d28, d24, d28
	fadd	d4, d28, d4
	fadd	d28, d26, d4
	fsub	d31, d28, d26
	fsub	d8, d28, d31
	fsub	d26, d26, d8
	fsub	d4, d4, d31
	fadd	d4, d4, d26
	fadd	d0, d0, d4
	mov	d4, v29[1]
	fadd	d26, d4, d2
	fsub	d29, d26, d2
	fsub	d31, d26, d29
	fsub	d2, d2, d31
	fsub	d4, d4, d29
	fadd	d2, d4, d2
	fadd	d4, d28, d2
	fsub	d29, d4, d28
	fsub	d31, d4, d29
	fsub	d28, d28, d31
	fsub	d2, d2, d29
	fadd	d2, d2, d28
	fadd	d0, d0, d2
	mov	d2, v30[1]
	fadd	d28, d2, d26
	fsub	d29, d28, d26
	fsub	d30, d28, d29
	fsub	d26, d26, d30
	fsub	d2, d2, d29
	fadd	d2, d2, d26
	fadd	d26, d4, d2
	fsub	d29, d26, d4
	fsub	d30, d26, d29
	fsub	d4, d4, d30
	fsub	d2, d2, d29
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v24[1]
	fadd	d4, d2, d28
	fsub	d24, d4, d28
	fsub	d29, d4, d24
	fsub	d28, d28, d29
	fsub	d2, d2, d24
	fadd	d2, d2, d28
	fadd	d24, d26, d2
	fsub	d28, d24, d26
	fsub	d29, d24, d28
	fsub	d26, d26, d29
	fsub	d2, d2, d28
	fadd	d2, d2, d26
	fadd	d0, d0, d2
	fadd	d2, d25, d4
	fsub	d26, d2, d4
	fsub	d28, d2, d26
	fsub	d4, d4, d28
	fsub	d26, d25, d26
	fadd	d4, d26, d4
	fadd	d26, d24, d4
	fsub	d28, d26, d24
	fsub	d29, d26, d28
	fsub	d24, d24, d29
	fsub	d4, d4, d28
	fadd	d4, d4, d24
	fadd	d0, d0, d4
	fadd	d4, d27, d2
	fsub	d24, d4, d2
	fsub	d28, d4, d24
	fsub	d2, d2, d28
	fsub	d24, d27, d24
	fadd	d2, d24, d2
	fadd	d24, d26, d2
	fsub	d28, d24, d26
	fsub	d29, d24, d28
	fsub	d26, d26, d29
	fsub	d2, d2, d28
	fadd	d2, d2, d26
	fadd	d0, d0, d2
	fadd	d2, d21, d4
	fsub	d26, d2, d4
	fsub	d28, d2, d26
	fsub	d4, d4, d28
	fsub	d26, d21, d26
	fadd	d4, d26, d4
	fadd	d26, d24, d4
	fsub	d28, d26, d24
	fsub	d29, d26, d28
	fsub	d24, d24, d29
	fsub	d4, d4, d28
	fadd	d4, d4, d24
	fadd	d0, d0, d4
	mov	d4, v25[1]
	fadd	d24, d4, d2
	fsub	d25, d24, d2
	fsub	d28, d24, d25
	fsub	d2, d2, d28
	fsub	d4, d4, d25
	fadd	d2, d4, d2
	fadd	d4, d26, d2
	fsub	d25, d4, d26
	fsub	d28, d4, d25
	fsub	d26, d26, d28
	fsub	d2, d2, d25
	fadd	d2, d2, d26
	fadd	d0, d0, d2
	mov	d2, v27[1]
	fadd	d25, d2, d24
	fsub	d26, d25, d24
	fsub	d27, d25, d26
	fsub	d24, d24, d27
	fsub	d2, d2, d26
	fadd	d2, d2, d24
	fadd	d24, d4, d2
	fsub	d26, d24, d4
	fsub	d27, d24, d26
	fsub	d4, d4, d27
	fsub	d2, d2, d26
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v21[1]
	fadd	d4, d2, d25
	fsub	d21, d4, d25
	fsub	d26, d4, d21
	fsub	d25, d25, d26
	fsub	d2, d2, d21
	fadd	d2, d2, d25
	fadd	d21, d24, d2
	fsub	d25, d21, d24
	fsub	d26, d21, d25
	fsub	d24, d24, d26
	fsub	d2, d2, d25
	fadd	d2, d2, d24
	fadd	d0, d0, d2
	fadd	d2, d22, d4
	fsub	d24, d2, d4
	fsub	d25, d2, d24
	fsub	d4, d4, d25
	fsub	d24, d22, d24
	fadd	d4, d24, d4
	fadd	d24, d21, d4
	fsub	d25, d24, d21
	fsub	d26, d24, d25
	fsub	d21, d21, d26
	fsub	d4, d4, d25
	fadd	d4, d4, d21
	fadd	d0, d0, d4
	fadd	d4, d23, d2
	fsub	d21, d4, d2
	fsub	d25, d4, d21
	fsub	d2, d2, d25
	fsub	d21, d23, d21
	fadd	d2, d21, d2
	fadd	d21, d24, d2
	fsub	d25, d21, d24
	fsub	d26, d21, d25
	fsub	d24, d24, d26
	fsub	d2, d2, d25
	fadd	d2, d2, d24
	fadd	d0, d0, d2
	fadd	d2, d18, d4
	fsub	d24, d2, d4
	fsub	d25, d2, d24
	fsub	d4, d4, d25
	fsub	d24, d18, d24
	fadd	d4, d24, d4
	fadd	d24, d21, d4
	fsub	d25, d24, d21
	fsub	d26, d24, d25
	fsub	d21, d21, d26
	fsub	d4, d4, d25
	fadd	d4, d4, d21
	fadd	d0, d0, d4
	mov	d4, v22[1]
	fadd	d21, d4, d2
	fsub	d22, d21, d2
	fsub	d25, d21, d22
	fsub	d2, d2, d25
	fsub	d4, d4, d22
	fadd	d2, d4, d2
	fadd	d4, d24, d2
	fsub	d22, d4, d24
	fsub	d25, d4, d22
	fsub	d24, d24, d25
	fsub	d2, d2, d22
	fadd	d2, d2, d24
	fadd	d0, d0, d2
	mov	d2, v23[1]
	fadd	d22, d2, d21
	fsub	d23, d22, d21
	fsub	d24, d22, d23
	fsub	d21, d21, d24
	fsub	d2, d2, d23
	fadd	d2, d2, d21
	fadd	d21, d4, d2
	fsub	d23, d21, d4
	fsub	d24, d21, d23
	fsub	d4, d4, d24
	fsub	d2, d2, d23
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v18[1]
	fadd	d4, d2, d22
	fsub	d18, d4, d22
	fsub	d23, d4, d18
	fsub	d22, d22, d23
	fsub	d2, d2, d18
	fadd	d2, d2, d22
	fadd	d18, d21, d2
	fsub	d22, d18, d21
	fsub	d23, d18, d22
	fsub	d21, d21, d23
	fsub	d2, d2, d22
	fadd	d2, d2, d21
	fadd	d0, d0, d2
	fadd	d2, d16, d4
	fsub	d21, d2, d4
	fsub	d22, d2, d21
	fsub	d4, d4, d22
	fsub	d21, d16, d21
	fadd	d4, d21, d4
	fadd	d21, d18, d4
	fsub	d22, d21, d18
	fsub	d23, d21, d22
	fsub	d18, d18, d23
	fsub	d4, d4, d22
	fadd	d4, d4, d18
	fadd	d0, d0, d4
	fadd	d4, d19, d2
	fsub	d18, d4, d2
	fsub	d22, d4, d18
	fsub	d2, d2, d22
	fsub	d18, d19, d18
	fadd	d2, d18, d2
	fadd	d18, d21, d2
	fsub	d22, d18, d21
	fsub	d23, d18, d22
	fsub	d21, d21, d23
	fsub	d2, d2, d22
	fadd	d2, d2, d21
	fadd	d0, d0, d2
	fadd	d2, d6, d4
	fsub	d21, d2, d4
	fsub	d22, d2, d21
	fsub	d4, d4, d22
	fsub	d21, d6, d21
	fadd	d4, d21, d4
	fadd	d21, d18, d4
	fsub	d22, d21, d18
	fsub	d23, d21, d22
	fsub	d18, d18, d23
	fsub	d4, d4, d22
	fadd	d4, d4, d18
	fadd	d0, d0, d4
	mov	d4, v16[1]
	fadd	d16, d4, d2
	fsub	d18, d16, d2
	fsub	d22, d16, d18
	fsub	d2, d2, d22
	fsub	d4, d4, d18
	fadd	d2, d4, d2
	fadd	d4, d21, d2
	fsub	d18, d4, d21
	fsub	d22, d4, d18
	fsub	d21, d21, d22
	fsub	d2, d2, d18
	fadd	d2, d2, d21
	fadd	d0, d0, d2
	mov	d2, v19[1]
	fadd	d18, d2, d16
	fsub	d19, d18, d16
	fsub	d21, d18, d19
	fsub	d16, d16, d21
	fsub	d2, d2, d19
	fadd	d2, d2, d16
	fadd	d16, d4, d2
	fsub	d19, d16, d4
	fsub	d21, d16, d19
	fsub	d4, d4, d21
	fsub	d2, d2, d19
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v6[1]
	fadd	d4, d2, d18
	fsub	d6, d4, d18
	fsub	d19, d4, d6
	fsub	d18, d18, d19
	fsub	d2, d2, d6
	fadd	d2, d2, d18
	fadd	d6, d16, d2
	fsub	d18, d6, d16
	fsub	d19, d6, d18
	fsub	d16, d16, d19
	fsub	d2, d2, d18
	fadd	d2, d2, d16
	fadd	d0, d0, d2
	fadd	d2, d5, d4
	fsub	d16, d2, d4
	fsub	d18, d2, d16
	fsub	d4, d4, d18
	fsub	d16, d5, d16
	fadd	d4, d16, d4
	fadd	d16, d6, d4
	fsub	d18, d16, d6
	fsub	d19, d16, d18
	fsub	d6, d6, d19
	fsub	d4, d4, d18
	fadd	d4, d4, d6
	fadd	d0, d0, d4
	fadd	d4, d7, d2
	fsub	d6, d4, d2
	fsub	d18, d4, d6
	fsub	d2, d2, d18
	fsub	d6, d7, d6
	fadd	d2, d6, d2
	fadd	d6, d16, d2
	fsub	d18, d6, d16
	fsub	d19, d6, d18
	fsub	d16, d16, d19
	fsub	d2, d2, d18
	fadd	d2, d2, d16
	fadd	d0, d0, d2
	fadd	d2, d14, d4
	fsub	d16, d2, d4
	fsub	d18, d2, d16
	fsub	d4, d4, d18
	fsub	d16, d14, d16
	fadd	d4, d16, d4
	fadd	d16, d6, d4
	fsub	d18, d16, d6
	fsub	d19, d16, d18
	fsub	d6, d6, d19
	fsub	d4, d4, d18
	fadd	d4, d4, d6
	fadd	d0, d0, d4
	mov	d4, v5[1]
	fadd	d5, d4, d2
	fsub	d6, d5, d2
	fsub	d18, d5, d6
	fsub	d2, d2, d18
	fsub	d4, d4, d6
	fadd	d2, d4, d2
	fadd	d4, d16, d2
	fsub	d6, d4, d16
	fsub	d18, d4, d6
	fsub	d16, d16, d18
	fsub	d2, d2, d6
	fadd	d2, d2, d16
	fadd	d0, d0, d2
	mov	d2, v7[1]
	fadd	d6, d2, d5
	fsub	d7, d6, d5
	fsub	d16, d6, d7
	fsub	d5, d5, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d5
	fadd	d5, d4, d2
	fsub	d7, d5, d4
	fsub	d16, d5, d7
	fsub	d4, d4, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v14[1]
	fadd	d4, d2, d6
	fsub	d7, d4, d6
	fsub	d16, d4, d7
	fsub	d6, d6, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d6
	fadd	d6, d5, d2
	fsub	d7, d6, d5
	fsub	d16, d6, d7
	fsub	d5, d5, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d5
	fadd	d0, d0, d2
	fadd	d2, d20, d4
	fsub	d5, d2, d4
	fsub	d7, d2, d5
	fsub	d4, d4, d7
	fsub	d5, d20, d5
	fadd	d4, d5, d4
	fadd	d5, d6, d4
	fsub	d7, d5, d6
	fsub	d16, d5, d7
	fsub	d6, d6, d16
	fsub	d4, d4, d7
	fadd	d4, d4, d6
	fadd	d0, d0, d4
	fadd	d4, d3, d2
	fsub	d6, d4, d2
	fsub	d7, d4, d6
	fsub	d2, d2, d7
	fsub	d6, d3, d6
	fadd	d2, d6, d2
	fadd	d6, d5, d2
	fsub	d7, d6, d5
	fsub	d16, d6, d7
	fsub	d5, d5, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d5
	fadd	d0, d0, d2
	fadd	d2, d13, d4
	fsub	d5, d2, d4
	fsub	d7, d2, d5
	fsub	d4, d4, d7
	fsub	d5, d13, d5
	fadd	d4, d5, d4
	fadd	d5, d6, d4
	fsub	d7, d5, d6
	fsub	d16, d5, d7
	fsub	d6, d6, d16
	fsub	d4, d4, d7
	fadd	d4, d4, d6
	fadd	d0, d0, d4
	mov	d4, v20[1]
	fadd	d6, d4, d2
	fsub	d7, d6, d2
	fsub	d16, d6, d7
	fsub	d2, d2, d16
	fsub	d4, d4, d7
	fadd	d2, d4, d2
	fadd	d4, d5, d2
	fsub	d7, d4, d5
	fsub	d16, d4, d7
	fsub	d5, d5, d16
	fsub	d2, d2, d7
	fadd	d2, d2, d5
	fadd	d0, d0, d2
	mov	d2, v3[1]
	fadd	d3, d2, d6
	fsub	d5, d3, d6
	fsub	d7, d3, d5
	fsub	d6, d6, d7
	fsub	d2, d2, d5
	fadd	d2, d2, d6
	fadd	d5, d4, d2
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d2, d2, d6
	fadd	d2, d2, d4
	fadd	d0, d0, d2
	mov	d2, v13[1]
	fadd	d4, d2, d3
	fsub	d6, d4, d3
	fsub	d7, d4, d6
	fsub	d3, d3, d7
	fsub	d2, d2, d6
	fadd	d2, d2, d3
	fadd	d3, d5, d2
	fsub	d6, d3, d5
	fsub	d7, d3, d6
	fsub	d5, d5, d7
	fsub	d2, d2, d6
	fadd	d2, d2, d5
	fadd	d0, d0, d2
	fadd	d2, d17, d4
	fsub	d5, d2, d4
	fsub	d6, d2, d5
	fsub	d4, d4, d6
	fsub	d5, d17, d5
	fadd	d4, d5, d4
	fadd	d5, d3, d4
	fsub	d6, d5, d3
	fsub	d7, d5, d6
	fsub	d3, d3, d7
	fsub	d4, d4, d6
	fadd	d3, d4, d3
	fadd	d0, d0, d3
	fadd	d3, d1, d2
	fsub	d4, d3, d2
	fsub	d6, d3, d4
	fsub	d2, d2, d6
	fsub	d4, d1, d4
	fadd	d2, d4, d2
	fadd	d4, d5, d2
	fsub	d6, d4, d5
	fsub	d7, d4, d6
	fsub	d5, d5, d7
	fsub	d2, d2, d6
	fadd	d2, d2, d5
	fadd	d0, d0, d2
	fadd	d2, d12, d3
	fsub	d5, d2, d3
	fsub	d6, d2, d5
	fsub	d3, d3, d6
	fsub	d5, d12, d5
	fadd	d3, d5, d3
	fadd	d5, d4, d3
	fsub	d6, d5, d4
	fsub	d7, d5, d6
	fsub	d4, d4, d7
	fsub	d3, d3, d6
	fadd	d3, d3, d4
	fadd	d0, d0, d3
	mov	d3, v17[1]
	fadd	d4, d3, d2
	fsub	d6, d4, d2
	fsub	d7, d4, d6
	fsub	d2, d2, d7
	fsub	d3, d3, d6
	fadd	d2, d3, d2
	fadd	d3, d5, d2
	fsub	d6, d3, d5
	fsub	d7, d3, d6
	fsub	d5, d5, d7
	fsub	d2, d2, d6
	fadd	d2, d2, d5
	fadd	d0, d0, d2
	mov	d1, v1[1]
	fadd	d2, d1, d4
	fsub	d5, d2, d4
	fsub	d6, d2, d5
	fsub	d4, d4, d6
	fsub	d1, d1, d5
	fadd	d1, d1, d4
	fadd	d4, d3, d1
	fsub	d5, d4, d3
	fsub	d6, d4, d5
	fsub	d3, d3, d6
	fsub	d1, d1, d5
	fadd	d1, d1, d3
	fadd	d3, d0, d1
	mov	d1, v12[1]
	fadd	d0, d1, d2
	fsub	d5, d0, d2
	fsub	d6, d0, d5
	fsub	d2, d2, d6
	fsub	d1, d1, d5
	fadd	d2, d1, d2
	fadd	d1, d4, d2
	fsub	d5, d1, d4
	fsub	d6, d1, d5
	fsub	d4, d4, d6
	fsub	d2, d2, d5
	fadd	d2, d2, d4
	fadd	d2, d3, d2
	subs	x8, x8, x9
	b.le	LBB88_10
; %bb.8:
	lsl	x9, x9, #3
	add	x10, x9, #32
	add	x9, x1, x10
	add	x10, x0, x10
LBB88_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	d3, [x10], #8
	ldr	d4, [x9], #8
	fmul	d5, d3, d4
	fadd	d6, d0, d5
	fsub	d7, d6, d0
	fsub	d16, d6, d7
	fsub	d0, d0, d16
	fsub	d7, d5, d7
	fadd	d0, d7, d0
	fadd	d7, d1, d0
	fsub	d16, d7, d1
	fsub	d17, d7, d16
	fsub	d1, d1, d17
	fsub	d0, d0, d16
	fadd	d0, d0, d1
	fadd	d2, d2, d0
	fnmsub	d1, d3, d4, d5
	fadd	d0, d6, d1
	fsub	d3, d0, d6
	fsub	d4, d0, d3
	fsub	d4, d6, d4
	fsub	d1, d1, d3
	fadd	d3, d1, d4
	fadd	d1, d7, d3
	fsub	d4, d1, d7
	fsub	d5, d1, d4
	fsub	d5, d7, d5
	fsub	d3, d3, d4
	fadd	d3, d3, d5
	fadd	d2, d2, d3
	subs	x8, x8, #1
	b.ne	LBB88_9
LBB88_10:
	fadd	d3, d1, d0
	fsub	d4, d3, d0
	fsub	d5, d3, d4
	fsub	d0, d0, d5
	fsub	d1, d1, d4
	fadd	d0, d1, d0
	fadd	d0, d2, d0
	fadd	d0, d3, d0
	ldp	d9, d8, [sp, #80]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #64]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #48]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy16_8     ; -- Begin function __swift_memcpy16_8
	.globl	___swift_memcpy16_8
	.weak_definition	___swift_memcpy16_8
	.p2align	2
___swift_memcpy16_8:                    ; @__swift_memcpy16_8
; %bb.0:
	ldr	q0, [x1]
	str	q0, [x0]
	ret
                                        ; -- End function
	.private_extern	___swift_noop_void_return ; -- Begin function __swift_noop_void_return
	.globl	___swift_noop_void_return
	.weak_definition	___swift_noop_void_return
	.p2align	2
___swift_noop_void_return:              ; @__swift_noop_void_return
; %bb.0:
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot2Vwet
_$s7Kernels10ScalarDot2Vwet:            ; @"$s7Kernels10ScalarDot2Vwet"
; %bb.0:
	cbz	w1, LBB91_3
; %bb.1:
	ldrb	w8, [x0, #16]
	cbz	w8, LBB91_3
; %bb.2:
	ldr	w8, [x0]
	add	w0, w8, #1
	ret
LBB91_3:
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot2Vwst
_$s7Kernels10ScalarDot2Vwst:            ; @"$s7Kernels10ScalarDot2Vwst"
; %bb.0:
	cbz	w1, LBB92_3
; %bb.1:
	sub	w8, w1, #1
	stp	x8, xzr, [x0]
	cbz	w2, LBB92_6
; %bb.2:
	mov	w8, #1                          ; =0x1
	b	LBB92_5
LBB92_3:
	cbz	w2, LBB92_6
; %bb.4:
	mov	w8, #0                          ; =0x0
LBB92_5:
	strb	w8, [x0, #16]
LBB92_6:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot2VMa ; -- Begin function $s7Kernels10ScalarDot2VMa
	.globl	_$s7Kernels10ScalarDot2VMa
	.p2align	2
_$s7Kernels10ScalarDot2VMa:             ; @"$s7Kernels10ScalarDot2VMa"
; %bb.0:
Lloh20:
	adrp	x0, _$s7Kernels10ScalarDot2VMf@PAGE+16
Lloh21:
	add	x0, x0, _$s7Kernels10ScalarDot2VMf@PAGEOFF+16
	mov	x1, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh20, Lloh21
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot2VwCP
_$s7Kernels10VectorDot2VwCP:            ; @"$s7Kernels10VectorDot2VwCP"
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	ldr	x19, [x1]
	str	x19, [x0]
	mov	x0, x19
	bl	_swift_retain
	add	x0, x19, #16
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy64_16    ; -- Begin function __swift_memcpy64_16
	.globl	___swift_memcpy64_16
	.weak_definition	___swift_memcpy64_16
	.p2align	2
___swift_memcpy64_16:                   ; @__swift_memcpy64_16
; %bb.0:
	ldp	q0, q1, [x1]
	ldp	q2, q3, [x1, #32]
	stp	q2, q3, [x0, #32]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot2Vwet
_$s7Kernels10VectorDot2Vwet:            ; @"$s7Kernels10VectorDot2Vwet"
; %bb.0:
	cbz	w1, LBB96_3
; %bb.1:
	ldrb	w8, [x0, #64]
	cbz	w8, LBB96_3
; %bb.2:
	ldr	w8, [x0]
	add	w0, w8, #1
	ret
LBB96_3:
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot2Vwst
_$s7Kernels10VectorDot2Vwst:            ; @"$s7Kernels10VectorDot2Vwst"
; %bb.0:
	cbz	w1, LBB97_3
; %bb.1:
	sub	w8, w1, #1
	str	x8, [x0]
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #8]
	stur	q0, [x0, #24]
	stur	q0, [x0, #40]
	str	xzr, [x0, #56]
	cbz	w2, LBB97_6
; %bb.2:
	mov	w8, #1                          ; =0x1
	b	LBB97_5
LBB97_3:
	cbz	w2, LBB97_6
; %bb.4:
	mov	w8, #0                          ; =0x0
LBB97_5:
	strb	w8, [x0, #64]
LBB97_6:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot2VMa ; -- Begin function $s7Kernels10VectorDot2VMa
	.globl	_$s7Kernels10VectorDot2VMa
	.p2align	2
_$s7Kernels10VectorDot2VMa:             ; @"$s7Kernels10VectorDot2VMa"
; %bb.0:
Lloh22:
	adrp	x0, _$s7Kernels10VectorDot2VMf@PAGE+16
Lloh23:
	add	x0, x0, _$s7Kernels10VectorDot2VMf@PAGEOFF+16
	mov	x1, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh22, Lloh23
                                        ; -- End function
	.private_extern	___swift_memcpy24_8     ; -- Begin function __swift_memcpy24_8
	.globl	___swift_memcpy24_8
	.weak_definition	___swift_memcpy24_8
	.p2align	2
___swift_memcpy24_8:                    ; @__swift_memcpy24_8
; %bb.0:
	ldr	q0, [x1]
	ldr	x8, [x1, #16]
	str	x8, [x0, #16]
	str	q0, [x0]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot3Vwet
_$s7Kernels10ScalarDot3Vwet:            ; @"$s7Kernels10ScalarDot3Vwet"
; %bb.0:
	cbz	w1, LBB100_3
; %bb.1:
	ldrb	w8, [x0, #24]
	cbz	w8, LBB100_3
; %bb.2:
	ldr	w8, [x0]
	add	w0, w8, #1
	ret
LBB100_3:
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10ScalarDot3Vwst
_$s7Kernels10ScalarDot3Vwst:            ; @"$s7Kernels10ScalarDot3Vwst"
; %bb.0:
	cbz	w1, LBB101_3
; %bb.1:
	sub	w8, w1, #1
	stp	xzr, xzr, [x0, #8]
	str	x8, [x0]
	cbz	w2, LBB101_6
; %bb.2:
	mov	w8, #1                          ; =0x1
	b	LBB101_5
LBB101_3:
	cbz	w2, LBB101_6
; %bb.4:
	mov	w8, #0                          ; =0x0
LBB101_5:
	strb	w8, [x0, #24]
LBB101_6:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10ScalarDot3VMa ; -- Begin function $s7Kernels10ScalarDot3VMa
	.globl	_$s7Kernels10ScalarDot3VMa
	.p2align	2
_$s7Kernels10ScalarDot3VMa:             ; @"$s7Kernels10ScalarDot3VMa"
; %bb.0:
Lloh24:
	adrp	x0, _$s7Kernels10ScalarDot3VMf@PAGE+16
Lloh25:
	add	x0, x0, _$s7Kernels10ScalarDot3VMf@PAGEOFF+16
	mov	x1, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh24, Lloh25
                                        ; -- End function
	.private_extern	___swift_memcpy96_16    ; -- Begin function __swift_memcpy96_16
	.globl	___swift_memcpy96_16
	.weak_definition	___swift_memcpy96_16
	.p2align	2
___swift_memcpy96_16:                   ; @__swift_memcpy96_16
; %bb.0:
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	ldp	q0, q1, [x1, #32]
	ldp	q2, q3, [x1, #64]
	stp	q2, q3, [x0, #64]
	stp	q0, q1, [x0, #32]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot3Vwet
_$s7Kernels10VectorDot3Vwet:            ; @"$s7Kernels10VectorDot3Vwet"
; %bb.0:
	cbz	w1, LBB104_3
; %bb.1:
	ldrb	w8, [x0, #96]
	cbz	w8, LBB104_3
; %bb.2:
	ldr	w8, [x0]
	add	w0, w8, #1
	ret
LBB104_3:
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot3Vwst
_$s7Kernels10VectorDot3Vwst:            ; @"$s7Kernels10VectorDot3Vwst"
; %bb.0:
	cbz	w1, LBB105_3
; %bb.1:
	sub	w8, w1, #1
	str	x8, [x0]
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #8]
	stur	q0, [x0, #24]
	stur	q0, [x0, #40]
	stur	q0, [x0, #56]
	stur	q0, [x0, #72]
	str	xzr, [x0, #88]
	cbz	w2, LBB105_6
; %bb.2:
	mov	w8, #1                          ; =0x1
	b	LBB105_5
LBB105_3:
	cbz	w2, LBB105_6
; %bb.4:
	mov	w8, #0                          ; =0x0
LBB105_5:
	strb	w8, [x0, #96]
LBB105_6:
	ret
                                        ; -- End function
	.private_extern	_$s7Kernels10VectorDot3VMa ; -- Begin function $s7Kernels10VectorDot3VMa
	.globl	_$s7Kernels10VectorDot3VMa
	.p2align	2
_$s7Kernels10VectorDot3VMa:             ; @"$s7Kernels10VectorDot3VMa"
; %bb.0:
Lloh26:
	adrp	x0, _$s7Kernels10VectorDot3VMf@PAGE+16
Lloh27:
	add	x0, x0, _$s7Kernels10VectorDot3VMf@PAGEOFF+16
	mov	x1, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh26, Lloh27
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s7Kernels10VectorDot3VwCP
_$s7Kernels10VectorDot3VwCP:            ; @"$s7Kernels10VectorDot3VwCP"
; %bb.0:
	b	_$s7Kernels10VectorDot2VwCP
                                        ; -- End function
	.section	__TEXT,__swift5_entry,regular,no_dead_strip
	.p2align	2, 0x0                          ; @"\01l_entry_point"
l_entry_point:
	.long	_main-l_entry_point
	.long	0                               ; 0x0

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10ScalarDot2VWV"
_$s7Kernels10ScalarDot2VWV:
	.quad	___swift_memcpy16_8
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy16_8
	.quad	___swift_memcpy16_8
	.quad	___swift_memcpy16_8
	.quad	___swift_memcpy16_8
	.quad	_$s7Kernels10ScalarDot2Vwet
	.quad	_$s7Kernels10ScalarDot2Vwst
	.quad	16                              ; 0x10
	.quad	16                              ; 0x10
	.long	7                               ; 0x7
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.7.Kernels:                       ; @.str.7.Kernels
	.asciz	"Kernels"

	.private_extern	_$s7KernelsMXM          ; @"$s7KernelsMXM"
	.section	__TEXT,__constg_swiftt
	.globl	_$s7KernelsMXM
	.weak_definition	_$s7KernelsMXM
	.p2align	2, 0x0
_$s7KernelsMXM:
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	l_.str.7.Kernels-_$s7KernelsMXM-8

	.section	__TEXT,__const
l_.str.10.ScalarDot2:                   ; @.str.10.ScalarDot2
	.asciz	"ScalarDot2"

	.private_extern	_$s7Kernels10ScalarDot2VMn ; @"$s7Kernels10ScalarDot2VMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s7Kernels10ScalarDot2VMn
	.p2align	2, 0x0
_$s7Kernels10ScalarDot2VMn:
	.long	81                              ; 0x51
	.long	_$s7KernelsMXM-_$s7Kernels10ScalarDot2VMn-4
	.long	l_.str.10.ScalarDot2-_$s7Kernels10ScalarDot2VMn-8
	.long	_$s7Kernels10ScalarDot2VMa-_$s7Kernels10ScalarDot2VMn-12
	.long	_$s7Kernels10ScalarDot2VMF-_$s7Kernels10ScalarDot2VMn-16
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10ScalarDot2VMf"
_$s7Kernels10ScalarDot2VMf:
	.quad	0
	.quad	_$s7Kernels10ScalarDot2VWV
	.quad	512                             ; 0x200
	.quad	_$s7Kernels10ScalarDot2VMn
	.long	0                               ; 0x0
	.long	8                               ; 0x8

	.private_extern	"_symbolic _____ 7Kernels10ScalarDot2V" ; @"symbolic _____ 7Kernels10ScalarDot2V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 7Kernels10ScalarDot2V"
	.weak_definition	"_symbolic _____ 7Kernels10ScalarDot2V"
	.p2align	1, 0x0
"_symbolic _____ 7Kernels10ScalarDot2V":
	.byte	1                               ; 0x1
	.long	_$s7Kernels10ScalarDot2VMn-"_symbolic _____ 7Kernels10ScalarDot2V"-1
	.byte	0                               ; 0x0

	.private_extern	"_symbolic Sd"          ; @"symbolic Sd"
	.globl	"_symbolic Sd"
	.weak_definition	"_symbolic Sd"
	.p2align	1, 0x0
"_symbolic Sd":
	.ascii	"Sd"
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_reflstr
l___unnamed_1:                          ; @0
	.asciz	"high"

l___unnamed_2:                          ; @1
	.asciz	"low"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s7Kernels10ScalarDot2VMF"
_$s7Kernels10ScalarDot2VMF:
	.long	"_symbolic _____ 7Kernels10ScalarDot2V"-_$s7Kernels10ScalarDot2VMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	"_symbolic Sd"-_$s7Kernels10ScalarDot2VMF-20
	.long	l___unnamed_1-_$s7Kernels10ScalarDot2VMF-24
	.long	2                               ; 0x2
	.long	"_symbolic Sd"-_$s7Kernels10ScalarDot2VMF-32
	.long	l___unnamed_2-_$s7Kernels10ScalarDot2VMF-36

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10VectorDot2VWV"
_$s7Kernels10VectorDot2VWV:
	.quad	_$s7Kernels10VectorDot2VwCP
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	_$s7Kernels10VectorDot2Vwet
	.quad	_$s7Kernels10VectorDot2Vwst
	.quad	64                              ; 0x40
	.quad	64                              ; 0x40
	.long	131087                          ; 0x2000f
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.10.VectorDot2:                   ; @.str.10.VectorDot2
	.asciz	"VectorDot2"

	.private_extern	_$s7Kernels10VectorDot2VMn ; @"$s7Kernels10VectorDot2VMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s7Kernels10VectorDot2VMn
	.p2align	2, 0x0
_$s7Kernels10VectorDot2VMn:
	.long	81                              ; 0x51
	.long	_$s7KernelsMXM-_$s7Kernels10VectorDot2VMn-4
	.long	l_.str.10.VectorDot2-_$s7Kernels10VectorDot2VMn-8
	.long	_$s7Kernels10VectorDot2VMa-_$s7Kernels10VectorDot2VMn-12
	.long	_$s7Kernels10VectorDot2VMF-_$s7Kernels10VectorDot2VMn-16
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10VectorDot2VMf"
_$s7Kernels10VectorDot2VMf:
	.quad	0
	.quad	_$s7Kernels10VectorDot2VWV
	.quad	512                             ; 0x200
	.quad	_$s7Kernels10VectorDot2VMn
	.long	0                               ; 0x0
	.long	32                              ; 0x20

	.private_extern	"_symbolic _____ 7Kernels10VectorDot2V" ; @"symbolic _____ 7Kernels10VectorDot2V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 7Kernels10VectorDot2V"
	.weak_definition	"_symbolic _____ 7Kernels10VectorDot2V"
	.p2align	1, 0x0
"_symbolic _____ 7Kernels10VectorDot2V":
	.byte	1                               ; 0x1
	.long	_$s7Kernels10VectorDot2VMn-"_symbolic _____ 7Kernels10VectorDot2V"-1
	.byte	0                               ; 0x0

	.private_extern	"_symbolic _____ySdG s5SIMD4V" ; @"symbolic _____ySdG s5SIMD4V"
	.globl	"_symbolic _____ySdG s5SIMD4V"
	.weak_definition	"_symbolic _____ySdG s5SIMD4V"
	.p2align	1, 0x0
"_symbolic _____ySdG s5SIMD4V":
	.byte	2                               ; 0x2
Ltmp0:
	.long	_$ss5SIMD4VMn@GOT-Ltmp0
	.ascii	"ySdG"
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s7Kernels10VectorDot2VMF"
_$s7Kernels10VectorDot2VMF:
	.long	"_symbolic _____ 7Kernels10VectorDot2V"-_$s7Kernels10VectorDot2VMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	"_symbolic _____ySdG s5SIMD4V"-_$s7Kernels10VectorDot2VMF-20
	.long	l___unnamed_1-_$s7Kernels10VectorDot2VMF-24
	.long	2                               ; 0x2
	.long	"_symbolic _____ySdG s5SIMD4V"-_$s7Kernels10VectorDot2VMF-32
	.long	l___unnamed_2-_$s7Kernels10VectorDot2VMF-36

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10ScalarDot3VWV"
_$s7Kernels10ScalarDot3VWV:
	.quad	___swift_memcpy24_8
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy24_8
	.quad	___swift_memcpy24_8
	.quad	___swift_memcpy24_8
	.quad	___swift_memcpy24_8
	.quad	_$s7Kernels10ScalarDot3Vwet
	.quad	_$s7Kernels10ScalarDot3Vwst
	.quad	24                              ; 0x18
	.quad	24                              ; 0x18
	.long	7                               ; 0x7
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.10.ScalarDot3:                   ; @.str.10.ScalarDot3
	.asciz	"ScalarDot3"

	.private_extern	_$s7Kernels10ScalarDot3VMn ; @"$s7Kernels10ScalarDot3VMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s7Kernels10ScalarDot3VMn
	.p2align	2, 0x0
_$s7Kernels10ScalarDot3VMn:
	.long	81                              ; 0x51
	.long	_$s7KernelsMXM-_$s7Kernels10ScalarDot3VMn-4
	.long	l_.str.10.ScalarDot3-_$s7Kernels10ScalarDot3VMn-8
	.long	_$s7Kernels10ScalarDot3VMa-_$s7Kernels10ScalarDot3VMn-12
	.long	_$s7Kernels10ScalarDot3VMF-_$s7Kernels10ScalarDot3VMn-16
	.long	3                               ; 0x3
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10ScalarDot3VMf"
_$s7Kernels10ScalarDot3VMf:
	.quad	0
	.quad	_$s7Kernels10ScalarDot3VWV
	.quad	512                             ; 0x200
	.quad	_$s7Kernels10ScalarDot3VMn
	.long	0                               ; 0x0
	.long	8                               ; 0x8
	.long	16                              ; 0x10
	.space	4

	.private_extern	"_symbolic _____ 7Kernels10ScalarDot3V" ; @"symbolic _____ 7Kernels10ScalarDot3V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 7Kernels10ScalarDot3V"
	.weak_definition	"_symbolic _____ 7Kernels10ScalarDot3V"
	.p2align	1, 0x0
"_symbolic _____ 7Kernels10ScalarDot3V":
	.byte	1                               ; 0x1
	.long	_$s7Kernels10ScalarDot3VMn-"_symbolic _____ 7Kernels10ScalarDot3V"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_reflstr
l___unnamed_3:                          ; @2
	.asciz	"middle"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s7Kernels10ScalarDot3VMF"
_$s7Kernels10ScalarDot3VMF:
	.long	"_symbolic _____ 7Kernels10ScalarDot3V"-_$s7Kernels10ScalarDot3VMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	"_symbolic Sd"-_$s7Kernels10ScalarDot3VMF-20
	.long	l___unnamed_1-_$s7Kernels10ScalarDot3VMF-24
	.long	2                               ; 0x2
	.long	"_symbolic Sd"-_$s7Kernels10ScalarDot3VMF-32
	.long	l___unnamed_3-_$s7Kernels10ScalarDot3VMF-36
	.long	2                               ; 0x2
	.long	"_symbolic Sd"-_$s7Kernels10ScalarDot3VMF-44
	.long	l___unnamed_2-_$s7Kernels10ScalarDot3VMF-48

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10VectorDot3VWV"
_$s7Kernels10VectorDot3VWV:
	.quad	_$s7Kernels10VectorDot3VwCP
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy96_16
	.quad	___swift_memcpy96_16
	.quad	___swift_memcpy96_16
	.quad	___swift_memcpy96_16
	.quad	_$s7Kernels10VectorDot3Vwet
	.quad	_$s7Kernels10VectorDot3Vwst
	.quad	96                              ; 0x60
	.quad	96                              ; 0x60
	.long	131087                          ; 0x2000f
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.10.VectorDot3:                   ; @.str.10.VectorDot3
	.asciz	"VectorDot3"

	.private_extern	_$s7Kernels10VectorDot3VMn ; @"$s7Kernels10VectorDot3VMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s7Kernels10VectorDot3VMn
	.p2align	2, 0x0
_$s7Kernels10VectorDot3VMn:
	.long	81                              ; 0x51
	.long	_$s7KernelsMXM-_$s7Kernels10VectorDot3VMn-4
	.long	l_.str.10.VectorDot3-_$s7Kernels10VectorDot3VMn-8
	.long	_$s7Kernels10VectorDot3VMa-_$s7Kernels10VectorDot3VMn-12
	.long	_$s7Kernels10VectorDot3VMF-_$s7Kernels10VectorDot3VMn-16
	.long	3                               ; 0x3
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s7Kernels10VectorDot3VMf"
_$s7Kernels10VectorDot3VMf:
	.quad	0
	.quad	_$s7Kernels10VectorDot3VWV
	.quad	512                             ; 0x200
	.quad	_$s7Kernels10VectorDot3VMn
	.long	0                               ; 0x0
	.long	32                              ; 0x20
	.long	64                              ; 0x40
	.space	4

	.private_extern	"_symbolic _____ 7Kernels10VectorDot3V" ; @"symbolic _____ 7Kernels10VectorDot3V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 7Kernels10VectorDot3V"
	.weak_definition	"_symbolic _____ 7Kernels10VectorDot3V"
	.p2align	1, 0x0
"_symbolic _____ 7Kernels10VectorDot3V":
	.byte	1                               ; 0x1
	.long	_$s7Kernels10VectorDot3VMn-"_symbolic _____ 7Kernels10VectorDot3V"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s7Kernels10VectorDot3VMF"
_$s7Kernels10VectorDot3VMF:
	.long	"_symbolic _____ 7Kernels10VectorDot3V"-_$s7Kernels10VectorDot3VMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	"_symbolic _____ySdG s5SIMD4V"-_$s7Kernels10VectorDot3VMF-20
	.long	l___unnamed_1-_$s7Kernels10VectorDot3VMF-24
	.long	2                               ; 0x2
	.long	"_symbolic _____ySdG s5SIMD4V"-_$s7Kernels10VectorDot3VMF-32
	.long	l___unnamed_3-_$s7Kernels10VectorDot3VMF-36
	.long	2                               ; 0x2
	.long	"_symbolic _____ySdG s5SIMD4V"-_$s7Kernels10VectorDot3VMF-44
	.long	l___unnamed_2-_$s7Kernels10VectorDot3VMF-48

	.private_extern	__swift_FORCE_LOAD_$_swiftAccelerate_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftAccelerate_$_Kernels"
	.section	__DATA,__const
	.globl	__swift_FORCE_LOAD_$_swiftAccelerate_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftAccelerate_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftAccelerate_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftAccelerate

	.private_extern	__swift_FORCE_LOAD_$_swiftsimd_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftsimd_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftsimd_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftsimd_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftsimd_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftsimd

	.private_extern	__swift_FORCE_LOAD_$_swift_Builtin_float_$_Kernels ; @"_swift_FORCE_LOAD_$_swift_Builtin_float_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swift_Builtin_float_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swift_Builtin_float_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swift_Builtin_float_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swift_Builtin_float

	.private_extern	__swift_FORCE_LOAD_$_swiftXPC_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftXPC_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftXPC_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftXPC_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftXPC_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftXPC

	.private_extern	__swift_FORCE_LOAD_$_swiftDispatch_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftDispatch_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftDispatch_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftDispatch_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftDispatch_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftDispatch

	.private_extern	__swift_FORCE_LOAD_$_swiftObjectiveC_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftObjectiveC_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftObjectiveC_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftObjectiveC_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftObjectiveC_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftObjectiveC

	.private_extern	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftCoreFoundation_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftCoreFoundation_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftCoreFoundation

	.private_extern	__swift_FORCE_LOAD_$_swiftIOKit_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftIOKit_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftIOKit_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftIOKit_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftIOKit_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftIOKit

	.private_extern	__swift_FORCE_LOAD_$_swiftFoundation_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftFoundation_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftFoundation_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftFoundation_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftFoundation_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftFoundation

	.private_extern	__swift_FORCE_LOAD_$_swiftMetal_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftMetal_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftMetal_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftMetal_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftMetal_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftMetal

	.private_extern	__swift_FORCE_LOAD_$_swiftos_$_Kernels ; @"_swift_FORCE_LOAD_$_swiftos_$_Kernels"
	.globl	__swift_FORCE_LOAD_$_swiftos_$_Kernels
	.weak_definition	__swift_FORCE_LOAD_$_swiftos_$_Kernels
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftos_$_Kernels:
	.quad	__swift_FORCE_LOAD_$_swiftos

	.section	__TEXT,__swift5_types
	.p2align	2, 0x0                          ; @"$s7Kernels10ScalarDot2VHn"
l_$s7Kernels10ScalarDot2VHn:
	.long	_$s7Kernels10ScalarDot2VMn-l_$s7Kernels10ScalarDot2VHn

	.p2align	2, 0x0                          ; @"$s7Kernels10VectorDot2VHn"
l_$s7Kernels10VectorDot2VHn:
	.long	_$s7Kernels10VectorDot2VMn-l_$s7Kernels10VectorDot2VHn

	.p2align	2, 0x0                          ; @"$s7Kernels10ScalarDot3VHn"
l_$s7Kernels10ScalarDot3VHn:
	.long	_$s7Kernels10ScalarDot3VMn-l_$s7Kernels10ScalarDot3VHn

	.p2align	2, 0x0                          ; @"$s7Kernels10VectorDot3VHn"
l_$s7Kernels10VectorDot3VHn:
	.long	_$s7Kernels10VectorDot3VMn-l_$s7Kernels10VectorDot3VHn

	.private_extern	___swift_reflection_version ; @__swift_reflection_version
	.section	__TEXT,__const
	.globl	___swift_reflection_version
	.weak_definition	___swift_reflection_version
	.p2align	1, 0x0
___swift_reflection_version:
	.short	3                               ; 0x3

	.no_dead_strip	l_entry_point
	.no_dead_strip	l_$s7Kernels10ScalarDot2VHn
	.no_dead_strip	_$s7Kernels10ScalarDot2VMF
	.no_dead_strip	l_$s7Kernels10ScalarDot3VHn
	.no_dead_strip	_$s7Kernels10ScalarDot3VMF
	.no_dead_strip	l_$s7Kernels10VectorDot2VHn
	.no_dead_strip	_$s7Kernels10VectorDot2VMF
	.no_dead_strip	l_$s7Kernels10VectorDot3VHn
	.no_dead_strip	_$s7Kernels10VectorDot3VMF
	.no_dead_strip	___swift_reflection_version
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftAccelerate_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftDispatch_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftFoundation_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftIOKit_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftMetal_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftObjectiveC_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftXPC_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swift_Builtin_float_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftos_$_Kernels
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftsimd_$_Kernels
	.no_dead_strip	_main
	.linker_option "-lswiftAccelerate"
	.linker_option "-lswiftsimd"
	.linker_option "-lswiftCore"
	.linker_option "-lswift_DarwinFoundation2"
	.linker_option "-lswift_DarwinFoundation1"
	.linker_option "-lswift_Builtin_float"
	.linker_option "-lswift_StringProcessing"
	.linker_option "-lswift_Concurrency"
	.linker_option "-lswiftDarwin"
	.linker_option "-lswift_DarwinFoundation3"
	.linker_option "-framework", "Accelerate"
	.linker_option "-framework", "CoreVideo"
	.linker_option "-framework", "IOSurface"
	.linker_option "-lswiftXPC"
	.linker_option "-lswiftDispatch"
	.linker_option "-lswiftObjectiveC"
	.linker_option "-framework", "Combine"
	.linker_option "-lswiftSystem"
	.linker_option "-lswiftCoreFoundation"
	.linker_option "-framework", "CoreFoundation"
	.linker_option "-lswiftIOKit"
	.linker_option "-framework", "IOKit"
	.linker_option "-lswiftFoundation"
	.linker_option "-framework", "Foundation"
	.linker_option "-lswiftObservation"
	.linker_option "-framework", "CoreServices"
	.linker_option "-framework", "Security"
	.linker_option "-framework", "CFNetwork"
	.linker_option "-framework", "DiskArbitration"
	.linker_option "-framework", "CoreGraphics"
	.linker_option "-lswiftMetal"
	.linker_option "-framework", "Metal"
	.linker_option "-framework", "OpenGL"
	.linker_option "-lswiftos"
	.linker_option "-lobjc"
	.section	__DATA,__objc_imageinfo,regular,no_dead_strip
L_OBJC_IMAGE_INFO:
	.long	0
	.long	100927296

	.globl	_$s7Kernels10ScalarDot2VN
	.private_extern	_$s7Kernels10ScalarDot2VN
	.alt_entry	_$s7Kernels10ScalarDot2VN
_$s7Kernels10ScalarDot2VN = _$s7Kernels10ScalarDot2VMf+16
	.globl	_$s7Kernels10VectorDot2VN
	.private_extern	_$s7Kernels10VectorDot2VN
	.alt_entry	_$s7Kernels10VectorDot2VN
_$s7Kernels10VectorDot2VN = _$s7Kernels10VectorDot2VMf+16
	.globl	_$s7Kernels10ScalarDot3VN
	.private_extern	_$s7Kernels10ScalarDot3VN
	.alt_entry	_$s7Kernels10ScalarDot3VN
_$s7Kernels10ScalarDot3VN = _$s7Kernels10ScalarDot3VMf+16
	.globl	_$s7Kernels10VectorDot3VN
	.private_extern	_$s7Kernels10VectorDot3VN
	.alt_entry	_$s7Kernels10VectorDot3VN
_$s7Kernels10VectorDot3VN = _$s7Kernels10VectorDot3VMf+16
	.weak_reference __swift_FORCE_LOAD_$_swiftAccelerate
	.weak_reference __swift_FORCE_LOAD_$_swiftsimd
	.weak_reference __swift_FORCE_LOAD_$_swift_Builtin_float
	.weak_reference __swift_FORCE_LOAD_$_swiftXPC
	.weak_reference __swift_FORCE_LOAD_$_swiftDispatch
	.weak_reference __swift_FORCE_LOAD_$_swiftObjectiveC
	.weak_reference __swift_FORCE_LOAD_$_swiftCoreFoundation
	.weak_reference __swift_FORCE_LOAD_$_swiftIOKit
	.weak_reference __swift_FORCE_LOAD_$_swiftFoundation
	.weak_reference __swift_FORCE_LOAD_$_swiftMetal
	.weak_reference __swift_FORCE_LOAD_$_swiftos
.subsections_via_symbols
