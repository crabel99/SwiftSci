# Reproduce the dot qualification

This directory is experimental evidence for `SwiftSci` commit `1cc66fc663ead7250f39996034306bfe462e83ba`. It is not a production module. Run on Apple silicon with Accelerate and the recorded Swift toolchain for comparable measurements.

1. Compile the candidates with `swiftc -O Kernels.swift main.swift -o probe`.
2. Run `python3 qualify.py`. It regenerates the seeded inputs and exact rational references, runs the candidate binary, and records every result. It reports misses without claiming that every candidate passes.
3. Run `python3 make-bench.py`, then `swiftc -O Kernels.swift bench/main.swift -o bench/probe`.
4. Run `bench/probe > bench/results.jsonl 2> bench/checksum.txt`.
5. Run `VECLIB_MAXIMUM_THREADS=1 bench/probe > bench/single-thread-results.jsonl 2> bench/single-thread-checksum.txt`.
6. For the actual public API, inspect and adapt the repository and dependency-cache paths in `build-public.py`. Build the tracked source at the recorded revision. Run `public/probe cases.json > public/results.jsonl`.
7. Run `python3 check-smls.py`, `python3 check-exceptional.py`, and `public/probe earlier-inputs.json > earlier-results.jsonl`. The SmLs driver refers to the recorded repository path and original NIST fixtures. Run `python3 verify-earlier.py`.
8. Run `swift check-decoder.swift cases.json > decoder-check.txt` to check typed decoding separately.
9. Run `python3 verify-study.py` to check all saved results together. It explicitly expects the unresolved range cases to remain failures; a passing study check does not mean those algorithms are qualified for every input.

The original `check-inputs.swift` driver uses the exploratory Foundation bridge. Run `swift check-inputs.swift cases.json` to emit the parsed input bits and compare them with `a_bits` and `b_bits`. The retained mismatch file records the observed discrepancy. Corrected candidate runs do not use that numeric bridge.

`bench/probe` checks reduction performance on repeated arrays. It does not include fixture construction, JSON parsing, model fitting or validation overhead. Rebuild binaries before timing; binaries are deliberately absent from this archive.
