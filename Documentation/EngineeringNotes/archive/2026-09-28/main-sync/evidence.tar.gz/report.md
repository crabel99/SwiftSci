# Upstream integration after Parquet merge

Date: 2026-09-28

Upstream merged Parquet PR #42 into `main` at `55be1d971c8f86e726ac446a3100fab9753dcec7`. PR #41 remains the testing and benchmark draft. The three-contribution plan remains testing, fault repairs, then precision policies and numerical input handling.

## Branches

| Branch | Updated commit | Base |
| --- | --- | --- |
| main | `55be1d971c8f86e726ac446a3100fab9753dcec7` | upstream main |
| codex/standardized-benchmarks | `7d2dcb33c024e31827cd21d238c6cc72f1fdcdb5` | main |
| codex/certification-fault-repairs | `fe23b1b35a6193c26368831b28b83b336e5a61aa` | standardized-benchmarks |
| codex/apple-silicon-precision | `34b532a6e0550b1ab9cde03d1b0b9d355a492b09` | certification-fault-repairs |

Updates use normal merges and preserve the existing commits. The benchmark branch has identical tracked file contents before and after the upstream merge. Its diff against upstream no longer includes the accepted Parquet implementation or fixtures. Its source fingerprint remains `9435ebda31ed435401a8e8a7dbc6ec3fc89e13153933a84ec157ee2cd4b2303a`.

The repairs and precision branches now also include the two previously missing benchmark CI commits, `112bcfb52d` and `7054d5e93f`. Relative to the previous precision tip, the combined changes rename worker and CLI entry-point files, split the boundary-sweep fixture expression without changing arithmetic, and restore Python CodeQL. No numerical production logic changed during this integration.

The compact-storage branch remains local at `20dad063b976c3b03d07da7610609992b3c74bee` and is outside this three-PR stack. Historical merged branches remain unchanged. The engineering-notes branch is not an ancestor of the contribution branches, and their diffs contain no EngineeringNotes, Reproductions, or decisions.tsv paths.

## Validation of the combined precision branch

Source fingerprint: `412f3c8f03ba62705584a1a19b57365e1e1880e15d24d1f698c571cbb83045d7`.

- Release build-for-testing succeeded from a fresh tracked-source snapshot. Benchmark coverage instrumentation is absent.
- Full Release unit suite: 944 tests, 1,105 executions including parameterized cases, zero failures and zero skips.
- Benchmark controller suite: 147 tests passed.
- Public-workflow corruption controls: all 100 checks passed; no baseline cases were excluded.
- All 15 CPU acceptance profiles completed with complete evidence and zero infrastructure errors.
- Swift: 196 of 196 engine-case executions passed.
- Python reference adapter: 192 of 196 passed. Wampler4 and Wampler5 intercept comparisons fail in both numerical-binary64 and numerical-conformance profiles. These are the previously observed Python limits; they remain visible.
- Aggregate acceptance remains failed because all engines must satisfy their declared contracts. No tolerances or expected answers changed.

These results apply to the combined precision tip. They must not be represented as passing acceptance results for the standalone testing PR, which deliberately retains the defects repaired later in the stack. Apple-specific acceptance profiles and performance sweeps were not repeated during this integration. The full unit suite did run on the local Apple silicon machine.

An initial acceptance invocation began while the build lock was held and correctly refused fixture preparation. Its incomplete infrastructure report is retained separately as `cpu-acceptance`; the completed run is `cpu-acceptance-rebuilt`.

Workflow corruption-control output is retained in `workflow-controls.log` and the workflow-controls directory. The initial upstream-sync patch and branch mapping are also in the evidence archive.

## Evidence

[Archived validation evidence](../archive/2026-09-28/main-sync/evidence.tar.gz) includes the source and binary build record, unit summary and test log, controller results, acceptance inputs/outputs and reports, workflow corruption controls, and integration diff. The archive omits the Xcode result bundle and generated model payloads; the complete local run is under `/private/tmp/swiftsci-main-sync`.
