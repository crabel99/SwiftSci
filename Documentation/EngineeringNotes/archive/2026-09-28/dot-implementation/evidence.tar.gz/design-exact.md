# Range-safe dot-product design

Keep the existing two-argument function and delegate to an overload taking `accuracy: DotProductAccuracy`. The enum has `.performance` and `.compensated`. Do not give the overload a default argument; the existing signature already supplies the default. Preserve validation order and errors. The current implementation does not reject NaNs despite its generic comment, so correct that comment rather than introducing rejection.

## Recommended implementation

Use BLAS for performance. Use SIMD compensation for ordinary finite inputs, with an integer fallback when its range assumptions fail. Keep both implementations internal. The compensated contract should promise recovery of multiplication and accumulation residues, not universal correct rounding or an error tolerance that the implementation cannot establish.

Detect range exceptions during the compensated pass and restart from the original inputs. Check every accumulator component and the final merge for nonfinite values. A rounded product of zero from two nonzero operands must trigger fallback. This case would escape a literal test for a “nonzero product below the threshold.”

For nonzero rounded products, `abs(product) <= 2^-969` is a conservative fallback threshold. A product of two binary64 significands spans at most 106 bits. Products above this threshold have their lowest possible exact product bit above or at the minimum subnormal position, so FMA can represent the multiplication residue. Using `<=` avoids making the boundary proof part of the fast path. Underflow in TwoSum itself does not require the same product restriction.

## Exact fallback audit

Represent each finite input as an unsigned significand and a binary exponent. Normal significands include the implicit bit and use exponent `biasedExponent - 1075`; subnormals use exponent `-1074`. Multiply significands with `multipliedFullWidth`. The product occupies at most 106 bits.

With a base unit of `2^-2148`, product shifts range from 0 through 4090. The largest product is below `2^4196` base units. At most `Int.max < 2^63` terms make each unsigned total less than `2^4259`. Therefore 67 limbs, or 4288 bits, suffice separately for positive and negative totals on Apple silicon. Add the shifted product into up to three limbs, then propagate carries. Avoid shifts by 64, and assert that a final carry cannot escape the fixed allocation.

Subtract the smaller unsigned total from the larger. Record the sign. For a nonzero magnitude with highest set bit `k`, discard `max(1074, k - 52)` bits. Use the highest discarded bit, the OR of every lower discarded bit, and retained parity for one nearest-even rounding. Convert the retained integer exactly to Double and scale by the corresponding power of two. Preserve negative zero when a negative tiny exact result rounds to zero. Exact cancellation may return positive zero. Test rounding carry at the normal/subnormal boundary and overflow midpoint.

Classify exceptional operands explicitly. NaN or zero times infinity gives NaN; opposing infinite contributions give NaN; otherwise an infinite contribution determines the signed infinity. Finite products that overflow must enter the integer path, not be mistaken for genuinely infinite operands.

## Alternatives

An always-exact accumulator simplifies the numerical contract but penalizes ordinary workloads and would justify a separate `.exact` name. A fixed SIMD compensation-only implementation leaves known underflow and intermediate-overflow defects unresolved. Scaling all operands by one common exponent is simpler but can erase small terms across a large exponent range. Reject those alternatives for this increment.

Required tests include half-minimum-subnormal products that sum to a representable value, overflowing products that cancel, ties with even and odd retained bits, limb-crossing shifts, long carry/borrow chains, true result overflow, exceptional operands, and ordinary compensated cancellation cases. Compare against independently generated integer or rational references.
