import Foundation
import Accelerate
@inline(never) func previous(_ a:[Double],_ b:[Double])->Double {
    try! Stats.requireNonEmpty(a);try! Stats.requireSameSize(a,b);return vDSP.dot(a,b)
}
let candidates: [(String,([Double],[Double])->Double)] = [
 ("previous",previous),
 ("performance",{try! Stats.dotProduct($0,$1)}),
 ("compensated",{try! Stats.dotProduct($0,$1,accuracy:.compensated)})]
func emit(_ row:[String:Any]) {print(String(data:try! JSONSerialization.data(withJSONObject:row,options:[.sortedKeys]),encoding:.utf8)!)}

if CommandLine.arguments.count == 1 {
var state:UInt64=284019
func next()->Int64 {state=state &* 6364136223846793005 &+ 1442695040888963407;return Int64(state >> 47)}
var sink=0.0
for n in [32,128,384,768,1536,4096,65536,1048576,8388608] {
 for family in ["mixed","positive","product-cancellation"] {
  var a=[Double](),b=[Double]();a.reserveCapacity(n);b.reserveCapacity(n)
  var exactNumerator:Int64=0
  let denominator=4294967296.0
  for i in 0..<n {
   if family == "product-cancellation" {
    let e=0x1p-27
    a.append(i%2==0 ? 1+e : -1);b.append(i%2==0 ? 1-e : 1)
   } else {
    let x=next()-(family == "mixed" ? 65536 : 0),y=next()-(family == "mixed" ? 65536 : 0)
    a.append(Double(x)/65536);b.append(Double(y)/65536);exactNumerator+=x*y
   }
  }
  let reference=family == "product-cancellation" ? -Double(n/2)*0x1p-54 : Double(exactNumerator)/denominator
  let batch=max(1,262144/n)
  var times=Array(repeating:[Double](),count:candidates.count)
  for round in 0..<17 {
   for offset in 0..<candidates.count {
    let i=(offset+round)%candidates.count
    let t=DispatchTime.now().uptimeNanoseconds
    for _ in 0..<batch {sink+=candidates[i].1(a,b)}
    let elapsed=Double(DispatchTime.now().uptimeNanoseconds-t)/Double(batch)
    if round>3 {times[i].append(elapsed)}
   }
  }
  for (i,c) in candidates.enumerated() {
   let r=c.1(a,b)
   emit(["family":family,"n":n,"candidate":c.0,"value":String(r),"reference":String(reference),"reference_bits":String(reference.bitPattern),"value_bits":String(r.bitPattern),"absolute_error":abs(r-reference),"median_ns":times[i].sorted()[6],"ns":times[i]])
  }
 }
}
fputs("checksum=\(sink)\n",stderr)

} else {
let cases = try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))) as! [[String:Any]]
for c in cases {
 let a=(c["a_bits"] as! [String]).map {Double(bitPattern:UInt64($0)!)},b=(c["b_bits"] as! [String]).map {Double(bitPattern:UInt64($0)!)}
 for accuracy in [DotProductAccuracy.performance,.compensated] {
  let value=try Stats.dotProduct(a,b,accuracy:accuracy)
  emit(["case":c["id"]!,"accuracy":accuracy == .performance ? "performance":"compensated","value":String(value),"bits":String(value.bitPattern)])
 }
}
}
