# Design synthesis

The exact fallback design is the base. Both independent sketches preserve the old signature and add an explicit policy. The exact design and cross-review establish the fixed 67-limb bound and nearest-even rounding procedure. The bounded design contributes separation of public validation from the internal kernel and explicit documentation of numerical limits. Rejection of finite range cases is not used; those solvable cases are recovered.

Implementation verification found that finite-depth compensation can lose a severely cancelled result without a nonfinite intermediate. The internal dispatch now detects that regime conservatively and restarts from original inputs. The public interface did not need to change. Independent full-exponent qualification then passed.

Code review found no concrete remaining arithmetic defects and requested two additional regressions: ordinary product residuals outside the exact-fallback regime, and exceptional values above the BLAS crossover. Both are implemented and pass.
