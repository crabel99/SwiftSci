from pathlib import Path
import subprocess
root=Path('/Users/crabel/Documents/src/SwiftSci')
build=Path('/Users/crabel/Library/Caches/SwiftSci/standardized-benchmarks/derived/Build/Products/Release')
files=subprocess.check_output(['git','ls-files','Sources/SwiftStats/*.swift','Sources/SwiftStats/**/*.swift'],cwd=root,text=True).splitlines()
files += ['Sources/SwiftStats/Core/'+n+'.swift' for n in ['DotProductAccuracy','CompensatedDotProduct','ExactDotProduct'] if 'Sources/SwiftStats/Core/'+n+'.swift' not in files]
args=['swiftc','-O','-I',str(build),'-F',str(build/'PackageFrameworks'),'-lc++','-I','/Users/crabel/Library/Caches/SwiftSci/xcode-packages/checkouts/swift-atomics/Sources/_AtomicsShims/include','-Xcc','-fmodule-map-file=/Users/crabel/Library/Caches/SwiftSci/standardized-benchmarks/derived/Build/Intermediates.noindex/GeneratedModuleMaps/ArrowC.modulemap']+[str(root/f) for f in files]+[str(build/(name+'.o')) for name in ['SwiftDataFrame','Arrow','ArrowC','FlatBuffers','Atomics','_AtomicsShims']]+['/private/tmp/swiftsci-dot-implementation/public/main.swift','-o','/private/tmp/swiftsci-dot-implementation/public/probe']
subprocess.run(args,check=True)
