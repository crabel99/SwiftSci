# Reproduce this increment

The implementation source in `source/` is commit `ede79c1ad3fda868d3661979360aaeed31dcbf9c`. Public usage and guarantees are documented in the library's ChoosingDotProductAccuracy guide.

For the isolated range accumulator, compile `ExactDotProduct.swift` with `exact-probe/main.swift` using `swiftc -O`. Run the resulting `exact-probe/probe` with `qualification-cases.json`, or run `python3 fuzz-exact.py` to regenerate the full-exponent fixtures and check their exact rational references.

For the combined algorithm, compile `ExactDotProduct.swift`, `CompensatedDotProduct.swift` and `compensated-probe/main.swift`. Run that binary with the same inputs. The public probe uses the actual tracked SwiftStats source; `build-public.py` records the repository and cached dependency paths used here. Adjust those paths for another checkout and rebuild before running `public/probe qualification-cases.json` or `public/probe fuzz-inputs.json`.

Running the public probe without arguments performs the timing sweep. Compare its JSON results with `timing-summary.json`. Use a quiet machine and distinguish repeated-buffer timings from an end-to-end application workload.

The maintained regression tests belong to `DotProductAccuracyTests` in SwiftStatsTests. `final.log` records the full targeted Xcode command and the passed statistics and forecast tests. `test-summary.json` records Xcode's official totals. `red.log` records the numerical failures before implementation; `before.log` is an earlier fixture compilation failure and is not numerical evidence.

`worker-build.json` and each maintained-profile directory record the source fingerprint, binary hash, environment and certification outputs. The source fingerprint is verified against a tracked-source snapshot. Those runs were recorded before the commit; their source bytes match the committed code. The original-decimal profile remains failed on its three named SmLs cases.

The archive contains no compiled executables or Xcode result bundles. Rebuild using the recorded toolchain and resolved dependencies. `MANIFEST.json` hashes every retained member.
