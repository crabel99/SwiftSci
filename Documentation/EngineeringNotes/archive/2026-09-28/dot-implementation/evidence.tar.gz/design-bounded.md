# Bounded compensated dot product

Status: independent design candidate. No implementation or repository changes.

## Caller usage

```swift
try Stats.dotProduct(a, b)
try Stats.dotProduct(a, b, accuracy: .performance)
try Stats.dotProduct(a, b, accuracy: .compensated)
```

Keep the existing two-argument function and add an overload. The original function forwards to `.performance`. Preserve its existing empty-input and size-mismatch validation order. Performance selects the validated BLAS adapter; it preserves the current ordinary IEEE exceptional-value behavior.

## Proposed shape

```swift
public enum DotProductAccuracy: Sendable {
    case performance
    case compensated
}

internal enum CompensatedDot {
    static func evaluate(_ a: [Double], _ b: [Double]) throws -> Double
}
```

`Stats+LinearAlgebra.swift` owns validation and public policy dispatch. `CompensatedDot.swift` owns range qualification, SIMD reduction, component merging and final rounding. Use a private fixed tuple or struct for the three accumulator components. Do not expose the algorithm, vector width, or backend as public choices.

## Range contract

For `.compensated`, reject NaN and infinity with the existing `StatsError.containsNaN` and `.containsInfinity`. This is explicit-mode behavior; do not change the legacy function's behavior. Return stronger accumulation of the supplied binary64 inputs, not a universal correctly rounded or original-decimal answer.

Before reducing, perform a conservative, constant-memory range qualification. Decode finite operands' significands and exponents from their bit patterns. Compute each exact product's least nonzero binary position, accounting for trailing zeros, without multiplying floating-point values. Reject products requiring bits below the minimum subnormal unit. Such products can lose information even when their rounded product appears normal or zero. Also bound the magnitude of the absolute product sum using exponent arithmetic and sufficient headroom for the accumulator transformations. Reject uncertain cases rather than testing only whether a completed result is finite.

A rejected finite case throws the existing `.unsupportedOperation` with a message that compensated dot product cannot represent the required product range. The message distinguishes numerical range from invalid dimensions. Do not return BLAS or a weaker finite answer. This avoids adding a new shared error enum case solely for an experimental path.

This gate deliberately rejects some solvable problems. Document that limitation. In particular, cancellation of overflowing products and accumulation of individually underflowing products are unsupported. A final result outside Double's finite range also throws. Zero operands contribute exact zero. Normalization and merging must retain the qualified arithmetic assumptions; add development assertions for unexpected nonfinite intermediates.

## Alternatives and tradeoffs

A common power-of-two rescaling can solve some overflow examples, but may erase small contributions in wide-range data. A fallback needs checked representability of every scaled operand and residual, plus final rescaling. Once several scale buckets are needed, this is no longer the smallest implementation.

Exact signed integer bins offer coherent behavior across the entire finite-input exponent range. Multiplying decoded integer significands and accumulating them in fixed limbs avoids floating-point intermediate overflow and underflow. With headroom for the maximum Swift array length, memory remains bounded. Correct rounding and signed carry handling require more implementation and boundary tests, but this is the stronger long-term fallback.

My minimal recommendation is bounded compensation with explicit failure. If broad finite-input coverage is required now, choose exact integer bins as a rare fallback instead. Do not disguise range rejection through rescaling that silently loses terms.

## Tests

Keep the two public entry points equivalent in performance mode. Check validation order, exceptional values, cancellation, product residues, SIMD tails and merge boundaries. The seven known range failures must throw in this design. Test just-inside and just-outside qualification limits using exact-bit fixtures and an independent integer reference. Benchmark qualification overhead separately from the reduction.
