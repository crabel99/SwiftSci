import Foundation
let cases = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))) as! [[String: Any]]
for c in cases {
    let a = (c["a_bits"] as! [String]).map { Double(bitPattern: UInt64($0)!) }
    let b = (c["b_bits"] as! [String]).map { Double(bitPattern: UInt64($0)!) }
    let r = ExactDotProduct.evaluate(a, b)
    print(String(data: try JSONSerialization.data(withJSONObject: ["case": c["id"]!, "value": String(r), "bits": String(r.bitPattern)]), encoding: .utf8)!)
}
