# Dot-product implementation

- [x] Ground existing API and qualification evidence.
- [x] Compare range-safe designs and select the internal structure.
- [x] Add the public policy and capture failing regression tests.
- [x] Implement performance dispatch and compensated reduction.
- [x] Verify exact fallback independently, then public API accuracy and performance.
- [x] Run nearby Release tests and numerical certification profiles.
- [x] Review, commit implementation, and preserve evidence on engineering-notes.
