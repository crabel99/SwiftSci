import json,math,random,struct,subprocess
from fractions import Fraction as F
from pathlib import Path
p=Path(__file__).parent;rng=random.Random(9282026)
def bits(x):return str(struct.unpack('Q',struct.pack('d',x))[0])
def value():return struct.unpack('d',struct.pack('Q',rng.getrandbits(64)&~(0x7ff<<52)|(rng.randrange(2047)<<52)))[0]
cases=[]
def add(a,b):cases.append(dict(id=str(len(cases)),a_bits=list(map(bits,a)),b_bits=list(map(bits,b))))
for i in range(2400):
 n=rng.choice([1,2,3,4,7,16,17,65]);a=[value() for _ in range(n)];b=[value() for _ in range(n)]
 if i%3==0:
  a=a+[-x for x in a]+[value()];b=b+b+[value()]
 add(a,b)
tiny=math.ulp(0.0);largest=float.fromhex('0x1.fffffffffffffp1023');normal=float.fromhex('0x1p-1022')
for sign in [1.,-1.]:
 for a,b in [([1.,2**-53,2.**-537],[1.,1.,2.**-538]),([normal,-tiny,tiny],[1.,1.,.5]),([normal,-2*tiny,tiny],[1.,1.,.5]),([largest,2.**970,-tiny],[1.,1.,1.]),([largest,2.**970],[1.,1.]),([largest,2.**970,tiny],[1.,1.,1.]),([largest]*4096+[-largest]*4096+[tiny],[1.]*8193)]:add([sign*x for x in a],b)
(p/'fuzz-inputs.json').write_text(json.dumps(cases))
raw=subprocess.check_output([str(p/'exact-probe/probe'),str(p/'fuzz-inputs.json')],text=True);(p/'fuzz-results.jsonl').write_text(raw)
refs={};fail=[]
for c,line in zip(cases,raw.splitlines()):
 def decode(xs):return [struct.unpack('d',struct.pack('Q',int(x)))[0] for x in xs]
 a=decode(c['a_bits']);b=decode(c['b_bits']);exact=sum(F(x)*F(y) for x,y in zip(a,b))
 try:rounded=float(exact)
 except OverflowError:rounded=math.copysign(math.inf,1 if exact>0 else -1)
 refs[c['id']]=dict(bits=bits(rounded),rounded=str(rounded))
 got=json.loads(line)
 if got['bits']!=bits(rounded):fail.append(dict(case=c['id'],actual=got,expected=refs[c['id']]))
(p/'fuzz-references.json').write_text(json.dumps(refs));(p/'fuzz-summary.json').write_text(json.dumps(dict(cases=len(cases),failures=fail),indent=2))
print('Full-exponent exact fallback:',len(cases),'cases;',len(fail),'bit mismatches');print(fail[:3]);assert not fail
