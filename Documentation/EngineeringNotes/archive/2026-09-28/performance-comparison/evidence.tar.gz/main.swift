import Foundation
import CryptoKit

#if BEFORE
let implementation = "swift-before"
#else
let implementation = "swift-current"
#endif
var sink = 0.0
func hash(_ arrays: [[Double]]) -> String {
    var h = SHA256()
    for a in arrays { a.withUnsafeBytes { h.update(bufferPointer: $0) } }
    return h.finalize().map { String(format: "%02x", $0) }.joined()
}
func bench(_ op: String, _ n: Int, _ family: String, _ inputs: [[Double]], _ body: () throws -> Double) rethrows {
    let batch = max(1, 262144 / n)
    var samples: [Double] = []
    for round in 0..<13 {
        let start = DispatchTime.now().uptimeNanoseconds
        for _ in 0..<batch { sink += try body() }
        let elapsed = Double(DispatchTime.now().uptimeNanoseconds - start) / Double(batch)
        if round >= 4 { samples.append(elapsed) }
    }
    let row: [String: Any] = ["implementation": implementation, "op": op, "n": n, "family": family, "input_sha256": hash(inputs), "samples_ns": samples, "value": try body()]
    print(String(data: try! JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]), encoding: .utf8)!)
}
for n in [32, 1024, 4096, 65536, 1048576, 8388608] {
    let a = (0..<n).map { Double($0 % 1021 - 510) / 128 }
    let b = (0..<n).map { Double($0 % 509 - 254) / 512 }
    try bench("dot", n, "mixed", [a,b]) { try Stats.dotProduct(a,b) }
    #if !BEFORE
    try bench("dot-compensated", n, "mixed", [a,b]) { try Stats.dotProduct(a,b,accuracy:.compensated) }
    #endif
    for offset in [0.0,1e12] {
        let x = a.map { $0 + offset }
        let family = offset == 0 ? "centered" : "offset"
        try bench("variance", n, family, [x]) { try Stats.variance(x) }
        try bench("stddev", n, family, [x]) { try Stats.standardDeviation(x) }
    }
    if n <= 1048576 {
        let groups = (0..<3).map { g in (0..<n).map { 1e12 + Double($0 % 5 - 2) + Double(g) } }
        try bench("anova", n, "offset", groups) { try Stats.oneWayANOVA(groups: groups).fStatistic }
    }
}
let n = 1048576
let c = (0..<n).map { $0 % 2 == 0 ? 1 + 0x1p-27 : -1.0 }
let d = (0..<n).map { $0 % 2 == 0 ? 1 - 0x1p-27 : 1.0 }
try bench("dot", n, "product-cancellation", [c,d]) { try Stats.dotProduct(c,d) }
#if !BEFORE
try bench("dot-compensated", n, "product-cancellation", [c,d]) { try Stats.dotProduct(c,d,accuracy:.compensated) }
#endif
let edge = [1e15 + 5.75,1e15 - 5.875]
try bench("variance", 2, "rounded-mean", [edge]) { try Stats.variance(edge) }
fputs("checksum=\(sink)\n",stderr)
