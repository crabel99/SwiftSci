from pathlib import Path
from fractions import Fraction
import json,math,statistics,collections
p=Path(__file__).parent

def moments(n,period,center):
 q,r=divmod(n,period)
 values=[i-center for i in range(period)]
 return sum(values)*q+sum(values[:r]),sum(v*v for v in values)*q+sum(v*v for v in values[:r])
def expected(op,n,family):
 if op.startswith('dot'):
  if family=='product-cancellation':return -float(Fraction(n//2,2**54))
  period=1021*509;q,r=divmod(n,period)
  # A complete period contains every pair and each centered factor sums to zero.
  return float(Fraction(sum((i%1021-510)*(i%509-254) for i in range(r)),65536))
 if op=='anova':
  s,ss=moments(n,5,2);return float(Fraction(n*(n-1),1)/(ss-Fraction(s*s,n)))
 if family=='rounded-mean':return 67.5703125
 s,ss=moments(n,1021,510);v=Fraction(ss*n-s*s,n*(n-1)*128**2)
 return math.sqrt(float(v)) if op=='stddev' else float(v)
records=collections.defaultdict(list)
for candidate in ['before','current','python']:
 for round_index in range(3):
  for line in (p/f'{candidate}-{round_index}.jsonl').read_text().splitlines():
   row=json.loads(line);records[(row['op'],row['n'],row['family'],candidate)].append(row)
result=[];hashes=collections.defaultdict(set)
for (op,n,family,candidate),rows in records.items():
 assert len(rows)==3
 ref=expected(op,n,family);limit=abs(ref)*1e-12+8*float.fromhex('0x0.0000000000001p-1022')
 samples=[statistics.median(row['samples_ns']) for row in rows]
 maximum=max(abs(row['value']-ref) for row in rows)
 for row in rows:hashes[(op.replace('-compensated',''),n,family)].add(row['input_sha256'])
 result.append(dict(op=op,n=n,family=family,candidate=candidate,median_ns=statistics.median(samples),process_medians_ns=samples,minimum_process_median_ns=min(samples),maximum_process_median_ns=max(samples),reference=ref,values=[row['value'] for row in rows],max_absolute_error=maximum,passed=maximum<=limit,absolute_tolerance=limit,input_sha256=rows[0]['input_sha256'],sample_count=sum(len(row['samples_ns']) for row in rows)))
assert all(len(s)==1 for s in hashes.values()),'Input hashes differ'
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('Matched input hashes:',len(hashes))
for op,n,family in [('dot',65536,'mixed'),('dot',1048576,'mixed'),('dot',8388608,'mixed'),('variance',1048576,'offset'),('variance',8388608,'offset'),('stddev',1048576,'offset'),('anova',1048576,'offset'),('dot',1048576,'product-cancellation'),('variance',2,'rounded-mean')]:
 selected=[r for r in result if r['op']==op and r['n']==n and r['family']==family]
 print(op,n,family,[(r['candidate'],round(r['median_ns']/1000,3),r['passed'],r['max_absolute_error']) for r in selected])
print('Numerical misses:',[(r['candidate'],r['op'],r['n'],r['family'],r['max_absolute_error']) for r in result if not r['passed']])
