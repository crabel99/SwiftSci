import Foundation
import CryptoKit

#if BEFORE
let implementation = "swift-before"
#else
let implementation = "swift-current"
#endif
var sink = 0.0
func hash(_ arrays: [[Double]]) -> String {
    var h = SHA256()
    for a in arrays { a.withUnsafeBytes { h.update(bufferPointer: $0) } }
    return h.finalize().map { String(format: "%02x", $0) }.joined()
}
func bench(_ op: String, _ n: Int, _ family: String, _ inputs: [[Double]], _ body: () throws -> Double) rethrows {
    let batch = max(1, 262144 / n)
    var samples: [Double] = []
    for round in 0..<13 {
        let start = DispatchTime.now().uptimeNanoseconds
        for _ in 0..<batch { sink += try body() }
        let elapsed = Double(DispatchTime.now().uptimeNanoseconds - start) / Double(batch)
        if round >= 4 { samples.append(elapsed) }
    }
    let row: [String: Any] = ["implementation": implementation, "op": op, "n": n, "family": family, "input_sha256": hash(inputs), "samples_ns": samples, "value": try body()]
    print(String(data: try! JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]), encoding: .utf8)!)
}

struct DecimalInput: Decodable { let groups: [[String]] }
for name in ["SmLs07", "SmLs08", "SmLs09"] {
    let path = "/Users/crabel/Documents/src/SwiftSci/Benchmarks/Fixtures/nist-models/inputs/" + name + "-decimal.json"
    let data = try Data(contentsOf: URL(fileURLWithPath: path))
    let groups = try JSONDecoder().decode(DecimalInput.self, from: data).groups
    let n = groups.reduce(0) { $0 + $1.count }
    var samples: [Double] = []
    var value = 0.0
    let batch = max(1, 18009 / n)
    for round in 0..<13 {
        let start = DispatchTime.now().uptimeNanoseconds
        for _ in 0..<batch { value = try Stats.oneWayANOVA(decimalGroups: groups).fStatistic; sink += value }
        if round >= 4 { samples.append(Double(DispatchTime.now().uptimeNanoseconds - start) / Double(batch)) }
    }
    let row: [String: Any] = ["implementation":implementation,"dataset":name,"n":n,"input_sha256":SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined(),"samples_ns":samples,"value":value]
    print(String(data:try JSONSerialization.data(withJSONObject:row,options:[.sortedKeys]),encoding:.utf8)!)
}
fputs("checksum=\(sink)\n",stderr)
