from decimal import Decimal,localcontext,Inexact
from pathlib import Path
import numpy as np
from scipy import stats
import time,json,hashlib,sys
sink=0.
for name in ['SmLs07','SmLs08','SmLs09']:
 path=Path('/Users/LOCAL_USER/Documents/src/SwiftSci/Benchmarks/Fixtures/nist-models/inputs')/(name+'-decimal.json');raw=path.read_bytes();groups=json.loads(raw)['groups'];n=sum(map(len,groups));batch=max(1,18009//n);samples=[]
 def execute():
  with localcontext() as c:
   c.prec=80;c.traps[Inexact]=True;origin=Decimal(groups[0][0])
   a=[np.asarray([float(Decimal(x)-origin) for x in g]) for g in groups]
  return float(stats.f_oneway(*a).statistic)
 for repeat in range(13):
  start=time.perf_counter_ns()
  for _ in range(batch):value=execute();sink+=value
  elapsed=(time.perf_counter_ns()-start)/batch
  if repeat>=4:samples.append(elapsed)
 print(json.dumps(dict(implementation='numpy-scipy',dataset=name,n=n,input_sha256=hashlib.sha256(raw).hexdigest(),samples_ns=samples,value=value)))
print('checksum='+str(sink),file=sys.stderr)
