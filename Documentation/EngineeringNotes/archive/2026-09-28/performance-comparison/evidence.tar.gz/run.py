from pathlib import Path
import os,subprocess,json,time
p=Path(__file__).parent;r=Path('/Users/LOCAL_USER/Documents/src/SwiftSci')
commands={'before':[str(p/'before/probe')],'current':[str(p/'current/probe')],'python':[str(r/'Benchmarks/.venv-standardized/bin/python'),str(p/'python-bench.py')]}
env=os.environ.copy();env['VECLIB_MAXIMUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
metadata={'start':time.time(),'thread_environment':{k:env[k] for k in ['VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS']},'platform':subprocess.check_output(['sw_vers'],text=True),'hardware':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True),'swift':subprocess.check_output(['swift','--version'],text=True),'processes':[]}
for round in range(3):
 order=['before','current','python'];order=order[round:]+order[:round]
 for name in order:
  with (p/f'{name}-{round}.jsonl').open('w') as out,(p/f'{name}-{round}.stderr').open('w') as err:
   start=time.time();subprocess.run(commands[name],env=env,stdout=out,stderr=err,check=True)
  metadata['processes'].append({'round':round,'candidate':name,'started':start,'ended':time.time()})
  print(round,name,'complete',flush=True)
metadata['end']=time.time();(p/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n')
