import hashlib,json,time,sys
import numpy as np
from scipy import stats
sink=0.0

def bench(op,n,family,inputs,body):
 global sink
 batch=max(1,262144//n);samples=[]
 for repeat in range(13):
  start=time.perf_counter_ns()
  for _ in range(batch):sink+=float(body())
  elapsed=(time.perf_counter_ns()-start)/batch
  if repeat>=4:samples.append(elapsed)
 h=hashlib.sha256()
 for a in inputs:h.update(a.astype('<f8',copy=False).tobytes())
 print(json.dumps(dict(implementation='numpy-scipy',op=op,n=n,family=family,input_sha256=h.hexdigest(),samples_ns=samples,value=float(body()))),flush=True)
for n in [32,1024,4096,65536,1048576,8388608]:
 i=np.arange(n,dtype=np.int64);a=(i%1021-510).astype(np.float64)/128;b=(i%509-254).astype(np.float64)/512
 bench('dot',n,'mixed',[a,b],lambda:np.dot(a,b))
 for offset in [0.,1e12]:
  x=a+offset;family='centered' if offset==0 else 'offset'
  bench('variance',n,family,[x],lambda:np.var(x,ddof=1))
  bench('stddev',n,family,[x],lambda:np.std(x,ddof=1))
 if n<=1048576:
  groups=[1e12+(i%5-2).astype(np.float64)+g for g in range(3)]
  bench('anova',n,'offset',groups,lambda:stats.f_oneway(*groups).statistic)
n=1048576;i=np.arange(n)
c=np.where(i%2==0,1+2**-27,-1.);d=np.where(i%2==0,1-2**-27,1.)
bench('dot',n,'product-cancellation',[c,d],lambda:np.dot(c,d))
edge=np.array([1e15+5.75,1e15-5.875]);bench('variance',2,'rounded-mean',[edge],lambda:np.var(edge,ddof=1))
print('checksum='+str(sink),file=sys.stderr)
