from pathlib import Path
import subprocess,hashlib,json
p=Path(__file__).parent;r=Path('/Users/LOCAL_USER/Documents/src/SwiftSci')
build=Path('/Users/LOCAL_USER/Library/Caches/SwiftSci/standardized-benchmarks/derived/Build/Products/Release')
records={}
for name,ref in [('before','36053baca6bf38a9233ca9798c151816f4bdf259'),('current','3a31534e3604bb0eb516546b2f8ab898f1f87ccd')]:
 files=subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'Sources/SwiftStats'],cwd=r,text=True).splitlines();files=[f for f in files if f.endswith('.swift')]
 inputs=[];hashes={}
 for f in files:
  raw=subprocess.check_output(['git','show',ref+':'+f],cwd=r);target=p/name/'source'/f;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);inputs.append(str(target));hashes[f]=hashlib.sha256(raw).hexdigest()
 args=['swiftc','-O','-I',str(build),'-F',str(build/'PackageFrameworks'),'-lc++','-I','/Users/LOCAL_USER/Library/Caches/SwiftSci/xcode-packages/checkouts/swift-atomics/Sources/_AtomicsShims/include','-Xcc','-fmodule-map-file=/Users/LOCAL_USER/Library/Caches/SwiftSci/standardized-benchmarks/derived/Build/Intermediates.noindex/GeneratedModuleMaps/ArrowC.modulemap']
 if name=='before':args+=['-D','BEFORE']
 args+=inputs+[str(build/(n+'.o')) for n in ['SwiftDataFrame','Arrow','ArrowC','FlatBuffers','Atomics','_AtomicsShims']]+[str(p/'main.swift'),'-o',str(p/name/'probe')]
 with (p/(name+'-build.log')).open('w') as log:subprocess.run(args,check=True,stdout=log,stderr=log)
 records[name]={'commit':ref,'sources':hashes,'command':args,'binary_sha256':hashlib.sha256((p/name/'probe').read_bytes()).hexdigest()}
(p/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
