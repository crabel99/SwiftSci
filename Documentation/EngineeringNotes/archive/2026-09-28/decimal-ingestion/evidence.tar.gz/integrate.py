from pathlib import Path
import json
r=Path('/Users/LOCAL_USER/Documents/src/SwiftSci')
def edit(p,a,b):
 p=r/p;s=p.read_text();assert a in s,(p,a);p.write_text(s.replace(a,b))
edit('Benchmarks/Tools/build_nist_model_fixtures.py', "        print(f'{name}: {model[\"observations\"]} rows verified; {len(certified)} outputs')", '''        if name in ANOVA:
            # Keep source decimal tokens intact; the public API performs centering.
            decimal_fixture = {'operation':'nist-anova-decimal', 'groups':list(groups.values())}
            decimal_path = base_dir / f'inputs/{name}-decimal.json'
            write_json(decimal_path, decimal_fixture)
            decimal_bytes = decimal_path.read_bytes()
            decimal_reference = dict(reference, inputIdentity={'sha256':sha(decimal_bytes), 'bytes':len(decimal_bytes)})
            write_json(base_dir / f'references/{name}-decimal.json', decimal_reference)
        print(f'{name}: {model["observations"]} rows verified; {len(certified)} outputs')''')
for p in ['Benchmarks/Tools/contracts.py', 'Benchmarks/Tools/numerical_fixtures.py','Benchmarks/Worker/NumericalWorkloads.swift']:
 edit(p,'"ols-cpu", "nist-anova",','"ols-cpu", "nist-anova", "nist-anova-decimal",')
for p in ['Benchmarks/Specs/schemas/workload.json', 'Benchmarks/Specs/schemas/dataset.json']:
 edit(p, '"nist-anova",', '"nist-anova",\n        "nist-anova-decimal",')
edit('Benchmarks/Tools/numerical_fixtures.py', 'import math\n', 'import math\nimport re\n')
edit('Benchmarks/Tools/numerical_fixtures.py', '    elif operation == "nist-anova":', '    elif operation in ("nist-anova", "nist-anova-decimal"):')
edit('Benchmarks/Tools/numerical_fixtures.py', '            finite_vector(group, "ANOVA group")', '''            if operation == "nist-anova-decimal":
                require(isinstance(group, list) and group, "Empty decimal ANOVA group")
                require(all(isinstance(v, str) and re.fullmatch(r"[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?", v) for v in group), "Invalid decimal ANOVA token")
            else:
                finite_vector(group, "ANOVA group")''')
edit('Benchmarks/Tools/numerical_fixtures.py', '    for key in ["fixture", "source_fixture", "reference_fixture"]:', '''    if manifest.get("operation") == "nist-anova-decimal":
        require(manifest.get("reference_basis") == "nist-decimal-v1", "Decimal ANOVA requires original-decimal references")
    if manifest.get("operation") == "nist-anova":
        require(manifest.get("reference_basis") == "binary64-v1", "Binary64 ANOVA requires binary64 references")
    for key in ["fixture", "source_fixture", "reference_fixture"]:''')
p=r/'Benchmarks/Specs/workloads/nist-anova-v1.json';o=json.loads(p.read_text());o['semantics']='Balanced one-way ANOVA on predecoded float64 groups through the existing binary64 API. Output: F statistic, between-group degrees of freedom, within-group degrees of freedom. Independently computed exact-binary64-input reference. No p-value certification claim.';p.write_text(json.dumps(o,indent=2)+'\n')
o['id']='nist-anova-decimal-v1';o['operation']='nist-anova-decimal';o['semantics']='One-way ANOVA from original decimal strings. Times decimal parsing, exact common-origin subtraction, binary64 residual conversion, public ANOVA and output materialization. Output: F statistic, between-group degrees of freedom, within-group degrees of freedom. Original-decimal NIST certified references and unchanged tolerances. JSON decoding is outside timing. Python uses checked decimal centering then SciPy f_oneway. No p-value certification claim.'
(r/'Benchmarks/Specs/workloads/nist-anova-decimal-v1.json').write_text(json.dumps(o,indent=2)+'\n')
p=r/'Benchmarks/Specs/profiles/numerical-conformance.json';o=json.loads(p.read_text());
for c in o['cases']:
 if c['workload']=='nist-anova-v1':c['workload']='nist-anova-decimal-v1'
p.write_text(json.dumps(o,indent=2)+'\n')
edit('Benchmarks/Worker/NumericalWorkloads.swift', 'enum NumericalInputs {', '''private struct DecimalANOVAInput: Decodable {
  let operation: String
  let groups: [[String]]
}

enum NumericalInputs {''')
edit('Benchmarks/Worker/NumericalWorkloads.swift', '  case anova(groups: [[Double]])','  case anova(groups: [[Double]])\n  case decimalANOVA(groups: [[String]])')
edit('Benchmarks/Worker/NumericalWorkloads.swift', '    let input = try JSONDecoder().decode(ANOVAInput.self, from: data)', '''    if operation == "nist-anova-decimal" {
      let input = try JSONDecoder().decode(DecimalANOVAInput.self, from: data)
      guard input.operation == operation, input.groups.count >= 2,
        input.groups.allSatisfy({ !$0.isEmpty }),
        input.groups.reduce(0, { $0 + $1.count }) == rows, rows > input.groups.count
      else { throw BenchmarkFailure("Invalid decimal ANOVA dimensions") }
      return .decimalANOVA(groups: input.groups)
    }
    let input = try JSONDecoder().decode(ANOVAInput.self, from: data)''')
edit('Benchmarks/Worker/NumericalWorkloads.swift','    case .anova(let groups):', '''    case .decimalANOVA(let groups):
      let result = try Stats.oneWayANOVA(decimalGroups: groups)
      return .values([result.fStatistic, Double(result.dfBetween), Double(result.dfWithin)])
    case .anova(let groups):''')
edit('Benchmarks/Python/standard_worker.py', '        elif op == "ols-cpu":', '        elif op == "nist-anova-decimal":\n            decimal_groups = numerical["groups"]\n        elif op == "ols-cpu":')
edit('Benchmarks/Python/standard_worker.py', '        if op == "nist-anova":', '''        if op == "nist-anova-decimal":
            from decimal import Decimal, Inexact, localcontext
            with localcontext() as context:
                context.prec = 80
                context.traps[Inexact] = True
                origin = Decimal(decimal_groups[0][0])
                centered = [np.asarray([float(Decimal(v) - origin) for v in g]) for g in decimal_groups]
            return [stats.f_oneway(*centered).statistic, len(centered)-1, request["rows"]-len(centered)]
        if op == "nist-anova":''')
