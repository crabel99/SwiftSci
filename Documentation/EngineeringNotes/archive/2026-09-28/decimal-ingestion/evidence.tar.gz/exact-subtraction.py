from pathlib import Path
r=Path('/Users/crabel/Documents/src/SwiftSci');p=r/'Sources/SwiftStats/Core/Stats+DecimalANOVA.swift'
s=p.read_text().replace('import Foundation\n','')
a=s.index('        var origin =');b=s.index('        return try oneWayANOVA(groups: residuals)',a)
s=s[:a]+'''        let origin = try ANOVADecimal.parse(decimalGroups[0][0])
        let residuals = try decimalGroups.map { group in
            try group.map { text in
                let value = try ANOVADecimal.parse(text)
                let residual = try value.subtracting(origin)
                guard let converted = Double(residual.text), converted.isFinite,
                      converted != 0 || residual.digits == "0" else {
                    throw StatsError.invalidInput("oneWayANOVA: decimal residual exceeds binary64 range")
                }
                return converted
            }
        }
'''+s[b:]
a=s.index('/// Strict parsing');b=s.index('    private static func normalize',a)
s=s[:a]+'''/// Bounded decimal coefficients keep parsing and subtraction exact before conversion.
private struct ANOVADecimal: Equatable {
    let negative: Bool
    let digits: String
    let exponent: Int

    var text: String { (negative ? "-" : "") + digits + "e" + String(exponent) }

    static func parse(_ text: String) throws -> ANOVADecimal {
        let value = try normalize(text)
        guard value.digits.count <= 38, (-128...127).contains(value.exponent) else {
            throw StatsError.invalidInput("oneWayANOVA: decimal input is outside the supported exact range")
        }
        return value
    }

    func subtracting(_ other: ANOVADecimal) throws -> ANOVADecimal {
        let commonExponent = min(exponent, other.exponent)
        // Input bounds limit the aligned coefficients to at most 293 digits.
        func aligned(_ value: ANOVADecimal) -> [UInt8] {
            if value.digits == "0" { return [0] }
            return Array(repeating: 0, count: value.exponent - commonExponent)
                + value.digits.utf8.reversed().map { $0 - 48 }
        }
        let left = aligned(self), right = aligned(other)
        var result: [UInt8] = []
        let sign: Bool
        if negative != other.negative {
            sign = negative
            var carry: UInt8 = 0
            for i in 0..<max(left.count, right.count) {
                let sum = (i < left.count ? left[i] : 0) + (i < right.count ? right[i] : 0) + carry
                result.append(sum % 10)
                carry = sum / 10
            }
            if carry != 0 { result.append(carry) }
        } else {
            let leftIsSmaller = left.count != right.count
                ? left.count < right.count
                : left.reversed().lexicographicallyPrecedes(right.reversed())
            let larger = leftIsSmaller ? right : left
            let smaller = leftIsSmaller ? left : right
            sign = leftIsSmaller ? !negative : negative
            var borrow = 0
            for i in larger.indices {
                var difference = Int(larger[i]) - (i < smaller.count ? Int(smaller[i]) : 0) - borrow
                borrow = difference < 0 ? 1 : 0
                if difference < 0 { difference += 10 }
                result.append(UInt8(difference))
            }
        }
        guard let first = result.firstIndex(where: { $0 != 0 }),
              let last = result.lastIndex(where: { $0 != 0 }) else {
            return ANOVADecimal(negative: false, digits: "0", exponent: 0)
        }
        guard last - first + 1 <= 38 else {
            throw StatsError.invalidInput("oneWayANOVA: decimal subtraction exceeds 38 significant digits")
        }
        return ANOVADecimal(negative: sign,
                           digits: String(decoding: result[first...last].reversed().map { $0 + 48 }, as: UTF8.self),
                           exponent: commonExponent + first)
    }

'''+s[b:]
s=s.replace('-> Canonical','-> ANOVADecimal').replace('return Canonical(', 'return ANOVADecimal(')
p.write_text(s)
p=r/'Tests/SwiftStatsTests/DecimalANOVATests.swift';s=p.read_text();at=s.index('    @Test("Retains the existing')
s=s[:at]+'''    @Test("Preserves scale invariance at the supported exponent boundaries",
          arguments: [-128, -60, -1, 0, 60, 127])
    func exponentBounds(exponent: Int) throws {
        let groups = [[1, 2, 3], [4, 5, 6]].map { $0.map { "\\($0)e\\(exponent)" } }
        let result = try Stats.oneWayANOVA(decimalGroups: groups)
        #expect(abs(result.fStatistic - 13.5) < 1e-12)
    }

    @Test("Checks full-precision carries, borrows and opposite signs")
    func coefficientArithmetic() throws {
        for prefix in ["99999999999999999999999999999999999", "-99999999999999999999999999999999999"] {
            let groups = [[1, 2, 3], [4, 5, 6]].map { $0.map { prefix + String($0) } }
            #expect(abs(try Stats.oneWayANOVA(decimalGroups: groups).fStatistic - 13.5) < 1e-12)
        }
        let groups = [["-2", "-1", "0"], ["1", "2", "3"]]
        #expect(abs(try Stats.oneWayANOVA(decimalGroups: groups).fStatistic - 13.5) < 1e-12)
        #expect(throws: StatsError.self) {
            try Stats.oneWayANOVA(decimalGroups: [["99999999999999999999999999999999999999", "0"], ["-2", "-1"]])
        }
    }

'''+s[at:];p.write_text(s)
p=r/'Sources/SwiftStats/SwiftStats.docc/DecimalANOVA.md';s=p.read_text().replace('Foundation must represent each parsed value exactly; the implementation verifies this with a decimal round trip.', 'Swift integer digit arithmetic parses each coefficient and subtracts aligned coefficients without rounding. A residual with more than 38 significant decimal digits is rejected before binary64 conversion.');p.write_text(s)
