import Foundation

extension Stats {
    /// One-way ANOVA that preserves decimal differences before binary64 conversion.
    ///
    /// Pass the original decimal text, not strings reconstructed from `Double`.
    /// The first observation is subtracted from every observation in decimal
    /// arithmetic. The existing binary64 ANOVA then operates on those residuals.
    /// See <doc:DecimalANOVA> for input limits and numerical guarantees.
    public static func oneWayANOVA(decimalGroups: [[String]]) throws -> ANOVAResult {
        guard decimalGroups.count >= 2 else {
            throw StatsError.invalidGroupCount(minimum: 2, got: decimalGroups.count)
        }
        for group in decimalGroups {
            try requireNonEmpty(group, minimum: 1)
        }
        var origin = try ANOVADecimal.parse(decimalGroups[0][0])
        let residuals = try decimalGroups.map { group in
            try group.map { text in
                var value = try ANOVADecimal.parse(text)
                var residual = Decimal()
                guard NSDecimalSubtract(&residual, &value, &origin, .plain) == .noError else {
                    throw StatsError.invalidInput("oneWayANOVA: decimal subtraction cannot preserve all digits")
                }
                guard let converted = Double(NSDecimalString(&residual, ANOVADecimal.locale)),
                      converted.isFinite, converted != 0 || residual == 0 else {
                    throw StatsError.invalidInput("oneWayANOVA: decimal residual exceeds binary64 range")
                }
                return converted
            }
        }
        return try oneWayANOVA(groups: residuals)
    }
}

/// Strict parsing prevents Foundation's prefix parsing or rounding from losing input digits.
private enum ANOVADecimal {
    static let locale = Locale(identifier: "en_US_POSIX")

    private struct Canonical: Equatable {
        let negative: Bool
        let digits: String
        let exponent: Int

        var text: String { (negative ? "-" : "") + digits + "e" + String(exponent) }
    }

    static func parse(_ text: String) throws -> Decimal {
        let canonical = try normalize(text)
        guard canonical.digits.count <= 38, (-128...127).contains(canonical.exponent),
              var value = Decimal(string: canonical.text, locale: locale), !value.isNaN,
              try normalize(NSDecimalString(&value, locale)) == canonical else {
            throw StatsError.invalidInput("oneWayANOVA: decimal input is outside the supported exact range")
        }
        return value
    }

    private static func normalize(_ text: String) throws -> Canonical {
        let bytes = Array(text.utf8)
        var i = 0
        func digit(_ b: UInt8) -> Bool { b >= 48 && b <= 57 }
        let negative = bytes.first == 45
        if bytes.first == 45 || bytes.first == 43 { i += 1 }
        var digits: [UInt8] = []
        while i < bytes.count && digit(bytes[i]) { digits.append(bytes[i]); i += 1 }
        var fractionCount = 0
        if i < bytes.count && bytes[i] == 46 {
            i += 1
            while i < bytes.count && digit(bytes[i]) {
                digits.append(bytes[i]); fractionCount += 1; i += 1
            }
        }
        guard !digits.isEmpty else {
            throw StatsError.invalidInput("oneWayANOVA: expected an ASCII decimal number")
        }
        var exponent = 0
        if i < bytes.count && (bytes[i] == 69 || bytes[i] == 101) {
            i += 1
            let start = i
            if i < bytes.count && (bytes[i] == 43 || bytes[i] == 45) { i += 1 }
            let firstDigit = i
            while i < bytes.count && digit(bytes[i]) { i += 1 }
            guard i > firstDigit,
                  let parsed = Int(String(decoding: bytes[start..<i], as: UTF8.self)) else {
                throw StatsError.invalidInput("oneWayANOVA: invalid decimal exponent")
            }
            exponent = parsed
        }
        guard i == bytes.count else {
            throw StatsError.invalidInput("oneWayANOVA: expected an ASCII decimal number")
        }
        guard let first = digits.firstIndex(where: { $0 != 48 }) else {
            return Canonical(negative: false, digits: "0", exponent: 0)
        }
        let last = digits.lastIndex(where: { $0 != 48 })!
        let (fractionAdjusted, overflow) = exponent.subtractingReportingOverflow(fractionCount)
        let (normalizedExponent, trailingOverflow) = fractionAdjusted.addingReportingOverflow(digits.count - last - 1)
        guard !overflow && !trailingOverflow else {
            throw StatsError.invalidInput("oneWayANOVA: decimal exponent exceeds supported range")
        }
        return Canonical(negative: negative,
                         digits: String(decoding: digits[first...last], as: UTF8.self),
                         exponent: normalizedExponent)
    }
}
