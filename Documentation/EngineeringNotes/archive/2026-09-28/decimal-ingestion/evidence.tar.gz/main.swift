import Foundation
let base = URL(fileURLWithPath: "/Users/crabel/Documents/src/SwiftSci/Benchmarks/Fixtures/nist-models/originals")
for name in ["SmLs07", "SmLs08", "SmLs09"] {
    let lines = try String(contentsOf: base.appendingPathComponent(name + ".dat"), encoding: .ascii).components(separatedBy: "\n")
    var groups = Array(repeating: [String](), count: 9)
    for line in lines.dropFirst(60) where !line.trimmingCharacters(in: .whitespaces).isEmpty {
        let parts = line.split(whereSeparator: { $0.isWhitespace })
        groups[Int(parts[0])! - 1].append(String(parts[1]))
    }
    let result = try Stats.oneWayANOVA(decimalGroups: groups)
    print(name, result.fStatistic)
}

struct QualifiedCase: Decodable { let id: Int; let groups: [[String]]; let f: Double }
let cases = try JSONDecoder().decode([QualifiedCase].self, from: Data(contentsOf: URL(fileURLWithPath: "/private/tmp/swiftsci-decimal-ingestion/qualification.json")))
var maximumRelativeError = 0.0
for item in cases {
    let actual = try Stats.oneWayANOVA(decimalGroups: item.groups).fStatistic
    let error = abs(actual - item.f) / max(abs(item.f), 1e-30)
    guard error < 1e-12 else { fatalError("qualification failure: \(item.id), \(actual), \(item.f)") }
    maximumRelativeError = max(maximumRelativeError, error)
}
print("Independent qualification:", cases.count, "passed; max relative error:", maximumRelativeError)
for exponent in [-128, -60, -1, 0, 60, 127] {
    let groups = [[1, 2, 3], [4, 5, 6]].map { $0.map { "\($0)e\(exponent)" } }
    let f = try Stats.oneWayANOVA(decimalGroups: groups).fStatistic
    guard abs(f - 13.5) < 1e-12 else { fatalError("range failure: \(exponent), \(f)") }
    print("Exponent boundary:", exponent, f)
}
