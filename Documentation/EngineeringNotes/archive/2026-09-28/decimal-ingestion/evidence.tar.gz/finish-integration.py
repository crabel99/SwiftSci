from pathlib import Path
import json,hashlib
r=Path('/Users/crabel/Documents/src/SwiftSci')
for p in (r/'Benchmarks/Specs/datasets').glob('nist-*-decimal.json'):
 o=json.loads(p.read_text())
 if o['operation']!='nist-anova':continue
 for key,sha,size in [('fixture','sha256','size_bytes'),('reference_fixture','reference_sha256','reference_size_bytes')]:
  o[key]=o[key].removesuffix('.json')+'-decimal.json'
  raw=(r/o[key]).read_bytes();o[sha]=hashlib.sha256(raw).hexdigest();o[size]=len(raw)
 o['operation']='nist-anova-decimal';o['generator_version']=2
 p.write_text(json.dumps(o,indent=2)+'\n')
p=r/'Benchmarks/Tests/test_numerical_fixtures.py';s=p.read_text();s+='''
    def test_original_decimal_tokens_survive_fixture_construction(self):
        for case in load_profile(ROOT, 'numerical-conformance')['cases']:
            m, w = self.fixture(case['dataset'])
            if m['operation'] != 'nist-anova-decimal':
                continue
            payload = json.loads(prepare(ROOT, m).read_text())
            original = (ROOT / m['source_fixture']).read_text().splitlines()[60:]
            expected = {}
            for line in original:
                if line.strip():
                    label, token = line.split()
                    expected.setdefault(label, []).append(token)
            self.assertEqual(payload['groups'], list(expected.values()))
            binary = load_manifest(ROOT, case['dataset'].replace('-decimal', '-binary64'))
            self.assertNotEqual(m['sha256'], binary['sha256'])
            self.assertEqual(m['tolerances'], binary['tolerances'])
            decimal_reference = json.loads((ROOT / m['reference_fixture']).read_text())
            binary_reference = json.loads((ROOT / binary['reference_fixture']).read_text())
            for key in ['nistCertifiedValues', 'independentDecimalReference', 'binary64InputDiagnostic']:
                self.assertEqual(decimal_reference[key], binary_reference[key])

    def test_decimal_fixture_rejects_numeric_tokens_and_answer_leakage(self):
        for value in [1.1, True, None, '1x', 'NaN', ' 1', '1_000', '١']:
            with self.assertRaises(ContractError):
                validate_input(dict(operation='nist-anova-decimal', groups=[['1', '2'], [value, '4']]), 'nist-anova-decimal', 4)
        with self.assertRaises(ContractError):
            validate_input(dict(operation='nist-anova-decimal', groups=[['1', '2'], ['3', '4']], expected=[1]), 'nist-anova-decimal', 4)

    def test_decimal_and_binary64_operations_cannot_swap_reference_bases(self):
        from numerical_fixtures import validate_manifest
        for suffix, basis in [('decimal', 'binary64-v1'), ('binary64', 'nist-decimal-v1')]:
            m, _ = self.fixture('nist-smls09-' + suffix)
            m['reference_basis'] = basis
            with self.assertRaises(ContractError):
                validate_manifest(m)
''';p.write_text(s)
p=r/'Sources/SwiftStats/SwiftStats.docc/DecimalANOVA.md';p.write_text('''# ANOVA from original decimal observations

Preserve small differences around a large offset before converting observations to `Double`.

## Choose the input path

Use `Stats.oneWayANOVA(groups:)` for existing `Double` arrays. It operates on their binary64 values. It cannot recover decimal digits lost before the call.

Use `Stats.oneWayANOVA(decimalGroups:)` when the original observations are decimal text:

```swift
let result = try Stats.oneWayANOVA(decimalGroups: [
    ["10000000000000000.1", "10000000000000000.2", "10000000000000000.3"],
    ["10000000000000000.4", "10000000000000000.5", "10000000000000000.6"]
])
// result.fStatistic is approximately 13.5.
```

Keep the source text from CSV, JSON strings or instrument output. Formatting an already converted `Double` as a string cannot restore the original decimal value.

## What the decimal path preserves

The method parses the observations as exact decimal values, subtracts the first observation from every group, then converts the residuals to `Double`. It uses one common origin because subtracting a different origin from each group would change the between-group variation. ANOVA's F statistic, degrees of freedom, p-value and effect size are invariant under a common translation in exact arithmetic.

Parsing and subtraction occur once per call. The method then uses the existing binary64 ANOVA implementation. It does not turn the statistical calculation into arbitrary-precision arithmetic. Residual conversion still rounds to binary64, and subsequent operations retain binary64's precision and range limits. A dataset with a wide dynamic range can still need a different representation or algorithm.

## Accepted decimal text

Inputs use ASCII digits, an optional leading sign, a period as the decimal separator, and an optional `e` or `E` exponent. Examples include `-0.2`, `.2`, `2.` and `2e-1`. Whitespace, grouping separators, trailing text, NaN and infinity are rejected.

After removing leading and trailing zeros, a nonzero input must have at most 38 significant decimal digits and a coefficient exponent between -128 and 127. For example, `12.30` normalizes to `123 × 10^-1`. Zero ignores its sign and scale. Foundation must represent each parsed value exactly; the implementation verifies this with a decimal round trip.

The method throws `StatsError.invalidInput` if parsing or common-origin subtraction would lose decimal information. Group-count, empty-group and zero-within-group-variance errors follow the existing ANOVA API. Decimal parsing and checked subtraction cost more than accepting preconverted arrays. Use this path when preserving the source decimal differences matters.

## Validation

The NIST benchmark suite keeps separate original-decimal and exact-binary64-input workloads. Original-decimal ANOVA fixtures retain NIST's source tokens as strings and call this method. Binary64 fixtures continue to call `oneWayANOVA(groups:)`. Both retain their declared reference answers and acceptance tolerances.
''')
p=r/'Sources/SwiftStats/SwiftStats.docc/SwiftStats.md';p.write_text(p.read_text()+'- <doc:DecimalANOVA>\n')
p=r/'Benchmarks/Fixtures/nist-models/README.md';s=p.read_text().replace('Both use the same input bytes and the same CPU API calls.', 'OLS retains the same binary64 input bytes and CPU API calls in both profiles. ANOVA uses separate inputs and explicit API paths.')
s=s.replace('- `numerical-conformance` checks', '- `numerical-conformance` passes original ANOVA decimal tokens to `Stats.oneWayANOVA(decimalGroups:)` and checks')
s=s.replace('Both profiles retain these cases and report failures. They never relax a threshold or exclude a difficult dataset based on measured results.', 'The original-decimal ANOVA path subtracts one common origin in checked decimal arithmetic before converting residuals to binary64. The binary64 profile keeps the original conversion and checks its independently computed answers. Neither profile relaxes a threshold or excludes a difficult dataset based on measured results.')
s=s.replace('ANOVA times the public operation and exports F and both degrees of freedom.', 'Binary64 ANOVA times the existing public operation. Decimal ANOVA also includes decimal parsing, checked subtraction and residual conversion inside the timed public call. Its Python comparator performs checked Decimal centering before SciPy ANOVA. Both export F and both degrees of freedom. Compare timings only within the same declared workload.')
s+='\nDecimal ANOVA inputs and references use the `-decimal.json` suffix. Their input identities differ from the binary64 files; the reference numbers are unchanged. Reconstruction preserves each original decimal token verbatim. The worker receives no certified answers.\n';p.write_text(s)
