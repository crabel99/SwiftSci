import Foundation
let loc = Locale(identifier: "en_US_POSIX")
for s in ["1.0000000000004e12", "1e-128", "1e127", "1e128", "12345678901234567890123456789012345678901", "-0", "1x", ".1", "+1"] {
  if var d = Decimal(string:s, locale:loc) { print(s, NSDecimalString(&d, loc), d.isNaN) } else { print(s, "nil") }
}
var a = Decimal(string: "1e127")!, b = Decimal(string: "1e-128")!, c = Decimal()
print(NSDecimalSubtract(&c, &a, &b, .plain), c)
