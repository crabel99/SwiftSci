from pathlib import Path
root=Path('/Users/LOCAL_USER/Documents/src/SwiftSci')
p=root/'Sources/SwiftStats/Core/Stats+DecimalANOVA.swift'
p.write_text('''import Foundation

extension Stats {
    /// One-way ANOVA that preserves decimal differences before binary64 conversion.
    ///
    /// Pass the original decimal text, not strings reconstructed from `Double`.
    /// The first observation is subtracted from every observation in decimal
    /// arithmetic. The existing binary64 ANOVA then operates on those residuals.
    /// See <doc:DecimalANOVA> for input limits and numerical guarantees.
    public static func oneWayANOVA(decimalGroups: [[String]]) throws -> ANOVAResult {
        try oneWayANOVA(groups: decimalGroups.map { $0.map { Double($0)! } })
    }
}
''')
# Compile the public API with a temporary failing implementation to capture the reproduction.
src=Path('/private/tmp/swiftsci-dot-implementation/build-public.py').read_text()
src=src.replace("files += ['Sources/SwiftStats/Core/'+n+'.swift' for n in ['DotProductAccuracy','CompensatedDotProduct','ExactDotProduct'] if 'Sources/SwiftStats/Core/'+n+'.swift' not in files]", "files += ['Sources/SwiftStats/Core/Stats+DecimalANOVA.swift']")
src=src.replace('/private/tmp/swiftsci-dot-implementation/public/', '/private/tmp/swiftsci-decimal-ingestion/')
Path('/private/tmp/swiftsci-decimal-ingestion/build-public.py').write_text(src)
Path('/private/tmp/swiftsci-decimal-ingestion/main.swift').write_text('''import Foundation
let base = URL(fileURLWithPath: "/Users/LOCAL_USER/Documents/src/SwiftSci/Benchmarks/Fixtures/nist-models/originals")
for name in ["SmLs07", "SmLs08", "SmLs09"] {
    let lines = try String(contentsOf: base.appendingPathComponent(name + ".dat"), encoding: .ascii).components(separatedBy: .newlines)
    var groups = Array(repeating: [String](), count: 9)
    for line in lines.dropFirst(60) where !line.trimmingCharacters(in: .whitespaces).isEmpty {
        let parts = line.split(whereSeparator: { $0.isWhitespace })
        groups[Int(parts[0])! - 1].append(String(parts[1]))
    }
    let result = try Stats.oneWayANOVA(decimalGroups: groups)
    print(name, result.fStatistic)
}
''')
