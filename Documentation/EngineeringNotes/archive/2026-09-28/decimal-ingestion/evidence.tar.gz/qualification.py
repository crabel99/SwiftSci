from pathlib import Path
from decimal import Decimal,localcontext
import random,json
p=Path(__file__).parent
rng=random.Random(9282026)
cases=[]
with localcontext() as ctx:
 ctx.prec=100
 for i in range(300):
  precision=rng.choice([1,8,16,24,32]); exp=rng.choice([-100,-40,-4,0,30,80])
  origin=Decimal(rng.choice([-1,1]))*Decimal(10)**precision
  groups=[[rng.randint(-1000,1000) for _ in range(rng.randint(2,30))] for _ in range(rng.randint(2,8))]
  texts=[[str((origin+Decimal(v))*Decimal(10)**exp) for v in g] for g in groups]
  n=sum(map(len,groups));k=len(groups)
  means=[sum(map(Decimal,g))/len(g) for g in groups]
  mean=sum(sum(map(Decimal,g)) for g in groups)/n
  between=sum(len(g)*(m-mean)**2 for g,m in zip(groups,means))
  within=sum((Decimal(v)-m)**2 for g,m in zip(groups,means) for v in g)
  f=between/(k-1)/(within/(n-k))
  cases.append({'id':i,'groups':texts,'f':float(f)})
(p/'qualification.json').write_text(json.dumps(cases))
