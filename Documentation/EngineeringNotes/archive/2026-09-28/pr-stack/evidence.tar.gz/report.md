# Four-PR implementation sequence

Date: 2026-09-28

The four branches are published to the fork and have upstream draft PRs:

| Contribution | PR | Branch |
| --- | --- | --- |
| Testing and benchmarks | [#41](https://github.com/Nodibell/SwiftSci/pull/41) | codex/standardized-benchmarks |
| Nine fault repairs | [#43](https://github.com/Nodibell/SwiftSci/pull/43) | codex/certification-fault-repairs |
| Precision policies and decimal ANOVA | [#44](https://github.com/Nodibell/SwiftSci/pull/44) | codex/apple-silicon-precision |
| Compact numerical preparation | [#45](https://github.com/Nodibell/SwiftSci/pull/45) | codex/compact-column-storage |

## Integration decisions

Merge in the order above. Each downstream branch contains its predecessors. All PRs target upstream main because prerequisite branch refs exist only on the fork. PR descriptions link to contribution-only comparisons and disclose the cumulative GitHub diffs. Once a prerequisite merges, update the next branch and verify that accepted changes disappear from its diff. Revalidate changed implementation and conflict resolutions.

PR #41 deliberately retains a failing baseline. Combined downstream results must not be presented as passing results for that standalone branch. The repair-only branch still needs an acceptance run on its final head before readiness. Precision policy needs review of accuracy contracts and cost. Compact storage needs ownership/API review and maintained first-use, reuse, mutation, snapshot and layout performance workloads before those are treated as a formal baseline. Current regression tests validate those behaviors. Minimum-toolchain and wider hardware qualification remain unclaimed.

## Clean compact contribution

The original branch is preserved locally as `codex/compact-column-storage-pre-integration` at `20dad063b976c3b03d07da7610609992b3c74bee`. Its original prototype and engineering-result directories are retained in the nested `compact-original-evidence.tar.gz` archive. They were not published in the compact PR branch's history.

The new compact branch starts at the updated precision branch. Seven implementation/test commits were reapplied without conflict, and the public API guide was added separately. The production files and guide match their original compact-branch bytes. The contribution contains 13 files, 948 additions and 100 deletions. It retains additive APIs, Swift tools 6.0 and macOS 14. No engineering-notes branch was merged into contribution history.

Current compact head: `fb56f3ac30c5acd5b4f63b6c8e4cd4ff6cf5dd80`.
Source fingerprint: `13d1c4a2f6220f7cda4a4cb94a74db71da6106722619fed7e029f5d3e33f468a`.

## Fresh validation

- Clean tracked-source Release build succeeded with benchmark coverage instrumentation absent.
- Full Release unit suite: 966 tests, 1,138 executions including parameterized cases, no failures or skips.
- Standard profile: all 84 Swift/Python executions passed, and the certificate audit passed.
- CPU acceptance: 15 profiles, 392 engine-case executions, 388 passed. Complete coverage, no infrastructure errors. Failure details are retained in the report.
- Workflow corruption-control results are retained with the evidence.

The comparison table in PR #45 uses the same resolved standard workload contracts as the earlier precision-branch run, verified by contract and case equality. It uses median timings across 15 samples per engine/case. The runs were separate sessions on a shared M4 Max, not alternating baseline/candidate processes. These are descriptive measurements, not the formal baseline.

| 100,000-row operation | Earlier Swift ms | Compact Swift ms | Current Python ms |
| --- | ---: | ---: | ---: |
| Target extraction | 3.958542 | 0.058083 | 0.111584 |
| Flat matrix | 0.131041 | 0.114709 | 0.697291 |
| Standard scaling and flat export | 28.393000 | 2.785333 | 0.891666 |
| Min-max scaling and flat export | 33.164708 | 0.751166 | 0.785417 |

## Evidence

[Archive](../archive/2026-09-28/pr-stack/evidence.tar.gz) contains the old compact evidence, updated branch mapping, PR drafts, public compact-only diff, build provenance, unit summary/log, standard run and audit, CPU acceptance and workflow controls. Xcode result bundles and generated compiled model directories are omitted. Full local artifacts remain under `/private/tmp/swiftsci-pr-stack`.
