## Problem and result

Scientific reductions need a fast default and an explicit way to spend more computation on accuracy. Large-offset statistics also need to distinguish arithmetic error from precision lost before the calculation begins.

This change adds a performance/compensated dot-product policy, improves centered variance and ANOVA reductions, and provides an explicit decimal-string ANOVA entry point. Existing Double-input APIs and the two-argument dot-product call remain available.

## Review scope and implementation

This draft depends on #43 and #41. Until those merge, GitHub's upstream-main diff includes their changes. The [precision-only comparison](https://github.com/crabel99/SwiftSci/compare/fe23b1b35a6193c26368831b28b83b336e5a61aa...34b532a6e0550b1ab9cde03d1b0b9d355a492b09) contains four implementation commits:

1. Centered variance with bounded SIMD reductions and no input-sized centered temporary.
2. Reuse of blocked centered moments in ANOVA.
3. `DotProductAccuracy.performance` and `.compensated`. Performance remains the default and uses Accelerate vDSP/BLAS. The stronger path uses compensated accumulation with exact fallback for unsafe ranges or severe cancellation. It does not promise universally correctly rounded finite results.
4. `Stats.oneWayANOVA(decimalGroups:)`. Parse bounded decimal strings, subtract a common origin before conversion to Double, then use the numerical reduction. Unsupported precision/range throws rather than silently discarding information. The documented parser limits remain part of the API contract.

The original binary64 inputs, references, and tolerances are retained. Original-decimal ANOVA uses separate string fixtures and an explicitly named workload. It does not relabel previously rounded Double input as exact decimal data.

## Performance and accuracy evidence

Recorded on an M4 Max, macOS 27, Swift 6.4, optimized Release, with matching input hashes and Apple Accelerate NumPy/SciPy references. These timings compare repair base `36053baca6` with precision implementation `3a31534e36`; subsequent merges changed CI/build compatibility only. Times are milliseconds.

| Operation | Repair base | Precision | Python |
| --- | ---: | ---: | ---: |
| Dot, 65,536 values | 0.008969 | 0.001729 | 0.002062 |
| Dot, 1,048,576 values | 0.156875 | 0.051166 | 0.053583 |
| Dot, 8,388,608 values | 1.24925 | 0.934916 | 0.78975 |
| ANOVA, three groups of 1,048,576 | 8.441708 | 5.020083 | 4.987125 |

Measurements used three rotating-order processes per engine, nine samples after four warmups, and reused buffers. They characterize these workloads, not universal speedups or a formal performance baseline. The 8-million-value dot process ranges overlap.

The accurate path has a real cost: a one-million-value mixed dot took about 1.56 ms versus 0.051 ms for the fast path. Cancellation requiring stronger fallback cost more. Centered variance improved numerical validity and eliminated an approximately 64 MiB temporary at 8,388,608 values, but some measured variance timings were slightly slower.

All three original-decimal SmLs ANOVA cases now meet the declared reference checks. Decimal parsing adds cost; for SmLs09 the measured Swift decimal path was about 1.84 times slower than the Python decimal preparation/reference path. The fast rounded-input API is not an accuracy-equivalent comparator.

## Validation and merge strategy

At integrated head `34b532a6e0`, full Release testing passed 944 tests, 1,105 executions, with zero failures or skips. Controller tests passed 147/147. All 15 CPU profiles completed: Swift 196/196 passed, Python 192/196 passed, with the four known Wampler4/Wampler5 comparisons still failing. Public-workflow controls passed 100/100. Source fingerprint: `412f3c8f03ba62705584a1a19b57365e1e1880e15d24d1f698c571cbb83045d7`.

Earlier focused qualification matched 3,092 exact dot-product cases and checked 300 independent high-precision decimal ANOVA cases. These checks support the tested cases, not a universal numerical-stability guarantee.

Merge the testing and repair prerequisites first. Then update this draft, confirm that only these four changes remain, and review the accuracy API, decimal limits, and performance tradeoffs before marking it ready. Repeat validation after any implementation or conflict-resolution changes. Compact dataframe storage and scaler allocation changes are a separate contribution.

## Related drafts

Merge order: #41 testing → #43 repairs → #44 precision → #45 compact numerical preparation. The downstream drafts remain separate review decisions.
