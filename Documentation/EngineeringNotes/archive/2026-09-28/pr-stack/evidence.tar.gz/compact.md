## Problem and result

Dataframe-to-numerical workflows allocate optional columns and nested matrices repeatedly. Target extraction previously constructed a one-column matrix just to flatten it, and dataframe scaling repeated conversion and row allocation.

This change resolves numeric columns once, extracts target vectors directly, reuses scaler workspaces, and adds `PreparedNumericBatch` for pipelines that can retain contiguous Double columns between operations. It is an additive step toward #40, not a replacement of heterogeneous dataframe storage.

## Review scope

This draft follows #44, #43, and #41. GitHub's upstream-main diff includes those prerequisites until they merge. Review the compact-only contribution in [this comparison](https://github.com/crabel99/SwiftSci/compare/34b532a6e0550b1ab9cde03d1b0b9d355a492b09...fb56f3ac30).

The compact contribution contains seven implementation commits and one public API guide, totaling 13 files. It changes dataframe numeric extraction, concrete StandardScaler/MinMaxScaler integration, and their regression tests. Historical prototypes and internal engineering reports are excluded from this branch's contribution and history.

## Implementation strategy and compatibility

1. Consolidate conversion paths while preserving accepted types, feature order, repeated columns, missing values, and zero-dimensional behavior.
2. Add owned contiguous Double columns with optional validity bitmaps. Missing entries remain distinct from valid NaNs.
3. Route concrete dataframe scaler conveniences through prepared columns. StandardScaler retains the previous row-width vDSP arithmetic sequence, with reusable scratch, to preserve finite results. Generic preprocessing adapters retain their dispatch.
4. Preserve original row positions through selections, including duplicates and repeated selection. Export explicitly row-major or column-major numerical buffers.
5. Support validated, fixed-size batched column updates. Validate every edit before mutation. Copy-on-write preserves batch snapshots and previously exported matrices.

Existing `TypedColumn.values`, heterogeneous storage, and matrix APIs retain their contracts. Int64-to-Double retains the existing conversion precision limits. Scalers retain their existing NaN arithmetic and do not provide imputation or preserve input validity masks in scaled output.

Swift tools version 6.0 and minimum macOS 14 are unchanged. Validation here uses Swift 6.4 on Apple silicon; it is not a separate minimum-toolchain certification. Appending rows, changing schemas, generic compact element types, borrowed foreign buffers, and zero-copy MLX/Metal/NumPy/Arrow adapters remain outside this PR. The batch owns CPU memory; unified physical memory does not itself guarantee API-level zero-copy interoperability.

See [the public API and ownership guide](https://github.com/crabel99/SwiftSci/blob/codex/compact-column-storage/Documentation/CompactNumericBatches.md).

## Validation

The integrated branch passed all 966 Release tests, with 1,138 executions including parameterized cases, zero failures and zero skips. Tests cover bitmap boundaries, valid NaNs, invalid and repeated indices, atomic rejection, snapshots, independent concurrent copies, composed row identity, both matrix layouts, and actual BLAS consumption.

The maintained `standard` profile passed all 84 Swift/Python executions and its certificate audit. All 14 workloads use three process batches, two warmups and five samples per batch. Source fingerprint: `13d1c4a2f6220f7cda4a4cb94a74db71da6106722619fed7e029f5d3e33f468a`. All 15 CPU conformance profiles completed with complete coverage and no infrastructure errors: Swift passed 196/196 engine-case executions; Python passed 192/196. The four known Wampler4/Wampler5 intercept comparisons remain failures in the two numerical profiles, so aggregate acceptance correctly remains failed. No new failure identities appeared after compact integration. All 100 public-workflow corruption controls passed, with no excluded baseline cases.

The table compares medians across 15 samples with the earlier precision-branch run at `3a31534e36`. Dataset, resolved workload and contract hashes match. Both use optimized Release without coverage instrumentation on the same M4 Max, with pinned Python references. Times are milliseconds for the 100,000-row fixture.

| Operation | Earlier Swift | Compact Swift | Current Python |
| --- | ---: | ---: | ---: |
| Target vector | 3.958542 | 0.058083 | 0.111584 |
| Flat feature matrix | 0.131041 | 0.114709 | 0.697291 |
| Dataframe standard scaling and flat export | 28.393000 | 2.785333 | 0.891666 |
| Dataframe min-max scaling and flat export | 33.164708 | 0.751166 | 0.785417 |

The earlier and current runs were separate sessions on a shared desktop, not alternating baseline/candidate processes. These measurements support further review; they are not a formal performance baseline or a universal speedup claim. Standard scaling still trails the Python path in this workload. The numerical output checks, rather than speed, determine conformance.

Reproduce with the pinned `Benchmarks/Python/requirements-standardized.txt` environment, `Benchmarks/Tools/bench.py build`, and `bench.py run --profile standard --engines swiftsci,pandas --swift-worker <built-worker> --python <pinned-python> --output <new-directory>`, followed by `bench.py audit <new-directory>`. See the suite README for setup and timing contracts.

## Merge and follow-up criteria

Merge #41, #43, and #44 in order, then update this draft so its upstream diff contains only the compact contribution. Rerun correctness checks after conflict resolution or code changes. Review ownership, mutation behavior, and the public API boundaries before marking it ready.

The standardized `standard` profile exercises the changed public target-extraction and dataframe-scaler routes. Before treating prepared-batch performance as a maintained baseline, extend the suite with explicit first-use/reuse, sparse mutation, snapshot, and matrix-layout workloads. Current regression tests cover their correctness; historical workload measurements are not a substitute for those versioned performance contracts. Broader hardware/size sweeps and minimum-toolchain validation remain separate qualification work.

This is part of #40. It does not close the broader storage and compatibility discussion.
