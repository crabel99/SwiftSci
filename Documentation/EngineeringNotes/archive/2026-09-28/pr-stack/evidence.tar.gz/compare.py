from pathlib import Path
import json,statistics
p=Path(__file__).parent
old=json.loads(Path('/private/tmp/swiftsci-performance-comparison/standard/run.json').read_text())
new=json.loads((p/'standard/run.json').read_text())
assert old['status']==new['status']=='passed'
assert old['plan']['contract_hash']==new['plan']['contract_hash']
assert old['plan']['cases']==new['plan']['cases']
for engine in ['swiftsci','pandas']:
 print(engine)
 for case in ['medium-target','medium-flat-matrix','medium-standard-scale','medium-minmax-scale']:
  def values(r):return [s['elapsed_ns']/1e6 for e in r['events'] if e['engine']==engine and e['case_id']==case for s in e['result']['samples']]
  a=statistics.median(values(old));b=statistics.median(values(new));print(case,round(a,6),round(b,6),round(a/b,2))
