## Problem and result

The conformance suite in #41 exposes failures in supplied model state, numerical calculations, decoder execution, and persistence. This change repairs nine causes with a separate implementation commit and regression tests for each. It preserves the validation suite's expected answers and tolerances.

## Review scope

This draft depends on #41. GitHub currently compares it with upstream `main`, so the displayed diff includes that prerequisite. Review this contribution separately in [the repair-only comparison](https://github.com/crabel99/SwiftSci/compare/7d2dcb33c024e31827cd21d238c6cc72f1fdcdb5...fe23b1b35a6193c26368831b28b83b336e5a61aa).

| Repair | Result |
| --- | --- |
| Supplied linear-regression state | A model initialized with fitted parameters can predict, including after native reload. |
| Supplied logistic-regression state | A model initialized with fitted parameters can predict. |
| Cosine similarity | Nonzero vectors retain meaningful similarity across very small and large scales. |
| PCA explained variance | Component ratios use total fitted variance. |
| Decoder weight loading | Attention weights map to registered MLX parameters. |
| Rotary encoding | Single-token execution covers every batch. |
| One-way ANOVA | Centered calculations reduce large-offset cancellation. |
| OLS coefficient refinement | Compensated residual gradients improve difficult regression fits. |
| Core ML pipeline export | Named scaler stages have valid feature descriptions. |

## Implementation and merge strategy

1. Merge #41 so its fixtures and failure evidence exist independently of the fixes.
2. Update this branch against the accepted testing commit and review the nine repair commits independently.
3. Run CPU conformance and the local Apple/Metal profiles required for decoder changes. Preserve any remaining failures as failures.
4. Merge these repairs before the separate precision-policy and compact-storage contributions. Those additions are outside this PR.

No new precision-selection API is introduced here. This ANOVA repair alone does not recover information already rounded away during decimal-to-Double input conversion.

## Validation

The updated combined repair-and-precision stack at `34b532a6e0` passed the full local Release suite: 944 tests, 1,105 parameterized executions, no failures or skips. All 147 benchmark-controller tests and all 100 public-workflow corruption controls passed. CPU acceptance completed all 15 profiles without infrastructure errors: Swift passed 196/196 engine-case executions; Python passed 192/196, retaining Wampler4 and Wampler5 intercept failures in both numerical profiles.

Those totals include the later precision contribution. They are integration evidence, not a claim that this repair-only branch resolves every numerical case. Before marking this draft ready, rerun acceptance on this branch's own final head and retain its remaining numerical failures. The full local unit suite includes MLX-dependent tests; the latest integration run did not repeat the separate Apple-tier acceptance profiles.

## Related drafts

Merge order: #41 testing → #43 repairs → #44 precision → #45 compact numerical preparation. The downstream drafts remain separate review decisions.
