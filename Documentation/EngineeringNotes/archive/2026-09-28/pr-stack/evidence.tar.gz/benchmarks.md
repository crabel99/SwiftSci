## Problem and resulting behavior

Benchmark timings are useful only when inputs, operation semantics, completed work, and output correctness are comparable. This draft adds a versioned validation and benchmark suite that checks complete results against independent answers, retains failures, and rejects incompatible performance comparisons.

The goal is to establish reproducible evidence for scientific data preparation, numerical computation, and selected AI workflows on Apple silicon before repairing the remaining implementation defects or publishing a formal performance baseline.

## Scope

- Versioned dataset, workload, profile, and response contracts with checksums, provenance, pinned dependencies, and independent reference calculations.
- NIST univariate, regression, and balanced ANOVA datasets; public grouping and supervised datasets; exact and controlled numerical/model fixtures; dataframe semantics; bounded neural, vision, and dataframe-to-tensor checks.
- Fresh-process Swift and Python comparison workers, complete output validation, declared timing boundaries, source/binary identities, retained raw samples, and evidence auditing. A certificate is an unsigned local workload-conformance record, not NIST endorsement or third-party accreditation.
- Migration records for legacy workloads, with unmatched algorithms and model-quality work explicitly retained as research. Kiraa remains an unofficial research reference, not a correctness oracle.
- Two complete public-API workflow profiles: typed CSV → filter → join → matrix → CPU OLS/prediction; and training-only preprocessing/model fitting → persistence → fresh-process held-out prediction. The latter distinguishes fit-only, native regressor reload, and composite Core ML export routes.
- Swift and Python CodeQL analysis, plus CPU acceptance CI with retained artifacts on failure and actual-worker corruption controls. Metal diagnostics and larger sweeps have explicit local execution tiers.

Parquet interoperability landed separately in #42. This branch now includes upstream `main` at `55be1d971c`, so the Parquet reader, writer, and regression fixtures are no longer part of this PR's diff. The CLI entry-point file is renamed without changing its contents. Numerical and persistence repairs remain on separate branches.

## Review entry points

Start with the [suite guide and structure diagram](https://github.com/crabel99/SwiftSci/blob/codex/standardized-benchmarks/Benchmarks/README.md), then the [acceptance policy](https://github.com/crabel99/SwiftSci/blob/codex/standardized-benchmarks/Benchmarks/Specs/acceptance.json) and [public workflow contracts](https://github.com/crabel99/SwiftSci/blob/codex/standardized-benchmarks/Benchmarks/Fixtures/workflows/README.md).

`Benchmarks/Tools` owns preparation, references, execution, and auditing. `Benchmarks/Worker` and `Benchmarks/Python` contain comparison adapters. `Benchmarks/Tests` validates the machinery. Most added lines are pinned inputs and generated reference data, rather than implementation code. Original upstream dataset bytes are preserved, including whitespace.

## Validation

| Check | Recorded result |
| --- | --- |
| Controller suite after merging current upstream `main` | 144 tests passed |
| Integrated Release worker | Built successfully with coverage instrumentation absent |
| Scientific public workflow | 8/8 engine-case executions passed; certificate audit passed |
| Fitted-model/persistence workflow | 8/12 engine-case executions passed; 4 retained Swift failures; complete evidence and no infrastructure errors |
| Actual-worker sensitivity checks | 16 unchanged controls passed; 64 corrupted cases rejected; 4 failing baselines excluded from sensitivity claims |
| Existing CPU dataframe-to-tensor profile | 8/8 engine-case executions passed; certificate audit passed |
| Hosted CPU acceptance after CI fixes | All 15 profiles completed: 392 engine-case executions, 361 passed, 31 failed, zero infrastructure errors; workflow corruption-control step passed |
| Earlier 22-profile acceptance at `ab7aa2f1da` | 1,132 engine-case executions: 1,102 passed, 30 failed, no infrastructure errors |

The workflow results above were recorded at source fingerprint `06fe15359c24e90dd820f61b20832f8865055b661ece5a17e261122c7300c2b8`. CI subsequently exposed entry-point filename conflicts and a compiler type-checking limit. Commit `112bcfb52d` renames the worker and CLI entry-point files and splits the boundary-sweep fixture expression into typed steps, preserving its arithmetic. The current source fingerprint is `9435ebda31ed435401a8e8a7dbc6ec3fc89e13153933a84ec157ee2cd4b2303a` across 364 files. After this fix, local and hosted SwiftPM Debug/Release builds pass. Local Xcode build-for-testing also passes, as do all 144 controller tests, CI's selected unit tests (65 XCTest and 456 Swift Testing cases), all 54 CPU/GPU boundary-sweep cases, and all eight scientific-workflow engine-case executions. Both workload audits pass. Hosted unit tests and documentation checks also pass. The hosted CPU acceptance run completed with the retained failures listed below; Swift CodeQL analysis subsequently passed. Commit `7054d5e93f` restores the Python no-build scan expected by the upstream code-scanning baseline, with Python on Linux and Swift on macOS. The restored Python CodeQL job passed in [run 36363536223](https://github.com/Nodibell/SwiftSci/actions/runs/36363536223/job/108745309046). This workflow-only commit does not change the source fingerprint. The subsequent merge of upstream `main` also leaves this branch's tracked file contents unchanged, so the source fingerprint remains the same; its PR diff now excludes the merged Parquet work. The persistence and sensitivity-control results remain historical evidence; those runs have not been repeated at the changed fingerprint. The full 24-profile acceptance run has not been repeated after adding the two public workflows. Building the worker does not mean the entire library unit-test suite was executed.

The scientific workflow declares CSV types explicitly. Zero/one numeric quality values must not be left to Boolean inference. Its independent expected answers cover row identity, duplicate-key multiplicity, feature/target alignment, coefficients, predictions, and residuals.

## Why this remains a draft

**The conformance CI job is expected to fail on retained library defects.** Failures remain visible and cannot produce passing certificates or performance claims.

The [hosted CPU run](https://github.com/Nodibell/SwiftSci/actions/runs/36360955147) reproduces 31 previously recorded failing engine-case executions: 23 strict numerical-reference comparisons, two supplied-weight inference cases, one near-zero cosine case, one PCA explained-variance case, and four persistence cases. Of those failures, 24 are in SwiftSci and seven in the Python reference adapter. All 15 selected profiles completed, with no infrastructure errors or newly failing case identities relative to the recorded local runs.

The new persistence cases reproduce two failures, each on both held-out variants:

- Native regressor reload refuses prediction with “Model must be fitted before calling predict or transform.”
- Core ML rejects the exported composite pipeline with “Feature descriptions exceeded 1.”

The earlier acceptance run also retains difficult numerical, supplied-weight inference, PCA, cosine, and decoder/cache/loader failures. Shared failures in reference engines do not by themselves exonerate SwiftSci; numerical cases require analysis of input representation, conditioning, solver behavior, and justified bounds.

Maintainer review is requested on workload semantics, fixture scope, and CI treatment of known failures before follow-up repairs. Follow-up production repairs should retain these tests. This draft makes no general numerical-stability, predictive-quality, zero-copy, or production-speed claim.

## Implementation and merge sequence

This is the first of four draft contributions. Review and merge them in order:

1. **#41, testing and benchmarks:** establish versioned inputs, references, workload semantics, failure records and CI. This branch deliberately retains failures repaired by later contributions. Agree on their CI treatment without turning failed conformance into a passing certificate.
2. **#43, fault repairs:** fix nine causes with individual regression tests and commits.
3. **#44, precision policies:** add fast/compensated reductions and decimal-preserving ANOVA ingestion, with explicit costs and limits.
4. **#45, compact numerical preparation:** reduce dataframe conversion and scaling allocations while preserving existing APIs, then expose additive prepared-batch operations.

The later drafts currently target upstream `main` because their predecessor branches live on the fork. Their descriptions link to contribution-only comparisons. After each prerequisite merges, update the next branch and verify its diff excludes accepted work. Rerun validation after implementation or conflict-resolution changes. Keep these contributions separate so reviewers can assess test contracts, defect repairs, numerical policy and storage API choices independently.

The latest combined-stack passing Swift results belong to the downstream branches. They do not replace this draft's retained failing baseline or constitute a formal performance baseline.
