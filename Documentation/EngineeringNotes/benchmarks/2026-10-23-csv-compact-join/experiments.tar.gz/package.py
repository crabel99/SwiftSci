from pathlib import Path
import json,subprocess,tarfile,hashlib,gzip,shutil,ast,re
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-compact-join'
if T.exists():assert {p.name for p in T.iterdir()} <= {'README.md','results.md','audit.json','comparator-provenance.json','changes.patch.gz','experiments.tar.gz','artifact-sha256.json','compatibility-results.md','compatibility-audit.json'}
T.mkdir(parents=True,exist_ok=True)
audit=json.loads((R/'audit.json').read_text());assert audit['all_outputs_match']
summary=json.loads((R/'measurement/summary.json').read_text())
flows=['read','join-inner-matrix','join-matrix','join-right-matrix','join-outer-matrix','batch']
rows=[];stage=[]
for flow in flows:
 g={x['engine']:x['medians'] for x in summary if x['case']=='energy-common/serial/'+flow}
 trip=lambda key,scale:' / '.join(f'{g[label][key]/scale:.2f}' for label in ['original','prior','current'])
 rows.append(f"| {flow} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
 stage.append(f"| {flow} | {trip('operations_cpu_ns',1e6)} |")
compat=json.loads((R/'compatibility/audit.json').read_text())
assert compat['all_outputs_match'] and compat['current_head']==audit['current_head']
assert compat['parent_audit_sha256']==hashlib.sha256((R/'audit.json').read_bytes()).hexdigest()
compat_summary=json.loads((R/'compatibility/measurement/summary.json').read_text())
compat_rows=[]
for flow in ['join-only','join-materialize']:
 g={x['engine']:x['medians'] for x in compat_summary if x['case']=='energy-common/serial/'+flow}
 trip=lambda key,scale:' / '.join(f'{g[label][key]/scale:.2f}' for label in ['original','prior','current'])
 compat_rows.append(f"| {flow} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
cpu_savings=[];heap_savings=[]
for case in json.loads((R/'measurement/plan.json').read_text())['cases']:
 if case['workflow'].startswith('join'):
  key='/'.join(case.values());g={x['engine']:x['medians'] for x in summary if x['case']==key}
  cpu_savings.append(100*(1-g['current']['total_cpu_ns']/g['prior']['total_cpu_ns']))
  heap_savings.append(100*(1-g['current']['held_heap_bytes']/g['prior']['held_heap_bytes']))
head=audit['current_head']
readme=f'''# Compact storage through nullable joins

Nullable gathering and joined-key construction now read compact Double values directly and keep the output compact. The existing numerical conversion initializer delegates to a shared indexed constructor, which owns the same dense values and lazily allocated validity bitmap. Joins use that constructor instead of exporting an optional source array and allocating optional output.

This is a child of [compact row selection](../2026-10-23-csv-compact-selection/README.md). It keeps join matching, key equality, row ordering, native integer storage and worker scheduling unchanged. It does not promote a production default.

## Comparison versions and scope

- Original is the qualified optional-array reader at `5d1f89a961106104757f2d8d0b8faba79487d100`.
- Prior is compact selection at `9c329614adddfc48f87a31a84214b5737a6d6851`.
- Current is `codex/csv-compact-join` at `{head}`.
- Twin runs the exact current executable again to check measurement variability.

The focused panel covers complete inner, left, right and outer joins, followed by numerical matrix preparation. Read-only and prepared-batch workflows check neighboring behavior. Both reference datasets run with serial and parallel CSV conversion. The lookup includes the same deliberately unmatched right-side key in every version, so right and outer joins must construct missing payloads. It does not change the reference CSV or its schema. These join workloads have different lookup contents from the preceding experiment, and their timings must be compared within this panel.

## Complete workflows on reference data

The table reports the 2,075,259-row household dataset with serial column conversion. Each entry lists original, prior and current medians. CPU includes CSV construction, the requested operation and release. Held heap includes the result frame and requested numerical output. Peak RSS captures the process peak before fingerprint validation.

| Workflow | CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |
|---|---:|---:|---:|
{chr(10).join(rows)}

[The full table](results.md) includes both datasets and both conversion modes. The household contract uses the same eleven null tokens in every version, including `?`. The air-quality contract uses the same default ten tokens. Both use explicit native schemas. No worker cap, dataset-specific dispatch or tolerance change was added.

## What improved

Across all sixteen join-plus-matrix combinations, current uses **{min(cpu_savings):.1f}% to {max(cpu_savings):.1f}% less CPU** and **{min(heap_savings):.1f}% to {max(heap_savings):.1f}% less held heap** than prior. The household inner and right joins return small subsets and now use roughly the original reader's CPU. Household left and outer joins use about one third less CPU than the original reader while retaining less memory.

These results support preserving compact storage through the join and numerical consumer. They do not establish an unconditional memory win for every consumer, as the compatibility check below shows.

## Retaining optional exports changes the memory result

A second panel measures a left join with the frame retained, first alone and then alongside optional Double arrays requested through `.values`. Every version uses the same client and lookup. The table lists original, prior and current medians for household data with serial conversion.

| Workflow | CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |
|---|---:|---:|---:|
{chr(10).join(compat_rows)}

With only the joined frame retained, current held heap is about **208 MiB**, compared with the original reader's **317 MiB**. Retaining the compact frame and optional exports together raises current held heap to about **429 MiB**, while original remains near **317 MiB** because its exported arrays share existing optional storage. Current still uses less CPU and lower peak RSS in this workload. Its held heap is worse when the caller retains both representations.

This is a real consumer-dependent tradeoff. Numerical consumers can use the compact buffers directly. General promotion still needs an explicit storage and export policy for callers that retain optional arrays. Repeated materialization also remains a compatibility cost. [Full compatibility results](compatibility-results.md) cover both datasets and conversion modes.

All 32 additional preflights and 256 measured processes match their original outputs. The compatibility panel reuses the same tested source and object files. Its three clients were rebuilt only after the first panel finished. Its [audit](compatibility-audit.json) records `quality_passed={compat['quality_passed']}` with these flags: `{json.dumps(compat['quality_flags'])}`. Across both panels, 128 workflow preflights and 1,024 measured processes match exactly.

## Operation CPU within the same workers

These medians use each worker's operation stage. They are not differences between unrelated workflow medians. CSV reading and output release are outside this stage.

| Workflow | Operation CPU original / prior / current, ms |
|---|---:|
{chr(10).join(stage)}

## Correctness and ownership

Two focused regression tests fail before the patch because nullable gathering and coalesced keys lose compact storage. Both pass afterward. They cover empty output and empty sources, missing indices, missing values, repeated and unordered rows, bitmap boundaries, NaN payload bits, signed zero and infinities. A mapped left row has priority even when its value is missing. Either input may use optional or compact storage.

The public join test compares all four join kinds against optional-backed frames, including duplicate, missing and unmatched keys. It checks column order, native types, exact values and null counts, and Int64 identifiers above 2^53. Matrix results agree bit for bit. Joined key buffers pass directly to prepared batches, and subsequent batch mutations preserve the joined frame.

Release, Debug and Address Sanitizer each pass all 409 dataframe tests with no failures or skips. Fourteen eager CSV and fourteen streaming checks pass pinned native types, value and null hashes and ordering. All 96 workflow preflights and 768 measured processes match the original output fingerprints. These derived-workflow checks establish equivalence to the original implementation, not independent mathematical certification.

## Measurement checks and limits

Eight balanced orders give each label each position twice and each ordered adjacent pair twice. The fixed policy flags more than 10% current/twin median CPU difference or peak-memory differences beyond 5% plus 8 MiB. Flags are retained and disqualify affected comparisons. The audit records `quality_passed={audit['quality_passed']}` and these flags: `{json.dumps(audit['quality_flags'])}`.

Tests and builds finished before measurements. AC power was checked at both ends. Every comparator client uses identical source compiled against its matching module interface and object. Build receipts verify imported module paths. Full output fingerprints run outside timing. The audit recomputes medians and checks source and binary fingerprints.

CPU means process user plus system time. Malloc live bytes, RSS and logical column payload describe different costs. This panel does not measure energy, FLOPs or cache activity. Address Sanitizer checks do not establish universal leak freedom. Float-key matching still uses the existing join implementation, and optional-array exports remain a compatibility cost. This branch has not been pushed or submitted for production integration.

## Evidence and reproduction

- [Full resource results](results.md).
- [Independent audit](audit.json).
- [Comparator source provenance](comparator-provenance.json).
- [Exact experimental patch](changes.patch.gz).
- [Scripts, raw outputs, source snapshots and receipts](experiments.tar.gz).
- [Artifact hashes](artifact-sha256.json).

Restore the recorded prior commit, decompress and apply the patch, restore pinned dependencies, and update machine-specific paths. `validate.py` runs the three test configurations and builds matching clients. `measure.py` runs stream checks, exact preflights, the main resource panel and its audit. Then `compatibility/run.py` builds and runs the separate optional-export panel and its audit. The archive excludes executables, caches, result bundles and large reference CSVs. Engineering records stay on `codex/engineering-notes`; source changes and tests stay on the experimental branch.
'''
(T/'README.md').write_text(readme)
for name in ['results.md','audit.json','comparator-provenance.json']:shutil.copy2(R/name,T/name)
shutil.copy2(R/'compatibility/results.md',T/'compatibility-results.md')
shutil.copy2(R/'compatibility/audit.json',T/'compatibility-audit.json')
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as out:out.write((R/'changes.patch').read_bytes())
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==(R/'changes.patch').read_bytes()
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.txt','.log','.md','.patch','.jsonl'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for p in (S/'Sources/SwiftDataFrame').rglob('*.swift'):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 for name in ['CompactNullableGatherTests.swift','CompactJoinTests.swift']:
  tar.add(S/'Tests/SwiftDataFrameTests'/name,arcname='final-source/Tests/SwiftDataFrameTests/'+name)
 for label,root,filename in [('original','/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata','build.json'),('prior','/private/tmp/swiftsci-csv-compact-selection-20261023','module-build.json')]:
  tar.add(Path(root)/filename,arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',readme):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
assert '—' not in readme
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'}
(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(T/k)==v for k,v in manifest.items())
print(T);print('Verified evidence hashes, patch bytes, links, archive paths and script syntax')
