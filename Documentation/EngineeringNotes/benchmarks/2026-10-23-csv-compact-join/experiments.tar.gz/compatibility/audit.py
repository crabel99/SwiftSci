from pathlib import Path
import json,hashlib,statistics,subprocess,collections
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
D=R/'measurement';plan=json.loads((D/'plan.json').read_text())
assert plan==json.loads((R/'preflight/plan.json').read_text())
assert plan['controller_sha256']==h(R/'run-panel.py')
assert len(plan['cases'])==8 and len(plan['orders'])==8
pairs=collections.Counter((a,b) for order in plan['orders'] for a,b in zip(order,order[1:]))
assert len(pairs)==12 and set(pairs.values())=={2}
for label in ['original','prior','current','twin']:
 assert collections.Counter(order.index(label) for order in plan['orders'])=={0:2,1:2,2:2,3:2}
 assert h(R/(('current' if label=='twin' else label)+'-workflow'))==plan['binaries'][label]
parent=json.loads((R.parent/'audit.json').read_text());assert parent['all_outputs_match'] and parent['quality_passed']
module=json.loads((R.parent/'module-build.json').read_text());assert all(h(S/p)==v for p,v in module['sources'].items())
for label in ['original','prior','current']:
 receipt=json.loads((R/(label+'-workflow-build.json')).read_text());assert receipt['source_sha256']==h(R/'WorkflowProbe.swift')
pre=json.loads((R/'preflight/decision.json').read_text());assert pre['passed'] and pre['workers']==32
expect=json.loads((R/'preflight/expectations.json').read_text())
rows=[json.loads(line) for line in (D/'workers.jsonl').read_text().splitlines()];assert len(rows)==256
assert len(set((r['case'],r['engine'],r['round']) for r in rows))==256
for r in rows:
 assert r['engine']==plan['orders'][r['round']][r['position']]
 assert {k:r[k] for k in ['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256']}==expect[r['case']]
summary=json.loads((D/'summary.json').read_text());flags=[]
for r in summary:
 samples=[x['samples'][0] for x in rows if x['case']==r['case'] and x['engine']==r['engine']]
 assert len(samples)==r['workers']==8
 for k,v in r['medians'].items():
  xs=[x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in samples] if k=='peak_above_baseline_bytes' else [x[k] for x in samples]
  assert statistics.median(xs)==v
for c in plan['cases']:
 key='/'.join(c.values());xs={x['engine']:x['medians'] for x in summary if x['case']==key};a,b=xs['current'],xs['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append({'case':key,'reason':'identical-binary CPU','ratio':ratio})
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':key,'reason':'identical-binary memory'})
assert flags==json.loads((D/'decision.json').read_text())['quality_flags']
audit={'all_outputs_match':True,'quality_passed':not flags,'quality_flags':flags,'preflight_workflows':32,'measured_workers':256,'case_combinations':8,'replicates_per_label':8,'current_head':parent['current_head'],'parent_audit_sha256':h(R.parent/'audit.json'),'validation':'Reuses unchanged source and test receipts from parent panel'}
(R/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
summary=json.loads((D/'summary.json').read_text())
lines=['# Joined-frame compatibility costs','','Every entry lists original / prior / current. CPU includes CSV, left join, optional exports when requested, and release. The joined frame remains retained alongside any exported optional Double arrays.','','| Case | CPU, ms | Held heap, MiB | Peak RSS, MiB |','|---|---:|---:|---:|']
for case in plan['cases']:
 key='/'.join(case.values());g={x['engine']:x['medians'] for x in summary if x['case']==key}
 trip=lambda metric,scale:' / '.join(f'{g[label][metric]/scale:.2f}' for label in ['original','prior','current'])
 lines.append(f"| {key} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
lines+=['','Identical-binary flags: '+json.dumps(flags),'']
(R/'results.md').write_text('\n'.join(lines));print(json.dumps(audit,indent=2),flush=True)
