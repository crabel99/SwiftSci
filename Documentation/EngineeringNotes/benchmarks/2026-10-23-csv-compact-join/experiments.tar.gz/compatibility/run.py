from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parent
for script,args in [('prepare.py',[]),('run-panel.py',['preflight']),('run-panel.py',['measurement']),('audit.py',[])]:
 subprocess.run([sys.executable,str(R/script),*args],check=True)
