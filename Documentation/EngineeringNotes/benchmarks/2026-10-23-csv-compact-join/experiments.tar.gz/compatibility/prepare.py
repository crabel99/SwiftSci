from pathlib import Path
import subprocess,json,re,hashlib
R=Path(__file__).resolve().parent;P=R.parent
s=(P/'WorkflowProbe.swift').read_text()
anchor='        case "join-matrix", "join-inner-matrix", "join-right-matrix", "join-outer-matrix":'
addition='        case "join-only", "join-materialize":\n            output = try output!.join(lookup, on: key, how: .left)\n            if workflow == "join-materialize" {\n                for name in numeric {\n                    if let column = output![column: name, as: Double.self] { exports.append(column.values) }\n                }\n            }\n'
assert s.count(anchor)==1
(R/'WorkflowProbe.swift').write_text(s.replace(anchor,addition+anchor))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label in ['original','prior','current']:
 receipt=json.loads((P/(label+'-workflow-build.json')).read_text())
 cmd=[str(R/'WorkflowProbe.swift') if a==str(P/'WorkflowProbe.swift') else str(R/(label+'-workflow')) if a==str(P/(label+'-workflow')) else a for a in receipt['command']]
 with (R/(label+'-workflow-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-workflow-build.log')).read_text()))
 assert loaded.get('SwiftDataFrame')==receipt['verified_module']
 (R/(label+'-workflow-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':h(R/'WorkflowProbe.swift'),'binary_sha256':h(R/(label+'-workflow'))},indent=2)+'\n')
 print(label,'compatibility client built',flush=True)
