from pathlib import Path
import subprocess,json
R=Path(__file__).resolve().parent
I=Path('/private/tmp/swiftsci-csv-external-20261023/inputs')
responses=[]
for path in sorted(I.glob('*.json')):
 for policy in ['serial','parallel']:
  p=subprocess.run([str(R/'build/StreamProbe'),str(path),'10000',policy],capture_output=True,text=True,check=True,timeout=90)
  x=json.loads(p.stdout);assert x['validated'];x['policy']=policy;responses.append(x)
(R/'stream-checks.json').write_text(json.dumps({'validated':True,'responses':responses,'accepted_timing':False},indent=2)+'\n')
print('Exact streaming checks:',len(responses),'passed',flush=True)
