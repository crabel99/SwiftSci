from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
import sys
p=Path(sys.argv[1]) if len(sys.argv)>1 else S/'Sources/SwiftDataFrame/Columns/TypedColumn.swift';s=p.read_text()
assert 'private struct DoubleSortKeys' not in s
s=s.replace('    for optional in values {\n        guard let value = optional else { continue }\n        if value.isNaN {', '    for (index, optional) in values.enumerated() {\n        guard let value = optional else { continue }\n        if value.isNaN {',1)
a='''            if direction != 0 && direction != nextDirection { runs += 1 }
            direction = nextDirection
'''
b='''            if direction != 0 && direction != nextDirection {
                runs += 1
                // Row-addressed 8-byte keys fit within 16-byte valid-row tuples.
                if runs == 2 && nullCount <= validCount {
                    let resume = (nextRow: index + 1, previous: value, direction: nextDirection, runs: runs)
                    if let prepared = prepareDoubleSortKeys(values, ascending: ascending,
                                                            resume: resume, runLimit: runLimit) {
                        return sortedDoubleRows(prepared, validCount: validCount)
                    }
                    requiresComparisonFallback = true
                    break
                }
            }
            direction = nextDirection
'''
assert s.count(a)==1;s=s.replace(a,b)
a='''            if let indices = radixIndicesDouble(values, nullCount: nullCount, ascending: ascending) {
                return indices
            }
'''
b='''            if let prepared = prepareDoubleSortKeys(values, ascending: ascending,
                                                    resume: nil, runLimit: runLimit) {
                return sortedDoubleRows(prepared, validCount: validCount)
            }
'''
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('Choose the path before allocating cached comparison keys.', 'Probe monotonic order before allocating keys.')
start=s.index('private func radixIndicesDouble<');finish=s.index('/// Sorts cached non-null keys',start)
old=s[start:finish]
kstart=old.index('    var scratch =');kend=old.index('    if resultInScratch { swap(&indices, &scratch) }')
kernel=old[kstart:kend].replace('let count = indices.count','let count = validCount').replace('count: indices.count','count: validCount')
replacement='''private struct DoubleSortKeys {
    let keys: [UInt64]
    let differingBits: UInt64
    let requiresRadix: Bool
}

private func orderedDoubleKey(_ value: Double, ascending: Bool) -> UInt64? {
    guard !value.isNaN else { return nil }
    let bits = value == 0 ? UInt64(0) : value.bitPattern
    let key = bits >> 63 == 0 ? bits ^ (UInt64(1) << 63) : ~bits
    return ascending ? key : ~key
}

private func prepareDoubleSortKeys<Values: RandomAccessCollection>(
    _ values: Values, ascending: Bool,
    resume: (nextRow: Int, previous: Double, direction: Int, runs: Int)?, runLimit: Int
) -> DoubleSortKeys? where Values.Element == Double?, Values.Index == Int {
    // Non-NaN keys in either direction exclude UInt64.max, reserved for missing rows.
    var keys = [UInt64](repeating: .max, count: values.count)
    var differingBits: UInt64 = 0
    var firstKey: UInt64?
    var requiresRadix = resume == nil
    var previous = resume?.previous ?? 0
    var direction = resume?.direction ?? 0
    var runs = resume?.runs ?? 1
    let nextRow = resume?.nextRow ?? values.count
    for (index, optional) in values.enumerated() {
        guard let value = optional else { continue }
        guard let key = orderedDoubleKey(value, ascending: ascending) else { return nil }
        keys[index] = key
        if let firstKey { differingBits |= key ^ firstKey } else { firstKey = key }
        if !requiresRadix && index >= nextRow {
            if value != previous {
                let nextDirection = value > previous ? 1 : -1
                if direction != nextDirection { runs += 1 }
                direction = nextDirection
                if runs > runLimit { requiresRadix = true }
            }
            previous = value
        }
    }
    return DoubleSortKeys(keys: keys, differingBits: differingBits, requiresRadix: requiresRadix)
}

private func sortedDoubleRows(_ prepared: DoubleSortKeys, validCount: Int) -> [Int] {
    var indices = [Int](unsafeUninitializedCapacity: prepared.keys.count) { buffer, initializedCount in
        var present = 0
        var missing = validCount
        for (index, key) in prepared.keys.enumerated() {
            if key == .max {
                buffer[missing] = index
                missing += 1
            } else {
                buffer[present] = index
                present += 1
            }
        }
        initializedCount = prepared.keys.count
    }
    if prepared.requiresRadix {
        radixDoubleRows(prepared.keys, indices: &indices, validCount: validCount,
                        differingBits: prepared.differingBits)
    } else {
        prepared.keys.withUnsafeBufferPointer { keys in
            indices.withUnsafeMutableBufferPointer { rows in
                var present = UnsafeMutableBufferPointer(rebasing: rows[..<validCount])
                present.sort { keys[$0] < keys[$1] }
            }
        }
    }
    return indices
}

private func radixDoubleRows(_ keys: [UInt64], indices: inout [Int],
                             validCount: Int, differingBits: UInt64) {
'''+kernel+'''    if resultInScratch {
        if validCount == indices.count {
            swap(&indices, &scratch)
        } else {
            indices.withUnsafeMutableBufferPointer { rows in
                scratch.withUnsafeBufferPointer { sorted in
                    rows.baseAddress!.update(from: sorted.baseAddress!, count: validCount)
                }
            }
        }
    }
}

'''
s=s[:start]+replacement+s[finish:];p.write_text(s)
print('Shared encoder, prepared keys, stable prefix comparison and one radix kernel installed')
