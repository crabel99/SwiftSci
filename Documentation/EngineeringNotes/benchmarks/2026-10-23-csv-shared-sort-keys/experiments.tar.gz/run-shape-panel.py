from pathlib import Path
import itertools,json,subprocess,hashlib,statistics,time,sys
R=Path(__file__).resolve().parent
I=R/'shape-inputs'
mode=sys.argv[1]
assert mode in ['preflight','measurement']
D=R/('shape-'+mode);D.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=['original','prior','current','twin']
base=[0,1,3,2]
first=[[labels[(x+shift)%4] for x in base] for shift in range(4)]
orders=first+[list(reversed(x)) for x in reversed(first)]
def binary(label):return R/(('current' if label=='twin' else label)+'-shape')
cases=[{'input':i,'policy':p,'storage':s,'workflow':w} for i,p,s,w in itertools.product(sorted(p.stem for p in I.glob('*.json')),['serial'],['optional','compact'],['sort-indices'])]
plan={'storage_capabilities':{'original':'case choice','prior':'case choice','current':'case choice','twin':'case choice'},'cases':cases,'orders':orders,'quality_policy':{'identical_binary_cpu_median_ratio_max_deviation':.10,'identical_binary_peak_max_relative':1.05,'identical_binary_peak_slack_bytes':8*2**20},'binaries':{k:h(binary(k)) for k in labels},'contracts':{p.stem:json.loads(p.read_text()) for p in sorted(I.glob('*.json'))},'controller_sha256':h(Path(__file__))}
plan=json.loads(json.dumps(plan))
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
rows=[];expectations={}
if mode=='measurement':
 assert json.loads((R/'shape-preflight/decision.json').read_text())['passed']
 expectations=json.loads((R/'shape-preflight/expectations.json').read_text())
 preplan=json.loads((R/'shape-preflight/plan.json').read_text())
 assert preplan==plan,'Panel inputs or binaries changed after preflight'
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power.txt').open('w'),check=True)
 assert 'AC Power' in (D/'power.txt').read_text()
with (D/'workers.jsonl').open('w') as out:
 for case_index,case in enumerate(cases):
  key='/'.join(case.values())
  for round_index,order in enumerate(orders if mode=='measurement' else [tuple(labels)]):
   for pos,label in enumerate(order):
    cmd=[str(binary(label)),str(I/(case['input']+'.json')),case['workflow'],case['policy'],case['storage']]
    start=time.time();p=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
    assert p.returncode==0,(case,label,p.stderr)
    x=json.loads(p.stdout)
    fingerprint={k:x[k] for k in ['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']}
    contract=plan['contracts'][case['input']]
    assert x['selection_sha256']==contract['expected_index_sha256']
    assert x['frame']=={'rows':contract['rows'],'columns':[{'name':'x','type':'Double','nulls':contract['null_count'],'sha256':contract['hashes'][0]}]}
    if mode=='preflight' and label=='original':expectations[key]=fingerprint
    assert fingerprint==expectations[key],(case,label,'Workflow output mismatch')
    x.update(case=key,engine=label,round=round_index,position=pos,worker_seconds=time.time()-start,effective_double_storage=case['storage'])
    out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();rows.append(x)
  print(mode,case_index+1,'/',len(cases),key,flush=True)
summary=[];flags=[]
for case in cases:
 key='/'.join(case.values());group={}
 for label in labels:
  samples=[r['samples'][0] for r in rows if r['case']==key and r['engine']==label]
  med={k:statistics.median(x[k] for x in samples) for k in samples[0]}
  med['peak_above_baseline_bytes']=statistics.median(x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in samples)
  group[label]=med
  summary.append(dict(case=key,engine=label,workers=len(samples),medians=med))
 if mode=='measurement':
  a,b=group['current'],group['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
  if abs(ratio-1)>.10:flags.append({'case':key,'reason':'identical-binary CPU','ratio':ratio})
  for x,y in [(a,b),(b,a)]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':key,'reason':'identical-binary memory'})
if mode=='measurement':
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power-end.txt').open('w'),check=True)
 assert 'AC Power' in (D/'power-end.txt').read_text()
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(D/'expectations.json').write_text(json.dumps(expectations,indent=2)+'\n')
(D/'decision.json').write_text(json.dumps({'passed':True,'workers':len(rows),'quality_passed':not flags,'quality_flags':flags,'all_outputs_match':True},indent=2)+'\n')
print(mode,len(rows),'exact workflow matches; quality flags',flags,flush=True)
