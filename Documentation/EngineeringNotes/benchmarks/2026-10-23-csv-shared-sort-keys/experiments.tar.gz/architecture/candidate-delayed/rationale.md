# Delayed tuple cache with radix promotion

## Usage (caller's view)

The public calls do not change.

```swift
let ascendingRows = column.sortedIndices(ascending: true)
let sortedFrame = frame.sortBy("reading", ascending: false)
```

Both calls still return stable order, place nulls last, keep signed-zero ties in source order, and use the legacy comparator for any valid NaN. Callers do not select a preparation strategy.

## Problem

The current adaptive Double path finishes run detection before it builds cached `(row, value)` pairs. A nearly ordered column is therefore read twice. Allocating pairs at the start would remove that scan but would also charge monotonic inputs and could leave a nearly full allocation to discard when disorder crosses the radix limit late. The design must keep the existing sparse and minimum-size dispatch, and it must not turn NaN into a total-order key.

## Shape

`sortIndicesDouble` keeps its public boundary and existing cutoffs. Its scan holds scalar direction state until the first direction change. At that point it creates a private `DelayedTupleCache`, backfills only the prefix through the changed value, and then appends the rest of the scan. The cache represents native `(Double, Int)` pairs as two parallel lanes. This layout is deliberate: an array of Swift tuples cannot donate its allocation to row-addressed radix keys.

If detection finishes within the run limit, comparison sorts stable valid ordinals by the native Double lane, maps them through the row lane, and appends missing rows. The cache supplies every comparison key, so there is no post-detection source scan. Equal values retain their source ordinal. This covers signed zero without changing its bits.

If runs exceed the existing limit, the scan marks radix intent but keeps filling the cache and checking for NaN. After the scan, the value lane grows from `validCount` to `rowCount`. Walking valid ordinals backward is safe because source rows are increasing and `row >= ordinal`. Each native Double becomes the existing ordered `UInt64` key at its original row slot. The row lane becomes the radix source and final permutation buffer. The existing stable radix kernel allocates only its scratch indices and offsets. No filled tuple allocation is abandoned, even when the threshold is crossed near the end.

`orderedDoubleKey` remains the single encoding function. It normalizes both zero signs, applies the existing IEEE transform, and complements for descending order. A valid NaN at any position destroys the private cache before allocating the legacy full index array, then calls the exact existing optional-key comparator. Monotonic input never creates the cache and continues through `monotonicIndicesDouble`.

The private interface is one classifier, one cache, one key encoder, and the existing radix kernel. Public callers still know only `sortedIndices(ascending:)`, so the module hides classification, storage promotion, null handling, and fallback policy.

## Synthesis decision

This is an isolated candidate. It should become a synthesis base only if allocation measurements confirm that value-lane growth does not raise peak memory beyond the current radix path.

## Tradeoffs accepted

- We accept one prefix backfill after the first direction change in exchange for removing the later full preparation scan.
- We accept a small private raw-storage owner in exchange for reusing native-value capacity when comparison preparation becomes radix preparation.
- We accept finishing the classification scan after the radix limit is crossed in exchange for reusing filled rows and detecting a later NaN before radix allocation.

Standard Swift arrays cannot provide this handoff with the same steady-state memory. Changing `[Double]` into a row-sized `[UInt64]` needs another allocation, while an array of tuples cannot become the returned `[Int]`. The raw value lane keeps steady radix storage at `8 * rowCount` keys, `8 * validCount` indices, one equally sized scratch index lane, and missing indices, matching the current explicit buffers. `realloc` may still hold old and new value storage briefly. If strict peak RSS rejects that transient or the raw owner is too risky, this candidate's best limited role is the nearly ordered comparison path. Late radix must then release the tuple cache and pay the current extra source pass.

## Alternatives considered

- Cache ordered keys from row zero. Comparison and radix share data, but monotonic input pays a row-sized allocation and NaN handling no longer stays naturally outside key encoding.
- Keep an array of `(Int, Double)` records. Comparison is simple, but stable radix needs a second record buffer plus a final `[Int]`, so late selection raises retained memory.
- Sort direct source indices after detection. It uses less explicit cache memory, but repeated optional and validity reads reproduce the CPU cost already seen in screening.

## Open questions and risks

- Does the supported Swift platform permit a small, auditable raw allocation owner with balanced binding and deallocation rules?
- Do early, middle, and late direction changes show a peak RSS crossover during value-lane growth, especially with null density just above the existing sparse boundary?
- Do exact-output tests confirm legacy NaN fallback after partial cache fill and after radix intent, in both directions and both storage forms?

## Next implementation step

Prototype `DelayedTupleCache` behind the current private Double dispatcher, then measure exact outputs, source-read counts, CPU, and peak RSS before changing the existing path.
