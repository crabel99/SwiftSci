import Foundation
// Public usage remains column.sortedIndices(ascending:) and frame.sortBy(...).
private enum DoubleSortPlan { case comparison, radix }
/// Owns exact native Double storage, later grown and rebound as UInt64 keys.
private final class NativeDoubleLane {
    private var storage: UnsafeMutableRawPointer
    private(set) var count: Int, capacity: Int
    init(capacity: Int) { fatalError("not implemented") }
    func append(_ value: Double) { fatalError("not implemented") }
    func double(at ordinal: Int) -> Double { fatalError("not implemented") }
    func growExactly(to count: Int) { fatalError("use checked realloc; not implemented") }
    func store(key: UInt64, at row: Int) { fatalError("not implemented") }
    func withKeys<R>(count: Int, _ body: (UnsafeBufferPointer<UInt64>) -> R) -> R { fatalError("borrow rebound storage; not implemented") }
}
/// Parallel lanes form native `(row, value)` tuples in source order.
private final class DelayedTupleCache {
    let values: NativeDoubleLane
    var rows: [Int], missing: [Int]
    init<Values>(backfilling source: Values, through row: Int, validCount: Int, nullCount: Int) where Values.Element == Double? {
        fatalError("allocate exact lanes; append source[0...row]")
    }
    func append(row: Int, value: Double?) { fatalError("not implemented") }
    func stableComparisonIndices(ascending: Bool) -> [Int] {
        fatalError("stable-sort ordinals by native values; map rows; append missing")
    }
    func promoteToRadix(rowCount: Int, ascending: Bool) -> RadixInput {
        values.growExactly(to: rowCount)
        // Backward scatter is safe because source rows are increasing and row >= ordinal.
        for ordinal in rows.indices.reversed() {
            let row = rows[ordinal]
            values.store(key: orderedDoubleKey(values.double(at: ordinal), ascending: ascending), at: row)
        }
        return RadixInput(keys: values, indices: take(&rows), missing: take(&missing))
    }
}
private struct RadixInput { let keys: NativeDoubleLane; var indices: [Int]; let missing: [Int] }
private func orderedDoubleKey(_ value: Double, ascending: Bool) -> UInt64 {
    precondition(!value.isNaN)
    let bits = value == 0 ? UInt64(0) : value.bitPattern, ordered = bits >> 63 == 0 ? bits ^ (UInt64(1) << 63) : ~bits
    return ascending ? ordered : ~ordered
}
private func delayedSortIndicesDouble<Values: RandomAccessCollection>(_ source: Values,
    nullCount: Int, ascending: Bool) -> [Int] where Values.Element == Double?, Values.Index == Int {
    let validCount = source.count - nullCount
    guard validCount >= 1_024, validCount >= source.count / 20 else {
        return cachedComparison(source, nullCount: nullCount, ascending: ascending)
    }
    let runLimit = max(8, validCount / 64); var previous: Double?, direction = 0, runs = 1
    var plan = DoubleSortPlan.comparison
    var cache: DelayedTupleCache?
    for row in source.indices {
        let optional = source[row]
        if let value = optional, value.isNaN {
            cache = nil
            return legacyComparison(source, ascending: ascending)
        }
        cache?.append(row: row, value: optional)
        guard plan != .radix, let value = optional else { continue }
        if let previous, value != previous {
            let next = value > previous ? 1 : -1
            if direction != 0, direction != next {
                runs += 1
                if cache == nil {
                    cache = DelayedTupleCache(backfilling: source, through: row,
                                              validCount: validCount, nullCount: nullCount)
                }
                if runs > runLimit { plan = .radix }
            }
            direction = next
        }
        previous = value
    }
    guard let cache else {
        return monotonicIndicesDouble(source, nullCount: nullCount,
                                      reverse: direction != 0 && (direction > 0) != ascending)
    }
    if plan == .comparison { return cache.stableComparisonIndices(ascending: ascending) }
    return radixIndicesDouble(cache.promoteToRadix(rowCount: source.count, ascending: ascending))
}
