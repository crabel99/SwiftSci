// Private design sketch only. Bodies describe implementation, not executable code.
private struct DoubleSortKeys {
    let keys: [UInt64] // Physical-row addressed; UInt64.max means missing.
    let differingBits: UInt64 // Only valid keys contribute.
    let requiresRadix: Bool // Existing max(8, validCount / 64) decision.
}

private func orderedDoubleKey(_ value: Double, ascending: Bool) -> UInt64? {
    // Reject NaN. Normalize both zeros to bits == 0.
    // Existing transform: sign clear ? bits ^ (1 << 63) : ~bits.
    // Complement for descending. Non-NaN output never equals UInt64.max.
    fatalError("not implemented")
}

private func sortIndicesDouble<V: RandomAccessCollection>(
    _ values: V, nullCount: Int, ascending: Bool
) -> [Int] where V.Element == Double?, V.Index == Int {
    // Keep existing validCount < 1_024 or validCount < count / 20 bypass.
    // Scalar probe skips nulls/ties and rejects NaN through exact old fallback.
    // At first direction change, if nullCount <= validCount:
    //   prepare keys using prefix boundary and existing probe scalar state.
    //   nil => release preparation and call exact existing NaN fallback.
    //   partition indices from keys; stable-sort valid prefix by key or radix.
    //   return rows, including untouched stable null suffix.
    // Otherwise finish original scalar classification.
    //   one run => existing monotonic helper, including equal-group repair.
    //   excessive runs => fresh key preparation and same radix kernel.
    //   remaining multi-run case => existing cached native tuple helper.
    fatalError("not implemented")
}

private func prepareDoubleKeys<V: RandomAccessCollection>(
    _ values: V, ascending: Bool,
    resume: (nextRow: Int, previous: Double, direction: Int, runs: Int)?,
    runLimit: Int
) -> DoubleSortKeys? where V.Element == Double?, V.Index == Int {
    // Called once after first direction change, or after scalar radix dispatch.
    // Allocate only keys. Encode prior prefix without recounting runs.
    // Resume scalar run detection on unread suffix, using supplied state.
    // If resume is nil, radix was already selected; only encode and validate.
    // Nulls write UInt64.max. Reject any valid NaN, even after radix selection.
    // Stop run bookkeeping once limit crossed; finish key and differing bits.
    fatalError("not implemented")
}

private func partitionDoubleRows(_ keys: [UInt64], validCount: Int) -> [Int] {
    // Allocate count rows once. Enumerate keys in source order.
    // Write valid indices at increasing positions beginning at 0.
    // Write sentinel indices at increasing positions beginning at validCount.
    fatalError("not implemented")
}

private func radixDoubleRows(
    _ rows: inout [Int], validCount: Int, prepared: borrowing DoubleSortKeys
) {
    // Same existing kernel; borrow keys, valid row prefix, scratch, offsets.
    // Scratch has validCount entries. Stable 11-bit passes skip uniform digits.
    // Never read a null key. Preserve suffix during final buffer selection.
    // If final data is in scratch, copy only valid prefix into result rows.
    // Compare that copy with swapping/appending in baseline measurements.
    fatalError("not implemented")
}

// Comparison borrows rows[0..<validCount] and prepared.keys together.
// Its sole comparator is keys[left] < keys[right], already direction-encoded.
// Keep stable sort; never tie-break by row or alter stored source values.
// Every new helper stays in TypedColumn.swift; no new module or public policy.
