# Shared ordered keys

## Usage (caller's view)

```swift
let order = column.sortedIndices(ascending: true)
let descending = compactColumn.sortedIndices(ascending: false)
let reordered = frame.sortBy("depth", ascending: true)
```

All callers keep their current API and receive the same stable permutation. Internal dispatch owns preparation and algorithm choice. This candidate changes only the private Double implementation in `TypedColumn.swift`.

## Problem

Nearly ordered Double columns currently undergo a complete scalar run probe followed by a complete scan to prepare native-value tuples. Radix instead prepares row-addressed UInt64 keys. Preparing those same keys after the first direction change can save most repeated source reads without producing a discarded tuple allocation when later disorder selects radix. Monotonic columns must keep their scalar probe and existing result builder.

## Shape

Use one private key encoder and extract the existing radix passes into one kernel accepting prepared keys. Remove radix's separate missing-row array. These are the subtraction steps, per subtract-before-you-add.

`DoubleSortKeys` owns one UInt64 per physical row, the differing-bit mask, and the existing run-limit decision. The encoder preserves the current IEEE transformation, normalizes signed zero, and complements valid keys for descending order. It returns nil for a valid NaN. Reserve UInt64.max for missing rows. Neither ascending nor descending non-NaN keys can equal that value, including infinities. Null detection therefore needs no separate bitmap or index array in this representation.

Keep the minimum-size and existing sparse bypass unchanged. Otherwise begin with the existing scalar probe. If the first direction change occurs and `N <= 2*V`, enter key preparation. Express that overflow-safely as `N - V <= V`. This is the exact crossover between 8 bytes per physical-row key and 16 bytes per valid native tuple, not a tuned row threshold.

Preparation rereads the already probed prefix, encodes it without recounting its runs, then continues from the next unread row with the scalar probe state. It validates every remaining value even after the run limit selects radix. For first disorder at row k, source reads are approximately N + k, rather than 2N. Late disorder offers little source-read saving. No representation is allocated for a wholly monotonic input.

After successful preparation, scan the keys to construct one result array of N row indices. Fill its valid prefix and null suffix independently, both in input order. Sort only the valid prefix. Stable comparison reads UInt64 keys, and radix reads those identical keys through the existing stable 11-bit passes. The null suffix never enters either sorter. The radix scratch array remains V integers and offsets remain 2,048 integers. Long alternating runs that cross the run limit late reuse all prepared keys; they discard no tuples and do not restart source preparation.

Below the byte crossover, retain the original scalar classification and existing tuple comparison path. If its original run limit selects radix, prepare keys once from row zero and call the same kernel. The 5% sparse rule alone is insufficient: at 10% occupancy a physical-row key buffer costs five times the native tuples. This retained path also preserves its monotonic shortcut.

The crossover compares preparation storage, not the whole operation. Key preparation holds 8N bytes, versus existing comparison preparation's 16V + 8M bytes for tuples and missing indices. Building the result later brings shared comparison storage to 16N bytes, versus existing mapping's 16V + 8M + 8N = 16N + 8V bytes. These figures exclude allocator capacity and stable-sort workspace. Radix's prepared keys survive algorithm selection, so its source preparation is never speculative waste. Release rejected keys before constructing the exact legacy NaN fallback permutation.

Native integer dispatch remains untouched. No public type, threshold, cache lifetime, or caller obligation changes, per interface depth and boundary-discipline.

## Synthesis decision

Candidate for comparison by the orchestrator. Its defining choice is one authoritative key representation for both sorting algorithms, with result indices allocated after source validation.

## Tradeoffs accepted

- We accept a second scan of the probed prefix in exchange for zero row-sized allocation on monotonic data.
- We accept a sequential key scan and indirect comparison reads in exchange for shared radix preparation and removal of tuple mapping and missing-row storage.
- We accept the existing two-scan comparison path below 50% occupancy in exchange for bounding key preparation by the representation it replaces.

## Alternatives considered

Delayed native tuples hide the same private choices, but cannot feed the current radix kernel. Long alternating runs can produce a large tuple allocation that radix then discards. Direct source-index comparison keeps the private interface small, but repeatedly reads compact validity and values inside the comparator and has no shared prepared representation.

## Open questions and risks

- Does stable UInt64 index comparison beat native tuple locality on the same nearby-swap and long-run inputs?
- Can borrowing the valid prefix avoid Swift copy-on-write allocation while retaining stable sorting and the existing radix buffer discipline?
- Do measurements confirm the calculated memory improvement after allocator capacity and stable-sort workspace are included?
- Do sentinel-boundary tests prove both directions exclude UInt64.max for every valid IEEE edge class?

## Next implementation step

Extract the existing encoder and radix kernel privately, then test exact permutations and measured allocations on both sides of the density crossover before evaluating source-read savings.
