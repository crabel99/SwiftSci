# Sort preparation design phases

- [done] Ground existing public sort flow and allocation lifetimes.
- [done] Sketch shared-key and delayed-native-tuple alternatives.
- [done] Independently cross-judge and synthesize the smaller private design.
- [done] Implement and screen the shared-key sketch; reject direct source-index comparison.
- [done] Verify exact outputs, CPU, and memory with full tests and matched panels.
- [done] Retain the local candidate with explicit sparse-admission and CPU tradeoffs.

## Arena phases

- [done] Frame caller contract and resource rubric.
- [done] Fan out isolated candidates with configured available model choices.
- [done] Cross-judge complete, stable candidate artifacts.
- [done] Pick the shared-key base and record parent and judge reasons.
- [done] Retain late-disorder, NaN and transient-memory tests; reject raw ownership.
- [done] Verify the synthesized implementation.
