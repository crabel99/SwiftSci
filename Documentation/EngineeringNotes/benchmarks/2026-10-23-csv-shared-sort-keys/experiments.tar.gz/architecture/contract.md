# Internal sort preparation contract

Public callers continue to use column.sortedIndices(ascending:) and frame.sortBy(column, ascending:). Results remain stable, nulls last, signed-zero ties preserve input row order, and valid NaNs use the exact existing comparison fallback. Native Int64 metadata is never converted to Double.

The current e1f5f8c305 source uses a low-allocation monotonic path. Nearly ordered values undergo full run detection and then full cached row/value tuple preparation. Disorder exceeding max(8, validCount / 64) selects the existing serial radix algorithm. Sparse/minimum-size policies stay unchanged unless an allocation crossover is derived explicitly from representation byte sizes, with tests on both sides. No tuned workload constants, worker limits, new public switches or precision changes.

A rejected direct-index trial is def5a57c59. Its 64 exact-output preflights showed roughly 11 to 27 ms CPU for one million nearly ordered compact values, with lower peak memory. These are unqualified screening observations, not accepted benchmark claims. Source and all receipts are preserved at /private/tmp/swiftsci-csv-nearly-ordered-indices-20261023.

Architectural alternatives must include shared eight-byte ordered UInt64 keys consumed by comparison and radix, and delayed cached tuples after the first direction change. The latter must address oversized discarded allocations when disorder is discovered late, not only the existing nearby-swap fixture.

## Private evaluation rubric

1. Exact stable ordering and legacy NaN fallback across optional/compact, sparse/dense, both directions, large IDs and IEEE edge values.
2. Reduces duplicate reads and total CPU without silently increasing speculative or retained memory; accounts for sparse representation costs.
3. Retains proven monotonic and radix gains, with first disorder early/middle/late and long-run controls.
4. No new public API, arbitrary worker cap, tuned row-count cutoff, or hidden dataset policy.
5. Small readable implementation, one authoritative key encoding and one radix kernel, no extra framework or public ownership protocol.
6. Rerunnable same-input measurements and full module correctness checks; notes stay only on engineering-notes.

Configured gpt-5.5, gpt-5.6-terra and gpt-5.6-luna are unavailable through this session's agent interface. Use inherited model and available configured gpt-5.6-sol for bounded sketches; use an inherited-model independent judge.
