from pathlib import Path
from collections import Counter
import hashlib,itertools,json,statistics,subprocess
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
P=Path('/private/tmp/swiftsci-csv-monotonic-permutations-20261023')
Q=Path('/private/tmp/swiftsci-csv-compact-sorting-20261023')
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=S,text=True).strip()
study=json.loads((R/'study.json').read_text())
assert git('rev-parse','HEAD')==study['current_head']
plan=json.loads((R/'measurement/plan.json').read_text())
assert plan==json.loads((R/'preflight/plan.json').read_text())
assert plan['controller_sha256']==h(R/'run-panel.py')
labels=['original','prior','current','twin']
assert Counter(x for order in plan['orders'] for x in order)==Counter({x:8 for x in labels})
for label in labels:
 assert Counter(order.index(label) for order in plan['orders'])==Counter({x:2 for x in range(4)})
assert Counter((a,b) for order in plan['orders'] for a,b in zip(order,order[1:]))==Counter({x:2 for x in itertools.permutations(labels,2)})
for label in labels:
 assert plan['binaries'][label]==h(R/(('current' if label=='twin' else label)+'-workflow'))
clients={label:json.loads((R/(label+'-workflow-build.json')).read_text()) for label in labels[:-1]}
for label,root in [('original',Q/'build'),('prior',P/'build'),('current',R/'build')]:
 receipt=clients[label]
 assert receipt['verified_module']==str(root/'SwiftDataFrame.swiftmodule')
 assert receipt['source_sha256']==h(R/'WorkflowProbe.swift')
 assert receipt['binary_sha256']==plan['binaries'][label]
 assert 'CSV_STORAGE_CHOICE' in receipt['command']
module=json.loads((R/'module-build.json').read_text())
for path,digest in module['sources'].items():assert h(S/path)==digest
assert h(R/'build/SwiftDataFrame.o')==module['object_sha256']
for root,revision in [(Q,'91c0ff09b7'),(P,'e1f5f8c305')]:
 receipt=json.loads((root/'module-build.json').read_text())
 for path,digest in receipt['sources'].items():
  assert hashlib.sha256(subprocess.check_output(['git','show',revision+':'+path],cwd=S)).hexdigest()==digest
 assert h(root/'build/SwiftDataFrame.o')==receipt['object_sha256']
assert git('status','--porcelain')==''
tests={}
for name in ['final-release','final-debug','final-asan']:
 x=json.loads((R/(name+'-summary.json')).read_text())
 assert x['passedTests']==study['expected_dataframe_test_functions'] and x['totalTestCount']==study['expected_dataframe_test_functions'] and x['failedTests']==0 and x['skippedTests']==0
 tests[name]={k:x[k] for k in ['result','totalTestCount','passedTests','failedTests','skippedTests']}
 receipt=json.loads((R/(name+'-command.json')).read_text());assert receipt['exit_code']==0
 for path,digest in receipt['source_sha256'].items():assert h(S/path)==digest
before=json.loads((R/'before-prepared-final-command.json').read_text())
for path,digest in before['source_sha256'].items():
 if path.startswith('Sources/'):
  assert hashlib.sha256(subprocess.check_output(['git','show','e1f5f8c305:'+path],cwd=S)).hexdigest()==digest
assert json.loads((R/'before-prepared-final-summary.json').read_text())['passedTests']==3
strict=json.loads((R/'strict-inputs.json').read_text());stream=json.loads((R/'stream-checks.json').read_text())['responses']
assert len(strict)==len(stream)==28
assert all(x['validated'] for x in strict+stream)
expected=json.loads((R/'preflight/expectations.json').read_text())
keys=['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']
rows=[json.loads(x) for x in (R/'measurement/workers.jsonl').read_text().splitlines()]
pre=[json.loads(x) for x in (R/'preflight/workers.jsonl').read_text().splitlines()]
assert len(rows)==768 and len(pre)==96
for x in rows+pre:
 assert {k:x[k] for k in keys}==expected[x['case']]
 storage=x['case'].split('/')[2]
 assert x['effective_double_storage']==storage
for name in ['power.txt','power-end.txt']:assert 'AC Power' in (R/'measurement'/name).read_text()
summary=[];flags=[]
for case in plan['cases']:
 key='/'.join(case.values());group={}
 for label in labels:
  samples=[x for x in rows if x['case']==key and x['engine']==label]
  assert len(samples)==8 and {x['round'] for x in samples}==set(range(8))
  for x in samples:assert x['engine']==plan['orders'][x['round']][x['position']]
  xs=[x['samples'][0] for x in samples]
  med={k:statistics.median(x[k] for x in xs) for k in xs[0]}
  med['peak_above_baseline_bytes']=statistics.median(x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in xs)
  group[label]=med;summary.append(dict(case=key,engine=label,workers=8,medians=med))
 a,b=group['current'],group['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append(dict(case=key,reason='identical-binary CPU',ratio=ratio))
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append(dict(case=key,reason='identical-binary memory'))
assert summary==json.loads((R/'measurement/summary.json').read_text())
assert flags==json.loads((R/'measurement/decision.json').read_text())['quality_flags']
provenance={label:{'head':git('rev-parse',revision),'module_receipt_sha256':h(root/'module-build.json'),'object_sha256':h(root/'build/SwiftDataFrame.o'),'module_sha256':h(root/'build/SwiftDataFrame.swiftmodule')} for label,root,revision in [('original',Q,'91c0ff09b7'),('prior',P,'e1f5f8c305'),('current',R,'HEAD')]}
provenance['clients']=clients
(R/'comparator-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
audit={'branch':git('branch','--show-current'),'current_head':git('rev-parse','HEAD'),'base':git('rev-parse','e1f5f8c305'),'all_outputs_match':True,'strict_eager_reads':28,'strict_stream_reads':28,'workflow_preflights':96,'measured_processes':768,'case_combinations':24,'replicates_per_label':8,'quality_passed':not flags,'quality_flags':flags,'tests':tests,'before_semantic_tests_passed':3,'production_promotion':False}
shape=json.loads((R/'shape-audit.json').read_text())
assert shape['cases']==study['shape_case_count']
audit.update(shape_preflights=shape['preflights'],shape_measured_processes=shape['measured_processes'],shape_quality_passed=shape['quality_passed'],shape_quality_flags=shape['quality_flags'],promotion_decision='retain_local_trial: dense_nearly_ordered_cpu_and_peak_improve; sparse_admission_and_small_control_costs_remain')
(R/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
lines=['# Shared prepared-key sort resource results','','Eight fresh processes per label. Total CPU includes CSV construction, the requested operation, consumer preparation and release. Operation CPU excludes CSV construction and release. Output validation is outside timing. Original is checkpoint 91c0ff09b7; prior is e1f5f8c305. Every client honors the declared storage choice.','','| Case | Total CPU original / prior / current, ms | Operation CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |','|---|---:|---:|---:|---:|']
for case in plan['cases']:
 key='/'.join(case.values());g={x['engine']:x['medians'] for x in summary if x['case']==key}
 trip=lambda k,den:' / '.join(f'{g[label][k]/den:.2f}' for label in labels[:-1])
 lines.append(f"| {key} | {trip('total_cpu_ns',1e6)} | {trip('operations_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
lines+=['','Identical-binary flags: '+json.dumps(flags)+'. Affected comparisons remain unqualified. CPU is user plus system process time. These measurements do not establish energy, FLOP or cache effects.','']
(R/'results.md').write_text('\n'.join(lines))
print(json.dumps(audit,indent=2))
