from pathlib import Path
import hashlib,json,re,struct,subprocess
R=Path(__file__).resolve().parent;I=R/'shape-inputs';I.mkdir(exist_ok=True)
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata');P=Path('/private/tmp/swiftsci-csv-monotonic-permutations-20261023')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tokens=['','NA','na','N/A','n/a','null','NULL','NaN','nan','None']
for count in [32768,1000000]:
 for layout in ['ascending','descending','nearby-swaps','random']:
  identifier=f'{layout}-{count}';path=I/(identifier+'.csv')
  integers=[row//4 for row in range(count)]
  if layout=='descending':integers.reverse()
  elif layout=='nearby-swaps':
   for row in range(4095,count-1,4096):integers[row],integers[row+1]=integers[row+1],integers[row]
  elif layout=='random':
   state=0x12345678
   for row in range(count):
    state=(state*6364136223846793005+1)&((1<<64)-1);integers[row]=state%max(1,count//4)
  value_hash=hashlib.sha256();index_hash=hashlib.sha256()
  with path.open('w') as out:
   out.write('x\n')
   for value in integers:
    out.write(f'{value}.125\n');value_hash.update(b'\x01'+struct.pack('<d',value+.125))
  for row in sorted(range(count),key=integers.__getitem__):index_hash.update(b'\x01'+struct.pack('<q',row))
  contract={'id':identifier,'path':str(path),'delimiter':',','rows':count,'names':['x'],'types':['Double'],'hashes':[value_hash.hexdigest()],'null_tokens':tokens,'integral':[False],'file_sha256':h(path),'expected_index_sha256':index_hash.hexdigest(),'layout':layout}
  (I/(identifier+'.json')).write_text(json.dumps(contract,indent=2)+'\n')
s=(R/'WorkflowProbe.swift').read_text().replace('let chosen = input.id.hasPrefix("energy") ? "Global_active_power" : "PM2.5"','let chosen = "x"')
line='        let h0=heap(),r0=resident(),p0=peak(),c0=cpu(),t0=DispatchTime.now().uptimeNanoseconds\n'
assert s.count(line)==1;s=s.replace(line,'')
a='        var output: DataFrame? = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)\n'
assert s.count(a)==1;s=s.replace(a,a+'        let retainedInput = output!\n'+line)
s=s.replace('        let t3=DispatchTime.now().uptimeNanoseconds,c3=cpu()','        let t3=DispatchTime.now().uptimeNanoseconds,c3=cpu()\n        withExtendedLifetime(retainedInput) {}')
s=s.replace('CSV construction, requested public operations and release; held memory before full validation. Complete output hashes outside CPU/wall timing.','Input construction excluded. Public sorting and index release with input retained by caller. Full output hashes outside timing.')
source=R/'ShapeProbe.swift';source.write_text(s)
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('original',Path('/private/tmp/swiftsci-csv-compact-sorting-20261023/build')),('prior',P/'build'),('current',R/'build')]:
 cmd=[a.replace(str(F),str(D)) for a in base]
 cmd=[str(source) if a.endswith('/ResourceProbe.swift') else str(R/(label+'-shape')) if a==str(D/'ResourceProbe') else a for a in cmd]
 if label in ['original','prior','current']:cmd+=['-D','CSV_STORAGE_CHOICE']
 cmd+=['-Rmodule-loading']
 with (R/(label+'-shape-build.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-shape-build.log')).read_text()));assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-shape-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':h(source),'binary_sha256':h(R/(label+'-shape'))},indent=2)+'\n')
 print(label,'shape client built',flush=True)
print('Prepared eight shape fixtures with independent stable permutations',flush=True)
