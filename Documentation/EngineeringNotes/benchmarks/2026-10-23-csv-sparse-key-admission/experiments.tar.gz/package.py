from pathlib import Path
import ast,gzip,hashlib,json,re,shutil,subprocess,tarfile
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
assert subprocess.check_output(['git','branch','--show-current'],cwd=N,text=True).strip()=='codex/engineering-notes'
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-sparse-key-admission'
T.mkdir(parents=True,exist_ok=True)
a=json.loads((R/'audit.json').read_text());sh=json.loads((R/'shape-audit.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==a['current_head']
rows=json.loads((R/'comparison.json').read_text())
shape=['| Million-row compact layout | CPU parent / candidate, ms | Peak RSS parent / candidate, MiB | Qualified |','|---|---:|---:|---|']
for x in rows:
 if '-1000000/serial/compact/' not in x['case']:continue
 shape.append(f"| {x['case'].split('/')[0]} | {x['cpu_prior_ms']:.3f} / {x['cpu_current_ms']:.3f} | {x['peak_prior_mib']:.3f} / {x['peak_current_mib']:.3f} | {x['qualified']} |")
real=json.loads((R/'measurement/summary.json').read_text());table=['| Household serial storage and workflow | Total CPU parent / candidate, ms | Operation CPU parent / candidate, ms | Held heap parent / candidate, MiB | Peak RSS parent / candidate, MiB |','|---|---:|---:|---:|---:|']
for storage in ['optional','compact']:
 for flow in ['sort-indices','sort-matrix','sort-materialize']:
  g={x['engine']:x['medians'] for x in real if x['case']==f'energy-common/serial/{storage}/{flow}'}
  pair=lambda k,d:' / '.join(f'{g[e][k]/d:.3f}' for e in ['prior','current'])
  table.append(f"| {storage} / {flow} | {pair('total_cpu_ns',1e6)} | {pair('operations_cpu_ns',1e6)} | {pair('held_heap_bytes',2**20)} | {pair('process_peak_held_bytes',2**20)} |")
text=f'''# Sparse admission for shared sort keys

The candidate removes the 50% valid-row condition from the shared-key sorter. Source is `{a['current_head']}` on `{a['branch']}`, based on `{a['base']}`. This remains a local experiment. No push or PR is included.

## Whole-sort storage replaces a component-only bound

The parent compares 8*N key bytes with 16*V tuple bytes. That bound omits the parent's separate 8*(N-V) missing-row indices. The complete replaced preparation is 8*N+8*V, before allocator capacity and output storage. Removing the component bound therefore needs measurement of the complete sort, especially sparse comparison locality.

Preparation now starts at the first direction change for every column admitted by the existing 1,024-valid-row minimum and 5% sparse bypass. The radix run limit is unchanged. Removing the density condition makes the secondary scalar run-count branch and its final tuple fallback unreachable, so this patch deletes them. The source change removes 25 lines and adds 9.

Monotonic permutations, stable numeric ties, signed zeros, missing rows last, valid-NaN fallback, native Int64 identifiers, stored values, public options, and CPU parallelism retain their existing contracts. The [parent study](../2026-10-23-csv-shared-sort-keys/README.md) explains the shared representation and its earlier alternatives.

## Broad controls measure CPU and peak memory

Forty fixtures at 32,768 and 1,000,000 rows produce 80 cases across optional and compact storage. Existing controls cover ascending, descending, nearby swaps, single early/middle/late swaps, random values, late radix selection, and the former 50% admission boundary. New nearly ordered fixtures contain approximately 5.3%, 10%, 25%, or 50% valid rows. Missing rows are distributed or clustered. Each new fixture swaps two unequal valid values near the middle of its valid sequence.

Independent Python stable permutations and complete value hashes define exact results. Quoted empty CSV fields preserve missing rows. Timing uses ascending order. Correctness tests cover both directions. The input is retained throughout sort timing. CSV construction and output verification are outside sort CPU timing. Peak RSS can include the earlier CSV construction peak.

{chr(10).join(shape)}

## Complete observation workflows remain separate

The real-data panel covers 2,075,259 household electricity observations and 35,064 air-quality observations. Every executable receives the same complete schema, null tokens, native types, storage policy, values, and row order. Serial and native parallel CSV conversion each run index sorting, sorting followed by matrix preparation, and sorting followed by retained optional exports.

Total CPU includes CSV construction, requested operations, consumer preparation, and release. Operation CPU excludes CSV construction and release. Complete output verification is outside timing. The table gives serial household medians.

{chr(10).join(table)}

{(R/'discussion.md').read_text()}

## Verification and limits

Release, Debug, and Address Sanitizer each pass {a['tests']['final-release']['passedTests']} dataframe test functions with zero failures or skips. The two new test functions also pass on the unchanged parent. They check early, middle, and late first disorder, clustered and distributed missing rows, both sort directions and storage choices, public dataframe sorting, stable Int64 row identities above 2^53, and valid NaNs before and after preparation. The new type is 68 lines.

Twenty-eight eager and twenty-eight streamed reference reads pass exact type, value, null, and row-order checks. The shape panel has {sh['preflights']} preflights and {sh['measured_processes']} measured processes. The real-data panel has {a['workflow_preflights']} preflights and {a['measured_processes']} measured processes. All output fingerprints match.

Eight balanced orders place each label in each position twice and each ordered adjacent pair twice. Original is `91c0ff09b7810b57cabdd953f8bc67791b1008f5`. Parent is `b982028c59c89f615688882ee71be19a0eccd8f2`. Current and twin run the identical candidate executable. The frozen quality policy flags candidate/twin median CPU differences above 10%, or peak RSS differences above 5% plus 8 MiB. Flagged cases remain unqualified. Shape quality flags are `{json.dumps(sh['quality_flags'])}`. Real-data quality flags are `{json.dumps(a['quality_flags'])}`.

Tests, builds, and fixture preparation finish before accepted timings. AC power is checked at both ends. Audits verify source, input, executable, and module-import hashes, balanced order, exact outputs, and independently recomputed medians. The machine is an Apple M4 Max with 128 GiB unified memory, Swift 6.4, and an arm64 macOS 14 deployment target. No worker caps or affinity settings change.

CPU means process user plus system time. These results do not establish energy, FLOPs, cache effects, physical memory traffic, or universal leak freedom. The validated scope is the dataframe module, not the complete MLX-dependent package.

## Evidence and reproduction

[All shape cases](shape-results.md), [all reference cases](results.md), [source and validation audit](audit.json), [shape audit](shape-audit.json), and [comparator provenance](comparator-provenance.json) retain the full results. The [experiment archive](experiments.tar.gz) contains controllers, input generators, commands, receipts, raw measurements, source snapshots, and logs. The [source patch](changes.patch.gz) applies to the recorded parent. [Artifact hashes](artifact-sha256.json) identify these files.

The archived `verify.py`, `validate.py`, `measure.py`, `analyze.py`, and `package.py` reproduce each phase. Build receipts record the compiler, dependency, and module paths. Restore their local dependencies and the recorded external dataset contracts before rerunning. Rebuild each comparator at its recorded head. Never mix a client module from one head with an object from another.
'''
assert '—' not in text
(T/'README.md').write_text(text)
for name in ['results.md','shape-results.md','audit.json','shape-audit.json','comparator-provenance.json','study.json','comparison.json']:shutil.copy2(R/name,T/name)
patch=subprocess.check_output(['git','diff',a['base'],'--binary'],cwd=S)
(R/'changes.patch').write_bytes(patch)
subprocess.run(['git','apply','--reverse','--check','-'],cwd=S,input=patch,check=True)
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as out:out.write(patch)
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==patch
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.jsonl','.txt','.log','.md','.patch'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for folder in ['Sources/SwiftDataFrame','Tests/SwiftDataFrameTests']:
  for p in sorted((S/folder).rglob('*.swift')):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 for label,root in [('original','/private/tmp/swiftsci-csv-compact-sorting-20261023'),('prior','/private/tmp/swiftsci-csv-lazy-sort-cache-20261023')]:tar.add(Path(root)/'module-build.json',arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',text):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'}
(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(T/k)==v for k,v in manifest.items())
print(T)
print('Verified patch, archive paths, links, script syntax and artifact hashes')
