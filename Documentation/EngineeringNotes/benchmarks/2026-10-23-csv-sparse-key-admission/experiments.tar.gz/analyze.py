from pathlib import Path
import json
R=Path(__file__).resolve().parent
shape=json.loads((R/'shape-measurement/summary.json').read_text())
flags={x['case'] for x in json.loads((R/'shape-audit.json').read_text())['quality_flags']}
rows=[]
for case in sorted({x['case'] for x in shape}):
 g={x['engine']:x['medians'] for x in shape if x['case']==case}
 p,c=g['prior'],g['current']
 rows.append(dict(case=case,qualified=case not in flags,cpu_prior_ms=p['total_cpu_ns']/1e6,cpu_current_ms=c['total_cpu_ns']/1e6,cpu_ratio=c['total_cpu_ns']/p['total_cpu_ns'],peak_prior_mib=p['process_peak_held_bytes']/2**20,peak_current_mib=c['process_peak_held_bytes']/2**20,peak_delta_mib=(c['process_peak_held_bytes']-p['process_peak_held_bytes'])/2**20))
(R/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
for x in rows:
 if '/compact/' in x['case'] and '-1000000/' in x['case']:print(json.dumps(x))
print('Qualified controls with largest CPU ratios:')
for x in sorted((x for x in rows if x['qualified']),key=lambda x:x['cpu_ratio'],reverse=True)[:6]:print(json.dumps(x))
