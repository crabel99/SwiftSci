# Sparse key admission trial contract

The source change removes the 50% component-only admission bound and its unreachable secondary probe. Existing 1,024-valid-row and 5% bypasses, the radix run policy, stable ties, null order, NaN fallback, and storage choices remain unchanged.

The primary comparison is candidate against parent b982028c59 in the same panel. Earlier checkpoint 91c0ff09b7 supplies historical context. Every client is freshly compiled against its matching module. No comparison uses numbers from a prior timing session.

Forty shapes across two storage choices cover ordered, nearly ordered, disordered, sparse, and former-admission-boundary inputs. New sparse fixtures contain approximately 5.3%, 10%, 25%, or 50% valid rows with clustered or distributed missing values. Two observation datasets exercise complete CSV and consumer paths.

CPU is process user plus system time. Sort-only CPU retains its input and excludes construction and verification. Whole-path CPU includes CSV, requested operations, consumer preparation, and release. Retained heap and process peak RSS are separate metrics. Peak RSS can include earlier input construction.

Eight balanced orders and an identical-binary twin retain the frozen 10% CPU and 5%-plus-8-MiB peak quality rules. Quality flags remain unqualified and cannot be waived. Correctness requires exact native types, all values, null placement, row order, and complete output fingerprints. No numerical tolerance changes are allowed.

Tests and builds finish before measured workers. Fresh processes execute sequentially on AC power with native CPU parallelism. Source and tests remain on the isolated trial branch. All scripts, decisions, and evidence are archived only on codex/engineering-notes. No push or PR is authorized for this trial.
