from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
p=S/'Sources/SwiftDataFrame/Columns/TypedColumn.swift'
s=p.read_text();start=s.index('private func sortIndicesDouble<');end=s.index('private func monotonicIndicesDouble<',start)
old=s[start:end]
if 'if runs == 2 && nullCount <= validCount' not in old:
 assert 'let resume = (nextRow: index + 1, previous: value, direction: nextDirection, runs: 2)' in old
 print('Sparse admission already applied');raise SystemExit(0)
new=old.replace('    var runs = 1\n','').replace('full-row radix key buffer','full-row sort key buffer')
a=new.index('                runs += 1');b=new.index('            }\n            direction = nextDirection',a)
new=new[:a]+'''                let resume = (nextRow: index + 1, previous: value, direction: nextDirection, runs: 2)
                if let prepared = prepareDoubleSortKeys(values, ascending: ascending,
                                                        resume: resume, runLimit: runLimit) {
                    return sortedDoubleRows(prepared, validCount: validCount)
                }
                requiresComparisonFallback = true
                break
'''+new[b:]
a=new.index('        if runs > runLimit {');b=new.index('        previous = value',a)
new=new[:a]+new[b:]
a=new.index('    if runs == 1 {')
new=new[:a]+'''    return monotonicIndicesDouble(values, nullCount: nullCount,
                                  reverse: direction != 0 && (direction > 0) != ascending)
}

'''
p.write_text(s[:start]+new+s[end:]);print('Removed density guard and unreachable secondary probe/fallback')
