## The result favors broader admission, with measured limits

All eight new million-row compact sparse controls use less CPU, about 19.6% to 40.2%, and lower peak RSS. For approximately 5.3%, 10%, and 25% valid rows, CPU falls by 22.2% to 40.2%. Savings occur with distributed and clustered missing rows. This is broader evidence than the former half-occupancy boundary alone.

With one valid row below half occupancy and an early inversion, compact CPU falls from 3.529 to 2.558 ms. Peak RSS falls from 38.656 to 31.016 MiB, about 19.8%. At half occupancy, which already used prepared keys, CPU changes from 2.499 to 2.474 ms with essentially unchanged peak RSS. The old dispatch cliff is removed for these fixtures.

Other controls retain small costs. The largest observed sorting CPU increase is the optional 32,768-row half-occupancy case, 0.0625 to 0.0665 ms, about 6.4%. The compact early-inversion case at that size rises from 0.0840 to 0.0885 ms. Million-row optional nearby swaps rise from 6.689 to 6.831 ms, about 2.1%. The largest upward shape peak-RSS difference is 0.046875 MiB. These results are included without a quality waiver.

The reference datasets already qualified for shared keys in the parent. The current panel does not show an additional full-path CPU improvement. Reference total CPU ratios range from 0.989 to 1.0367. 18 of the 24 medians rise. The worst case is serial optional household sorting followed by matrix preparation, 436.280 to 452.313 ms, about 3.7%. Its operation CPU rises from 197.000 to 202.331 ms, about 2.7%.

Serial compact household index sorting rises from 296.571 to 299.313 ms total CPU, about 0.9%, with operation CPU 47.636 to 48.314 ms. Compact matrix preparation rises from 419.601 to 423.255 ms total CPU, while operation CPU falls from 169.919 to 168.633 ms. Retained heap and peak RSS are essentially unchanged for these reference paths. Their shared sorting algorithm was already selected before this edit. The measurements do not isolate a compiler-layout, constructor, or scheduling cause for the small CPU costs.

The decision is to preserve this smaller implementation as an isolated local candidate. It improves the newly admitted sparse operations in both CPU and peak memory, but it is not an unconditional production recommendation. Before combining it into a PR, investigate the common-path CPU costs without changing the frozen quality policy. The inherited minimum-size and 5% bypasses remain separate questions. No threshold was tuned from this panel.
