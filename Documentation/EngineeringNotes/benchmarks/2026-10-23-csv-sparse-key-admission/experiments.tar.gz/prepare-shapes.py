from pathlib import Path
import hashlib,json,re,struct,subprocess
R=Path(__file__).resolve().parent;I=R/'shape-inputs';I.mkdir(exist_ok=True)
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata');P=Path('/private/tmp/swiftsci-csv-lazy-sort-cache-20261023')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tokens=['','NA','na','N/A','n/a','null','NULL','NaN','nan','None']
layouts=['ascending','descending','nearby-swaps','random','single-early','single-middle','single-late','late-radix-64','half-minus-one','half','half-plus-one','sparse']+[f'valid-{denominator}-{arrangement}' for denominator in [19,10,4,2] for arrangement in ['distributed','clustered']]
for count in [32768,1000000]:
 for layout in layouts:
  identifier=f'{layout}-{count}';path=I/(identifier+'.csv')
  integers=[row//4 for row in range(count)]
  if layout=='descending':integers.reverse()
  elif layout=='nearby-swaps':
   for row in range(4095,count-1,4096):integers[row],integers[row+1]=integers[row+1],integers[row]
  elif layout=='random':
   state=0x12345678
   for row in range(count):
    state=(state*6364136223846793005+1)&((1<<64)-1);integers[row]=state%max(1,count//4)
  elif layout.startswith('single-'):
   row={'single-early':3,'single-middle':count//2-1,'single-late':count-5}[layout]
   integers[row],integers[row+1]=integers[row+1],integers[row]
  elif layout=='late-radix-64':
   integers=[(row//64)*64+(row%64 if (row//64)%2==0 else 63-row%64) for row in range(count)]
   integers[-2],integers[-1]=integers[-1],integers[-2]
  elif layout in ['half-minus-one','half','half-plus-one','sparse']:
   valid_count=count//19 if layout=='sparse' else count//2+{'half-minus-one':-1,'half':0,'half-plus-one':1}[layout]
   present=[row*count//valid_count for row in range(valid_count)]
   integers=[None]*count
   for rank,row in enumerate(present):integers[row]=(rank*7919)%1003 if layout=='sparse' else rank//4
   integers[present[3]],integers[present[4]]=integers[present[4]],integers[present[3]]
  elif layout.startswith('valid-'):
   _,denominator,arrangement=layout.split('-');denominator=int(denominator)
   valid_count=count//denominator-(1 if denominator==2 else 0)
   present=([rank*count//valid_count for rank in range(valid_count)] if arrangement=='distributed' else [count//4+rank for rank in range(valid_count)])
   integers=[None]*count
   for rank,row in enumerate(present):integers[row]=rank//4
   turn=(valid_count//2//4)*4-1
   integers[present[turn]],integers[present[turn+1]]=integers[present[turn+1]],integers[present[turn]]
  value_hash=hashlib.sha256();index_hash=hashlib.sha256()
  with path.open('w') as out:
   out.write('x\n')
   for value in integers:
    if value is None:
     out.write('""\n');value_hash.update(b'\x00')
    else:
     out.write(f'{value}.125\n');value_hash.update(b'\x01'+struct.pack('<d',value+.125))
  for row in sorted(range(count),key=lambda row:(integers[row] is None,integers[row] if integers[row] is not None else 0)):
   index_hash.update(b'\x01'+struct.pack('<q',row))
  contract={'id':identifier,'path':str(path),'delimiter':',','rows':count,'names':['x'],'types':['Double'],'hashes':[value_hash.hexdigest()],'null_tokens':tokens,'integral':[False],'file_sha256':h(path),'expected_index_sha256':index_hash.hexdigest(),'layout':layout,'null_count':integers.count(None)}
  (I/(identifier+'.json')).write_text(json.dumps(contract,indent=2)+'\n')
s=(R/'WorkflowProbe.swift').read_text().replace('let chosen = input.id.hasPrefix("energy") ? "Global_active_power" : "PM2.5"','let chosen = "x"')
line='        let h0=heap(),r0=resident(),p0=peak(),c0=cpu(),t0=DispatchTime.now().uptimeNanoseconds\n'
assert s.count(line)==1;s=s.replace(line,'')
a='        var output: DataFrame? = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)\n'
assert s.count(a)==1;s=s.replace(a,a+'        let retainedInput = output!\n'+line)
s=s.replace('        let t3=DispatchTime.now().uptimeNanoseconds,c3=cpu()','        let t3=DispatchTime.now().uptimeNanoseconds,c3=cpu()\n        withExtendedLifetime(retainedInput) {}')
s=s.replace('CSV construction, requested public operations and release; held memory before full validation. Complete output hashes outside CPU/wall timing.','Input construction excluded. Public sorting and index release with input retained by caller. Full output hashes outside timing.')
source=R/'ShapeProbe.swift';source.write_text(s)
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('original',Path('/private/tmp/swiftsci-csv-compact-sorting-20261023/build')),('prior',P/'build'),('current',R/'build')]:
 cmd=[a.replace(str(F),str(D)) for a in base]
 cmd=[str(source) if a.endswith('/ResourceProbe.swift') else str(R/(label+'-shape')) if a==str(D/'ResourceProbe') else a for a in cmd]
 if label in ['original','prior','current']:cmd+=['-D','CSV_STORAGE_CHOICE']
 cmd+=['-Rmodule-loading']
 with (R/(label+'-shape-build.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-shape-build.log')).read_text()));assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-shape-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':h(source),'binary_sha256':h(R/(label+'-shape'))},indent=2)+'\n')
 print(label,'shape client built',flush=True)
print('Prepared 40 shape fixtures with independent stable permutations',flush=True)
