from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
p=S/'Sources/SwiftDataFrame/Columns/TypedColumn.swift';s=p.read_text();needle='extension TypedColumn where T == Double {'
s=s.replace(needle,needle+'''
    internal var compactNumericStorage: CompactNumericColumn? {
        guard case .dense(let values, let validity) = storage else { return nil }
        var result = CompactNumericColumn(values)
        result.validity = validity
        result.nullCount = _nullCount
        return result
    }
''');p.write_text(s)
p=S/'Sources/SwiftDataFrame/Core/DataFrame+Matrix.swift';s=p.read_text()
s=s.replace('''        let cols = selected.count
        var flat''','''        let cols = selected.count
        if selected.count == 1, case .dense(let column) = selected[0], column.nullCount == 0 {
            return (column.values, rows, 1)
        }
        var flat''')
s=s.replace('''        let count = rows?.count ?? sourceCount
        let (elements, overflow)''','''        let count = rows?.count ?? sourceCount
        if rows == nil, selected.count == 1,
           case .dense(let column) = selected[0], column.nullCount == 0 {
            return PreparedNumericMatrix(values: column.values, columnNames: columns,
                rowCount: count, order: order, sourceRows: nil)
        }
        let (elements, overflow)''')
s=s.replace('''            if let column = self[column: name, as: Double.self] { return .double(column.values) }''','''            if let column = self[column: name, as: Double.self] {
                if let dense = column.compactNumericStorage { return .dense(dense) }
                return .double(column.values)
            }''')
s=s.replace('''    case double([Double?])
    case integer''','''    case double([Double?])
    case dense(CompactNumericColumn)
    case integer''')
s=s.replace('''        case .double(let values): return CompactNumericColumn(values, transform: { $0 })''','''        case .double(let values): return CompactNumericColumn(values, transform: { $0 })
        case .dense(let column): return column''')
s=s.replace('''        case .double(let values):
            for row in 0..<count''','''        case .dense(let column):
            for row in 0..<count { output[row * stride + offset] = column[row] ?? .nan }
        case .double(let values):
            for row in 0..<count''')
s=s.replace('''        case .double(let values):
            try write(values, transform: { $0 })''','''        case .dense(let column):
            for (destination, row) in rows.enumerated() {
                if let value = column[row] {
                    output[destination * stride + offset] = value
                } else if missing == .reject {
                    throw SwiftMLError.invalidParameter("Column \\(name) contains missing values")
                } else {
                    output[destination * stride + offset] = .nan
                }
            }
        case .double(let values):
            try write(values, transform: { $0 })''')
s=s.replace('''        case .double(let values):
            for (row, value) in values.enumerated()''','''        case .dense(let column):
            for row in column.values.indices { body(row, column[row] ?? .nan) }
        case .double(let values):
            for (row, value) in values.enumerated()''')
p.write_text(s)
