from pathlib import Path
import json,subprocess,tarfile,hashlib,gzip,shutil,ast,re
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-compact-consumers';T.mkdir(parents=True,exist_ok=True)
audit=json.loads((R/'audit.json').read_text());assert audit['all_outputs_match']
summary=json.loads((R/'measurement/summary.json').read_text())
def group(flow):return {x['engine']:x['medians'] for x in summary if x['case']=='energy-common/serial/'+flow}
rows=[]
for flow in ['read','materialize','matrix','batch','lag-matrix','sort-matrix','join-matrix']:
 g=group(flow)
 trip=lambda key,scale:' / '.join(f'{g[label][key]/scale:.2f}' for label in ['original','prior','current'])
 rows.append(f"| {flow} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
stage=json.loads((R/'stage-summary.json').read_text())
stage_lines=[]
for flow in ['materialize','matrix','batch','lag-matrix','join-matrix']:
 selected={x['engine']:x for x in stage if x['flow']==flow}
 stage_lines.append('| '+flow+' | '+' / '.join(f"{selected[label]['operations_ms']:.2f}" for label in ['original','prior','current'])+' |')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
readme=f'''# Compact numerical consumers

This experiment addresses the [first compact CSV prototype's](../2026-10-23-csv-compact-double-prototype/README.md) optional-array export penalty and unnecessary numerical conversion. It keeps the dense values and validity bitmap, exposes the existing getter body to client specialization, and lets numerical consumers use the compact buffers directly. No production default or public storage policy is promoted.

## Two changes with separate evidence

### Let the client compiler specialize the export loop

The optional-array getter originally remained generic at a separately compiled call site. The producer already contained a Double specialization, but the client called the generic getter. The archived optimized client SIL records that call. After `@inlinable` exposes the unchanged body, the client calls a concrete Double specialization instead.

The isolated diagnostic changed no loop, schema, storage representation or null policy. On the smaller air-quality export workflow, balanced diagnostic runs measured approximately **42.0 ms CPU before versus 9.9 ms after**, compared with **8.8 ms for the original optional-array reader**. Exact output fingerprints match. These diagnostic timings support the mechanism; use the complete resource panel below for qualification.

Commit `764c01bc6d` contains only this change and the storage metadata visibility required by the optimizer. Its dataframe Release suite passed 399 tests. The attributes do not remove the optional-array allocation or create a compatibility cache. They make the same loop available for concrete client optimization. This is not an ABI compatibility qualification for a separately distributed binary library.

### Remove optional-array conversion from numerical preparation

The next change adds an internal compact view for Double columns and a compact case in the existing private feature-column enum. It reuses `CompactNumericColumn` rather than introducing another numerical storage implementation.

- `prepareNumericBatch` retains existing dense value and validity arrays through Swift copy-on-write.
- Numerical matrix writers read dense values and validity directly. Missing-value rejection still considers the selected rows, with the existing error precedence.
- Full, present single-column matrix and target-vector exports can share the existing value array. Nullable inputs or row selections use the existing packing contract.
- Both matrix orders, duplicate columns, repeated row selections, valid NaNs, nil, signed zero and Int64 conversion behaviour remain covered.

Four focused ownership tests first failed on the copying implementation. They then passed after integration. The tests compare actual backing-buffer addresses, not just equal values, and verify that updating a prepared batch leaves the source dataframe unchanged. They also compare packed values bit for bit with the optional-backed implementation.

The integrated head is `{head}` on local branch `codex/csv-compact-consumers`, based on `6af4b8f071443779964ce77ac0856c48127657c6`. The preceding compact prototype and qualified CSV candidate remain separate branch heads. No source work is pushed.

## Complete workflow comparison

The panel compares the original optional-array reader, the first compact prototype, and the integrated code using identical client source. A fourth label runs the exact integrated binary again as a control. Each client imports the interface matching its linked object. Numerical preparation is included in the timed interval, along with CSV reading, the requested operations and release. Full output validation runs outside timing, after held and peak memory counters are captured.

The complete household and Aotizhongxin references retain their recorded schemas, values, null positions, native types and read scope. Household uses eleven declared null tokens including `?`; it is not the ten-token Swift default. Both existing CSV column-conversion policies are tested. Serial does not impose a single-core budget on the rest of the workflow. All comparisons use CPU execution with native scheduling.

Forty input/policy/workflow combinations cover reading, optional-array export, filtering, gathering, sorting, joining, boxed row scanning, lagged matrices, direct matrices and prepared batches. Four labels run in eight balanced orders. Every label occupies each position twice, and the order design balances adjacent label pairs. This gives **1,280 measured fresh processes**, after 160 exact workflow preflights. All final frame, matrix, exported-array, prepared-batch and row-scan bit fingerprints match the original reader.

The same power and quality rules apply throughout. AC power is checked before and after the panel. Builds, tests and profiling do not overlap accepted timings. Control limits remain 10% for median CPU and 5% plus 8 MiB for peak memory. The control result is **{'passed' if audit['quality_passed'] else 'flagged'}**. Flagged cases, if any, remain unqualified. Eight repetitions and the balanced four-label design are frozen for this experiment; this is a new panel, not an extension of the previous three-label twelve-repetition run.

## Household serial results

Values in each cell are **original / first compact prototype / integrated**. CPU is process user plus system time, not elapsed time or FLOPs. Held heap is live malloc allocation size. Peak RSS includes clean mapped input and allocator-retained pages, so it is not private retained storage or total system RAM use.

| Workflow | CPU, ms | Held heap, MiB | Peak RSS, MiB |
|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

The measured operation-stage CPU medians below exclude CSV reading and release. They come from each worker's actual stage counters, not subtraction of unrelated case medians. Separate stage medians need not sum to the median total.

| Operation | CPU original / first prototype / integrated, ms |
|---|---:|
'''+ '\n'.join(stage_lines)+'''

The matrix operation is faster than the first prototype but still costs more CPU than the original optional-backed operation. Prepared-batch construction mostly becomes buffer ownership transfer. Optional-array export still does real allocation and element construction even after specialization removes most of its former CPU cost. Join materialization remains a separate, substantial regression and is not fixed by the new numerical path.

[Complete results](results.md) include both reference datasets and both conversion policies. Small differences are descriptive observations. These results do not establish energy consumption, cache utilization, GPU/NPU performance or a universal cross-library ranking. Python libraries are not rerun in this panel.

## Validation and remaining work

The integrated dataframe suite passes **403 tests each in Release, Debug and Address Sanitizer**, with no failures or skips. Fourteen eager reference reads and fourteen streamed-reference checks preserve the existing exact contracts. The new test file contains four focused cases and remains separate from the preceding prototype tests.

Optional-array export still creates a second representation when the caller retains both. Filter, gather, sort and join outputs can still fall back to optional arrays. Faster export and direct numerical access do not by themselves justify switching every caller to dense storage. Further work must evaluate native selection outputs and make the eventual storage/performance policy explicit.

Keep the two changes as experimental commits. Resource improvements must be assessed by workload against CPU time, held allocations and peak memory separately. A lower retained payload does not automatically imply lower peak memory or less CPU work.

## Evidence and reproduction

- [Full resource results](results.md).
- [Independent audit](audit.json).
- [Experimental patch](changes.patch.gz), compressed without changing its bytes.
- [Specialization proof](specialization-proof.json), with optimized client SIL references and fingerprints.
- [Experiment archive](experiments.tar.gz), including scripts, source snapshots, input contracts, build and test receipts, the red/green test logs and raw outputs.
- [Artifact hashes](artifact-sha256.json).

Restore the recorded prototype base, decompress and apply the patch, rebuild its pinned dependencies, and update the scripts' machine-specific roots. The archive excludes native binaries, caches, result bundles and large reference CSVs. `verify.py` runs the restricted dataframe scheme. `build.py` builds the modified module. `prepare-panel.py` builds all comparator clients against the matching interfaces. `run-panel.py` performs preflights and measurements. `audit.py` recomputes medians, verifies source fingerprints and enforces the original control thresholds. Engineering records remain on `codex/engineering-notes` and source changes remain on the experimental branch.
'''
(T/'README.md').write_text(readme)
for name in ['results.md','audit.json','specialization-proof.json','stage-summary.json']:shutil.copy2(R/name,T/name)
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as out:out.write((R/'changes.patch').read_bytes())
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==(R/'changes.patch').read_bytes()
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.txt','.log','.md','.patch','.jsonl','.sil'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for p in (S/'Sources/SwiftDataFrame').rglob('*.swift'):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 tar.add(S/'Tests/SwiftDataFrameTests/CompactNumericConsumerTests.swift',arcname='final-source/Tests/SwiftDataFrameTests/CompactNumericConsumerTests.swift')
 for label,root in [('original','/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata'),('prior','/private/tmp/swiftsci-csv-compact-double-20261023')]:
  p=Path(root)/('build.json' if label=='original' else 'module-build.json');tar.add(p,arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',readme):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
assert '—' not in readme
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'}
(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(T/k)==v for k,v in manifest.items())
print(T);print('Verified evidence hashes, patch bytes, links, archive paths and script syntax')
