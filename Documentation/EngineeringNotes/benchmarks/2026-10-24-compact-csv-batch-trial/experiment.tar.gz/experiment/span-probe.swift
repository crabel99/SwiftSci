func appendProbe(_ values: inout [Double]) {
    values.append(addingCapacity: 2) { output in
        output.append(1.0)
        output.append(2.0)
    }
}
