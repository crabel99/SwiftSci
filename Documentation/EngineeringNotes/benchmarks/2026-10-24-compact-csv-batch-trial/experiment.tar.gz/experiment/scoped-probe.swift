func scopedAppend<R>(_ values: inout [Double], count: Int,
    body: (_ append: (Double?) -> Void) -> R) -> R {
    var result: R?
    values.append(addingCapacity: count) { output in
        result = body { value in output.append(value ?? .nan) }
    }
    return result!
}
