from pathlib import Path
s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
p=s/'Sources/SwiftDataFrame/IO/CSVColumnBuilder.swift';t=p.read_text()
t=t.replace('        if row & 63 == 63 { finishValidityWord(at: row >> 6) }','''        if row & 63 == 63 {
            Self.finishValidityWord(at: row >> 6, rowCount: values.count, expectedRows: expectedRows,
                validity: &validity, pendingValidity: &pendingValidity)
        }''')
t=t.replace('    private mutating func finishValidityWord(at index: Int) {','''    private static func finishValidityWord(
        at index: Int, rowCount: Int, expectedRows: Int,
        validity: inout [UInt64]?, pendingValidity: inout UInt64
    ) {''').replace('count: (max(expectedRows, values.count) + 63) / 64','count: (max(expectedRows, rowCount) + 63) / 64')
t=t.replace('        if values.count & 63 != 0 { finishValidityWord(at: values.count >> 6) }','''        if values.count & 63 != 0 {
            Self.finishValidityWord(at: values.count >> 6, rowCount: values.count, expectedRows: expectedRows,
                validity: &validity, pendingValidity: &pendingValidity)
        }''')
needle='    mutating func column(named name: String) -> TypedColumn<Double> {'
method='''    #if compiler(>=6.4)
    @available(macOS 26, *)
    mutating func appendBatch<Result>(
        maximumCount: Int, _ fill: (_ append: (Double?) -> Void) -> Result
    ) -> Result {
        let start = values.count
        let expected = expectedRows
        var bitmap: [UInt64]?
        swap(&bitmap, &validity)
        var pending = pendingValidity
        var missing = nullCount
        var result: Result?
        values.append(addingCapacity: maximumCount) { output in
            result = .some(fill { value in
                let row = start + output.count
                output.append(value ?? .nan)
                if value == nil {
                    pending &= ~(UInt64(1) << (row & 63))
                    missing += 1
                }
                if row & 63 == 63 {
                    Self.finishValidityWord(at: row >> 6, rowCount: row + 1, expectedRows: expected,
                        validity: &bitmap, pendingValidity: &pending)
                }
            })
        }
        validity = bitmap
        pendingValidity = pending
        nullCount = missing
        return result!
    }
    #endif

'''
assert t.count(needle)==1;t=t.replace(needle,method+needle);p.write_text(t)
p=s/'Sources/SwiftDataFrame/IO/CSVColumnConversion.swift';t=p.read_text();old='case .compactDouble(let attempt): attempt.appendDouble(buffer, records, startRow, rowCount, column, sourceOffset: sourceOffset)';new=old.replace('attempt.appendDouble','attempt.appendCompactDouble');assert t.count(old)==1;t=t.replace(old,new)
needle='    private func reject(_ field: CSVFieldOffset, sourceOffset: Int) {'
method='''    func appendCompactDouble<Records: CSVRecordAccess>(
        _ buffer: UnsafeBufferPointer<UInt8>, _ records: Records,
        _ startRow: Int, _ rowCount: Int, _ column: Int, sourceOffset: Int
    ) where Decoder == CSVDoubleDecoder, Builder == CSVCompactDoubleBuilder {
        #if compiler(>=6.4)
        if #available(macOS 26, *) {
            guard !rejected else { return }
            var batchValues = Builder(capacity: 0)
            swap(&batchValues, &values)
            let field: CSVFieldOffset? = batchValues.appendBatch(maximumCount: rowCount) { append in
                if !validates {
                    for row in startRow..<(startRow + rowCount) {
                        append(records.field(row: row, column: column).flatMap {
                            decoder.decodeValue(buffer: buffer, offset: $0)
                        })
                    }
                    return nil
                }
                for row in startRow..<(startRow + rowCount) {
                    guard let field = records.field(row: row, column: column) else {
                        append(nil)
                        continue
                    }
                    switch decoder.decode(buffer: buffer, offset: field) {
                    case .value(let value): append(value)
                    case .missing: append(nil)
                    case .invalid: return field
                    }
                }
                return nil
            }
            swap(&batchValues, &values)
            if let field { reject(field, sourceOffset: sourceOffset) }
            return
        }
        #endif
        appendDouble(buffer, records, startRow, rowCount, column, sourceOffset: sourceOffset)
    }

'''
assert t.count(needle)==1;t=t.replace(needle,method+needle);p.write_text(t)
