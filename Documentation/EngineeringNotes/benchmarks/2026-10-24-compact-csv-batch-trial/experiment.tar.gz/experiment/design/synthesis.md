# Scoped compact construction trial

## Usage first

Only the compact enum case calls `attempt.appendCompactDouble(...)`. Optional Doubles retain `appendDouble(...)`. The constrained compact attempt calls `builder.appendBatch(maximumCount: rowCount) { append in ... }`, appends accepted values or nil, and returns the first invalid field. Its existing `reject` method still rebases and clears that result.

## Shape

`CSVCompactDoubleBuilder.appendBatch<Result>(maximumCount: Int, _ fill: (_ append: (Double?) -> Void) -> Result) -> Result` borrows the Array output span through a synchronous nonescaping callback. It moves bitmap ownership into a local, carries null count and pending bits as scalar locals, commits only accepted elements, then restores metadata. A single private bitmap flush function serves scalar append, batch append, and finalization. No writer type or protocol requirement is added.

The batch method is guarded with `compiler(>=6.4)` and macOS26 availability for this first trial. Current SDK typecheck proves the operation can compile at the existing macOS14 deployment target, but does not prove older SDK/runtime support. Older builds use the unchanged scalar `appendDouble` path. Package minima stay Swift6.0/macOS14.

## Selection and graft

Use scoped candidate B. Parent scores A 7/10 and B 9/10, agreeing with the independent judge. B leaves established Double specialization and optional paths intact. Graft A's explicit moved-local bitmap ownership and boundary test cases. Replace B's noncopyable writer with the smaller scoped callback; a standalone Swift6.4/macOS14-target typecheck succeeds. Reject protocol-wide batching, new result enums, removal of the specialized Double path, and staging arrays.

## Verification

Keep 5b9c902977 as the preserved parent; prototype on a local child branch. First compare exact output hashes and scalar/bulk lifecycle behavior. Screen CPU across present, sparse, alternating and all-missing values, then complete real reference reads and sort/matrix queues with matched callers, binary twins and reversed order. Preserve controls before interpretation. If the added API/state handling yields only noise, harms another data pattern, or needs unsafe ownership workarounds, scrap it rather than layering fixes on it. A typecheck is not performance evidence.

## Limits

Array's closure must execute synchronously once, and conversion must append no more than its requested rows. Source records remain borrowed only during the worker's joined operation. The local bitmap must be moved, not copied alongside an owning reference, to avoid copy-on-write cloning. No full package/old-compiler compatibility or energy claim follows from this trial.
