# Compact batch construction trial

- [complete] Ground the current conversion and builder ownership.
- [complete] Sketch two distinct batch-construction designs and cross-judge them.
- [complete] Select a design; proceed without a human checkpoint.
- [complete] Implement one isolated prototype and measure it.
- [complete] Retain or scrap based on correctness and CPU/RSS evidence.

Arena: frame, fan out, cross-judge, pick, graft, verify.

Both scoped variants are rejected. Parent restored byte-for-byte; empty trial branch removed. Arena design verified by compilation/output checks, performance acceptance failed.
