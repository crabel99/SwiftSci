# Scoped compact Double batch writer

## Usage from the caller

Public CSV use does not change. Compact storage stays opt in, and `.optional` remains the default.

```swift
var options = CSVReadOptions()
options.doubleStorage = .compact
options.nullValues = ["NULL"]
let frame = try await DataFrame(csv: url, options: options)
```

Inference and replay also keep the same call. An integer sample may promote to compact Double on a later token, while a later invalid token still restarts from source row zero and can fall through to text.

```swift
var options = CSVReadOptions()
options.doubleStorage = .compact
options.columnConversionMode = .parallel
let inferred = try await DataFrame(csv: url, options: options)
```

The only changed internal call site is the existing enum dispatch. It remains one call per column and parser batch.

```swift
case .double(let attempt):
    attempt.appendDouble(buffer, records, startRow, rowCount, column,
                         sourceOffset: sourceOffset)
case .compactDouble(let attempt):
    attempt.appendCompactDouble(buffer, records, startRow, rowCount, column,
                                sourceOffset: sourceOffset)
```

## Problem

Compact Double decoding already appends directly inside the conversion loop, yet isolated compact reads use 3.2% more CPU than optional storage in the current controlled profile. Parsing dominates, so a broad abstraction is unlikely to pay for itself. The design must remove repeated Array growth checks from the compact path without changing decoding, retries, 16,384-row parser batches, storage defaults, or ownership. It must also distinguish nil from every valid Double bit pattern, including NaN.

## Shape

Keep `CSVColumnBuilding` exactly as it is. Add one specialized operation for the existing `CSVColumnAttempt<CSVDoubleDecoder, CSVCompactDoubleBuilder>` pairing. The attempt still owns the decoding loop and returns the first invalid `CSVFieldOffset`. The builder owns allocation, initialized-element accounting, and compact validity state.

```swift
extension CSVColumnAttempt
where Decoder == CSVDoubleDecoder, Builder == CSVCompactDoubleBuilder {
    func appendCompactDouble<Records: CSVRecordAccess>(
        _ buffer: UnsafeBufferPointer<UInt8>, _ records: Records,
        _ startRow: Int, _ rowCount: Int, _ column: Int,
        sourceOffset: Int
    )
}

#if compiler(>=6.4)
@available(macOS 26, *)
internal struct CSVCompactDoubleBatchWriter: ~Copyable, ~Escapable {
    mutating func append(_ value: Double?)
}

@available(macOS 26, *)
extension CSVCompactDoubleBuilder {
    mutating func appendBatch<Result>(
        maximumCount: Int,
        _ fill: (inout CSVCompactDoubleBatchWriter) -> Result
    ) -> Result
}
#endif
```

`appendCompactDouble` swaps the attempt's builder into one local owner, as today. For a validating attempt, its loop asks `CSVDoubleDecoder.decode` and stops on `.invalid`. For an explicit schema, its loop asks `decodeValue`, so invalid and missing fields both append nil. Absent fields append nil in both loops. The decoder remains the sole owner of null precedence, byte parsing, and String fallback.

On the guarded path, `appendBatch` moves the values and validity state into local single owners, then calls `values.append(addingCapacity:initializingWith:)` once with at most the parser batch's row count. It lends a nonescaping writer to the conversion loop. Each `writer.append` initializes one Double and updates validity using `startingRow + writer.count`. Nil initializes the current `.nan` placeholder, clears the corresponding bit, and increments `nullCount`. A valid NaN initializes its original bits and leaves validity set. The writer carries the pending validity word across the closure and returns all moved state to the builder on exit. It allocates the bitmap only on the first nil, extends it at word boundaries if the capacity estimate was low, and never stages decoded values in another array. It uses no new unsafe pointer API.

If decoding finds an invalid token, the OutputSpan commits only the accepted prefix. The attempt then records that field with `sourceOffset` and replaces the complete builder with an empty one. This preserves the current first-invalid, discard, and replay behavior. Finalization still flushes a partial validity word, transfers the arrays into `CompactNumericColumn`, and resets the builder. Swift array copy-on-write keeps finalized columns independent of builder reuse and exported-array mutation.

The bulk path uses `#if compiler(>=6.4)` and a conservative `if #available(macOS 26, *)`. Every other build runs the present per-value loop, with no package minimum change. The installed Swift 6.4 SDK declares the Array operation for macOS 10.14.4 and it typechecks for the package's macOS 14 target. That evidence does not establish Swift 6.2 source availability, so the first prototype should keep the stricter guards.

This is a deep internal interface: one closure hides capacity reservation, OutputSpan finalization, nil encoding, bitmap growth, and pending-word continuity. The caller controls only decoding order and calls one `append` operation per accepted row. No begin/end pair can be mismatched. Per boundary discipline, CSV token validation stays in the decoder. Per minimize-reader-load, the reader, retry coordinator, and record views do not change.

## Invariant ownership

- `CSVEagerReader` owns batch size, synchronous worker joins, row limits, and replay from offset zero.
- `CSVColumnAttempt` owns decoder choice, explicit versus inferred behavior, first-invalid stopping, source rebasing, and clearing rejected values.
- `CSVCompactDoubleBuilder` owns values, bitmap allocation and growth, null count, pending-word continuity across batches, drain/reset, and final snapshot transfer.
- `CSVCompactDoubleBatchWriter` owns only the temporary borrow. Its nonescapable type prevents record data or uninitialized storage from surviving the closure.

## Module map

- `CSVColumnConversion.swift`: route `.compactDouble` to `appendCompactDouble`; keep both compact decode loops and rejection rebasing here.
- `CSVColumnBuilder.swift`: hold the scoped writer, OutputSpan use, validity bookkeeping, fallback `append`, and final transfer.
- `CSVEagerReader.swift`, `CSVRecordIndex.swift`, and public CSV options: unchanged.
- Existing lifecycle, validity growth, retry, wide-index, and storage-mode tests remain the contract. Add parity coverage for a batch that stops mid-span and for a low capacity estimate crossing several validity words.

## Synthesis decision

Recommend this candidate as the scoped alternative to protocol-wide batch decoding. Arena synthesis remains to choose the final base.

## Tradeoffs accepted

- We accept one compact-specific attempt method in exchange for leaving every other builder and decoder untouched.
- We accept a guarded fast path plus fallback in exchange for preserving Swift 6.0 package and macOS 14 deployment settings.
- We accept possible Array reallocation when a hint is low in exchange for ordinary amortized growth without staging or copying a whole column ourselves.

## Alternatives considered

**Protocol-wide batch decoding.** Adding a batch requirement to `CSVColumnBuilding` makes every type implement storage policy it cannot use. It enlarges the internal interface and couples generic decoding to one optimization.

**Lazy `UnfoldSequence` into `Array.append(contentsOf:)`.** This avoids OutputSpan availability guards, but moves the decode loop into iterator state. Missing rows also prevent nil from cleanly representing sequence termination, so the iterator needs another result tag or side channel. Captured decoder and validity state may box, and ownership becomes harder to audit.

**Compact attempt type.** Replacing the generic attempt with `CSVCompactDoubleAttempt` gives clean dispatch but duplicates rejection, reset, finalization, and source-offset rules. The constrained method keeps those invariants in one owner.

## Open questions and risks

- Does the compiler keep the scoped writer and its validity state stack allocated in optimized builds?
- Does the bulk call lower total charged CPU in full public reads, given that parsing dominates and the isolated compact result currently regresses by 3.2%?
- Can later SDK evidence safely relax the macOS 26 guard while retaining the compiler guard?

Performance acceptance should compare total CPU for matched public-read panels with output and provenance checks. It should not use elapsed-time races or production thresholds tuned to one fixture.

## Next implementation step

Prototype the guarded writer behind the compact enum case, then run semantic suites and matched CPU panels before changing any availability guard.
