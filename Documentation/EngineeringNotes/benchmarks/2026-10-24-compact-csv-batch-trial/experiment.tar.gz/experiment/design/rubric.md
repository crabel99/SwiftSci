# Selection rubric

Score each item 0 to 2, then explain the result.

1. Preserve exact accepted values, missingness, rejection order, reset, replay, and snapshot ownership.
2. Avoid whole-column or temporary per-batch value arrays; give one owner to each mutable bitmap/array during decode.
3. Keep the public API and declared Swift6.0/macOS14 minima; distinguish implemented SDK APIs from type/proposal availability.
4. Concentrate storage details behind one small internal operation, without exposing staged writer lifecycle or bitmap handling to conversion callers.
5. Minimize changes to already-fast optional paths and decoding specialization; show one-variable tests and benchmark plan.

Configured runners outside the available tool model list were unavailable. Two gpt-5.6-sol candidates explore distinct structures; parent-model cross-judge reviews the resulting documents. No source implementations run in parallel.
