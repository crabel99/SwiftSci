# CSV conversion grounding

`CSVEagerReader` retains typed values across 16,384-row parser batches and releases each batch's record coordinates after synchronous column workers join. A `CSVColumnPlan` fixes the inference candidates; a `CSVColumnConversion` selects one typed `CSVColumnAttempt`; that reference owns a growing builder until rejection or finalization.

## Record access and decoding

`CSVRecordAccess.field(row:column:)` returns a field offset or nil for an absent field. `appendIndexed` selects a borrowed flat or compact record view when available, otherwise the index itself. Views and their buffer pointers cannot escape their synchronous closure. Offsets address the supplied batch buffer, including quote metadata.

`CSVColumnPlan.init` samples at most 1,000 selected rows. It skips absent fields, zero-length sample fields, and configured null tokens. Non-null evidence admits candidates in integer, Double, Boolean, date order, then text. An all-null sample admits text alone. A column override supplies one candidate and disables validation; disabled inference also selects text.

Conversion dispatch happens once per column and batch. Explicit schemas call `decodeValue`, which maps invalid and missing fields to nil. Inference calls `decode`, distinguishing a valid value, missing value, and invalid token. Absent fields always append nil. Numeric decoders preserve configured null precedence, try byte parsing, then use the existing string fallback. Inferred Doubles use `appendValidatedDoubles`; explicit Doubles use the generic nonvalidating loop. Both currently append each decoded value within the conversion loop.

## Ownership, retries, and completion

`CSVColumnAttempt.append` and `appendDouble` swap the owned builder into a local variable, mutate it through `inout`, then swap it back. The attempt remains shared by reference, but each joined worker owns a distinct column. Concurrent mutation of one attempt would violate that arrangement.

A validating loop stops at its first invalid field. The attempt rebases that field with `sourceOffset`, retains its length and escaped-quote flag, and replaces the entire builder with an empty builder. Earlier batches and the accepted prefix disappear. Further appends to that rejected attempt do nothing.

After a pass, the reader finalizes surviving columns and retries only rejected columns. `nextCandidate` probes the original rejected token against later candidates already admitted by the sample. A probe cannot admit a new type. Each replacement attempt replays selected source rows from offset zero, so earlier contradictory tokens still reject it and text fallback retains original spellings. Completed columns remain outside retries. Row limits apply to every pass.

`CSVColumnBuilder.column` transfers its optional array and null count into `TypedColumn`, then resets itself. `CSVCompactDoubleBuilder` instead stores contiguous Doubles, a lazy validity bitmap, null count, and one pending 64-bit validity word. Nil writes a NaN placeholder and clears validity; valid NaNs retain their bits. Finalization flushes a partial word, transfers storage into `CompactNumericColumn`, and resets the builder. Finalized columns must survive builder reuse and exported-array mutation.

## Constraints on a batch builder operation

- Append exactly the requested row range, in order, to existing values. Preserve absent-field handling, null-token matching, decoder fallback, and the explicit/inference distinction.
- Return the first invalid field unchanged in batch coordinates. Let the attempt rebase it once, discard all accumulated values, and remain rejected.
- Preserve a single mutable owner during the loop. Retain neither borrowed records nor source bytes, and finish before the column worker joins.
- Continue compact validity across batch boundaries using the total appended row index. Keep prior words valid when allocating the first bitmap late; grow beyond the capacity hint; preserve pending bits until finalization. Nil and valid NaN must remain distinguishable.
- Preserve null counts, exact Double bits, selected storage layout, drain/reset behavior, and independent finalized snapshots.

`CSVBatchBuilderStateTests`, `CSVCompactValidityGrowthTests`, and `CSVCompactDoublePrototypeTests` cover builder state and bitmap boundaries. `CSVConversionBoundaryTests` covers absent fields and wide indices. `CSVEagerBatchTests`, `CSVRejectedCandidateTests`, and `CSVDoubleStorageInferenceTests` cover retries and source replay. `CSVDoubleStorageModeTests` checks serial/parallel, explicit/inferred, and downstream ownership parity. These tests were inspected, not executed for this grounding.
