# Design judgment

Use candidate B as the base, replacing its writer type with the smaller scoped append callback. B limits the experiment to compact Double conversion and preserves the existing specialized Double loops. Neither candidate establishes a performance improvement or implementation correctness.

Scores assess each submitted design, before the recommended graft. Two means the design addresses the criterion, one means a material gap remains, and zero means the proposed change conflicts with it.

| Rubric criterion | A: builder-owned batch append | B: scoped compact writer |
| --- | ---: | ---: |
| Accepted values, missingness, rejection, reset, replay, snapshots | 2 | 2 |
| No decoded staging arrays; one mutable storage owner | 2 | 1 |
| Public API and Swift 6.0/macOS 14 minima | 1 | 2 |
| Small internal operation hides storage and lifecycle | 2 | 2 |
| Preserve optional paths and specialization; controlled verification | 0 | 2 |
| Total | 7/10 | 9/10 |

Both describe the required semantic behavior, including exact valid NaN bits, first-invalid stopping, one source-offset rebase, whole-attempt discard, replay, and snapshot independence. These are design commitments. Existing code already provides correct behavior, so implementation must demonstrate parity before any performance claim.

A explicitly moves the bitmap into a local owner and avoids decoded arrays. Its main defect is deleting `appendValidatedDoubles` and `appendDouble`, which were added for measured compiler specialization. The proposed generic provider and enum introduce another optimization question while removing an established optimization. Calling this subtraction does not justify it. A also leaves conservative runtime guarding optional; the first experiment should require it.

B preserves the useful specialization and confines the change to compact storage. Its ownership sketch is incomplete. A writer declaration with `~Copyable` and `~Escapable` does not specify how its stored `OutputSpan` borrows, how that lifetime is initialized, or how moved validity state returns. Its claim that the writer prevents retained record data is broader than the declaration establishes. The compiler must check actual storage and captures.

## Red-flag screen

Neither candidate requires a public staged lifecycle. A's single operation hides substantial bitmap policy, but expands every builder's protocol for one storage optimization. That expansion is avoidable; it is an interface cost rather than a clear shallow-module violation. A correctly keeps CSV decoding outside the builder.

B's scoped operation hides storage without leaking bitmap handling into conversion. Its new compact method risks duplicating decoding and rejection rules. Keep source rebasing, rejection clearing, and finalization with their existing owners. Do not add helper layers that merely forward the same arguments. The temporary writer is unnecessary once a callback can hide `OutputSpan`.

## Graft and reject

Keep B's compact-only dispatch, existing Double specialization, synchronous lifetime, compiler guard, and conservative runtime guard. Graft A's explicit local ownership of validity, pending word, and null count, plus its boundary cases at 63, 64, 65, 16,384, and 16,385 rows. Preserve late bitmap allocation and growth beyond capacity hints.

Replace `CSVCompactDoubleBatchWriter` with one builder-owned operation that lends a nonescaping `(Double?) -> Void` append callback to the existing decode loop. The parent has typechecked a smaller callback that captures the Array closure's `OutputSpan` on Swift 6.4 with a macOS 14 target. Extend that shape with locally owned validity state. This resolves the need for a stored span and a new writer type. It does not prove optimized allocation behavior, deployed runtime compatibility, or speed.

Reject A's protocol-wide requirement and deletion of specialized loops. Reject B's unsupported ownership claims and any temporary decoded value arrays. Keep the package minima and public API unchanged.

## Acceptance

First verify both guarded and fallback builds. Run semantic parity through real reads, including inferred rejection after earlier batches, explicit invalid-to-nil conversion, valid NaN payloads, bitmap boundaries, underestimated capacity, reset, and snapshot mutation independence. Then compare matched public-read panels with one implementation change, fixed workload and settings, total charged CPU, peak memory, output checks, and provenance. Use the actual inference workload with string overrides. A microbenchmark win or successful typecheck cannot establish resource efficiency. Retain the experiment only if the measured benefit survives correctness checks and run variation.
