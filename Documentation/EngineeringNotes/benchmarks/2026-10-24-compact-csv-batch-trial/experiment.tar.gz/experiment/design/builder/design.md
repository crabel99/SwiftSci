# Builder-owned batch append

## Problem

Compact Double CSV reads use less memory, but the isolated workload currently costs 3.2% more CPU than optional-backed storage. Profile `5b9c902977` shows that the compiler already inlines the common compact append into conversion, ownership checks sit above it, and parsing dominates. A useful change must therefore stay narrow and prove a reduction in total CPU. It must preserve first-invalid rejection and replay, exact Double bits, late validity allocation, pending words across 16,384-row batches, and builder drain semantics. The package remains Swift tools 6.0 with macOS 14 as its minimum.

## Usage, from the caller's view

Public callers see no change. Existing defaults and the compact opt-in remain intact.

```swift
var options = CSVReadOptions()
options.doubleStorage = .compact
let frame = try await DataFrame(csv: url, options: options)
```

`CSVColumnAttempt` gives its locally owned builder one operation for a whole batch. Inference passes the original bad field through unchanged.

```swift
let rejected = values.appendBatch(count: rowCount) { offset in
    let row = startRow + offset
    guard let field = records.field(row: row, column: column) else {
        return .value(nil)
    }
    switch decoder.decode(buffer: buffer, offset: field) {
    case .value(let value): return .value(value)
    case .missing:          return .value(nil)
    case .invalid:          return .invalid(field)
    }
}
```

An explicit schema uses the same builder operation, but its provider never rejects because invalid and missing fields retain their current nil behavior.

```swift
let rejected = values.appendBatch(count: rowCount) { offset in
    let row = startRow + offset
    let value = records.field(row: row, column: column).flatMap {
        decoder.decodeValue(buffer: buffer, offset: $0)
    }
    return .value(value)
}
precondition(rejected == nil)
```

The attempt still swaps the builder into a local variable before this call, swaps it back afterward, rebases one rejected field with `sourceOffset`, and replaces all accumulated values on rejection. Replay still starts at source row zero.

## Shape

```swift
internal enum CSVColumnBatchElement<Value> {
    case value(Value?)
    case invalid(CSVFieldOffset)
}

internal protocol CSVColumnBuilding<Value> {
    associatedtype Value: SupportedType

    init(capacity: Int)
    mutating func append(_ value: Value?)
    mutating func appendBatch(
        count: Int,
        elementAt: (Int) -> CSVColumnBatchElement<Value>
    ) -> CSVFieldOffset?
    mutating func column(named name: String) -> TypedColumn<Value>
}

internal extension CSVColumnBuilding {
    mutating func appendBatch(
        count: Int,
        elementAt: (Int) -> CSVColumnBatchElement<Value>
    ) -> CSVFieldOffset? {
        for offset in 0..<count {
            switch elementAt(offset) {
            case .value(let value): append(value)
            case .invalid(let field): return field
            }
        }
        return nil
    }
}
```

The default is the old scalar behavior. `CSVColumnBuilder<T>` needs no override. Under `#if compiler(>=6.4)`, `CSVCompactDoubleBuilder` supplies a witness that calls `values.append(addingCapacity: count, initializingWith:)` and fills its `OutputSpan<Double>` directly. Older compilers select the default witness. The Array API is available from macOS 10.14.4 and has typechecked for a macOS 14 target in the current Swift 6.4 SDK. This evidence does not establish Swift 6.2 source compatibility merely because `OutputSpan` appeared in 6.2. A first prototype may add a macOS 26 availability branch and use the scalar fallback elsewhere if the supported CI matrix exposes an SDK mismatch.

The compact override moves `validity` into one local with `swap`, and copies `pendingValidity` and `nullCount` into scalar locals before entering the Array closure. This avoids overlapping access to `self` and avoids a copy-on-write clone of the bitmap. For each accepted element, it appends either the exact Double or a NaN placeholder. It changes validity only when the optional is nil, so a valid NaN keeps its payload bits. The absolute row is `baseCount + acceptedOffset`; full 64-bit words flush as that row crosses a boundary. A partial word remains pending after the batch and flushes only at a later boundary or finalization.

`addingCapacity` receives the batch count, not `expectedRows - values.count`, so an underestimated capacity cannot underflow. `expectedRows` remains an allocation hint for the first bitmap. `finishValidityWord` still appends when the hint is exhausted. If decoding returns `.invalid`, the OutputSpan stops after the accepted prefix and returns that exact field. The attempt then discards the builder, as it does today. No borrowed record view or input byte escapes the synchronous call.

This is a deep internal interface: one method hides scalar versus bulk storage, bitmap word boundaries, growth, and compiler fallback. Callers still provide decoding policy because the builder should not know CSV bytes, null tokens, or inference rules. Per subtract-before-add, remove `appendValidatedDoubles` and `CSVColumnAttempt.appendDouble`; the single generic attempt path now delegates storage mechanics to the builder.

## Module map

- `CSVColumnBuilder.swift`: add `CSVColumnBatchElement`, the protocol requirement and default, and the conditional compact override. Keep bitmap and finalization ownership here.
- `CSVColumnConversion.swift`: make `appendRows` build batch elements; delete the separate Double loop and entry point. Keep decoding, rejection rebasing, and replay policy here.
- Existing focused tests remain the contract. Add boundary cases through the attempt for counts 63, 64, 65, 16,384, and 16,385, including an invalid token after a partial word and a capacity hint smaller than the data.

## Synthesis decision

Pending arena synthesis. This candidate recommends builder-owned batching because it changes no public API and keeps compact storage rules with their existing owner.

## Tradeoffs accepted

- We accept one internal batch-element enum and a provider call per row in exchange for keeping CSV decoding out of storage.
- We accept a scalar path on older compilers in exchange for preserving Swift tools 6.0 and macOS 14 package minima.
- We accept that the prototype may show no CPU win in exchange for testing the standard library bulk path without a custom buffer or extra arrays.

## Alternatives considered

- A specialized conversion or writer that owns compact buffers may give the optimizer more context, but it duplicates bitmap and drain rules outside the builder and makes conversion depend on storage layout.
- Protocol-wide batch decoding would expose CSV policy to every builder and widen an interface whose only new need is append mechanics.
- Per-batch `[Double]` and validity arrays simplify filling, but they violate the allocation goal and require copying into the growing column.
- Unsafe uninitialized storage avoids the new standard library API, but adds memory-initialization and lifetime rules that Array already owns.

## Open questions and risks

- Does the closure and batch-element switch erase the small gain from bulk append once total CPU is measured against optional storage with the same controls?
- Does the supported Swift 6.0 CI compiler accept the inactive `#if compiler(>=6.4)` branch cleanly, or must the bulk witness live in a conditionally compiled file?
- Can macOS 14 deployments use the SDK's back-deployed Array entry point in release builds, or should the first prototype retain the conservative macOS 26 runtime branch?
- Does SIL confirm one specialized provider loop for `CSVDoubleDecoder`, or is a narrow Double overload still warranted by evidence?

## Next implementation step

Build the protocol default and conditional compact witness, then run state tests and controlled total-CPU profiles before changing any broader ownership boundary.
