"""Keep observer placement separate from the timed compute-core requirement."""
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput import core_usage
from test_cpu_core_usage import snapshot, completed

WORKER_POLICY='e-core-workers-observer-v2'


class ObserverCoreTests(unittest.TestCase):
    def receipt(self):
        value=dict(policy=WORKER_POLICY,before=[snapshot(1)],after=[completed(1)],
                   controller_before=snapshot(2),controller_after=completed(2),
                   controller_qos_before=dict.fromkeys(core_usage.QOS_FIELDS,0),
                   controller_qos_after=dict.fromkeys(core_usage.QOS_FIELDS,0) | dict(default=24))
        value['controller_after']['p_user_ticks']=6
        return value

    def test_compute_stays_e_core_while_observer_p_time_is_charged(self):
        value=core_usage.audit_receipt(self.receipt(),[1],policy=WORKER_POLICY)
        self.assertEqual(value['worker_time_ns'],dict(user_e=1000,user_p=0,kernel_e=375,kernel_p=125))
        self.assertEqual(value['observer_time_ns'],dict(user_e=750,user_p=250,kernel_e=375,kernel_p=125))
        self.assertEqual(value['time_ns'],dict(user_e=1750,user_p=250,kernel_e=750,kernel_p=250))

    def test_old_policy_and_new_worker_rule_are_still_strict(self):
        old=self.receipt();old.pop('policy')
        with self.assertRaises(ValueError):core_usage.audit_receipt(old,[1])
        bad=self.receipt();bad['after'][0]['p_user_ticks']=1
        with self.assertRaises(ValueError):core_usage.audit_receipt(bad,[1],policy=WORKER_POLICY)

    def test_inherited_background_controller_is_rejected(self):
        bad=self.receipt();bad['controller_qos_after']['background']=1
        with self.assertRaises(ValueError):core_usage.audit_receipt(bad,[1],policy=WORKER_POLICY)

    def test_worker_launch_policy_is_closed_and_legacy_stays_unprefixed(self):
        self.assertEqual(core_usage.worker_prefix(None),())
        self.assertEqual(core_usage.worker_prefix(core_usage.POLICY),())
        self.assertEqual(core_usage.worker_prefix(WORKER_POLICY),('/usr/sbin/taskpolicy','-c','background'))
        with self.assertRaises(ValueError):core_usage.worker_prefix('arbitrary-command')

    def test_receipt_cannot_silently_change_its_core_policy(self):
        for policy in ['unknown',core_usage.POLICY]:
            with self.subTest(policy=policy),self.assertRaises(ValueError):
                core_usage.audit_receipt(self.receipt(),[1],policy=policy)


if __name__=='__main__':unittest.main()
