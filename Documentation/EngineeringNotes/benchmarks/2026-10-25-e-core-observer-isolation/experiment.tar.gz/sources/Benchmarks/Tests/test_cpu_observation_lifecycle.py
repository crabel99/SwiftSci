"""Charge receipt validation and preserve raw evidence when validation rejects it."""
import json
import os
import subprocess
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput import run, observation, core_usage
from test_cpu_core_usage import completed, snapshot


class Counters:
    policy=dict(policy=core_usage.WORKER_POLICY)
    def __init__(self):self.calls={};self.qos_calls=0
    def snapshot(self,pid):
        count=self.calls.get(pid,0);self.calls[pid]=count+1
        return completed(pid) if count else snapshot(pid)
    worker_snapshot=snapshot
    def memory(self,pid):return dict(pid=pid,start_identity=pid,rss_bytes=100,physical_footprint_bytes=80)
    def qos(self,pid):
        self.qos_calls+=1
        return dict.fromkeys(core_usage.QOS_FIELDS,0) | dict(default=self.qos_calls)


@unittest.skipUnless(sys.platform=='darwin','Worker clamp requires macOS')
class ObservationLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);worker=self.root/'worker.py'
        worker.write_text('''import json,os,sys,time
print(json.dumps(dict(ready=True,pid=os.getpid())),flush=True)
for line in sys.stdin:
    task=json.loads(line) if line.startswith('{') else line.strip()
    if task=='stats':value=dict(cpu_ns=time.process_time_ns(),rss_bytes=100)
    else:value=dict(task,cpu_ns=1,wall_ns=1,storage='test',input='tiny')
    print(json.dumps(value),flush=True)
''')
        self.command=[sys.executable,str(worker)]
        self.task=dict(id=0,input='tiny',workflow='read')

    def batch(self):
        return run.batch(self.command,'test',[self.task],1,self.root/'batch',core_reader=Counters())

    def test_direct_script_worker_launch_does_not_require_repository_on_pythonpath(self):
        code="""import runpy,sys
from pathlib import Path
module=runpy.run_path(sys.argv[1],run_name='cpu_controller')
worker=module['Worker']([sys.executable,sys.argv[2]],'test',Path(sys.argv[3]))
try: assert worker.ready['ready']
finally: worker.close()
"""
        env=dict(os.environ);env.pop('PYTHONPATH',None)
        result=subprocess.run([sys.executable,'-c',code,str(ROOT/'Benchmarks/CPUThroughput/run.py'),
            str(self.root/'worker.py'),str(self.root/'direct.log')],cwd=self.root,env=env,
            capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_final_cpu_snapshot_follows_both_observation_and_core_validation(self):
        ends=[]
        def charged(function):
            def wrapped(*args,**kwargs):
                value=function(*args,**kwargs)
                start=time.thread_time_ns()
                while time.thread_time_ns()-start<20_000_000:pass
                ends.append(time.process_time_ns())
                return value
            return wrapped
        with patch.object(observation,'summarize_observation',charged(observation.summarize_observation)), \
             patch.object(core_usage,'audit_receipt',charged(core_usage.audit_receipt)):
            summary=self.batch()
        raw=json.loads((self.root/'batch/result.json').read_text())
        self.assertEqual(len(ends),2)
        self.assertGreaterEqual(raw['memory_observation']['cpu_after_ns'],max(ends))
        self.assertGreaterEqual(summary['controller_cpu_ns'],40_000_000)

    def test_rejection_retains_the_full_receipt_and_closes_its_workers(self):
        with patch.object(observation,'summarize_observation',side_effect=ValueError('bad observation')):
            with self.assertRaisesRegex(ValueError,'bad observation'):self.batch()
        failure=json.loads((self.root/'batch/failure.json').read_text())
        raw=failure['record']
        for key in ['jobs','runtime','core_usage','memory_observation','before','after']:
            self.assertIn(key,raw)
        self.assertIn('charge_start_ns',raw['memory_observation'])
        for worker in raw['runtime']:
            with self.assertRaises(ProcessLookupError):os.kill(worker['pid'],0)


if __name__=='__main__':unittest.main()
