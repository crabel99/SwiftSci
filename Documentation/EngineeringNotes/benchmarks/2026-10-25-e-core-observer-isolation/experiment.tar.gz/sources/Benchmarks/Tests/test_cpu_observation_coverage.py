"""Reject observation holes without altering engine repeatability allowances."""
import copy
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput.observation import summarize_observation

MS=1_000_000


def receipt():
    return dict(policy=dict(interval_ns=10*MS,max_gap_ns=50*MS,max_scan_ns=50*MS),
        queue_start_ns=10*MS,queue_end_ns=90*MS,
        charge_start_ns=0,charge_end_ns=110*MS,cpu_before_ns=100,cpu_after_ns=200,
        scans=[dict(start_ns=t*MS,end_ns=(t+1)*MS,
            processes=[dict(pid=7,start_identity=123,rss_bytes=100,physical_footprint_bytes=80)])
            for t in range(0,101,10)])


class ObservationCoverageTests(unittest.TestCase):
    def audit(self,value):
        samples=[[s['end_ns'],sum(p['rss_bytes'] for p in s['processes'])] for s in value['scans']]
        return summarize_observation(value,samples,[7])

    def test_late_scans_skip_slots_without_moving_the_absolute_phase(self):
        from Benchmarks.CPUThroughput.observation import next_deadline_ns
        for now,expected in [(100,110),(109,110),(110,120),(112,120),(173,180)]:
            with self.subTest(now=now):self.assertEqual(next_deadline_ns(100,now,10),expected)

    def test_bracketed_scans_and_cpu_charge_are_recomputable(self):
        result=self.audit(receipt())
        self.assertTrue(result['observation_coverage_passed'])
        self.assertEqual(result['controller_cpu_ns'],100)
        self.assertEqual(result['max_observation_gap_ns'],10*MS)
        self.assertEqual(result['sampled_peak_footprint_bytes'],80)
        self.assertAlmostEqual(result['sampled_footprint_byte_seconds'],6.4)

    def test_many_clustered_samples_do_not_hide_a_hole(self):
        value=receipt();value['scans']=value['scans'][:2]+value['scans'][-2:]
        result=self.audit(value)
        self.assertFalse(result['observation_coverage_passed'])
        self.assertEqual(result['max_observation_gap_ns'],79*MS)

    def test_bad_boundaries_policy_identity_or_scan_are_rejected(self):
        mutations=[lambda v:v.update(queue_start_ns=0),lambda v:v.update(queue_end_ns=102*MS),
            lambda v:v.update(charge_start_ns=MS),lambda v:v.update(cpu_after_ns=99),
            lambda v:v['policy'].update(max_gap_ns=200*MS),
            lambda v:v['scans'][0]['processes'][0].update(pid=8),
            lambda v:v['scans'][0]['processes'][0].update(rss_bytes=-1),
            lambda v:v['scans'][1]['processes'][0].update(start_identity=124),
            lambda v:v['scans'][1].update(start_ns=0)]
        for mutate in mutations:
            with self.subTest(mutate=mutate),self.assertRaises(ValueError):
                value=copy.deepcopy(receipt());mutate(value);self.audit(value)

    def test_mismatched_rss_and_slow_scan_cannot_qualify(self):
        value=receipt()
        with self.assertRaises(ValueError):summarize_observation(value,[[1,1]],[7])
        value['scans']=value['scans'][:1]+[dict(start_ns=11*MS,end_ns=101*MS,
            processes=[dict(pid=7,start_identity=123,rss_bytes=100,physical_footprint_bytes=80)]),value['scans'][-1] | dict(start_ns=102*MS,end_ns=103*MS)]
        self.assertFalse(self.audit(value)['observation_coverage_passed'])


if __name__=='__main__':unittest.main()
