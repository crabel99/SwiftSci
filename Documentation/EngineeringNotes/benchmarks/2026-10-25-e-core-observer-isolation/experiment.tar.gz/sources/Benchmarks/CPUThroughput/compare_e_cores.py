#!/usr/bin/env python3
"""Run compare.py with verified E-core application execution and split kernel time."""
import argparse
from pathlib import Path
import subprocess
import sys
from core_usage import build, POLICY, WORKER_POLICY


def main():
    parser = argparse.ArgumentParser(description=__doc__,epilog='Other arguments are forwarded to compare.py.')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--observer-isolation',action='store_true',
        help='Background only compute workers; report ordinary controller/observation work separately')
    args,rest = parser.parse_known_args()
    args.output.mkdir(parents=True,exist_ok=False)
    calibration = build(args.output/'core-controls',policy=WORKER_POLICY if args.observer_isolation else POLICY)
    prefix = [] if args.observer_isolation else ['/usr/sbin/taskpolicy','-c','background']
    subprocess.run([*prefix,sys.executable,
        str(Path(__file__).with_name('compare.py')),*rest,'--output',str(args.output/'panel'),
        '--core-calibration',str(calibration.resolve())],check=True)


if __name__ == '__main__':
    main()
