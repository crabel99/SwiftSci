"""Recompute worker memory coverage and controller charges from raw observations."""

COVERAGE = dict(interval_ns=10_000_000,max_gap_ns=50_000_000,max_scan_ns=50_000_000)


def next_deadline_ns(previous, now, period):
    return previous + max(1,(now-previous)//period+1)*period


def summarize_observation(value, samples, worker_pids):
    if value['policy'] != COVERAGE:
        raise ValueError('Observation coverage policy changed')
    for key in ['queue_start_ns','queue_end_ns','charge_start_ns','charge_end_ns',
                'cpu_before_ns','cpu_after_ns']:
        if type(value[key]) is not int or value[key] < 0:
            raise ValueError('Invalid observation boundary: '+key)
    start,end=value['queue_start_ns'],value['queue_end_ns']
    if not value['charge_start_ns'] <= start < end <= value['charge_end_ns']:
        raise ValueError('Queue falls outside the controller charge interval')
    if value['cpu_after_ns'] < value['cpu_before_ns']:
        raise ValueError('Controller CPU counter moved backward')
    scans=value['scans']
    if not scans or len(worker_pids)!=len(set(worker_pids)):
        raise ValueError('Missing scans or duplicate worker identities')
    identities=None
    pairs=[];footprints=[];previous=value['charge_start_ns'];durations=[]
    for scan in scans:
        a,b=scan['start_ns'],scan['end_ns']
        if (type(a) is not int or type(b) is not int
                or not previous <= a <= b <= value['charge_end_ns']):
            raise ValueError('Invalid or overlapping observation scan')
        processes=scan['processes']
        if [p['pid'] for p in processes] != list(worker_pids):
            raise ValueError('Observation worker identity mismatch')
        current=[p['start_identity'] for p in processes]
        if any(type(n) is not int or n<=0 for n in current):
            raise ValueError('Missing worker start identity')
        if identities is None:
            identities=current
        if current!=identities:
            raise ValueError('Observed worker identity changed')
        for p in processes:
            for key in ['rss_bytes','physical_footprint_bytes']:
                if type(p[key]) is not int or p[key] < 0:
                    raise ValueError('Invalid observed memory value')
        pairs.append([b,sum(p['rss_bytes'] for p in processes)])
        footprints.append([b,sum(p['physical_footprint_bytes'] for p in processes)])
        durations.append(b-a);previous=b
    if pairs!=[list(pair) for pair in samples]:
        raise ValueError('RSS samples differ from observation scans')
    if pairs[0][0] > start or scans[-1]['start_ns'] < end:
        raise ValueError('Observation scans do not bracket the queue')
    gaps=[max(0,min(end,b[0])-max(start,a[0])) for a,b in zip(pairs,pairs[1:])]
    gap=max(gaps,default=0);duration=max(durations)
    return dict(controller_cpu_ns=value['cpu_after_ns']-value['cpu_before_ns'],
        max_observation_gap_ns=gap,max_observation_scan_ns=duration,
        observation_coverage_passed=gap<=COVERAGE['max_gap_ns'] and duration<=COVERAGE['max_scan_ns'],
        sampled_peak_footprint_bytes=max(p[1] for p in footprints),
        sampled_footprint_byte_seconds=sum(max(0,min(end,b[0])-max(start,a[0]))*a[1]/1e9
            for a,b in zip(footprints,footprints[1:])))
