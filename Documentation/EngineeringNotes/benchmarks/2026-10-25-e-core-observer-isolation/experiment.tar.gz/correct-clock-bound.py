import json
from pathlib import Path
q=Path(__file__).resolve().parent
rows=[json.loads(line) for p in q.glob('rate-probe-*-*.jsonl') for line in p.read_text().splitlines()]
value=dict(samples=len(rows),sdk_vs_getrusage_max_fraction=max(abs(r['rusage_ns']/r['sdk_cpu_ns']-1) for r in rows),
 all_three_max_fraction=max(max(r[k] for k in ['sdk_cpu_ns','rusage_ns','clock_cpu_ns'])/min(r[k] for k in ['sdk_cpu_ns','rusage_ns','clock_cpu_ns'])-1 for r in rows),
 scope='The original summary compared only SDK CPU time with getrusage. This recomputes the bound across all three clocks from unmodified raw rows.')
(q/'rate-probe-clock-audit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value,indent=2))
