# Controller observer design

Design only. No source edits or benchmark runs. Grounding completed against `/private/tmp/swiftsci-csv-compact-construction-20261024/Benchmarks/CPUThroughput`. Sketch completed. Agreement and implementation belong to the parent task. Nothing has been implemented or performance qualified.

## Problem

The current E-core wrapper applies background task policy to `compare.py` and its entire descendant tree. That tree contains the compute workers, the controller's four request lanes, and the memory sampler. The supplied diagnosis found timer coalescing near 200 ms for a requested 10 ms interval and runnable observer starvation up to two seconds with about 11 microseconds of CPU. A worker placement policy has therefore changed the scheduling of the observer needed to validate the benchmark.

Keep compute worker user execution on E cores, retain native engine pool defaults, report kernel P/E time separately, and charge observer CPU. Keep the existing twin CPU 10%, wall 10%, and RSS 5% plus 32 MiB limits at four callers. Every declared engine and twin remains in the panel.

## Usage, caller first

The existing invocation keeps its strict historical meaning:

```text
compare_e_cores.py --output OLD_PROFILE_OUTPUT [existing comparison arguments]
```

The new behavior requires an explicit profile:

```text
compare_e_cores.py --core-profile e-core-compute-observed-v2 \
  --output NEW_PROFILE_OUTPUT [existing comparison arguments]
```

The wrapper builds the supported-counter calibration before applying any scheduling clamp. For v2 it starts `compare.py` without the controller-wide background prefix. `compare.py` passes the selected profile through its existing preflight and batch entry points. `CoreReader` exposes the fixed worker launch prefix for its validated profile. `Worker` applies that prefix to each worker executable before native/Python startup:

```python
reader = CoreReader(calibration_path)
ready = preflight(configurations, cases, expected, preflight_dir,
                  launch_prefix=reader.launch_prefix)
summary = run.batch(command, mode, jobs, 4, directory,
                    core_reader=reader)
```

The caller chooses one profile. It does not select separate observer priority, worker priority, accounting mode, or per-engine exceptions. Postflight uses the same profile as preflight and timed workers.

## Runtime trace and evidence

1. `compare_e_cores.py:main` calls `core_usage.build`, then currently invokes `/usr/sbin/taskpolicy -c background python compare.py`. The calibration probe runs before the clamp. v2 removes that prefix from this one launch path.
2. `compare.py:conditions` declares Swift optional/compact and Python external-worker commands. pandas, Polars and DuckDB are always present. pandas_arrow remains governed by the existing declared-panel option. Every condition gets its own identical-command twin. `validate_plan` enforces the complete selected panel, four callers and fixed limits.
3. `run.py:Worker.__init__` normalizes the executable command, appends storage/engine mode and calls `Popen` with `worker_environment(PRODUCTION_MODE)` and `start_new_session=True`. The production environment clears thread overrides. v2 changes only the executable prefix to `taskpolicy -c background`; engine initialization and native pool sizing remain untouched. `taskpolicy` must exec the worker so the recorded PID and process group remain the ones being accounted and terminated.
4. `run.py:batch` launches four worker processes, reads worker stats and quiescent core snapshots, and reads controller core counters. It builds a queue and four `ThreadPoolExecutor` lanes. Each lane waits at the common barrier, writes one request, waits for a JSON result, and timestamps dispatch and receipt with `monotonic_ns`.
5. `MemorySampler` runs in the controller process. It reads each worker's resident bytes with `proc_pidinfo`, adds simultaneous scan readings, and waits on an event for the requested interval. Its initial/final synchronous samples also execute on the controller. Moving the controller to ordinary scheduling therefore moves both dispatch lanes and RSS observation, while the worker executables retain the compute policy.
6. Current `batch` measures queue wall time from barrier release to receipt of all results. Its process CPU measurement includes all controller threads during that interval and sampler join, but starts after the initial synchronous sample and ends before the final sample and later bookkeeping. Worker CPU uses independent before/after stats. v2 must explicitly bracket all batch observation work in its controller charge interval; merely moving the thread's scheduling would still leave the existing boundary samples outside that charge.
7. After the queue, `batch` stops/joins the sampler, samples once more, reads worker stats, obtains quiescent worker counters and reads controller counters. `core_usage.audit_receipt` validates identities/quiescence and currently calls the same strict `interval` function for workers and controller. `compare.audit` later repeats this audit against persisted records. v2 must pass the profile from the immutable plan on both paths.
8. `compare.audit` recomputes summaries from receipts and applies `audit.control_flags`. `compare.report` currently describes both worker and controller user CPU as E-only and reports one combined P/E table. v2 needs separate compute and observer rows/totals so unrestricted controller P user time cannot look like compute migration.

## Shape

Keep policy and counter validation in `core_usage.py`, worker launch ownership in `Worker`, queue/sampling ownership in `run.py`, and qualification ownership in `compare.audit`. Do not introduce a scheduler manager, observer service, generic policy adapter or production-library change.

Sketch signatures, with bodies intentionally omitted:

```python
# core_usage.py
POLICY = 'e-core-application-v1'  # existing default remains strict
COMPUTE_OBSERVED = 'e-core-compute-observed-v2'

def build(directory, *, profile=POLICY): ...
def validate_calibration(value): ...  # recognize only named profiles

def interval(before, after, *, require_e_user=True): ...
def audit_receipt(value, worker_pids, *, profile=POLICY): ...

# run.py
class Worker:
    def __init__(self, binary, storage, log, *, launch_prefix=()): ...

class MemorySampler:
    def __init__(self, workers, limit_bytes, interval=.01): ...
    def sample(self): ...  # records scan start, scan end and summed RSS

def batch(..., core_reader=None): ...

# compare.py
def preflight(..., *, launch_prefix=()): ...
def audit(root): ...  # new-profile receipt, coverage and existing twin checks
```

`interval` defaults to the old strict behavior, preserving existing strict unit expectations. For a v2 controller interval only, `audit_receipt` requests accounting without E-user enforcement. All workers still require zero P user ticks, and both profile versions retain counter monotonicity, positive work, valid P subsets, PID checks and worker quiescence. The interval arithmetic must become `user_e = user_ticks - p_user_ticks`. The current `user_e = user_ticks` is correct only because all P user work is rejected. Accepting controller P work without that subtraction would double-count it.

The private `require_e_user` parameter is driven by the validated named profile and process role, never by a user-exposed tolerance. `CoreReader.__init__` derives `launch_prefix` from the validated profile. `batch` passes it to `Worker`; comparison preflight and postflight pass it through their existing entry point. `Worker` prepends it to the normalized command before appending mode. The prefix is an internal fixed value, not another CLI choice. Worker launch and receipt validation use the same profile ID. A receipt cannot declare a looser local policy. An unknown or mismatched profile fails validation.

Keep raw counters and expose worker, controller, and combined P/E totals. The CPU twin gate continues to use worker plus controller CPU, with no subtraction for the sampler or P-core observer work. Do not equate split core totals with charged CPU until their interval boundaries actually match. The existing report already warns that they do not.

For v2, place the controller process CPU start before quiescent core reads, queue setup and the first RSS sample. Place its end after sampler join, final RSS sample, worker stats and final core reads. This charges batch observation overhead and controller lanes. Worker startup/calibration/report generation remain outside queue measurement as declared today. Persist these CPU bracket timestamps separately from queue wall timestamps. Wall time continues to measure queue release through receipt of all results, preserving the workload question.

This interface hides role-to-policy mapping and receipt arithmetic. The only added external choice is a named profile. No caller coordinates an observer lifecycle. Per subtract-before-you-add, remove the tree-wide clamp from the new profile before adding per-worker prefixes; keep the strict branch for historical use.

## Sampling coverage and interval anchors

A scheduling improvement is not a valid-memory certificate. v2 requires an independently recomputable coverage gate before performance qualification.

Persist integer monotonic queue start/end anchors, controller charge start/end anchors, and each RSS scan's start/end anchors with its RSS total. Persist requested interval and the versioned coverage policy in `plan.json`. The same-boot calibration already ties receipts to the host boot session. Preserve source hashes and raw samples. Do not reconstruct the queue start from response durations or infer coverage from `sample_count`.

Keep `MemorySampler.samples` and persisted `memory_samples` as the existing RSS pair list for compatibility. For v2 only, add scan records containing start/end monotonic anchors, RSS, and physical footprint from the same measurement call. The SDK helper `read_memory_usage` reads the same `PROC_PIDTASKINFO` RSS and adds `rusage_v6` physical footprint. A reusable-memory metric unavailable for an arbitrary PID is omitted, never inferred or filled with zero. Recompute the legacy RSS pairs from these scans during audit and require exact equality, so the additional records cannot disagree silently. Footprint is a separate reported measurement, not a replacement for RSS or its twin gate. Historical records retain their v1 parser; v2 requires scan records and cannot silently fall back. A rejected run retains its result receipt and a failure/quality explanation.

Freeze the requested interval at 10 ms and maximum effective sample gap at 50 ms in the new profile. This is an acceptance bound, not measured proof that ordinary scheduling meets it. Count queue start to first observation, every interval between observations inside the queue, and last observation to queue end. Use the observations immediately bracketing the queue as well; reject scans whose own duration exceeds 50 ms. An absent initial/final bracket, backward anchors, empty series, missing boundary coverage, or a 200 ms interior gap fails coverage. A large sample count cannot compensate for a missing interval.

Apply this frozen policy to all engines and twins. Never apply it retroactively to v1 records. Cadence qualification still does not prove the absolute instantaneous RSS peak. Keep the metric named sampled peak RSS.

## Synthesis decision

Use the ordinary controller with per-worker background launches as the base candidate. It changes the boundary responsible for the diagnosed interference and keeps all observer work in the controller's existing process-wide CPU counter. Adopt explicit role accounting, raw monotonic anchors and a coverage rejection gate. Reject any attempt to relabel v1, whitelist an engine, loosen twin limits or subtract observer CPU.

## Tradeoffs accepted

- Accept P-core observer user work in exchange for giving the controller and sampler ordinary scheduling. Receipts report that work separately and CPU gates still charge it.
- Accept movement of dispatch lanes along with the sampler in exchange for keeping the observer inside the one controller process whose CPU is already measurable. This changes the benchmark environment and therefore requires a new profile.
- Accept a broader v2 controller charge interval in exchange for charging initial/final scans and associated observation bookkeeping. Its anchors must make the change explicit; v1/v2 results are not interchangeable.
- Accept a failed qualification if ordinary scheduling still misses the pinned coverage bound. Native engine pools and twin limits cannot be adjusted to rescue the run.

## Alternative considered

A dedicated ordinary-priority observer process could sample background controller/workers independently. It provides stronger separation from the controller GIL and allows the controller's historical scheduling to remain in place. It also introduces process readiness/termination, PID handoff, concurrent receipt transfer, memory-limit kill ownership, a second process CPU charge, another set of P/E snapshots and shared interval coordination. The caller would need a richer lifecycle contract, or `batch` would hide substantially more state. Use it if the ordinary controller still fails coverage because of demonstrated GIL/control-path stalls. The supplied starvation diagnosis does not yet justify paying that cost. A high-priority sampler thread alone leaves Python GIL and inherited process-policy questions unresolved.

## Test seams and implementation order

1. Add profile fixtures that accept controller P user ticks only for v2; verify both profiles reject every worker P user tick and v1 still rejects controller P user ticks. Check `E + P = total` for user and kernel counters and verify malformed counters still fail.
2. Capture `Popen` commands for native and Python workers. v2 must prefix every preflight/timed/postflight worker, with the same environment clearing and process-group cleanup behavior. Verify old wrapper still clamps the whole controller and v2 does not. Use a tiny worker fixture to verify PID preservation and group termination before any long run.
3. Feed fixed monotonic sample records to the same summary/audit path used for receipts. Cover a healthy series, a 200 ms hole, scan duration overflow, missing edges, reversed anchors and many samples clustered on one edge. Change a saved summary and ensure re-audit rejects it.
4. Verify process CPU charging includes a controlled sampler's initial, threaded and final work. Keep worker CPU and controller CPU separately visible, then verify their sum drives the existing CPU twin gate.
5. Run existing comparison plan, full-output, engine/twin completeness and strict core tests. Add v2 report assertions so compute P user time cannot be concealed in a combined total. Do not run a comparative benchmark until these behavior checks pass and the coverage policy is fixed.

## Risks and decisions remaining

Will ordinary controller scheduling meet the frozen coverage bound under every declared engine? A measured coverage receipt must answer that. Does `taskpolicy` preserve the worker PID on this host? The short process-lifecycle check must answer it. Can GIL contention still delay the sampler after the process-wide clamp is removed? If so, the independent observer process becomes justified by new evidence. Will adding footprint observation increase scan duration or CPU noise enough to fail the frozen gate? Its cost belongs in observer accounting, with RSS thresholds unchanged.

The next implementation step is the named-profile counter/receipt tests and per-worker launch fixture, followed by the coverage receipt checks. This document authorizes no implementation or benchmark run by itself.
