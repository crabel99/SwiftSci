"""Verify real native/Python launch identity, E-core work, and cleanup."""
import json,os,sys
from pathlib import Path
root=Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source')
sys.path.insert(0,str(root))
from Benchmarks.CPUThroughput.core_usage import CoreReader,WORKER_POLICY,audit_receipt
from Benchmarks.CPUThroughput.run import Worker,batch,save
q=root.parent
reader=CoreReader(q/'sdk-probe/calibration.json')
worker='/private/tmp/swiftsci-csv-integer-overflow-20261024/sequential-build/worker'
contract='/private/tmp/swiftsci-csv-external-20261023/inputs/Aotizhongxin-default.json'
value=json.loads(Path(contract).read_text())
task=dict(id=0,contract=contract,workflow='read',input=value['id'],key='PM2.5',verify=False)
commands={'native':([worker],'compact'),'python':([sys.executable,str(root/'Benchmarks/CPUThroughput/external_worker.py')],'pandas_arrow')}
output={}
for name,(command,mode) in commands.items():
    launched=Worker(command,mode,q/(name+'-identity.log'),core_policy=WORKER_POLICY)
    pid=launched.process.pid
    try:
        assert launched.ready['pid']==pid
        assert os.getpgid(pid)==pid
        output[name]=dict(pid=pid,pgid=os.getpgid(pid),ready=launched.ready)
    finally:launched.close()
    try:os.kill(pid,0)
    except ProcessLookupError:pass
    else:raise AssertionError('Owned worker remained alive')
    summary=batch(command,mode,[task],1,q/(name+'-native-queue'),core_reader=reader)
    raw=json.loads((q/(name+'-native-queue/result.json')).read_text())
    core=audit_receipt(raw['core_usage'],[x['pid'] for x in raw['runtime']],policy=WORKER_POLICY)
    assert summary['worker_core_time_ns']['user_p']==0
    assert summary['observation_coverage_passed']
    output[name].update(summary=summary,core=core)
save(q/'native-check.json',output)
print(json.dumps({name:dict(worker_p_user_ns=v['summary']['worker_core_time_ns']['user_p'],
    max_gap_ms=v['summary']['max_observation_gap_ns']/1e6,observer_cpu_ms=v['summary']['controller_cpu_ns']/1e6)
    for name,v in output.items()},indent=2))
