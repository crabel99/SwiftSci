#!/usr/bin/env python3
"""Compare raw instruction, cycle, and CPU-time counters without normalizing results."""
import argparse,json,statistics
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('panel',type=Path);a=p.parse_args()
plan=json.loads((a.panel/'plan.json').read_text());rows=json.loads((a.panel/'records.json').read_text())
measurements=[]
for row in rows:
 raw=json.loads((a.panel/f"r{row['round']}-{row['label']}"/'result.json').read_text());c=raw['core_usage']
 totals={k:sum(b[k]-x[k] for x,b in zip(c['before'],c['after'])) for k in ['user_ticks','system_ticks','instructions','cycles']}
 ns=(totals['user_ticks']+totals['system_ticks'])*c['before'][0]['timebase_numer']/c['before'][0]['timebase_denom']
 measurements.append(dict(round=row['round'],label=row['label'],worker_cpu_ns=raw['summary']['worker_cpu_ns'],
  recount_cpu_ns=ns,instructions=totals['instructions'],cycles=totals['cycles'],cycles_per_cpu_ns=totals['cycles']/ns,
  controller_cpu_ns=raw['summary']['controller_cpu_ns']))
summary=[]
for name in plan['conditions']:
 def med(label,key):return statistics.median(x[key] for x in measurements if x['label']==label)
 summary.append(dict(condition=name,**{key+'_twin_over_primary':med(name+'_twin',key)/med(name,key)
  for key in ['worker_cpu_ns','recount_cpu_ns','instructions','cycles']},
  primary_cycles_per_cpu_ns=med(name,'cycles_per_cpu_ns'),twin_cycles_per_cpu_ns=med(name+'_twin','cycles_per_cpu_ns')))
print(json.dumps(dict(scope='Raw worker counters cover a wider interval than queue wall and process-stat charging. Cycles per CPU ns is an effective rate, not an independent hardware frequency measurement. No result is normalized or qualified here.',queues=measurements,summary=summary),indent=2))
