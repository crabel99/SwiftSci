import json,plistlib,subprocess,sys,tempfile
from pathlib import Path
script=Path(__file__).with_name('validate-frequency-capture.py')
checks=[]
with tempfile.TemporaryDirectory() as t:
 q=Path(t);(q/'native').mkdir()
 def run(label,summary,data,good):
  (q/'native/rate-probe-summary.json').write_text(json.dumps(summary));(q/'power.plist').write_bytes(data)
  r=subprocess.run([sys.executable,str(script),str(q)],capture_output=True,text=True)
  assert (r.returncode==0)==good,(label,r.stderr)
  checks.append(dict(case=label,passed=True,returncode=r.returncode))
 summary=dict(samples=240,checksum_count=1,all_p_user_zero=True)
 data=b'\0'.join(plistlib.dumps(dict(sample=i)) for i in range(600))
 run('complete format and native invariants',summary,data,True)
 run('incomplete native count',summary | dict(samples=239),data,False)
 run('nonzero P user',summary | dict(all_p_user_zero=False),data,False)
 run('inconsistent checksum',summary | dict(checksum_count=2),data,False)
 run('missing telemetry samples',summary,data.split(b'\0',1)[0],False)
 run('malformed telemetry',summary,b'not a plist',False)
print(json.dumps(dict(checks=checks,scope='Synthetic format and invariant validation only; no privileged telemetry collected.'),indent=2))
