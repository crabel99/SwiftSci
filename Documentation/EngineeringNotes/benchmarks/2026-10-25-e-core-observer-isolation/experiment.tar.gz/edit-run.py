from pathlib import Path
p=Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source/Benchmarks/CPUThroughput/run.py');s=p.read_text()
s=s.replace('def __init__(self, binary, storage, log):', 'def __init__(self, binary, storage, log, core_policy=None):')
s=s.replace("        self.log = log.open('w')", "        from Benchmarks.CPUThroughput.core_usage import worker_prefix\n        prefix = worker_prefix(core_policy)\n        self.log = log.open('w')")
s=s.replace('subprocess.Popen([*command, storage]', 'subprocess.Popen([*prefix, *command, storage]')
s=s.replace('def __init__(self, workers, limit_bytes, interval=.01):', 'def __init__(self, workers, limit_bytes, interval=.01, memory_reader=None):')
s=s.replace('self.samples, self.error = [], None', 'self.samples, self.scans, self.error = [], [], None\n        self.memory_reader = memory_reader\n        self.identities = None')
s=s.replace('    def sample(self):\n        total = 0', '''    def sample(self):
        if self.memory_reader is not None:
            start = time.monotonic_ns()
            processes = [self.memory_reader(w.process.pid) for w in self.workers]
            identities = [(p['pid'],p['start_identity']) for p in processes]
            if self.identities is None:
                self.identities = identities
            if identities != self.identities:
                raise RuntimeError('Observed worker identity changed')
            end = time.monotonic_ns()
            total = sum(p['rss_bytes'] for p in processes)
            self.scans.append(dict(start_ns=start,end_ns=end,processes=processes))
            self.samples.append((end,total))
        else:
            total = self.resident_bytes()
            self.samples.append((time.monotonic_ns(), total))
        if total > self.limit_bytes:
            raise MemoryError('Benchmark workers exceeded the experiment RSS ceiling')

    def resident_bytes(self):
        total = 0''')
s=s.replace("        self.samples.append((time.monotonic_ns(), total))\n        if total > self.limit_bytes:\n            raise MemoryError('Benchmark workers exceeded the experiment RSS ceiling')\n\n    def run", "        return total\n\n    def run")
s=s.replace('''        try:
            while not self.stop.is_set():
                self.sample()
                self.stop.wait(self.interval)
        except BaseException as e:''', '''        try:
            deadline = time.monotonic()
            while not self.stop.is_set():
                self.sample()
                if self.memory_reader is None:
                    self.stop.wait(self.interval)
                else:
                    deadline += self.interval
                    now = time.monotonic()
                    if deadline <= now:
                        deadline = now + self.interval
                    self.stop.wait(deadline-now)
        except BaseException as e:''')
s=s.replace('''    workers = []
    sampler = None
    try:''', '''    from Benchmarks.CPUThroughput.core_usage import WORKER_POLICY
    from Benchmarks.CPUThroughput.observation import COVERAGE, summarize_observation
    core_policy = None if core_reader is None else core_reader.policy['policy']
    observed = core_policy == WORKER_POLICY
    workers = []
    sampler = None
    try:''')
s=s.replace("Worker(binary, storage, directory / f'worker-{slot}.log')", "Worker(binary, storage, directory / f'worker-{slot}.log',core_policy=core_policy)")
s=s.replace("        before = [worker.ask('stats') for worker in workers]", "        if observed:\n            charge_start = time.monotonic_ns()\n            cpu_before = time.process_time_ns()\n            qos_before = core_reader.qos(os.getpid())\n        before = [worker.ask('stats') for worker in workers]")
s=s.replace('sampler = MemorySampler(workers, rss_limit_bytes)', 'sampler = MemorySampler(workers, rss_limit_bytes,\n            memory_reader=core_reader.memory if observed else None)')
s=s.replace('''        summary = summarize(results, end-start, sampler.samples, jobs)''', '''        observation = None
        if observed:
            qos_after = core_reader.qos(os.getpid())
            cpu_after = time.process_time_ns()
            charge_end = time.monotonic_ns()
            observation = dict(policy=COVERAGE.copy(),scans=sampler.scans,
                queue_start_ns=start,queue_end_ns=end,charge_start_ns=charge_start,
                charge_end_ns=charge_end,cpu_before_ns=cpu_before,cpu_after_ns=cpu_after)
            controller_cpu = cpu_after-cpu_before
        summary = summarize(results, end-start, sampler.samples, jobs)''')
s=s.replace("        if core_reader is not None:\n            from Benchmarks.CPUThroughput.core_usage import audit_receipt", "        if observed:\n            record['memory_observation'] = observation\n            summary.update(summarize_observation(observation,sampler.samples,[w.process.pid for w in workers]))\n        if core_reader is not None:\n            from Benchmarks.CPUThroughput.core_usage import audit_receipt")
s=s.replace("record['core_usage'] = dict(before=core_before,after=core_after,", "record['core_usage'] = dict(policy=core_policy,before=core_before,after=core_after,")
s=s.replace("            save(directory / 'result.json',record)\n            summary['core_time_ns'] = audit_receipt(record['core_usage'],[w.process.pid for w in workers])['time_ns']", "            if observed:\n                record['core_usage'].update(controller_qos_before=qos_before,controller_qos_after=qos_after)\n            save(directory / 'result.json',record)\n            core = audit_receipt(record['core_usage'],[w.process.pid for w in workers],policy=core_policy)\n            summary['core_time_ns'] = core['time_ns']\n            if observed:\n                summary.update(worker_core_time_ns=core['worker_time_ns'],\n                    controller_core_time_ns=core['observer_time_ns'],controller_qos_ticks=core['controller_qos_ticks'])")
s=s.replace("memory_samples=[] if sampler is None else sampler.samples))", "memory_samples=[] if sampler is None else sampler.samples,\n            memory_scans=[] if sampler is None else sampler.scans))")
p.write_text(s)
p=p.with_name('core_usage.py');s=p.read_text();s=s.replace("        self.launch_prefix = ('/usr/sbin/taskpolicy','-c','background') if self.policy['policy']==WORKER_POLICY else ()\n",'')
i=s.index('def digest')
s=s[:i]+'''def worker_prefix(policy):
    if policy not in (None,*POLICIES):
        raise ValueError('Unknown worker core policy')
    return ('/usr/sbin/taskpolicy','-c','background') if policy==WORKER_POLICY else ()


'''+s[i:];p.write_text(s)
