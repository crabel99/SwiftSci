from pathlib import Path
root=Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source/Benchmarks/CPUThroughput')
p=root/'core_counters.c';s=p.read_text().replace('out[1] = r.ri_phys_footprint;', 'out[1] = r.ri_phys_footprint;\n    out[2] = r.ri_proc_start_abstime;')
i=s.index('int running_threads')
s=s[:i]+'''int read_qos_usage(int pid, uint64_t *out) {
    struct rusage_info_v6 r = {0};
    if (proc_pid_rusage(pid, RUSAGE_INFO_V6, (rusage_info_t *)&r)) return -1;
    out[0] = r.ri_cpu_time_qos_default;
    out[1] = r.ri_cpu_time_qos_maintenance;
    out[2] = r.ri_cpu_time_qos_background;
    out[3] = r.ri_cpu_time_qos_utility;
    out[4] = r.ri_cpu_time_qos_legacy;
    out[5] = r.ri_cpu_time_qos_user_initiated;
    out[6] = r.ri_cpu_time_qos_user_interactive;
    return 0;
}

'''+s[i:];p.write_text(s)
p=root/'core_usage.py';s=p.read_text().replace("SOURCE = Path", "QOS_FIELDS = ('default','maintenance','background','utility','legacy','user_initiated','user_interactive')\nSOURCE = Path")
s=s.replace('self.lib.read_memory_usage.restype = ctypes.c_int', 'self.lib.read_memory_usage.restype = ctypes.c_int\n        self.lib.read_qos_usage.argtypes = [ctypes.c_int,ctypes.POINTER(ctypes.c_uint64)]\n        self.lib.read_qos_usage.restype = ctypes.c_int')
s=s.replace('(ctypes.c_uint64*2)()', '(ctypes.c_uint64*3)()')
s=s.replace('physical_footprint_bytes=int(data[1]))', 'physical_footprint_bytes=int(data[1]),start_identity=int(data[2]))')
s=s.replace('    def snapshot(self, pid):', "    def qos(self, pid):\n        data = (ctypes.c_uint64*len(QOS_FIELDS))()\n        if self.lib.read_qos_usage(pid,data):\n            raise OSError(ctypes.get_errno(),'Cannot read controller QoS for '+str(pid))\n        return dict(zip(QOS_FIELDS,map(int,data)))\n\n    def snapshot(self, pid):")
s=s.replace("    return dict(policy=policy,workers=workers,controller=controller,", "    qos = {}\n    if policy==WORKER_POLICY:\n        for key in QOS_FIELDS:\n            a,b=value['controller_qos_before'][key],value['controller_qos_after'][key]\n            if type(a) is not int or type(b) is not int or a < 0 or b < a:\n                raise ValueError('Invalid controller QoS counter')\n            qos[key]=b-a\n        if sum(qos.values())<=0 or any(qos[k] for k in ('background','maintenance','utility')):\n            raise ValueError('Controller did not run under the ordinary observation policy')\n    return dict(policy=policy,workers=workers,controller=controller,controller_qos_ticks=qos,")
p.write_text(s)
p=root.parent/'Tests/test_cpu_observation.py';s=p.read_text().replace("controller_before=snapshot(2),controller_after=completed(2))", "controller_before=snapshot(2),controller_after=completed(2),\n                   controller_qos_before=dict.fromkeys(core_usage.QOS_FIELDS,0),\n                   controller_qos_after=dict.fromkeys(core_usage.QOS_FIELDS,0) | dict(default=24))")
s=s.replace("    def test_receipt_cannot_silently_change_its_core_policy(self):", "    def test_inherited_background_controller_is_rejected(self):\n        bad=self.receipt();bad['controller_qos_after']['background']=1\n        with self.assertRaises(ValueError):core_usage.audit_receipt(bad,[1],policy=WORKER_POLICY)\n\n    def test_receipt_cannot_silently_change_its_core_policy(self):")
p.write_text(s)
