"""Check that the default whole-tree E-core profile still runs and audits."""
import json,subprocess,sys
from pathlib import Path
q=Path(__file__).resolve().parent;root=q/'source';sys.path.insert(0,str(root))
from Benchmarks.CPUThroughput.core_usage import build,CoreReader,POLICY
from Benchmarks.CPUThroughput.run import batch
if '--queue' not in sys.argv:
    build(q/'legacy-sdk',policy=POLICY)
    subprocess.run(['/usr/sbin/taskpolicy','-c','background',sys.executable,str(Path(__file__).resolve()),'--queue'],check=True)
else:
    contract='/private/tmp/swiftsci-csv-external-20261023/inputs/Aotizhongxin-default.json'
    data=json.loads(Path(contract).read_text())
    task=dict(id=0,contract=contract,input=data['id'],workflow='read',key='PM2.5',verify=False)
    summary=batch('/private/tmp/swiftsci-csv-integer-overflow-20261024/sequential-build/worker',
        'compact',[task],1,q/'legacy-queue',core_reader=CoreReader(q/'legacy-sdk/calibration.json'))
    raw=json.loads((q/'legacy-queue/result.json').read_text())
    assert raw['core_usage']['policy']==POLICY
    assert summary['core_time_ns']['user_p']==0
    assert 'memory_observation' not in raw
    print(json.dumps(dict(policy=POLICY,completed=summary['completed'],all_application_p_user_ns=0,
        new_observation_receipt=False),indent=2))
