"""Reuse the native fixed-register loop with background workers and ordinary coordination."""
import json,os,subprocess,time
from pathlib import Path
q=Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025')
probe=Path('/private/tmp/swiftsci-e-core-repeatability-diagnosis-20261025/fixed-work-mach-aligned')
owned=[];records=[]
for phase,callers in enumerate([1,4,1,4]):
    jobs=[]
    for slot in range(callers):
        out=(q/f'rate-probe-{phase}-{slot}.jsonl').open('w')
        err=(q/f'rate-probe-{phase}-{slot}.stderr').open('w')
        p=subprocess.Popen(['/usr/sbin/taskpolicy','-c','background',str(probe),'200000000'],stdout=out,stderr=err,start_new_session=True)
        jobs.append((p,out,err));owned.append(p.pid)
    try:
        for p,out,err in jobs:
            p.wait(timeout=60)
            if p.returncode:raise RuntimeError('Native rate probe failed')
    finally:
        for p,out,err in jobs:
            if p.poll() is None:p.kill();p.wait()
            out.close();err.close()
    for slot in range(callers):
        for row in map(json.loads,(q/f'rate-probe-{phase}-{slot}.jsonl').read_text().splitlines()):
            records.append(dict(phase=phase,callers=callers,slot=slot,**row))
summary=dict(samples=len(records),checksum_count=len({r['value'] for r in records}),
    all_p_user_zero=all(r['p_user_ns']==0 for r in records),
    cpu_ms_min=min(r['sdk_cpu_ns'] for r in records)/1e6,cpu_ms_max=max(r['sdk_cpu_ns'] for r in records)/1e6,
    effective_cycles_per_cpu_ns_min=min(r['cycles']/r['sdk_cpu_ns'] for r in records),
    effective_cycles_per_cpu_ns_max=max(r['cycles']/r['sdk_cpu_ns'] for r in records),
    maximum_clock_disagreement_fraction=max(abs(r['rusage_ns']/r['sdk_cpu_ns']-1) for r in records),
    owned_pids=owned)
(q/'rate-probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
