"""Record command, source revision, file hashes, and timing for the controller run."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
q=Path(__file__).resolve().parent;source=q/'source'
python=Path('/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=source,text=True).strip()
command=[str(python),'-m','unittest','discover','-s','Benchmarks/Tests']
env=dict(os.environ,SWIFTSCI_MLX_TEST_GPU='1')
record=dict(command=command,cwd=str(source),start_utc=now(),head_before=git('rev-parse','HEAD'),
 status_before=git('status','--porcelain'),explicit_environment=dict(SWIFTSCI_MLX_TEST_GPU='1'),
 python_sha256=hashlib.sha256(python.read_bytes()).hexdigest(),
 sources={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
  for directory in ['Benchmarks/Tests','Benchmarks/CPUThroughput'] for p in (source/directory).glob('*') if p.suffix in ['.py','.c']})
with (q/'controller-bound-tests.log').open('w') as log:r=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(end_utc=now(),returncode=r.returncode,head_after=git('rev-parse','HEAD'),status_after=git('status','--porcelain'),
 log_sha256=hashlib.sha256((q/'controller-bound-tests.log').read_bytes()).hexdigest())
(q/'controller-test-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
if r.returncode:raise SystemExit(r.returncode)
