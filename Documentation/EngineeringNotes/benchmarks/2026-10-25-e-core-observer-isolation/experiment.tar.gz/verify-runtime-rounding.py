import json,subprocess
from pathlib import Path
q=Path(__file__).resolve().parent
code='''import json,sys,importlib.util,math
from pathlib import Path
q=Path(sys.argv[1]);s=importlib.util.spec_from_file_location('core',q/'sources/Benchmarks/CPUThroughput/core_usage.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=q/'smoke-final/panel';out=[]
for row in json.loads((r/'records.json').read_text()):
 raw=json.loads((r/f"r{row['round']}-{row['label']}"/'result.json').read_text());core=m.audit_receipt(raw['core_usage'],[v['pid'] for v in raw['runtime']],policy=m.WORKER_POLICY)
 for k,v in core['time_ns'].items():
  expected=raw['summary']['core_time_ns'][k]
  if v!=expected:
   components=[w['time_ns'][k] for w in core['workers']]
   out.append(dict(label=row['label'],round=row['round'],component=k,expected=expected,observed=v,difference_ns=v-expected,worker_components=components,worker_sum=sum(components),worker_fsum=math.fsum(components)))
print(json.dumps(dict(python=sys.version,mismatches=len(out),maximum_absolute_difference_ns=max([abs(v['difference_ns']) for v in out],default=0),first=out[0] if out else None)))
'''
value=[]
for python in ['/usr/bin/python3','/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python']:
 value.append(json.loads(subprocess.check_output([python,'-c',code,str(q)],text=True)))
(q/'runtime-rounding-witness.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
