# Candidate B: isolated normal-scheduled observer

## Problem

The current 10 ms `MemorySampler` runs inside the background-clamped controller. Under the real queue, its timer produced gaps near 200 ms. A critical timer did not fix scheduling, and a two-second runnable probe received only 11 microseconds of CPU. The sampler therefore cannot support the claimed resolution while it shares the compute process. The replacement must keep the strict `e-core-application-v1` rule for workers and controller, leave jobs, data, native pools, and twin thresholds unchanged, and expose every cost introduced by observation.

## Usage from the caller

The normal wrapper starts one observer before it starts `compare.py` through `taskpolicy -c background`. It passes one end of a socket pair to each process. The wrapper then waits without participating in a batch.

```python
measured = observer.measure(
    targets=[ObservedProcess(w.process.pid, w.process.pid) for w in workers],
    rss_limit_bytes=rss_limit_bytes,
    run=lambda start_ns: collect_queue_results(start_ns),
)

summary.update(measured.summary)
record["memory_observation"] = measured.receipt
```

`measure` arms the observer, waits for its baseline sample, records the controller's monotonic start, calls `run`, records the end as soon as the queue finishes, and obtains a final sample. If `run` raises, it cancels the session. The caller never coordinates protocol messages or cleanup stages.

## Shape

The public Python interface stays small:

```python
@dataclass(frozen=True)
class ObservedProcess:
    pid: int
    process_group_id: int

@dataclass(frozen=True)
class MemorySample:
    monotonic_ns: int
    rss_bytes: int
    physical_footprint_bytes: int

@dataclass(frozen=True)
class Measured:
    value: object
    start_ns: int
    end_ns: int
    samples: tuple[MemorySample, ...]
    observer_cpu_ns: int
    max_sample_gap_ns: int
    summary: dict
    receipt: dict

class ObservationClient:
    pid: int
    def measure(self, targets, rss_limit_bytes, run) -> Measured: ...
    def close(self) -> None: ...
```

`Measured` carries the callback value, `start_ns`, `end_ns`, samples, `observer_cpu_ns`, maximum observed gap, and the private protocol receipt. One module owns launch, framed JSON over the socket, absolute 10 ms sampling deadlines, cancellation, and shutdown. `run.py` remains the only writer of result files.

At arm time the observer records each PID's `ri_proc_start_abstime`. Every sample rechecks it, which catches exit and PID reuse. A missing target, changed identity, read failure, or RSS ceiling breach ends the session and kills all registered worker process groups. Socket EOF during an active session does the same, so a dead controller cannot orphan workers. The final sample must be at or after `end_ns`; the baseline must be at or before `start_ns`. Both processes use the system monotonic clock.

The named policy becomes `e-core-application-v2`. Its compute clause invokes the unchanged `e-core-application-v1` audit for every worker and the controller, including zero P-core user time and separate P/E kernel time. Its observer clause requires an explicitly default-scheduled observer. The observer brackets each session with its own calibrated resource snapshots. Observer P-user is allowed, but observer P/E user and kernel time and QoS CPU buckets are reported separately. The observer reports its own user-plus-system CPU delta, and `charged_cpu_ns` becomes worker CPU plus controller CPU plus observer CPU. Core-counter intervals remain a wider cross-check, as they are now.

The worker-only `sampled_peak_rss_bytes` remains the input to the existing RSS twin control. The same samples also report summed physical footprint. `TASK_VM_INFO` exposes reusable bytes, but reading another process through that API needs task-port access. V1 of this observer omits reusable memory rather than adding privileges or worker instrumentation. RSS and physical footprint remain comparable process aggregates, not a claim about unique system memory.

The policy proposes a 50 ms maximum observed sample gap. This is a qualification gate computed from timestamps, not a hard scheduling deadline. A batch that exceeds it fails qualification instead of being described as 10 ms sampling. Existing CPU, wall, and RSS twin limits remain byte-for-byte unchanged.

## Candidate comparison

A normal controller with background-only worker prefixes removes the new process and protocol. It also lets queue lanes, dispatch, response collection, and bookkeeping run at normal priority and possibly on P cores. That changes the measured application and cannot preserve `e-core-application-v1` for the controller. It is still the cheapest diagnostic prototype for testing whether the GIL or sampler thread causes the gap. Candidate B is the smaller production policy change because it grants normal scheduling only to the work that proved starved.

## Tradeoffs and rejected alternatives

- We accept one long-lived process and one socket pair in exchange for keeping compute scheduling unchanged.
- We accept sampled enforcement and a 50 ms validity gate in exchange for avoiding privileged kernel tracing.
- A fresh observer per batch loses because startup noise and lifecycle failure repeat inside every condition.
- Raising thread QoS inside the clamped controller loses because the real queue already showed that timer priority alone did not restore service.

## Regression seams and risks

Pure audit tests should reject PID identity changes, missing boundary samples, gaps above 50 ms, omitted observer CPU, any compute P-user tick, and any altered twin threshold. A scripted socket peer can cover arm, finish, callback failure, EOF, and stale session IDs. One live saturated smoke test remains mandatory. It must show the observer receives default rather than background QoS CPU, the compute audit still passes `e-core-application-v1`, and observed gaps stay within 50 ms.

The main risks are observer perturbation, macOS changes to `taskpolicy` inheritance, and unavailable physical-footprint reads on a future OS. The receipt makes each visible. A failed read invalidates the batch; it never silently falls back to RSS-only output.
