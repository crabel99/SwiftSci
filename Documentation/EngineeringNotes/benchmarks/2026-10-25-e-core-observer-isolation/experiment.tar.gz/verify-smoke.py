#!/usr/bin/env python3
"""Replay saved observer receipts; this does not rerun counters or qualify speed."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('bundle',type=Path)
a=p.parse_args();root=a.bundle.resolve();panel=root/'smoke-final/panel';sources=root/'sources'
checks=0

def require(condition,message):
    global checks
    if not condition:raise ValueError(message)
    checks+=1


def load(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

plan=load(panel/'plan.json');rows=load(panel/'records.json');expected=load(panel/'expected.json')
recorded_python=tuple(map(int,plan['environment']['python'].split()[0].split('.')))
require(sys.version_info[:3]==recorded_python,'Replay requires recorded Python '+'.'.join(map(str,recorded_python))+' for exact floating-point counter bookkeeping')
for name,digest in plan['source_hashes'].items():
    require(sha(sources/name)==digest,'Archived measured source changed: '+name)
sys.path.insert(0,str(sources))
from Benchmarks.CPUThroughput.run import summarize
from Benchmarks.CPUThroughput.core_usage import audit_receipt,WORKER_POLICY
from Benchmarks.CPUThroughput.observation import summarize_observation,COVERAGE
from Benchmarks.CPUThroughput.audit import control_flags

limits=dict(twin_cpu_deviation=.10,twin_wall_deviation=.10,
    twin_peak_relative=1.05,twin_peak_slack_per_caller_bytes=8*2**20)
require(plan['quality_policy']==limits,'Twin limits changed')
require(plan['observation_policy']==COVERAGE,'Coverage policy changed')
require(plan['core_policy']['policy']==WORKER_POLICY,'Wrong core profile')
require(sha(root/'smoke-final/core-controls/core-counters.dylib')==plan['core_policy']['library_sha256'],'Archived counter binary changed')
require(plan['core_policy']['source_sha256']==sha(sources/'Benchmarks/CPUThroughput/core_counters.c'),'Counter source changed')
require(plan['callers']==4 and plan['copies_per_case']==2 and plan['smoke'],'Not the declared smoke work')
require(plan['rss_limit_bytes']==8*2**30,'RSS ceiling changed')
require(set(plan['conditions'])=={'swiftsci_optional','swiftsci_compact','pandas','polars','duckdb','pandas_arrow'},'Incomplete engine panel')
require((panel/'end.json').exists() and not (panel/'failure.json').exists(),'Incomplete run')
require(sha(panel/'expected.json')==plan['expected_sha256'],'Expected output changed')
require({(r['round'],r['label']) for r in rows}=={(i,n) for i,order in enumerate(plan['orders']) for n in order},'Incomplete queue set')
require(len(rows)==24,'Wrong smoke queue total')
coverage_flags=[];workers=0;controller_p=0;total_jobs=0;max_gap=0;max_scan=0
for row in rows:
    raw=load(panel/f"r{row['round']}-{row['label']}"/'result.json');summary=raw['summary']
    require(summary==row['summary'],'Summary differs from raw result')
    tasks=[dict(c,id=i*len(plan['cases'])+c['id']) for i in range(2) for c in plan['cases']]
    offset=row['round']%len(tasks);tasks=tasks[offset:]+tasks[:offset]
    basic=summarize(raw['jobs'],summary['elapsed_ns'],raw['memory_samples'],tasks)
    require(all(summary[k]==v for k,v in basic.items()),'Invalid job summary')
    pids=[w['pid'] for w in raw['runtime']]
    core=audit_receipt(raw['core_usage'],pids,policy=WORKER_POLICY)
    require(core['controller']['pid']==plan['controller_pid'],'Wrong controller PID')
    require(summary['core_time_ns']==core['time_ns'],'Invalid total core time')
    require(summary['worker_core_time_ns']==core['worker_time_ns'],'Invalid worker core time')
    require(summary['controller_core_time_ns']==core['observer_time_ns'],'Invalid controller core time')
    require(summary['controller_qos_ticks']==core['controller_qos_ticks'],'Invalid controller QoS')
    memory=summarize_observation(raw['memory_observation'],raw['memory_samples'],pids)
    require(all(summary[k]==v for k,v in memory.items()),'Invalid observation summary')
    anchors=raw['memory_observation']
    require(anchors['queue_end_ns']-anchors['queue_start_ns']==summary['elapsed_ns'],'Invalid wall anchors')
    worker_cpu=sum(b['cpu_ns']-a['cpu_ns'] for a,b in zip(raw['before'],raw['after']))
    require(summary['worker_cpu_ns']==worker_cpu and summary['charged_cpu_ns']==worker_cpu+memory['controller_cpu_ns'],'Invalid charged CPU')
    if not memory['observation_coverage_passed']:
        coverage_flags.append(dict(round=row['round'],label=row['label'],metric='observation_coverage',
            max_gap_ns=memory['max_observation_gap_ns'],max_scan_ns=memory['max_observation_scan_ns']))
    workers+=len(pids);total_jobs+=len(raw['jobs']);controller_p+=core['observer_time_ns']['user_p']
    max_gap=max(max_gap,memory['max_observation_gap_ns']);max_scan=max(max_scan,memory['max_observation_scan_ns'])
full_checks=0
for phase in ['preflight','postflight']:
    values=load(panel/phase/'checks.json')
    wanted={(name,c['input'],c['workflow']) for name in plan['conditions'] for c in plan['cases']}
    require(len(values)==24 and {(v['label'],v['input'],v['workflow']) for v in values}==wanted,'Incomplete output checks')
    for v in values:require(v['check']==expected[v['input']+'/'+v['workflow']],'Invalid full output')
    full_checks+=len(values)
metrics=['charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes']
medians={label:{k:statistics.median(r['summary'][k] for r in rows if r['label']==label) for k in metrics}
    for label in plan['orders'][0]}
flags=control_flags(medians,limits,{label:4 for label in medians})+coverage_flags
saved=load(panel/'audit.json')
require(saved['flags']==flags and saved['controls_passed']==(not flags),'Saved controls differ from replay')
require(saved['performance_qualified'] is False,'Smoke cannot qualify performance')
print(json.dumps(dict(checks=checks,queues=len(rows),jobs=total_jobs,worker_intervals=workers,
    controller_intervals=len(rows),full_output_checks=full_checks,coverage_failures=len(coverage_flags),
    max_gap_ms=max_gap/1e6,max_scan_ms=max_scan/1e6,controller_p_user_ms=controller_p/1e6,
    controls_passed=not flags,performance_qualified=False,flags=flags),indent=2))
