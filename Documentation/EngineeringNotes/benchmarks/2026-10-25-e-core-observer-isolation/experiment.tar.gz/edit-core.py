from pathlib import Path
root=Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source/Benchmarks/CPUThroughput')
p=root/'core_usage.py';s=p.read_text()
s=s.replace("POLICY = 'e-core-application-v1'", "POLICY = 'e-core-application-v1'\nWORKER_POLICY = 'e-core-workers-observer-v2'\nPOLICIES = (POLICY, WORKER_POLICY)")
s=s.replace("value['policy'] != POLICY", "value['policy'] not in POLICIES")
s=s.replace('def build(directory):\n    directory.mkdir()', "def build(directory, policy=POLICY):\n    if policy not in POLICIES:\n        raise ValueError('Unknown core policy')\n    directory.mkdir()")
s=s.replace('policy=POLICY,library=', 'policy=policy,library=')
s=s.replace("self.lib = ctypes.CDLL", "self.launch_prefix = ('/usr/sbin/taskpolicy','-c','background') if self.policy['policy']==WORKER_POLICY else ()\n        self.lib = ctypes.CDLL")
s=s.replace('self.lib.running_threads.argtypes', "self.lib.read_memory_usage.argtypes = [ctypes.c_int,ctypes.POINTER(ctypes.c_uint64)]\n        self.lib.read_memory_usage.restype = ctypes.c_int\n        self.lib.running_threads.argtypes")
s=s.replace('    def snapshot(self, pid):', "    def memory(self, pid):\n        data = (ctypes.c_uint64*2)()\n        if self.lib.read_memory_usage(pid,data):\n            raise OSError(ctypes.get_errno(),'Cannot read worker memory for '+str(pid))\n        return dict(pid=pid,rss_bytes=int(data[0]),physical_footprint_bytes=int(data[1]))\n\n    def snapshot(self, pid):")
s=s.replace('def interval(before, after):', 'def interval(before, after, require_e_user=True):')
s=s.replace("if counts['p_user_ticks']:", "if require_e_user and counts['p_user_ticks']:")
s=s.replace("ticks = dict(user_e=counts['user_ticks'],", "ticks = dict(user_e=counts['user_ticks']-counts['p_user_ticks'],")
s=s.replace('def audit_receipt(value, worker_pids):\n    worker_pids', "def audit_receipt(value, worker_pids, policy=POLICY):\n    if policy not in POLICIES or value.get('policy',POLICY) != policy:\n        raise ValueError('Core receipt policy differs from the plan')\n    worker_pids")
s=s.replace("controller = interval(value['controller_before'],value['controller_after'])", "controller = interval(value['controller_before'],value['controller_after'],require_e_user=policy==POLICY)")
s=s.replace("return dict(policy=POLICY,workers=workers,controller=controller,", "return dict(policy=policy,workers=workers,controller=controller,\n        worker_time_ns={key:sum(w['time_ns'][key] for w in workers) for key in controller['time_ns']},\n        observer_time_ns=controller['time_ns'],")
p.write_text(s)
p=root/'core_counters.c';s=p.read_text();index=s.index('int running_threads')
s=s[:index]+'''int read_memory_usage(int pid, uint64_t *out) {
    struct proc_taskinfo task;
    int size = proc_pidinfo(pid, PROC_PIDTASKINFO, 0, &task, sizeof(task));
    if (size != (int)sizeof(task)) {
        if (size >= 0) errno = EIO;
        return -1;
    }
    struct rusage_info_v6 r = {0};
    if (proc_pid_rusage(pid, RUSAGE_INFO_V6, (rusage_info_t *)&r)) return -1;
    out[0] = task.pti_resident_size;
    out[1] = r.ri_phys_footprint;
    return 0;
}

'''+s[index:];p.write_text(s)
