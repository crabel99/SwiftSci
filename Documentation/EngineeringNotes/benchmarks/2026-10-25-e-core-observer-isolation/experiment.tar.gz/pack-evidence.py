"""Archive this experiment without the Git checkout, caches, or live hardware captures."""
import hashlib,io,json,tarfile
from pathlib import Path
q=Path(__file__).resolve().parent
out=q/'evidence-package';out.mkdir(exist_ok=True)
excluded={'source','evidence-package','evidence-replay','__pycache__','.DS_Store'}
files=[]
for p in q.rglob('*'):
 rel=p.relative_to(q)
 if (not p.is_file() or p.is_symlink() or any(part in excluded for part in rel.parts)
     or rel.parts[0].startswith(('frequency-capture.','evidence-replay'))):continue
 files.append(p)
files.sort()
manifest={str(p.relative_to(q)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'experiment.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  info=tar.gettarinfo(str(p),arcname=str(p.relative_to(q)))
  info.uid=info.gid=0;info.uname=info.gname=''
  with p.open('rb') as stream:tar.addfile(info,stream)
 data=(out/'manifest.json').read_bytes();info=tarfile.TarInfo('manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'archive-summary.json').write_text(json.dumps(dict(files=len(files),bytes=archive.stat().st_size,
 sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2)+'\n')
print((out/'archive-summary.json').read_text())
