from pathlib import Path
import csv,collections,json
R=Path(__file__).resolve().parent
files=[R/'235/household_power_consumption.txt',*sorted((R/'501').rglob('PRSA_Data_*.csv'))]
for p in files:
 with p.open(newline='') as f:
  r=csv.reader(f,delimiter=';' if p.suffix=='.txt' else ',');header=next(r);first=next(r)
 print(p.name,header,first)
 print('quotes',p.read_bytes().count(b'"'))
