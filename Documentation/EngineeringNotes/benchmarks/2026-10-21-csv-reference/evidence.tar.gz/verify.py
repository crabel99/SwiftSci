from pathlib import Path
import json,hashlib,statistics as s,subprocess
R=Path(__file__).resolve().parent;B=Path('/private/tmp/swiftsci-csv-borrow-20261021');D=R/'measurement'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((D/'plan.json').read_text());records=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()];cases={c['id']:c for c in json.loads((R/'cases.json').read_text())};variants=['baseline','packed','scoped']
assert plan['power_start']['source']==json.loads((D/'power-end.json').read_text())['source']=='AC'
expected={(c['input']['id'],c['mode'],phase,n,v) for c in plan['cases'] for phase,rounds in [('timing',6),('memory',3)] for n in range(rounds) for v in variants}
assert len(records)==len(expected)==378
assert {(r['input'],r['mode'],r['phase'],r['round'],r['variant']) for r in records}==expected
for c in cases.values():assert h(Path(c['path']))==c['sha256']
for v in variants:
 b=json.loads((R/'build'/v/'build.json').read_text());assert b==plan['builds'][v]
 assert h(R/'build'/v/'ReferenceProbe')==b['binary_sha256'] and h(R/'ReferenceProbe.swift')==b['probe_sha256']
 assert h(B/'build'/v/'SwiftDataFrame.o')==b['module_object_sha256']==json.loads((B/'codegen.json').read_text())[v]['object_sha256']
 assert b['prior_module_build']==json.loads((B/'build'/v/'build.json').read_text())
 prior=b['prior_module_build']
 for name,digest in prior['sources'].items():assert h(Path(prior['variant']['path'])/name)==digest
 for name,digest in prior['dependency_objects'].items():assert h(Path('/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/Release')/(name+'.o'))==digest
for r in records:
 assert r['validated'] and r['checks']['passed']
 assert len(r['samples'])==(3 if r['phase']=='timing' else 1)
 c=cases[r['input']]
 for j,column in enumerate(r['checks']['columns']):
  assert column['name']==c['names'][j] and column['nulls']==c['null_counts'][j] and column['sha256']==c['hashes'][j]
 for x in r['samples']:
  assert x['total_ns']==x['call_ns']+x['release_ns'] and x['total_cpu_ns']==x['call_cpu_ns']+x['release_cpu_ns']
  assert x['total_ns']>0 and x['total_cpu_ns']>0
summary=json.loads((D/'summary.json').read_text());assert summary['records_sha256']==h(D/'workers.jsonl')
for row in summary['rows']:
 for comparison,metrics in row['comparisons'].items():
  a,b=comparison.split('-to-')
  for key,value in metrics.items():
   ratios=[y/x for x,y in zip(row['variants'][a][key],row['variants'][b][key])]
   assert value==dict(median_ratio=s.median(ratios),range=[min(ratios),max(ratios)],ratios=ratios)
audit=[json.loads(l) for l in (R/'audit.jsonl').read_text().splitlines()];assert len(audit)==78
failures=[]
for c in cases.values():
 for mode in ['known','infer']:
  group=[a for a in audit if a['input']==c['id'] and a['mode']==mode]
  assert len(group)==3 and all(a['checks']==group[0]['checks'] for a in group)
  if not group[0]['validated']:
   columns=[]
   for j,col in enumerate(group[0]['checks']['columns']):
    if col['sha256']!=c['hashes'][j]:columns.append({'column':col['name'],'inferred_type':col['type'],'added_nulls':col['nulls']-c['null_counts'][j],'first_fraction':c['first_fraction'][col['name']]})
   failures.append({'input':c['id'],'mode':mode,'identical_in':variants,'columns':columns})
dates=[json.loads(l) for l in (R/'date-audit.jsonl').read_text().splitlines()];assert len(dates)==3 and all(not d['validated'] and d['checks']==dates[0]['checks'] for d in dates)
paths=json.loads((R/'path-checks.json').read_text());assert len(paths)==39
for x in paths:
 for name,digest in x['sources'].items():assert h(Path(name))==digest
 assert x['result']['rows_including_header']==cases[x['case']]['rows']+1
inventory={'air_quality_inference':failures,'total_added_nulls_per_variant':sum(x['added_nulls'] for f in failures for x in f['columns']),'energy_date_prefix':{'rows':25000,'identical_in':variants,'failures':dates[0]['checks']['failures']}}
(R/'failure-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
result={'passed':True,'accepted_workers':len(records),'timing_samples':sum(len(x['samples']) for x in records if x['phase']=='timing'),'memory_samples':sum(len(x['samples']) for x in records if x['phase']=='memory'),'preflight_pass':sum(x['validated'] for x in audit),'preflight_fail':sum(not x['validated'] for x in audit),'date_diagnostics_failed_as_expected':3,'parser_path_checks':39,'additional_nulls_from_inference_per_variant':inventory['total_added_nulls_per_variant'],'probe_sha256':h(R/'ReferenceProbe.swift'),'records_sha256':h(D/'workers.jsonl'),'summary_sha256':h(D/'summary.json')}
(R/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
for row in summary['rows']:
 comp=row['comparisons']['packed-to-scoped'];print(row['input'],row['mode'],'incremental CPU%',round(100*(comp['total_cpu_ns']['median_ratio']-1),2),'range',[round(x,3) for x in comp['total_cpu_ns']['range']])
