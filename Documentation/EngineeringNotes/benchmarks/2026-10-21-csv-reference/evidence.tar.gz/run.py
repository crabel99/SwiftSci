from pathlib import Path
import subprocess,json,sys,hashlib,itertools
R=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/swiftsci-csv-sort-20261017/Benchmarks/Tools')
from runner import power_state,verify_uninstrumented,environment
from execution_policy import worker_environment,PRODUCTION_MODE
variants=['baseline','packed','scoped'];audits=[json.loads(l) for l in (R/'audit.jsonl').read_text().splitlines()]
cases=[]
for c in json.loads((R/'cases.json').read_text()):
 assert hashlib.sha256(Path(c['path']).read_bytes()).hexdigest()==c['sha256']
 for mode in ['known','infer']:
  entries=[a for a in audits if a['input']==c['id'] and a['mode']==mode]
  assert len(entries)==3 and {a['variant'] for a in entries}==set(variants)
  if all(a['validated'] for a in entries):cases.append({'input':c,'mode':mode})
assert len(cases)==14
builds={v:json.loads((R/'build'/v/'build.json').read_text()) for v in variants}
for v in variants:
 verify_uninstrumented(R/'build'/v/'ReferenceProbe')
 assert builds[v]['binary_sha256']==hashlib.sha256((R/'build'/v/'ReferenceProbe').read_bytes()).hexdigest()
 assert builds[v]['probe_sha256']==hashlib.sha256((R/'ReferenceProbe.swift').read_bytes()).hexdigest()
 assert builds[v]['prior_module_build']['dependency_objects']==builds['baseline']['prior_module_build']['dependency_objects']
orders=list(itertools.permutations(variants))
power=power_state();assert power['source']=='AC'
D=R/'measurement';D.mkdir(exist_ok=False)
plan={'cases':cases,'builds':builds,'orders':orders,'timing_rounds':6,'samples_per_worker':3,'warmups_per_timing_worker':2,'memory_rounds':3,'validation':'SHA256 of all output fields after every read, numeric IEEE754 bits, exact string bytes, null tags; validation excluded from measured time. Only passing case/mode across all three variants admitted.','power_start':power,'environment':environment(),'worker_environment':worker_environment(PRODUCTION_MODE)}
# Store only experiment controls, not unrelated shell environment or credentials.
plan['worker_environment']={k:v for k,v in plan['worker_environment'].items() if k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','POLARS_MAX_THREADS','MKL_NUM_THREADS','TZ']}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (D/'workers.jsonl').open('x') as f:
 for ci,case in enumerate(cases):
  c=case['input'];mode=case['mode']
  for phase,n in [('timing',6),('memory',3)]:
   for rnd in range(n):
    order=orders[(ci+rnd)%6] if phase=='timing' else variants[rnd:]+variants[:rnd]
    for position,v in enumerate(order):
     cmd=[str(R/'build'/v/'ReferenceProbe'),str(R/'inputs'/(c['id']+'.json')),mode,phase,'3']
     p=subprocess.run(cmd,env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=120)
     assert p.returncode==0,p.stderr
     r=json.loads(p.stdout);assert r['validated'] and len(r['samples'])==(3 if phase=='timing' else 1)
     f.write(json.dumps(dict(variant=v,round=rnd,position=position,**r))+'\n');f.flush()
  print(ci+1,len(cases),c['id'],mode,flush=True)
power=power_state();assert power['source']=='AC';(D/'power-end.json').write_text(json.dumps(power,indent=2)+'\n')
