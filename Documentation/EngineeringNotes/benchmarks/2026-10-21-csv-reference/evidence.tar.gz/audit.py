from pathlib import Path
import subprocess,json,time,sys
R=Path(__file__).resolve().parent
cases=json.loads((R/'cases.json').read_text());D=R/'inputs';D.mkdir(exist_ok=True)
for c in cases:(D/(c['id']+'.json')).write_text(json.dumps(c,indent=2)+'\n')
sys.path.insert(0,'/private/tmp/swiftsci-csv-sort-20261017/Benchmarks/Tools')
from execution_policy import worker_environment,PRODUCTION_MODE
with (R/'audit.jsonl').open('x') as f:
 for c in cases:
  for mode in ['known','infer']:
   for variant in ['baseline','packed','scoped']:
    t=time.time();p=subprocess.run([str(R/'build'/variant/'ReferenceProbe'),str(D/(c['id']+'.json')),mode,'audit','1'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=240)
    assert p.returncode==0,(variant,c['id'],p.stderr)
    r=json.loads(p.stdout);r.update(variant=variant,seconds=time.time()-t)
    f.write(json.dumps(r)+'\n');f.flush()
    print(c['id'],mode,variant,r['validated'],r['checks']['failures'],round(r['seconds'],2),flush=True)
