import Foundation
import SwiftDataFrame
let f=ISO8601DateFormatter();f.timeZone=TimeZone(secondsFromGMT:0)
for source in ["16/12/2006","1/2/2007","2/1/2007"] {
 print(source,Date.parse(from:source).map { f.string(from:$0) } ?? "nil")
}
