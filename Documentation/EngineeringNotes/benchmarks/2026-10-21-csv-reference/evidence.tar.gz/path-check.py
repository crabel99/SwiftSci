from pathlib import Path
import subprocess,json,hashlib
R=Path(__file__).resolve().parent;B=Path('/private/tmp/swiftsci-csv-borrow-20261021');receipts=[]
for v in ['baseline','packed','scoped']:
 sources=[B/v/'Sources/SwiftDataFrame/IO'/name for name in ['CSVRecordIndex.swift','SystemsCSVParser.swift']]
 cmd=['xcrun','swiftc','-O','-whole-module-optimization','-parse-as-library','-swift-version','6',*[str(s) for s in sources],str(R/'PathProbe.swift'),'-o',str(R/'build'/v/'PathProbe')]
 subprocess.run(cmd,check=True)
 for c in json.loads((R/'cases.json').read_text()):
  p=subprocess.run([str(R/'build'/v/'PathProbe'),c['path'],str(ord(c['delimiter']))],capture_output=True,text=True,check=True)
  result=json.loads(p.stdout);assert result['rows_including_header']==c['rows']+1
  expected='flat' if v=='baseline' or c['id']=='energy' else 'compact'
  assert result['storage']==expected,result
  receipts.append({'variant':v,'case':c['id'],'command':cmd,'sources':{str(s):hashlib.sha256(s.read_bytes()).hexdigest() for s in sources},'result':result})
(R/'path-checks.json').write_text(json.dumps(receipts,indent=2)+'\n');print('39 parser path checks passed')
