from pathlib import Path
import urllib.request,zipfile,hashlib,json,datetime
R=Path(__file__).resolve().parent
items=[]
for id,name in [(235,'individual%2Bhousehold%2Belectric%2Bpower%2Bconsumption'),(501,'beijing%2Bmulti%2Bsite%2Bair%2Bquality%2Bdata')]:
 url=f'https://archive.ics.uci.edu/static/public/{id}/{name}.zip'
 target=R/f'uci-{id}.zip'
 if not target.exists(): urllib.request.urlretrieve(url,target)
 dest=R/str(id);dest.mkdir(exist_ok=True)
 with zipfile.ZipFile(target) as z:
  for member in z.infolist():
   p=dest/member.filename
   assert p.resolve().is_relative_to(dest.resolve())
  z.extractall(dest)
 for inner in list(dest.rglob('*.zip')):
  with zipfile.ZipFile(inner) as z:
   for member in z.infolist(): assert (dest/member.filename).resolve().is_relative_to(dest.resolve())
   z.extractall(dest)
 files={str(p.relative_to(dest)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in dest.rglob('*') if p.is_file()}
 items.append({'id':id,'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'license':'CC BY 4.0','files':files})
 print(id,[(k,v['bytes']) for k,v in files.items()],flush=True)
(R/'provenance.json').write_text(json.dumps(items,indent=2)+'\n')
