from pathlib import Path
import subprocess,json,time
R=Path(__file__).resolve().parent
with (R/'date-audit.jsonl').open('x') as f:
 for v in ['baseline','packed','scoped']:
  t=time.time();p=subprocess.run([str(R/'build'/v/'ReferenceProbe'),str(R/'energy-date-diagnostic.json'),'infer','audit','1'],capture_output=True,text=True,timeout=180)
  assert p.returncode==0,p.stderr
  r=json.loads(p.stdout);r.update(variant=v,seconds=time.time()-t);f.write(json.dumps(r)+'\n');f.flush()
  print(v,r['validated'],r['checks']['failures'],round(r['seconds'],2),flush=True)
