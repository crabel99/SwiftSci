from pathlib import Path
import json,hashlib,tarfile,shutil
R=Path(__file__).resolve().parent;B=Path('/private/tmp/swiftsci-csv-borrow-20261021')
D=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-21-csv-reference')
D.mkdir(exist_ok=False)
for name in ['packed.patch','scoped.patch']:shutil.copy2(B/name,R/name)
text=(R/'README.md').read_text().replace('–',' to ')
(R/'README.md').write_text(text)
files=[*R.glob('*.py'),*R.glob('*.swift'),*R.glob('*.json'),*R.glob('*.jsonl'),*R.glob('*.patch'),*R.glob('build/*/build.json'),*R.glob('build/*/build.log'),*R.glob('measurement/*.json'),*R.glob('measurement/*.jsonl'),*R.glob('inputs/*.json')]
files=sorted(set(files));manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(D/'evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(R)))
with tarfile.open(D/'evidence.tar.gz','r:gz') as tar:
 assert set(tar.getnames())==set(manifest)
 for name,digest in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
shutil.copy2(R/'README.md',D/'README.md');shutil.copy2(R/'verification.json',D/'verification.json')
(D/'evidence-sha256.json').write_text(json.dumps({'archive_sha256':hashlib.sha256((D/'evidence.tar.gz').read_bytes()).hexdigest(),'files':manifest},indent=2)+'\n')
print(len(files),'verified archive members;', (D/'evidence.tar.gz').stat().st_size,'bytes')
p=D.parent/'2026-10-21-csv-borrow/CLOSEOUT.md'
s=p.read_text();assert 'Current status: planned and required. Actual reference files have not been downloaded or timed in this experiment.' in s
s=s.replace('Current status: planned and required. Actual reference files have not been downloaded or timed in this experiment.','Status on 2026-10-21: the [original reference-file comparison](../2026-10-21-csv-reference/README.md) completed this gate for the stated schemas. All twelve air-quality files improve CPU time and peak memory; the unquoted energy file is effectively neutral. Automatic inference remains unqualified because both pre-existing inference defects reproduce in all three variants. Production integration and separate inference repairs remain outstanding.')
p.write_text(s)
