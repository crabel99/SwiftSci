from pathlib import Path
import json,statistics as s,hashlib
R=Path(__file__).resolve().parent;D=R/'measurement';plan=json.loads((D/'plan.json').read_text());records=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()]
variants=['baseline','packed','scoped'];out=[]
for c in plan['cases']:
 id=c['input']['id'];mode=c['mode'];groups={v:{phase:sorted([r for r in records if r['input']==id and r['mode']==mode and r['variant']==v and r['phase']==phase],key=lambda r:r['round']) for phase in ['timing','memory']} for v in variants}
 row={'input':id,'mode':mode,'variants':{},'comparisons':{}}
 for v,g in groups.items():
  row['variants'][v]={key:[s.median(x[key] for x in r['samples']) for r in g['timing']] for key in ['total_cpu_ns','total_ns']}
  for key in ['process_peak_held_bytes','held_heap_delta_bytes','heap_after_release_bytes','heap_before_bytes']:
   row['variants'][v][key]=[r['samples'][0][key] for r in g['memory']]
 for base,candidate in [('baseline','packed'),('baseline','scoped'),('packed','scoped')]:
  row['comparisons'][base+'-to-'+candidate]={}
  for key in ['total_cpu_ns','total_ns']:
   ratios=[b/a for a,b in zip(row['variants'][base][key],row['variants'][candidate][key])]
   row['comparisons'][base+'-to-'+candidate][key]={'median_ratio':s.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
 out.append(row)
 a=row['variants']['baseline'];b=row['variants']['scoped'];comp=row['comparisons']['baseline-to-scoped']
 print(id,mode,'CPUms',*[round(s.median(row['variants'][v]['total_cpu_ns'])/1e6,2) for v in variants],'cpu%',round((comp['total_cpu_ns']['median_ratio']-1)*100,1),'range',[round(x,3) for x in comp['total_cpu_ns']['range']],'wall%',round((comp['total_ns']['median_ratio']-1)*100,1),'peakMiB',round(s.median(a['process_peak_held_bytes'])/2**20,2),round(s.median(b['process_peak_held_bytes'])/2**20,2),'heldMiB',round(s.median(a['held_heap_delta_bytes'])/2**20,2),round(s.median(b['held_heap_delta_bytes'])/2**20,2))
(D/'summary.json').write_text(json.dumps({'records_sha256':hashlib.sha256((D/'workers.jsonl').read_bytes()).hexdigest(),'rows':out},indent=2)+'\n')
