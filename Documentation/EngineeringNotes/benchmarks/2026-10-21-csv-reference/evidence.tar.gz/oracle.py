from pathlib import Path
import csv,hashlib,json,struct,collections,datetime
R=Path(__file__).resolve().parent
files=[R/'235/household_power_consumption.txt',*sorted((R/'501').rglob('PRSA_Data_*.csv'))]
cases=[]
for p in files:
 energy=p.suffix=='.txt'; delimiter=';' if energy else ','; nulls=['','?'] if energy else ['','NA']
 with p.open(newline='',encoding='utf-8') as f:
  reader=csv.reader(f,delimiter=delimiter);names=next(reader)
  kinds=['String','String']+['Double']*7 if energy else ['Int64']*5+['Double']*10+['String','Double','String']
  hashes=[hashlib.sha256() for _ in names]; nullcounts=[0]*len(names); integral=[True]*len(names);tokens=collections.Counter(); firstfraction={}
  prefix=[hashlib.sha256() for _ in names]
  for i,row in enumerate(reader):
   assert len(row)==len(names),(p,i,len(row))
   for j,(v,k) in enumerate(zip(row,kinds)):
    if v in nulls: b=b'\0';nullcounts[j]+=1;tokens[v]+=1
    elif k=='String':
     vb=v.encode();b=b'\1'+struct.pack('<I',len(vb))+vb
    else:
     number=float(v)
     if not number.is_integer():
      integral[j]=False;firstfraction.setdefault(names[j],{'row':i,'value':v})
     if k=='Int64':assert number.is_integer()
     b=b'\1'+struct.pack('<d',number)
    hashes[j].update(b)
    if energy and i<25000:
     if j==0:
      d=datetime.datetime.strptime(v,'%d/%m/%Y').replace(tzinfo=datetime.timezone.utc)
      prefix[j].update(b'\1'+struct.pack('<d',d.timestamp()))
     else:prefix[j].update(b)
  rows=i+1
 raw=p.read_bytes();raw.decode('utf-8')
 c={'id':'energy' if energy else p.stem.split('_')[2],'path':str(p),'rows':rows,'names':names,'types':kinds,'hashes':[h.hexdigest() for h in hashes],'null_counts':nullcounts,'integral':integral,'first_fraction':firstfraction,'null_tokens':nulls,'observed_null_tokens':dict(tokens),'delimiter':delimiter,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'quote_bytes':raw.count(b'"'),'crlf':raw.count(b'\r\n'),'lf':raw.count(b'\n'),'encoding':'UTF-8, ASCII subset' if raw.isascii() else 'UTF-8','expected_index_path':'flat-unquoted' if b'"' not in raw else 'fallback-compact-in-candidates'}
 if energy:
  c['inference_timestamp_policy']='Date and Time explicitly UTF-8; numeric columns inferred'
  diagnostic={**c,'id':'energy-date-inference-prefix','rows':25000,'types':['Date',*kinds[1:]],'hashes':[h.hexdigest() for h in prefix],'max_rows':25000}
  (R/'energy-date-diagnostic.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
 cases.append(c);print(c['id'],rows,c['observed_null_tokens'],c['first_fraction'],flush=True)
(R/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
