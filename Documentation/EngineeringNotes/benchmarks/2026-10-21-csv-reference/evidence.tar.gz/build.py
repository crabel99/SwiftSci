from pathlib import Path
import json,hashlib,subprocess
R=Path(__file__).resolve().parent;B=Path('/private/tmp/swiftsci-csv-borrow-20261021')
for v in ['baseline','packed','scoped']:
 d=R/'build'/v;d.mkdir(parents=True,exist_ok=True)
 prior=json.loads((B/'build'/v/'build.json').read_text())
 for path,digest in prior['sources'].items():assert hashlib.sha256((Path(prior['variant']['path'])/path).read_bytes()).hexdigest()==digest
 cmd=prior['commands'][1]
 cmd=[str(R/'ReferenceProbe.swift') if p==str(B/'ResourceProbe.swift') else str(d/'ReferenceProbe') if p==str(B/'build'/v/'ResourceProbe') else p for p in cmd]
 with (d/'build.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode: print((d/'build.log').read_text());raise SystemExit(p.returncode)
 receipt={'prior_module_build':prior,'command':cmd,'probe_sha256':hashlib.sha256((R/'ReferenceProbe.swift').read_bytes()).hexdigest(),'module_object_sha256':hashlib.sha256((B/'build'/v/'SwiftDataFrame.o').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((d/'ReferenceProbe').read_bytes()).hexdigest()}
 (d/'build.json').write_text(json.dumps(receipt,indent=2)+'\n');print(v,flush=True)
