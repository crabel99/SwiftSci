import Foundation
@main struct PathProbe {
 static func main() throws {
  let path=CommandLine.arguments[1], delim=UInt8(CommandLine.arguments[2])!
  let data=try Data(contentsOf:URL(fileURLWithPath:path),options:.alwaysMapped)
  try data.withUnsafeBytes { raw in
   let records=SystemsCSVParser(delimiterByte:delim).parseIndex(buffer:raw.bindMemory(to:UInt8.self))
   let fields=Mirror(reflecting:records).children.first { $0.label=="fields" }!.value
   let mirror=Mirror(reflecting:fields)
   let label=mirror.displayStyle == .enum ? mirror.children.first!.label! : "flat"
   let result:[String:Any] = ["file":path,"rows_including_header":records.count,"storage":label]
   print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:.sortedKeys),as:UTF8.self))
  }
 }
}
