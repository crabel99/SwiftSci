from pathlib import Path
import hashlib,json,statistics,subprocess,tarfile,re,shutil
S=Path('/private/tmp/swiftsci-mixed-throughput-20261024')
R=Path('/private/tmp/swiftsci-cpu-budget-panel-20261024')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-24-budgeted-cpu-throughput'
plan=json.loads((R/'plan.json').read_text());records=json.loads((R/'records.json').read_text());audit=json.loads((R/'audit.json').read_text())
assert audit['batches']==96 and audit['completed_jobs']==12288
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected in plan['controller_sha256'].items():assert sha(R/('measured-'+name))==expected
source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
summary=[];paired=[]
for b in plan['budgets_bytes']:
 for storage in ['optional','compact']:
  g=[x['summary'] for x in records if x['budget_bytes']==b and x['storage']==storage]
  keys=['completed_per_minute','charged_cpu_ns','sampled_peak_rss_bytes','retained_rss_bytes','sampled_resident_byte_seconds']
  summary.append(dict(budget_bytes=b,storage=storage,callers=plan['admissions'][str(b)][storage]['callers'],
    samples=len(g),cpu_ms_per_job=statistics.median(x['charged_cpu_ns']/128/1e6 for x in g),
    **{k:statistics.median(x[k] for x in g) for k in keys},
    responses={case:statistics.median(x['per_case'][case]['p95_response_ns']/1e6 for x in g) for case in g[0]['per_case']}))
 for i in range(8):
  row=dict(budget_bytes=b,round=i)
  for metric in ['completed_per_minute','charged_cpu_ns','sampled_peak_rss_bytes']:
   med={s:statistics.median(x['summary'][metric] for x in records if x['budget_bytes']==b and x['round']==i and x['storage']==s) for s in ['optional','compact']}
   row[metric+'_ratio']=med['compact']/med['optional']
  paired.append(row)
bounds=[]
for row in records:
 raw=json.loads((R/row['directory']/'result.json').read_text())
 upper=sum(w['peak_bytes'] for w in raw['after'])
 bounds.append(dict(directory=row['directory'],budget_bytes=row['budget_bytes'],
     sum_of_kernel_lifetime_peaks_bytes=upper,within_budget=upper<=row['budget_bytes']))
assert all(x['within_budget'] for x in bounds)
D.mkdir(parents=True,exist_ok=False)
(D/'kernel-peak-bounds.json').write_text(json.dumps(dict(all_within_budget=True,queues=bounds),indent=2)+'\n')
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(D/'paired-rounds.json').write_text(json.dumps(paired,indent=2)+'\n')
shutil.copy2(R/'audit.json',D/'audit.json')
end=json.loads((R/'end.json').read_text())
def counts(s):return {k:int(v) for k,v in re.findall(r'"?([A-Za-z ]+)"?:\s+(\d+)\.',s)}
a,b=counts(plan['system_start']['vm_stat']),counts(end['system_end']['vm_stat'])
deltas={k:b[k]-a[k] for k in ['Pageins','Pageouts','Swapins','Swapouts']}
comparisons={}
for budget in plan['budgets_bytes']:
 q={x['storage']:x for x in summary if x['budget_bytes']==budget}
 comparisons[budget]={key:(q['compact'][key]/q['optional'][key]-1)*100 for key in ['completed_per_minute','charged_cpu_ns','sampled_peak_rss_bytes','sampled_resident_byte_seconds']}
mid=comparisons[4*2**30]
lines=['# Fixed-memory queues expose a throughput and CPU tradeoff','',
 f'The experiment extends `codex/dataframe-mixed-throughput`, commit `{source_head}`. Production sources and the existing PR branches remain unchanged. This work is committed locally and has not been pushed.', '',
 f'The full panel completes 96 queues and 12,288 timed jobs. Four separate calibration queues complete another 512 jobs. Each timed queue contains the same 128 jobs. All preflight and postflight native-bit checks match the independent reference. Audit qualification is `{audit["qualified"]}`. [Every quality flag remains in the audit](audit.json).', '',
 '## Lower memory permits an extra caller, with a CPU cost','',
 f'At 4 GiB, the frozen rule admits four optional callers or five compact callers. Compact storage completes {mid["completed_per_minute"]:.1f}% more jobs per minute while using {mid["charged_cpu_ns"]:.1f}% more CPU time per result. Its sampled peak worker RSS is {-mid["sampled_peak_rss_bytes"]:.1f}% lower. This is a capacity and latency tradeoff, not a reduction in every resource.', '',
 '| Worker budget GiB | Storage | Callers | Jobs/min | CPU ms/job | Peak RSS MiB | Retained RSS MiB | Resident MiB-seconds |',
 '| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for x in summary:lines.append(f"| {x['budget_bytes']/2**30:g} | {x['storage']} | {x['callers']} | {x['completed_per_minute']:.1f} | {x['cpu_ms_per_job']:.2f} | {x['sampled_peak_rss_bytes']/2**20:.1f} | {x['retained_rss_bytes']/2**20:.1f} | {x['sampled_resident_byte_seconds']/2**20:.1f} |")
lines += ['', 'Tables pool the primary and identical-binary twin labels and report medians of 16 queues for each storage and budget. Every queue has 32 copies of each dataset and workflow combination. Jobs/min can be compared only with that fixed case mix. Charged CPU includes worker user and system time plus controller CPU during the queue.', '',
 '| Budget GiB | Compact throughput change | CPU/job change | Peak RSS change | Resident byte-seconds change |',
 '| ---: | ---: | ---: | ---: | ---: |']
for budget,x in comparisons.items():lines.append(f"| {budget/2**30:g} | {x['completed_per_minute']:+.1f}% | {x['charged_cpu_ns']:+.1f}% | {x['sampled_peak_rss_bytes']:+.1f}% | {x['sampled_resident_byte_seconds']:+.1f}% |")
lines += ['', 'At eight callers, CPU per job is essentially equal on these longer queues. The earlier 16-job panel showed a 3.6% compact CPU advantage at eight callers. That advantage does not persist here. Memory savings do persist. CPU benefits must therefore remain workload-specific.', '',
 'At 2 GiB and 8 GiB, both modes have the same admitted caller count. Those rows compare storage at matched concurrency. At 4 GiB, storage and allowed concurrency both differ. They test the complete admission policy, and cannot isolate the storage algorithm alone. The eight-caller ceiling also prevents this study from testing additional compact callers at 8 GiB.', '',
 '## Calibration is fixed before timing','',
 'Calibration executes two complete single-caller queues per storage mode, reversing mode order for the second pair. The larger of sampled RSS and the kernel-recorded single-process lifetime peak is retained. The maximum calibration peak receives the same 5% plus 8 MiB allowance in both modes.', '',
 '| Storage | Largest calibration peak MiB | Reservation per caller MiB |',
 '| --- | ---: | ---: |']
for s in ['optional','compact']:
 peak=max(plan['calibration']['observed_peaks'][s]);reservation=plan['admissions'][str(2*2**30)][s]['reservation_bytes']
 lines.append(f'| {s} | {peak/2**20:.1f} | {reservation/2**20:.1f} |')
lines += ['', 'The rule divides a declared budget by this reservation, rounds down, and admits at most eight callers. It is an experimental model for this known queue, not a production memory estimator or a guaranteed allocation bound. Calibration cost is outside timed queues and remains in separate raw receipts. No admission value is retuned using timed results.', '',
 'Each worker retains its native internal parallelism. Caller creation and readiness finish before timing. The first public operation in each fresh worker is inside timing. Input preparation inside the public API, sorting, matrix allocation, and output release are included. Full-output hashing is outside timing.', '',
 '## Response times include the entire queue','',
 'All 128 jobs enter together. Response includes waiting for a caller, execution, release, and receipt. The following values are medians of per-queue p95 response times. These are longer finite bursts, not a steady arrival stream or a service-level guarantee.', '',
 '| Budget GiB | Storage | Air read p95 ms | Air sort-matrix p95 ms | Energy read p95 ms | Energy sort-matrix p95 ms |',
 '| ---: | --- | ---: | ---: | ---: | ---: |']
for x in summary:
 lines.append(f"| {x['budget_bytes']/2**30:g} | {x['storage']} | "+' | '.join(f"{x['responses'][case]:.1f}" for case in ['Aotizhongxin-default/read','Aotizhongxin-default/sort-matrix','energy-common/read','energy-common/sort-matrix'])+' |')
lines += ['', '## Resource boundaries and controls','',
 'A secondary audit conservatively sums the kernel-recorded lifetime RSS peaks for each queue. This sum is an upper bound, not a simultaneous observed peak. Every one of the 96 upper bounds is below its budget. Worst upper bounds are 1,827.2 MiB under 2 GiB, 3,644.3 MiB under 4 GiB, and 7,270.7 MiB under 8 GiB. See [kernel peak bounds](kernel-peak-bounds.json).', '',
 'The declared budget covers aggregate sampled worker RSS. It excludes the controller and does not emulate a machine with only that much physical RAM. RSS can count shared pages more than once. Sampling can miss short-lived peaks. A sampled overrun kills only the benchmark process groups and fails the panel.', '',
 f'The largest sampling gap is {max(x["summary"]["max_sample_gap_ns"] for x in records)/1e6:.1f} ms. The maximum observed queue RSS is {max(x["summary"]["sampled_peak_rss_bytes"] for x in records)/2**20:.1f} MiB. All queues remain within their declared sampled budgets.', '',
 'Retained RSS includes runtimes and allocator caches after output release. Workers terminate after every queue, so their retained state does not carry into the next measurement. This is bounded shutdown testing, not proof of indefinite-time leak freedom.', '',
 f'System-wide counter changes are {json.dumps(deltas,sort_keys=True)}. Swap use starts at `{plan["system_start"]["swap"].strip()}` and ends at `{end["system_end"]["swap"].strip()}`. These counters do not attribute paging to benchmark workers. AC power is checked before each queue and at panel boundaries. Background process snapshots remain in the archive.', '',
 'Eight rotated rounds retain the primary and identical-binary twin labels. Budget order rotates too. The unchanged drift limits are 10% for CPU and elapsed time, and 5% plus 8 MiB per caller for sampled RSS. Passing controls does not make a small difference statistically significant. [Paired round observations](paired-rounds.json) keep consistency and variation visible.', '',
 '## What the result warrants','',
 'Compact storage consistently releases room within this application-level memory budget. Increasing admitted concurrency can use that room to improve completion rate, but can also increase CPU work per result. A resource-economy policy must keep those two decisions separate. This experiment makes no automatic production scheduling or storage-default change.', '',
 'A matched-caller control at four callers would isolate the storage cost at the 4 GiB boundary. Equivalent external-engine queues remain a separate extension. These results do not certify GPU or Neural Engine behavior, global memory-pressure behavior, energy use, or arbitrary scientific workloads.', '',
 '## Validation and evidence','',
 'The same uninstrumented Release worker and independent reference fingerprints are reused from the [earlier fixed-caller study](../2026-10-24-mixed-cpu-throughput/README.md). All timed outputs receive shape and type checks. Full column and matrix bit hashes pass before and after the panel, but not on every timed job.', '',
 'All 239 controller tests pass with the established Metal opt-in and no skips. A deliberately tiny 64 MiB sampled guard stops its workers after observing 205.8 MiB and retains the failure trace. That overshoot demonstrates why polling is not a hard allocation cap. No orphan benchmark workers remain.', '',
 'Controller tests cover identical admission rules, worst-case calibration, caller caps, incomplete full-output checks, changed admissions, and mismatched raw receipts. The shared-quality refactor reproduces the earlier panel audit exactly. Full test and failure-cleanup receipts are archived separately.', '',
 '[Summary](summary.json), [full audit](audit.json), [paired rounds](paired-rounds.json), [artifact hashes](artifact-sha256.json), and the [experiment archive](experiment.tar.gz) preserve the evidence. The archive includes all raw queues and calibrations, exact measured controllers, protocol snapshots, full-output checks, system counters, input contracts, and source code. It excludes CSV bytes, executables, compiled objects, and caches.', '',
 'Rebuild the worker with `build.py`, then run `budget.py` using the recorded reference plan, independent expected fingerprints, and a new output directory. Audit with `budget.py --audit`. The source README defines the parameters and measurement boundaries. Absolute input and dependency paths are local and must be present or remapped.']
(D/'README.md').write_text('\n'.join(lines)+'\n')
subprocess.run(['git','bundle','create','/private/tmp/swiftsci-cpu-budget-delivery-20261024/source.bundle','d205cb71c07bb5a94772393571371632cdd00e9e..HEAD'],cwd=S,check=True)
with tarfile.open(D/'experiment.tar.gz','w:gz') as tar:
 for root,prefix in [(R,'panel'),(Path('/private/tmp/swiftsci-cpu-budget-smoke-20261024'),'smoke')]:
  for f in root.rglob('*'):
   if f.is_file():tar.add(f,arcname=prefix+'/'+str(f.relative_to(root)))
 for f in (S/'Benchmarks/CPUThroughput').iterdir():
  if f.is_file():tar.add(f,arcname='source/'+f.name)
 tar.add(S/'Benchmarks/Tests/test_cpu_budget.py',arcname='source/test_cpu_budget.py')
 tar.add(S/'Benchmarks/Tests/test_cpu_throughput.py',arcname='source/test_cpu_throughput.py')
 for path,name in [('/private/tmp/swiftsci-cpu-throughput-panel-20261024/plan.json','reference/plan.json'),('/private/tmp/swiftsci-cpu-throughput-final-build-20261024/build.json','reference/build.json')]:tar.add(path,arcname=name)
 for f in Path('/private/tmp/swiftsci-cpu-budget-delivery-20261024').rglob('*'):
  if f.is_file():tar.add(f,arcname='delivery/'+str(f.relative_to('/private/tmp/swiftsci-cpu-budget-delivery-20261024')))
(D/'artifact-sha256.json').write_text(json.dumps({p.name:sha(p) for p in sorted(D.iterdir()) if p.is_file()},indent=2)+'\n')
print(D)
