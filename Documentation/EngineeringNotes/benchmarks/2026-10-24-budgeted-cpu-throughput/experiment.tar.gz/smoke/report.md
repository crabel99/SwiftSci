# Fixed-memory mixed CPU queues

Caller counts follow a frozen calibration model. The same queue runs under each worker-RSS budget. Actual sampled residency is checked throughout each queue. Process startup, calibration, and full-hash validation are outside timing. These are longer finite bursts, not a constant-rate request service.

| Budget GiB | Storage | Callers | Jobs/min | CPU ms/job | Peak RSS MiB | Resident MiB-seconds |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 2 | optional | 2 | 1016.9 | 187.96 | 1213.4 | 435.5 |
| 2 | compact | 2 | 1009.2 | 183.68 | 852.9 | 308.7 |
| 4 | optional | 4 | 1667.1 | 212.64 | 2133.4 | 388.3 |
| 4 | compact | 5 | 1650.6 | 207.44 | 1445.6 | 287.5 |

Audit qualified: True. See audit.json for every retained control failure.

The budget covers sampled worker RSS. It excludes controller RSS and is not an OS-enforced physical-memory cap. Sampling can miss short peaks; shared pages may be counted repeatedly. Worker native parallelism is unchanged. CPU and response costs must be considered beside any throughput gain.
