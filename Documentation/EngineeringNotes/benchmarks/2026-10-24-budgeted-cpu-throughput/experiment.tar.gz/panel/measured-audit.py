#!/usr/bin/env python3
"""Check completeness and identical-binary drift without changing recorded limits."""
import argparse
import json
from pathlib import Path
import statistics


def control_flags(medians, limits, callers):
    flags = []
    for label in ('optional', 'compact'):
        left, right = medians[label], medians[label+'_twin']
        for metric, limit in (('charged_cpu_ns', limits['twin_cpu_deviation']),
                              ('elapsed_ns', limits['twin_wall_deviation'])):
            ratio = right[metric]/left[metric]
            if abs(ratio-1) > limit:
                flags.append(dict(label=label, metric=metric, ratio=ratio))
        low, high = sorted((left['sampled_peak_rss_bytes'],right['sampled_peak_rss_bytes']))
        if high > low*limits['twin_peak_relative'] + callers[label]*limits['twin_peak_slack_per_caller_bytes']:
            flags.append(dict(label=label, metric='sampled_peak_rss_bytes', low=low, high=high))
    return flags


def audit(root):
    plan = json.loads((root/'plan.json').read_text())
    records = json.loads((root/'records.json').read_text())
    expected = {(i,n,label) for i,order in enumerate(plan['orders'])
                for n in plan['concurrency'] for label in order}
    actual = {(r['round'],r['concurrency'],r['label']) for r in records}
    if len(records) != len(expected) or actual != expected:
        raise ValueError('Incomplete panel')
    if not (root/'end.json').exists() or (root/'failure.json').exists():
        raise ValueError('Panel did not complete')
    expected_jobs = len(plan['cases']) * plan['copies_per_case']
    if any(r['summary']['completed'] != expected_jobs for r in records):
        raise ValueError('Work totals differ')
    limits = plan['quality_policy']
    flags, cases = [], []
    for callers in plan['concurrency']:
        group = [r for r in records if r['concurrency']==callers]
        med = {label: {metric: statistics.median(r['summary'][metric] for r in group if r['label']==label)
                       for metric in ('charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes')}
               for label in plan['orders'][0]}
        local = control_flags(med, limits, {'optional': callers, 'compact': callers})
        cases.append(dict(concurrency=callers, qualified=not local, medians=med))
        flags.extend(dict(concurrency=callers,**f) for f in local)
    return dict(batches=len(records), completed_jobs=expected_jobs*len(records),
                qualified=not flags, quality_flags=flags, cases=cases)

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('results',type=Path)
    a=p.parse_args()
    result=audit(a.results)
    (a.results/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
