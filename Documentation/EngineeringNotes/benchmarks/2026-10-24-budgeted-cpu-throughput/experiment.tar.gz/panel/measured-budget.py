#!/usr/bin/env python3
"""Run identical longer queues under fixed sampled worker-RSS budgets."""
import argparse
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from Benchmarks.CPUThroughput import run as throughput
from Benchmarks.CPUThroughput.audit import control_flags


BUDGETS = [2 * 2**30, 4 * 2**30, 8 * 2**30]
MAX_CALLERS = 8


def admission(peaks, budget_bytes):
    """Freeze a measured caller envelope with the existing RSS-control allowance."""
    reservation = math.ceil(max(peaks) * 1.05) + 8 * 2**20
    return dict(reservation_bytes=reservation, callers=min(MAX_CALLERS, budget_bytes // reservation))


def jobs_for(cases, copies, rotation):
    jobs = [dict(case, id=i*len(cases)+case['id']) for i in range(copies) for case in cases]
    offset = rotation % len(jobs)
    return jobs[offset:]+jobs[:offset]


def validate_inputs(worker, reference, expected_path):
    build = json.loads(worker.with_name('build.json').read_text())
    throughput.verify_uninstrumented(worker)
    if throughput.digest(worker) != build['binary_sha256']:
        raise ValueError('Worker binary differs from its receipt')
    if any(throughput.digest(ROOT/name) != sha for name,sha in build['sources'].items()):
        raise ValueError('Worker source is stale')
    if throughput.digest(expected_path) != reference['expected_sha256']:
        raise ValueError('Independent fingerprints differ from the reference panel')
    for path, contract in reference['contracts'].items():
        if json.loads(Path(path).read_text()) != contract:
            raise ValueError('Input contract changed')
        if throughput.digest(Path(contract['path'])) != contract['sha256']:
            raise ValueError('Input CSV changed')
    return build


def audit(root):
    plan = json.loads((root/'plan.json').read_text())
    records = json.loads((root/'records.json').read_text())
    expected = json.loads((root/'expected.json').read_text())
    if throughput.digest(root/'expected.json') != plan['expected_sha256']:
        raise ValueError('Independent fingerprints changed')
    if not (root/'end.json').exists() or (root/'failure.json').exists():
        raise ValueError('Budget panel did not complete')
    cases = plan['cases']
    check_keys = {(storage,c['input'],c['workflow']) for c in cases for storage in ('optional','compact')}
    for phase in ('preflight','postflight'):
        checks = json.loads((root/phase/'checks.json').read_text())
        if len(checks)!=len(check_keys) or {(x['storage'],x['input'],x['workflow']) for x in checks}!=check_keys:
            raise ValueError('Incomplete full-output validation')
        if any(x['check'] != expected[x['input']+'/'+x['workflow']] for x in checks):
            raise ValueError('Full-output validation failed')
    required = {(i,b,label) for i,order in enumerate(plan['orders']) for b in plan['budgets_bytes'] for label in order}
    actual = {(r['round'],r['budget_bytes'],r['label']) for r in records}
    if len(records)!=len(required) or actual!=required:
        raise ValueError('Incomplete budget panel')
    flags = []
    for record in records:
        slots = plan['admissions'][str(record['budget_bytes'])][record['storage']]['callers']
        if record['concurrency'] != slots:
            raise ValueError('Admission changed after calibration')
        raw = json.loads((root/record['directory']/'result.json').read_text())
        if raw['summary'] != record['summary']:
            raise ValueError('Raw queue receipt differs from the panel record')
        recomputed = throughput.summarize(raw['jobs'],raw['summary']['elapsed_ns'],raw['memory_samples'],
                                         jobs_for(cases,plan['copies_per_case'],record['round']))
        if any(value != raw['summary'][key] for key,value in recomputed.items()):
            raise ValueError('Queue accounting differs from raw observations')
        if raw['summary']['sampled_peak_rss_bytes'] > record['budget_bytes']:
            flags.append(dict(budget_bytes=record['budget_bytes'],label=record['label'],reason='observed RSS exceeded budget'))
    groups = []
    for budget in plan['budgets_bytes']:
        rows = [r for r in records if r['budget_bytes']==budget]
        medians = {label: {metric: statistics.median(r['summary'][metric] for r in rows if r['label']==label)
                          for metric in ('charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes')}
                   for label in plan['orders'][0]}
        counts = {s: plan['admissions'][str(budget)][s]['callers'] for s in ('optional','compact')}
        local = control_flags(medians, plan['quality_policy'], counts)
        flags.extend(dict(budget_bytes=budget,**flag) for flag in local)
        groups.append(dict(budget_bytes=budget,callers=counts,qualified=not local,medians=medians))
    return dict(batches=len(records),completed_jobs=sum(r['summary']['completed'] for r in records),
                qualified=not flags,quality_flags=flags,budgets=groups)


def render(records, result):
    lines = ['# Fixed-memory mixed CPU queues', '',
        'Caller counts follow a frozen calibration model. The same queue runs under each worker-RSS budget. '
        'Actual sampled residency is checked throughout each queue. Process startup, calibration, and full-hash validation '
        'are outside timing. These are longer finite bursts, not a constant-rate request service.', '',
        '| Budget GiB | Storage | Callers | Jobs/min | CPU ms/job | Peak RSS MiB | Resident MiB-seconds |',
        '| ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for b in sorted({x['budget_bytes'] for x in records}):
        for storage in ('optional','compact'):
            group=[r for r in records if r['budget_bytes']==b and r['storage']==storage]
            med=lambda f:statistics.median(f(x['summary']) for x in group)
            lines.append(f"| {b/2**30:g} | {storage} | {group[0]['concurrency']} | "
                f"{med(lambda x:x['completed_per_minute']):.1f} | "
                f"{med(lambda x:x['charged_cpu_ns']/x['completed']/1e6):.2f} | "
                f"{med(lambda x:x['sampled_peak_rss_bytes']/2**20):.1f} | "
                f"{med(lambda x:x['sampled_resident_byte_seconds']/2**20):.1f} |")
    lines += ['',f"Audit qualified: {result['qualified']}. See audit.json for every retained control failure.", '',
        'The budget covers sampled worker RSS. It excludes controller RSS and is not an OS-enforced physical-memory cap. '
        'Sampling can miss short peaks; shared pages may be counted repeatedly. Worker native parallelism is unchanged. '
        'CPU and response costs must be considered beside any throughput gain.']
    return '\n'.join(lines)+'\n'


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--worker',type=Path)
    p.add_argument('--reference-plan',type=Path)
    p.add_argument('--expected',type=Path)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--audit',action='store_true')
    a=p.parse_args()
    if a.audit:
        result=audit(a.output)
        throughput.save(a.output/'audit.json',result)
        print(json.dumps(result,indent=2))
        return
    if not all((a.worker,a.reference_plan,a.expected)):
        p.error('--worker, --reference-plan, and --expected are required for measurements')
    reference=json.loads(a.reference_plan.read_text())
    build=validate_inputs(a.worker,reference,a.expected)
    a.output.mkdir(parents=True,exist_ok=False)
    cases=reference['cases']
    orders=reference['orders'][:2] if a.smoke else reference['orders']
    budgets=BUDGETS[:2] if a.smoke else BUDGETS
    copies=2 if a.smoke else 32
    plan=dict(build=build,reference_plan_sha256=throughput.digest(a.reference_plan),cases=cases,
        contracts=reference['contracts'],orders=orders,budgets_bytes=budgets,copies_per_case=copies,
        expected_sha256=throughput.digest(a.expected),quality_policy=reference['quality_policy'],
        calibration=dict(rounds=2,copies_per_case=copies,headroom_relative=.05,headroom_bytes=8*2**20),
        controller_sha256={p.name:throughput.digest(p) for p in (Path(__file__),Path(throughput.__file__),Path(__file__).with_name('audit.py'))},
        power_start=throughput.power(),system_start=throughput.system_state(),environment=throughput.environment())
    throughput.save(a.output/'protocol.json',plan)
    for name in plan['controller_sha256']:
        (a.output/('measured-'+name)).write_bytes(Path(__file__).with_name(name).read_bytes())
    (a.output/'expected.json').write_bytes(a.expected.read_bytes())
    for phase in ('preflight','postflight'):
        (a.output/phase).mkdir()
    records=[]
    try:
        throughput.preflight(a.worker,cases,json.loads(a.expected.read_text()),a.output/'preflight')
        calibration={'optional':[],'compact':[]}
        for i in range(2):
            for storage in (('optional','compact') if i==0 else ('compact','optional')):
                throughput.power()
                name=f'calibration-{i}-{storage}'
                row=throughput.batch(a.worker,storage,jobs_for(cases,copies,i),1,a.output/name)
                raw=json.loads((a.output/name/'result.json').read_text())
                peak=max(row['sampled_peak_rss_bytes'], max(x['peak_bytes'] for x in raw['after']))
                calibration[storage].append(peak)
                print(f"calibration {i+1}/2 {storage}: {peak/2**20:.1f} MiB",flush=True)
        plan['calibration']['observed_peaks']=calibration
        plan['admissions']={str(b):{s:admission(peaks,b) for s,peaks in calibration.items()} for b in budgets}
        if any(x['callers']==0 for modes in plan['admissions'].values() for x in modes.values()):
            raise RuntimeError('A calibrated caller cannot fit a declared budget')
        throughput.save(a.output/'plan.json',plan)
        print('Frozen admissions:',json.dumps(plan['admissions']),flush=True)
        for i,order in enumerate(orders):
            ordered_budgets=budgets[i%len(budgets):]+budgets[:i%len(budgets)]
            tasks=jobs_for(cases,copies,i)
            for b in ordered_budgets:
                for label in order:
                    storage=label.split('_')[0]
                    callers=plan['admissions'][str(b)][storage]['callers']
                    name=f'r{i}-b{b//2**30}-{label}'
                    throughput.power()
                    row=throughput.batch(a.worker,storage,tasks,callers,a.output/name,rss_limit_bytes=b)
                    records.append(dict(round=i,budget_bytes=b,label=label,storage=storage,concurrency=callers,
                                        directory=name,summary=row))
                    throughput.save(a.output/'records.json',records)
                    print(f"round {i+1}/{len(orders)} budget={b//2**30} GiB {label} callers={callers}: "
                          f"{row['completed_per_minute']:.1f} jobs/min",flush=True)
        throughput.preflight(a.worker,cases,json.loads(a.expected.read_text()),a.output/'postflight')
        if throughput.digest(a.worker)!=build['binary_sha256']:
            raise ValueError('Worker changed during the panel')
        throughput.save(a.output/'end.json',dict(power_end=throughput.power(),system_end=throughput.system_state()))
        result=audit(a.output)
        throughput.save(a.output/'audit.json',result)
        (a.output/'report.md').write_text(render(records,result))
    except BaseException as e:
        throughput.save(a.output/'failure.json',dict(error=str(e),completed_batches=len(records),system=throughput.system_state()))
        raise

if __name__=='__main__':
    main()
