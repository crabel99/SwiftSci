# Fixed-memory mixed CPU queues

Caller counts follow a frozen calibration model. The same queue runs under each worker-RSS budget. Actual sampled residency is checked throughout each queue. Process startup, calibration, and full-hash validation are outside timing. These are longer finite bursts, not a constant-rate request service.

| Budget GiB | Storage | Callers | Jobs/min | CPU ms/job | Peak RSS MiB | Resident MiB-seconds |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 2 | optional | 2 | 1340.5 | 177.04 | 1818.8 | 9326.3 |
| 2 | compact | 2 | 1320.0 | 178.29 | 1319.5 | 6676.2 |
| 4 | optional | 4 | 2411.4 | 187.84 | 3502.6 | 9972.3 |
| 4 | compact | 5 | 2747.9 | 197.29 | 3171.3 | 7659.2 |
| 8 | optional | 8 | 3366.4 | 217.70 | 6978.3 | 13278.5 |
| 8 | compact | 8 | 3352.3 | 217.74 | 5022.4 | 9484.0 |

Audit qualified: True. See audit.json for every retained control failure.

The budget covers sampled worker RSS. It excludes controller RSS and is not an OS-enforced physical-memory cap. Sampling can miss short peaks; shared pages may be counted repeatedly. Worker native parallelism is unchanged. CPU and response costs must be considered beside any throughput gain.
