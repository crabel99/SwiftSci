from pathlib import Path
import ast,gzip,hashlib,json,re,shutil,subprocess,tarfile
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-compact-sorting'
T.mkdir(parents=True,exist_ok=True)
a=json.loads((R/'audit.json').read_text());rows=json.loads((R/'measurement/summary.json').read_text())
selected=[]
for storage in ['optional','compact']:
 for flow in ['sort-indices','sort-matrix','sort-materialize']:
  g={x['engine']:x['medians'] for x in rows if x['case']=='energy-common/serial/'+storage+'/'+flow}
  pair=lambda k,scale:' / '.join(f'{g[label][k]/scale:.2f}' for label in ['prior','current'])
  selected.append(f"| {storage} / {flow} | {pair('total_cpu_ns',1e6)} | {pair('operations_cpu_ns',1e6)} | {pair('held_heap_bytes',2**20)} | {pair('process_peak_held_bytes',2**20)} |")
text=(R/'report-template.md').read_text().format(head=a['current_head'],branch=a['branch'],table='\n'.join(selected),quality=str(a['quality_passed']).lower(),flags=json.dumps(a['quality_flags']))
assert '—' not in text
(T/'README.md').write_text(text)
for name in ['results.md','audit.json','comparator-provenance.json']:shutil.copy2(R/name,T/name)
patch=subprocess.check_output(['git','diff',a['base'],'--binary'],cwd=S)
(R/'changes.patch').write_bytes(patch)
subprocess.run(['git','apply','--reverse','--check','-'],cwd=S,input=patch,check=True)
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as out:out.write(patch)
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==patch
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.jsonl','.txt','.log','.md','.patch'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for folder in ['Sources/SwiftDataFrame','Tests/SwiftDataFrameTests']:
  for p in sorted((S/folder).rglob('*.swift')):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 for label,root,name in [('original','/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata','build.json'),('prior','/private/tmp/swiftsci-csv-compact-filtering-20261023','module-build.json')]:
  tar.add(Path(root)/name,arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',text):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'}
(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(T/k)==v for k,v in manifest.items())
print(T)
print('Verified patch, archive paths, links, script syntax and artifact hashes')
