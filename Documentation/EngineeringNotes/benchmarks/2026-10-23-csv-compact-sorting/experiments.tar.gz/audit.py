from pathlib import Path
from collections import Counter
import hashlib,itertools,json,statistics,subprocess
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
P=Path('/private/tmp/swiftsci-csv-compact-filtering-20261023')
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=S,text=True).strip()
plan=json.loads((R/'measurement/plan.json').read_text())
assert plan==json.loads((R/'preflight/plan.json').read_text())
assert plan['controller_sha256']==h(R/'run-panel.py')
labels=['original','prior','current','twin']
assert Counter(x for order in plan['orders'] for x in order)==Counter({x:8 for x in labels})
for label in labels:
 assert Counter(order.index(label) for order in plan['orders'])==Counter({x:2 for x in range(4)})
assert Counter((a,b) for order in plan['orders'] for a,b in zip(order,order[1:]))==Counter({x:2 for x in itertools.permutations(labels,2)})
for label in labels:
 assert plan['binaries'][label]==h(R/(('current' if label=='twin' else label)+'-workflow'))
clients={label:json.loads((R/(label+'-workflow-build.json')).read_text()) for label in labels[:-1]}
for label,root in [('original',F),('prior',P/'build'),('current',R/'build')]:
 receipt=clients[label]
 assert receipt['verified_module']==str(root/'SwiftDataFrame.swiftmodule')
 assert receipt['source_sha256']==h(R/'WorkflowProbe.swift')
 assert receipt['binary_sha256']==plan['binaries'][label]
 assert ('CSV_STORAGE_CHOICE' in receipt['command'])==(label!='original')
module=json.loads((R/'module-build.json').read_text())
for path,digest in module['sources'].items():assert h(S/path)==digest
assert h(R/'build/SwiftDataFrame.o')==module['object_sha256']
original=json.loads((F/'build.json').read_text())
for path,digest in original['sources'].items():
 assert hashlib.sha256(subprocess.check_output(['git','show','5d1f89a961:'+path],cwd=S)).hexdigest()==digest
prior=json.loads((P/'module-build.json').read_text())
for path,digest in prior['sources'].items():
 assert hashlib.sha256(subprocess.check_output(['git','show','3f850cb4cc:'+path],cwd=S)).hexdigest()==digest
assert git('status','--porcelain')==''
tests={}
for name in ['final-release','final-debug','final-asan']:
 x=json.loads((R/(name+'-summary.json')).read_text())
 assert x['passedTests']==420 and x['totalTestCount']==420 and x['failedTests']==0 and x['skippedTests']==0
 tests[name]={k:x[k] for k in ['result','totalTestCount','passedTests','failedTests','skippedTests']}
 receipt=json.loads((R/(name+'-command.json')).read_text());assert receipt['exit_code']==0
 for path,digest in receipt['source_sha256'].items():assert h(S/path)==digest
before=json.loads((R/'semantics-before-command.json').read_text())
for path,digest in before['source_sha256'].items():
 if path.startswith('Sources/'):
  assert hashlib.sha256(subprocess.check_output(['git','show','3f850cb4cc:'+path],cwd=S)).hexdigest()==digest
assert json.loads((R/'semantics-before-summary.json').read_text())['passedTests']==4
strict=json.loads((R/'strict-inputs.json').read_text());stream=json.loads((R/'stream-checks.json').read_text())['responses']
assert len(strict)==len(stream)==28
assert all(x['validated'] for x in strict+stream)
expected=json.loads((R/'preflight/expectations.json').read_text())
keys=['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']
rows=[json.loads(x) for x in (R/'measurement/workers.jsonl').read_text().splitlines()]
pre=[json.loads(x) for x in (R/'preflight/workers.jsonl').read_text().splitlines()]
assert len(rows)==768 and len(pre)==96
for x in rows+pre:
 assert {k:x[k] for k in keys}==expected[x['case']]
 storage=x['case'].split('/')[2]
 assert x['effective_double_storage']==('optional' if x['engine']=='original' else storage)
for name in ['power.txt','power-end.txt']:assert 'AC Power' in (R/'measurement'/name).read_text()
summary=[];flags=[]
for case in plan['cases']:
 key='/'.join(case.values());group={}
 for label in labels:
  samples=[x for x in rows if x['case']==key and x['engine']==label]
  assert len(samples)==8 and {x['round'] for x in samples}==set(range(8))
  for x in samples:assert x['engine']==plan['orders'][x['round']][x['position']]
  xs=[x['samples'][0] for x in samples]
  med={k:statistics.median(x[k] for x in xs) for k in xs[0]}
  med['peak_above_baseline_bytes']=statistics.median(x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in xs)
  group[label]=med;summary.append(dict(case=key,engine=label,workers=8,medians=med))
 a,b=group['current'],group['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append(dict(case=key,reason='identical-binary CPU',ratio=ratio))
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append(dict(case=key,reason='identical-binary memory'))
assert summary==json.loads((R/'measurement/summary.json').read_text())
assert flags==json.loads((R/'measurement/decision.json').read_text())['quality_flags']
provenance={'original':{'head':'5d1f89a961106104757f2d8d0b8faba79487d100','module_receipt_sha256':h(F/'build.json'),'object_sha256':h(F/'SwiftDataFrame.o'),'module_sha256':h(F/'SwiftDataFrame.swiftmodule')},'prior':{'head':git('rev-parse','3f850cb4cc'),'module_receipt_sha256':h(P/'module-build.json'),'object_sha256':h(P/'build/SwiftDataFrame.o'),'module_sha256':h(P/'build/SwiftDataFrame.swiftmodule')},'current':{'head':git('rev-parse','HEAD'),'module_receipt_sha256':h(R/'module-build.json'),'object_sha256':h(R/'build/SwiftDataFrame.o'),'module_sha256':h(R/'build/SwiftDataFrame.swiftmodule')},'clients':clients}
(R/'comparator-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
audit={'branch':git('branch','--show-current'),'current_head':git('rev-parse','HEAD'),'base':git('rev-parse','3f850cb4cc'),'all_outputs_match':True,'strict_eager_reads':28,'strict_stream_reads':28,'workflow_preflights':96,'measured_processes':768,'case_combinations':24,'replicates_per_label':8,'quality_passed':not flags,'quality_flags':flags,'tests':tests,'before_semantic_tests_passed':4,'production_promotion':False}
diag=json.loads((R/'capacity-diagnostic.json').read_text())
assert diag['accepted_timing'] is False and len(diag['responses'])==18
for label,D in [('prior',P/'build'),('current',R/'build')]:
 receipt=diag['clients'][label]
 assert receipt['verified_module']==str(D/'SwiftDataFrame.swiftmodule')
 assert receipt['binary_sha256']==h(R/(label+'-capacity'))
 assert receipt['source_sha256']==h(R/'CapacityProbe.swift')
for response in diag['responses']:
 assert response['accepted_timing'] is False
 key='energy-common/serial/compact/'+response['workflow']
 assert {k:response['output'][k] for k in keys}==expected[key]
cs=json.loads((R/'capacity-summary.json').read_text())
assert cs['accepted_timing'] is False and len(cs['responses'])==18
for x in cs['responses']:
 raw=next(y for y in diag['responses'] if all(y[k]==x[k] for k in ['workflow','engine','round']))
 assert x['value_capacity_bytes']==sum(c['value_capacity']*8 for c in raw['output']['buffer_capacities'])
 assert x['held_heap_bytes']==raw['output']['samples'][0]['held_heap_bytes']
for i in range(3):
 g={x['engine']:x for x in cs['responses'] if x['workflow']=='sort-matrix' and x['round']==i}
 assert g['prior']['value_capacity_bytes']-g['current']['value_capacity_bytes']==16_596_992
assert any(x['engine']=='prior' and x['workflow']=='sort-materialize' and len(x['oversized_columns'])==1 for x in cs['responses'])
audit.update(capacity_diagnostic_processes=18,memory_gain_allocation_sensitive=True)
(R/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
lines=['# Compact Double sorting resource results','','Eight fresh processes per label. Total CPU includes CSV construction, the requested operation, consumer preparation and release. Operation CPU excludes CSV construction and release. Output validation is outside timing. Original always has optional storage. Prior, current and twin honor the declared storage choice.','','| Case | Total CPU original / prior / current, ms | Operation CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |','|---|---:|---:|---:|---:|']
for case in plan['cases']:
 key='/'.join(case.values());g={x['engine']:x['medians'] for x in summary if x['case']==key}
 trip=lambda k,den:' / '.join(f'{g[label][k]/den:.2f}' for label in labels[:-1])
 lines.append(f"| {key} | {trip('total_cpu_ns',1e6)} | {trip('operations_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
lines+=['','Identical-binary flags: '+json.dumps(flags)+'. Affected comparisons remain unqualified. CPU is user plus system process time. These measurements do not establish energy, FLOP or cache effects.','']
(R/'results.md').write_text('\n'.join(lines))
print(json.dumps(audit,indent=2))
