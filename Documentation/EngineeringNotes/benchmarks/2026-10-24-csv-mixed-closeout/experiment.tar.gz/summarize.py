from pathlib import Path
import hashlib,json,statistics,subprocess
r=Path(__file__).parent;s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
load=lambda p:json.loads(p.read_text())
plan=load(r/'plan.json');panels={};audit={};comparisons={}
for name in plan['comparisons'] + ['confirmation-workflows']:
 panels[name]=load(r/name/'decision.json');audit[name]=load(r/name/'audit.json')
 assert audit[name]['source_and_binary_receipts_match']
 raw=load(r/name/'records.json');paired=[]
 for i in range(8):
  row={label:{metric:statistics.median(x['summary'][metric] for x in raw if x['round']==i and x['label'].removesuffix('_twin')==label) for metric in ['charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes','sampled_resident_byte_seconds']} for label in ['parent_optional','parent_compact','candidate_optional','candidate_compact']}
  paired.append(row)
 pairs={'optional stack':('parent_optional','candidate_optional'),'compact stack':('parent_compact','candidate_compact'),'current compact storage':('candidate_optional','candidate_compact'),'combined choice':('parent_optional','candidate_compact')}
 comparisons[name]={}
 for label,(a,b) in pairs.items():
  ratios={metric:[row[b][metric]/row[a][metric] for row in paired] for metric in paired[0][a]}
  comparisons[name][label]=dict(first=a,second=b,paired_ratios=ratios,paired_medians={k:statistics.median(v) for k,v in ratios.items()},rounds_lower_cpu=sum(v<1 for v in ratios['charged_cpu_ns']))
for name,head in plan['heads'].items():
 receipt=load(r/(name+'-build')/'build.json')
 for path,sha in receipt['sources'].items():
  assert hashlib.sha256((r/'snapshots'/name/path).read_bytes()).hexdigest()==sha
  assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+path],cwd=s)).hexdigest()==sha
native=load(Path('/private/tmp/swiftsci-csv-integer-overflow-20261024/provenance.json'));assert native['source_commit']==plan['heads']['candidate']
counts={mode:load(Path('/private/tmp/swiftsci-csv-integer-overflow-20261024/validation/green/compact-'+mode+'-tests.json')) for mode in ['debug','release']}
assert all(x['exit_code']==0 and x['summary']['failedTests']==x['summary']['skippedTests']==0 for x in counts.values())
result=dict(plan=plan,confirmation_plan=load(r/'confirmation-plan.json'),panels=panels,audits=audit,comparisons=comparisons,reused_native_validation=dict(source_commit=plan['heads']['candidate'],tests={k:{field:v['summary'][field] for field in ['totalTestCount','passedTests','failedTests','skippedTests']} for k,v in counts.items()},new_native_tests_run=False))
provenance=dict(heads=plan['heads'],changed_production_files=plan['changed_sources'],measured_source_files=51,full_source_manifests_match_commits=True,dependency_hashes_match=True,historical_build_receipts_unchanged=True,reused_native_validation=result['reused_native_validation'],controller_source_sha256=load(r/'controller-sources.json'))
(r/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
(r/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
(r/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
lines=['# Retained CSV stack in complete mixed workloads','',f"The local source head is `{plan['heads']['candidate']}` on `codex/csv-integer-overflow`. This experiment compares it directly with the starting checkpoint `{plan['heads']['parent']}`. No production source changed during closeout, and nothing was pushed.",'',
'Five retained commits change four production files: compact validity-word construction, structural scanning, raw-empty numeric fallback, normalized-empty numeric fallback, and signed-integer overflow handling. The endpoint comparison includes all five changes. The rejected digit-pair candidates remain excluded.','',
'## Complete queue results','',
'Every queue contains 128 jobs at four concurrent callers with native internal parallelism. Each panel rotates both builds and both storage modes, with an identical-binary twin for every condition. The second panel reverses every ordering. Its failed elapsed-time control triggers one unchanged reversed-order confirmation, frozen in a separate plan before that run. Each panel completes eight rounds, 64 queues, 8,192 timed jobs, and 32 full-output checks.','',
'| Panel | Storage | Before CPU ms/job | Current CPU ms/job | CPU change | Throughput change | Before peak MiB | Current peak MiB |','| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for name,d in panels.items():
 for storage in ['optional','compact']:
  a=d['medians']['parent_'+storage];b=d['medians']['candidate_'+storage]
  lines.append(f'| {name} | {storage} | {a["charged_cpu_ns"]/128e6:.2f} | {b["charged_cpu_ns"]/128e6:.2f} | {100*(b["charged_cpu_ns"]/a["charged_cpu_ns"]-1):+.2f}% | {100*(b["completed_per_minute"]/a["completed_per_minute"]-1):+.2f}% | {a["sampled_peak_rss_bytes"]/2**20:.1f} | {b["sampled_peak_rss_bytes"]/2**20:.1f} |')
lines+=['','CPU is summed worker user and system time plus measured controller CPU. It is resource consumption per completed job, not FLOPs, energy, or normalized performance-core and efficiency-core work. The table pools each condition with its twin. [Summary](summary.json) and [paired comparisons](comparisons.json) preserve the calculations.','',
'## Paired-round consistency','',
'| Panel | Comparison | Median paired CPU change | Rounds with less CPU | Median paired peak-RSS change |','| --- | --- | ---: | ---: | ---: |']
for name,rows in comparisons.items():
 for label,d in rows.items():
  lines.append(f'| {name} | {label} | {100*(d["paired_medians"]["charged_cpu_ns"]-1):+.2f}% | {d["rounds_lower_cpu"]}/8 | {100*(d["paired_medians"]["sampled_peak_rss_bytes"]-1):+.2f}% |')
lines+=['','The stack comparisons hold storage mode and caller count fixed. Current compact storage compares optional and compact modes on the same current binary. Combined choice compares the starting optional mode with the current compact mode. The compact memory saving predates these five changes and must not be credited to them.','',
'Paired ratios compare conditions within each round before taking medians. They can differ from ratios of pooled medians above. Counts describe the observed runs, not independent statistical samples or confidence intervals. A passing 10% twin control does not establish that every small difference is meaningful.','',
'## Operation CPU by reference case','',
'| Panel | Storage | Input and workflow | Before CPU ms/job | Current CPU ms/job | Change |','| --- | --- | --- | ---: | ---: | ---: |']
for name,d in panels.items():
 for storage in ['optional','compact']:
  a=d['per_case_operation_cpu_ns']['parent_'+storage];b=d['per_case_operation_cpu_ns']['candidate_'+storage]
  for case,value in a.items():lines.append(f'| {name} | {storage} | {case} | {value/1e6:.2f} | {b[case]/1e6:.2f} | {100*(b[case]/value-1):+.2f}% |')
lines+=['','These operation figures exclude controller and request-decoding work. They include the public read, any requested sort and matrix construction, shape checks, memory bookkeeping, and release.','',
'## Correctness and resource controls','',
'The reference inputs contain 35,064 Aotizhongxin air-quality observations and 2,075,259 household-electricity rows. Both endpoints receive identical complete schemas, CSV bytes, null sets, Float64 and Int64 types, stable missing-last sorting, and owned row-major matrix output. Independent expected fingerprints match every native numeric bit, null, column, and matrix before and after timing. Full hashing is outside timing. Timed outputs receive shape and type checks.','',
'All panels retain the unchanged twin controls: 10% CPU and elapsed-time drift, plus 5% and 8 MiB per caller for sampled RSS. The qualification table identifies the original reversed panel as unqualified. Its parent-compact twin elapsed-time ratio is 1.1063, above 1.10. No queue is removed and no threshold changes. The audit recomputes every planned queue and job, CPU accounting, memory summaries, output checks, and binary/source identity. All conservative sums of per-process lifetime peaks stay below the 4 GiB ceiling. Those sums are upper bounds, not simultaneous measured peaks.','',
'Sampled RSS can count shared pages more than once and miss short peaks. Resident byte-seconds and retained RSS remain in the raw records. The declared envelope covers benchmark workers, not all physical memory. Background applications remain active. AC and power-policy checks are recorded before every queue and at panel boundaries.','',
'## Validation already owned by the retained commits','',
'The unchanged current source previously passed 447 Debug and 447 Release dataframe tests with no failures or skips. This closeout reuses those exact-head receipts and does not claim a new native test run. The integer repair also passed its independent 6,796-row corpus in both storage modes. The baseline overflow crash remains a historical failure and is not included in the timed reference queue.','',
'The [integer fix report](../2026-10-24-csv-integer-overflow/README.md) owns those correctness receipts. The [construction report](../2026-10-24-compact-csv-construction/README.md), [scanner report](../2026-10-24-csv-structural-mask/README.md), [raw-empty report](../2026-10-24-csv-empty-numeric-fallback/README.md), and [normalized-empty report](../2026-10-24-csv-normalized-empty/README.md) own their individual trials and limitations. Their historical measurement fingerprints remain unchanged.','',
'The 16 CPU queue controller tests pass during this closeout. The measured controller is unchanged. No full MLX suite, hosted CI, or Codecov result is claimed.','',
'## Reproduction and scope','',
'The [source provenance](provenance.json) matches both named commits across all 51 measured sources. Dependency-object hashes match. Historical build-head fields remain untouched. Source snapshots, immutable build receipts, full plans, contracts, hashes, raw queues, generated summaries, and the independent audit are preserved in the [experiment archive](experiment.tar.gz). Compiled objects, executables, module caches, raw CSVs, and xcresult bundles are excluded.','',
'Rebuild the recorded endpoints with `Benchmarks/CPUThroughput/build.py` and matching dependency hashes. Restore the reference files by their recorded SHA256 identities, then remap local paths in `forward.py`, `reversed.py`, and `confirmation.py`. Run them sequentially in fresh output directories. Run `audit-workflows.py` on each completed panel, then `summarize.py`.','',
'This experiment measures finite bursts of full CSV workflows with repeated fixture reads after preflight. It does not measure cold disk, a sustained arrival process, inference performance, GPU or Neural Engine operation, unique physical memory, or energy. It compares SwiftSci endpoints. Equivalent concurrent queues for external engines remain separate work.']
qualification=['## Panel qualification','',
'| Panel | Qualified | Control flags |','| --- | --- | --- |']
for name,d in panels.items():
 flags='None' if not d['flags'] else '; '.join(f'{flag["label"]}: {flag["metric"]} ratio {flag.get("ratio",0):.4f}' for flag in d['flags'])
 qualification.append(f'| {name} | {d["qualified"]} | {flags} |')
qualification+=['','The original reversed panel remains in every table and in the archive. Its CPU and memory controls pass, but its elapsed control fails. The raw control diagnostic records substantial elapsed variation in several rounds. It does not prove a scheduler, clock, thermal, or cache mechanism. One unchanged confirmation is run under a plan that permits no further attempts. The failed panel remains unqualified.','']
index=lines.index('## Complete queue results');lines[index:index]=qualification
qualified=[name for name,d in panels.items() if d['qualified']]
confirmed=len(qualified)>=2 and all(comparisons[name][storage+' stack']['paired_medians']['charged_cpu_ns']<1 for name in qualified for storage in ['optional','compact'])
result['closeout']=dict(qualified_panels=qualified,unqualified_panels=[name for name,d in panels.items() if not d['qualified']],cpu_direction_confirmed=confirmed)
(r/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
if confirmed:
 optional=[100*(comparisons[name]['optional stack']['paired_medians']['charged_cpu_ns']-1) for name in qualified]
 compact=[100*(comparisons[name]['compact stack']['paired_medians']['charged_cpu_ns']-1) for name in qualified]
 conclusion=f'Two qualified panels measure {min(abs(x) for x in optional):.1f} to {max(abs(x) for x in optional):.1f}% less paired-round CPU with optional storage and {min(abs(x) for x in compact):.1f} to {max(abs(x) for x in compact):.1f}% less with compact storage. Current code uses less CPU in {sum(comparisons[name]["compact stack"]["rounds_lower_cpu"] for name in qualified)} of {8*len(qualified)} qualified compact comparisons. The original reversed panel fails its elapsed-time control and is excluded from this qualifying result.'
else:
 conclusion='The available qualified panels do not confirm the CPU direction. Closeout remains pending; all failed controls stay in the record.'
lines[4:4]=[conclusion,'']
stack=['## Retained source commits','', '| Commit | Change |','| --- | --- |']
for commit in load(r/'stack-commits.json'):
 stack.append(f'| `{commit["commit"][:10]}` | {commit["subject"]} |')
stack+=['','The complete source diff contains four production files and three small test files. No benchmark or production source changes are added during this closeout.','']
index=lines.index('## Panel qualification');lines[index:index]=stack
extra=['## Current storage choices at matched callers','',
'| Panel | Current storage | Jobs/min | CPU ms/job | Peak MiB | Retained MiB | Resident MiB-seconds |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for name,d in panels.items():
 for storage in ['optional','compact']:
  m=d['medians']['candidate_'+storage]
  extra.append(f'| {name} | {storage} | {m["completed_per_minute"]:.1f} | {m["charged_cpu_ns"]/128e6:.2f} | {m["sampled_peak_rss_bytes"]/2**20:.1f} | {m["retained_rss_bytes"]/2**20:.1f} | {m["sampled_resident_byte_seconds"]/2**20:.1f} |')
extra+=['','Retained RSS includes allocator and runtime caches. Resident MiB-seconds estimates memory occupancy integrated over queue time. Neither is a direct allocation count or proof of a leak.','']
index=lines.index('## Operation CPU by reference case');lines[index:index]=extra
lines=[line.replace('| reversed-workflows |','| reversed-workflows [unqualified] |') for line in lines]
(r/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({name:{label:dict(cpu_change_percent=100*(x['paired_medians']['charged_cpu_ns']-1),rounds_lower_cpu=x['rounds_lower_cpu']) for label,x in rows.items()} for name,rows in comparisons.items()},indent=2))
