"""Bind the focused tests and raw replay to their interpreter and input hashes."""
import hashlib,json,pathlib,platform,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
names=['frequency-workload.py','native-probe/fixed-work-mach-aligned','correlate.py','test-correlation.py','test-raw-replay.py','live-clock-bridge.json','correlation.json','matched-native.json','native.csv','hardware.csv']
paths=[root/name for name in names]+sorted(p for p in (root/'capture').rglob('*') if p.is_file())
receipt=dict(python=sys.version,executable=sys.executable,platform=platform.platform(),inputs={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},commands=[])
for script in ['test-correlation.py','test-raw-replay.py']:
    command=[sys.executable,str(root/script)]
    result=subprocess.run(command,cwd=root,capture_output=True,text=True)
    receipt['commands'].append(dict(command=command,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
receipt['passed']=all(row['returncode']==0 for row in receipt['commands'])
(root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(passed=receipt['passed'],test_commands=len(receipt['commands']),bound_inputs=len(receipt['inputs']))))
if not receipt['passed']:raise SystemExit(1)
