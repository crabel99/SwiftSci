"""Package and verify this diagnostic capture without rerunning workloads."""
import hashlib,json,pathlib,shutil,subprocess,sys,tarfile,tempfile
q=pathlib.Path(__file__).resolve().parent
names=['README.md','REPLAY.md','review.md','review-disposition.md','final-review.md','decisions.tsv','correlate.py','test-correlation.py','test-raw-replay.py','run-verification.py','verification.json','plot-correlation.R','plot.log','frequency-correlation.png','frequency-correlation.pdf','live-clock-bridge.json','collect-clock-bridge-reconstructed.py','capture-provenance.json','analysis-provenance.json','capture-cleanup.json','correlation.json','matched-native.json','native.csv','hardware.csv','correlation.log','verify-plist-time.py','plist-time-verification.json','apple-powermetrics-manual.txt','frequency-workload.py','capture-frequency.sh','validate-frequency-capture.py','package-evidence.py']
paths=[q/name for name in names]
paths += sorted(p for d in ['capture','native-probe'] for p in (q/d).rglob('*') if p.is_file())
missing=[str(p) for p in paths if not p.is_file()]
if missing:raise RuntimeError(missing)
manifest={str(p.relative_to(q)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(q/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(q/'experiment.tar.gz','w:gz') as archive:
    for p in paths+[q/'manifest.json']:archive.add(p,arcname=str(p.relative_to(q)),recursive=False)
with tempfile.TemporaryDirectory(prefix='swiftsci-frequency-archive-replay-') as directory:
    out=pathlib.Path(directory)
    with tarfile.open(q/'experiment.tar.gz','r:gz') as archive:archive.extractall(out,filter='data')
    for name,expected in manifest.items():
        if hashlib.sha256((out/name).read_bytes()).hexdigest()!=expected:raise ValueError(name)
    run=subprocess.run([sys.executable,str(out/'run-verification.py')],capture_output=True,text=True)
    receipt=dict(archive_sha256=hashlib.sha256((q/'experiment.tar.gz').read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256((q/'manifest.json').read_bytes()).hexdigest(),verified_files=len(manifest),command=[sys.executable,'run-verification.py'],returncode=run.returncode,stdout=run.stdout,stderr=run.stderr,replay_verification=json.loads((out/'verification.json').read_text()))
    (q/'archive-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if run.returncode:raise RuntimeError(run.stderr)
print(json.dumps({k:receipt[k] for k in ['archive_sha256','verified_files','returncode','stdout']}))
