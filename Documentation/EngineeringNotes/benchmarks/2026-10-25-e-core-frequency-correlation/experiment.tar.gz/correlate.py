"""Correlate native fixed-work timing with captured E-cluster telemetry."""
import argparse,csv,datetime,json,math,plistlib,statistics
from pathlib import Path

NS=10**9


def unix_ns(stamp):
    if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=datetime.timezone.utc)
    delta=stamp-datetime.datetime(1970,1,1,tzinfo=datetime.timezone.utc)
    return ((delta.days*86400+delta.seconds)*NS+delta.microseconds*1000)


def timeline(reports, at_end=True):
    elapsed=0;low=0;high=10**30;relative=[]
    for r in reports:
        period=r['elapsed_ns']
        if type(period) is not int or period<=0:raise ValueError('Invalid sampling period')
        a,b=elapsed,elapsed+period
        anchor=b if at_end else a
        stamp=unix_ns(r['timestamp'])
        if r['timestamp'].microsecond:raise ValueError('This replay expects observed whole-second timestamps')
        low=max(low,stamp-anchor);high=min(high,stamp+NS-anchor)
        e=next(c for c in r['processor']['clusters'] if c['name']=='E-Cluster')
        relative.append(dict(start_ns=a,end_ns=b,ghz=e['freq_hz']/NS,
            idle_ratio=e['idle_ratio'],dvfm_states=e['dvfm_states']))
        elapsed=b
    if low>=high:raise ValueError(f'Timestamp and elapsed_ns constraints have no common origin: low={low}, high={high}')
    origin=(low+high)//2
    return [dict(r,start_ns=r['start_ns']+origin,end_ns=r['end_ns']+origin) for r in relative],dict(
        timestamp_interpretation='end' if at_end else 'start',origin_low_ns=low,origin_high_ns=high,
        origin_uncertainty_ns=high-low,origin_midpoint_ns=origin)


def weighted_window(windows,start,end):
    if start>=end:raise ValueError('Invalid native interval')
    overlaps=[(max(0,min(end,w['end_ns'])-max(start,w['start_ns'])),w) for w in windows]
    used=sum(n for n,w in overlaps)
    return dict(coverage_fraction=used/(end-start),hardware_ghz=None if not used else sum(n*w['ghz'] for n,w in overlaps)/used)


def correlation(xs,ys):
    mx,my=statistics.mean(xs),statistics.mean(ys)
    numerator=sum((x-mx)*(y-my) for x,y in zip(xs,ys))
    return numerator/math.sqrt(sum((x-mx)**2 for x in xs)*sum((y-my)**2 for y in ys))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('capture',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();q=args.capture;out=args.output;out.mkdir(exist_ok=True)
    reports=[plistlib.loads(part.strip()) for part in (q/'power.plist').read_bytes().split(b'\0') if part.strip()]
    native=[]
    for path in sorted((q/'native').glob('rate-probe-*-*.jsonl')):
        _,_,phase,slot=path.stem.split('-')
        native += [dict(phase=int(phase),slot=int(slot),**json.loads(line)) for line in path.read_text().splitlines()]
    if len(reports)!=600 or len(native)!=240:raise ValueError('Incomplete capture')
    if len({r['value'] for r in native})!=1 or any(r['p_user_ns']!=0 for r in native):raise ValueError('Native result or placement mismatch')
    begin=json.loads((q/'native/anchors.json').read_text());end=json.loads((q/'native/end-anchors.json').read_text())
    lower=begin['start_unix_ns']-min(r['start_ns'] for r in native)
    upper=end['end_unix_ns']-max(r['end_ns'] for r in native)
    if lower>upper:raise ValueError('No Mach-to-wall offset satisfies the recorded workload envelope')
    bridge=json.loads((out/'live-clock-bridge.json').read_text())
    best=min(bridge['samples'],key=lambda r:r['mach_after_ns']-r['mach_before_ns'])
    live=(best['offset_low_ns']+best['offset_high_ns'])//2
    if not lower<=live<=upper:raise ValueError('Live clock bridge falls outside historical capture bounds')
    offsets=[('historical_low',lower),('historical_midpoint',(lower+upper)//2),('live_bridge',live),('historical_high',upper)]
    sensitivity=[];matched=[];rejected_models=[]
    for at_end in [True,False]:
        try:
            windows,clock=timeline(reports,at_end)
        except ValueError as error:
            rejected_models.append(dict(timestamp_interpretation='end' if at_end else 'start',reason=str(error)))
            if at_end:raise
            continue
        for label,offset in offsets:
            pairs=[];partial=[]
            for r in native:
                sample=weighted_window(windows,r['start_ns']+offset,r['end_ns']+offset)
                v=dict(r,**sample,cpu_ms=r['sdk_cpu_ns']/1e6,wall_ms=r['wall_ns']/1e6,
                    effective_ghz=r['cycles']/r['sdk_cpu_ns'],wall_minus_cpu_ms=(r['wall_ns']-r['sdk_cpu_ns'])/1e6)
                (pairs if sample['coverage_fraction']>=1-1e-12 else partial).append(v)
            value=dict(**clock,offset_case=label,offset_ns=offset,matched=len(pairs),partial=len(partial),
                effective_rate_correlation=correlation([v['effective_ghz'] for v in pairs],[v['hardware_ghz'] for v in pairs]),
                cpu_time_correlation=correlation([v['cpu_ms'] for v in pairs],[v['hardware_ghz'] for v in pairs]),
                median_absolute_rate_difference_ghz=statistics.median(abs(v['effective_ghz']-v['hardware_ghz']) for v in pairs))
            sensitivity.append(value)
            if at_end and label=='live_bridge':matched=pairs+partial
    full=[v for v in matched if v['coverage_fraction']>=1-1e-12]
    groups=[]
    for label,group in [('fastest_cpu_quartile',sorted(full,key=lambda r:r['cpu_ms'])[:len(full)//4]),
                        ('slowest_cpu_quartile',sorted(full,key=lambda r:r['cpu_ms'])[-(len(full)//4):])]:
        groups.append(dict(group=label,samples=len(group),**{key:statistics.median(v[key] for v in group)
            for key in ['cpu_ms','wall_ms','effective_ghz','hardware_ghz','instructions','cycles','wall_minus_cpu_ms']}))
    e=[next(c for c in r['processor']['clusters'] if c['name']=='E-Cluster') for r in reports]
    summary=dict(reports=len(reports),native_samples=len(native),all_results_identical=True,all_user_p_zero=True,
        telemetry_elapsed_s=sum(r['elapsed_ns'] for r in reports)/NS,
        telemetry_period_ms=dict(min=min(r['elapsed_ns'] for r in reports)/1e6,median=statistics.median(r['elapsed_ns'] for r in reports)/1e6,max=max(r['elapsed_ns'] for r in reports)/1e6),
        driver_elapsed_clock_difference_ns=(end['end_unix_ns']-begin['start_unix_ns'])-(end['end_monotonic_ns']-begin['start_monotonic_ns']),
        matched=len(full),partial=len(matched)-len(full),
        hardware_e_ghz_range=[min(c['freq_hz']/NS for c in e),max(c['freq_hz']/NS for c in e)],
        native_cpu_ms_range=[min(v['cpu_ms'] for v in matched),max(v['cpu_ms'] for v in matched)],
        thermal_states=sorted({r['thermal_pressure'] for r in reports}),
        sfi_window_sizes_us=sorted({r['sfi']['window_size_us'] for r in reports}),
        sfi_nonzero_endpoints=sum(any(r['sfi']['sfi_classes'].values()) for r in reports),
        native_clock_offset_bounds_ns=[lower,upper],native_offset_envelope_ms=(upper-lower)/1e6,
        timing_caveat='System Python monotonic anchors have a process-relative origin. Native Mach timestamps are mapped using an explicit live bridge bounded by the historical start/end envelope. Telemetry timestamps are whole-second values; elapsed_ns reconstruction uses the end-of-window timestamp model. The start model is rejected under the strict whole-second constraint model. Sensitivity evaluates four selected Mach offsets at the telemetry-origin midpoint, not every admissible alignment.',
        inference_caveat='Descriptive correlation, not independent samples or a p-value. Shared-cluster hardware averages do not identify the exact frequency at every instant of an individual worker. SFI is sampled at endpoints, so zeros do not exclude transient forced idle. No performance normalization or qualification is performed.',
        groups=groups,sensitivity=sensitivity,rejected_timestamp_models=rejected_models)
    (out/'correlation.json').write_text(json.dumps(summary,indent=2)+'\n')
    (out/'matched-native.json').write_text(json.dumps(matched,indent=2)+'\n')
    with (out/'native.csv').open('w') as f:
        fields=['phase','slot','run','start_ns','end_ns','cpu_ms','wall_ms','effective_ghz','hardware_ghz','coverage_fraction','instructions','cycles','wall_minus_cpu_ms']
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(matched)
    primary,clock=timeline(reports,True);offset=live
    with (out/'hardware.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['time_s','hardware_ghz','idle_ratio'])
        first=min(r['start_ns'] for r in native)+offset
        for window in primary:w.writerow([((window['start_ns']+window['end_ns'])/2-first)/NS,window['ghz'],window['idle_ratio']])
    print(json.dumps({k:summary[k] for k in ['reports','native_samples','matched','partial','hardware_e_ghz_range','thermal_states','sfi_nonzero_endpoints','groups']},indent=2))


if __name__=='__main__':main()
