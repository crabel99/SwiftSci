"""Replay captured input, not the privileged profiler or native workload."""
import hashlib,json,pathlib,shutil,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parent
class RawReplayTests(unittest.TestCase):
    def test_bound_capture_replays_numeric_outputs_and_clock_selection(self):
        provenance=json.loads((ROOT/'capture/native/provenance.json').read_text())
        self.assertEqual(hashlib.sha256((ROOT/'frequency-workload.py').read_bytes()).hexdigest(),provenance['driver_sha256'])
        self.assertEqual(hashlib.sha256((ROOT/'native-probe/fixed-work-mach-aligned').read_bytes()).hexdigest(),provenance['probe_sha256'])
        expected=json.loads((ROOT/'correlation.json').read_text())
        bridge=json.loads((ROOT/'live-clock-bridge.json').read_text())
        self.assertEqual(len(bridge['samples']),100)
        for row in bridge['samples']:
            self.assertLessEqual(row['mach_before_ns'],row['mach_after_ns'])
            self.assertEqual(row['offset_low_ns'],row['unix_ns']-row['mach_after_ns'])
            self.assertEqual(row['offset_high_ns'],row['unix_ns']-row['mach_before_ns'])
        best=min(bridge['samples'],key=lambda r:r['mach_after_ns']-r['mach_before_ns'])
        with tempfile.TemporaryDirectory(prefix='swiftsci-frequency-replay-') as directory:
            out=pathlib.Path(directory)
            shutil.copy2(ROOT/'live-clock-bridge.json',out)
            result=subprocess.run([sys.executable,str(ROOT/'correlate.py'),str(ROOT/'capture'),'--output',str(out)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            for name in ['correlation.json','matched-native.json','native.csv','hardware.csv']:
                self.assertEqual(hashlib.sha256((out/name).read_bytes()).hexdigest(),hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),name)
            actual=json.loads((out/'correlation.json').read_text())
            self.assertEqual(actual,expected)
            self.assertEqual((actual['reports'],actual['native_samples'],actual['matched'],actual['partial']),(600,240,239,1))
            cases=actual['sensitivity']
            self.assertEqual([r['offset_case'] for r in cases],['historical_low','historical_midpoint','live_bridge','historical_high'])
            self.assertEqual(cases[2]['offset_ns'],(best['offset_low_ns']+best['offset_high_ns'])//2)
            self.assertEqual([cases[0]['offset_ns'],cases[3]['offset_ns']],actual['native_clock_offset_bounds_ns'])
            self.assertTrue(all(r['matched']==239 and r['partial']==1 and r['timestamp_interpretation']=='end' for r in cases))
            self.assertEqual([r['timestamp_interpretation'] for r in actual['rejected_timestamp_models']],['start'])
            rows=json.loads((out/'matched-native.json').read_text())
            partial=[r for r in rows if r['coverage_fraction']<1-1e-12]
            self.assertEqual(len(partial),1)
            self.assertEqual(partial[0]['start_ns'],min(r['start_ns'] for r in rows))
            self.assertTrue(0<partial[0]['coverage_fraction']<1)
if __name__=='__main__':unittest.main()
