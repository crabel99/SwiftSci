"""Reconstructed collection procedure, not the original capture command.

Do not overwrite the historical bridge. A new bridge is a new observation.
The original command was not saved as a file. This source documents the
Mach/Unix pairing procedure described when the historical samples were taken.
"""
import ctypes,json,time
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
class Timebase(ctypes.Structure):
    _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
lib.mach_absolute_time.restype=ctypes.c_uint64
lib.mach_timebase_info.argtypes=[ctypes.POINTER(Timebase)]
base=Timebase()
if lib.mach_timebase_info(ctypes.byref(base))!=0:raise RuntimeError('Mach timebase unavailable')
def now():return lib.mach_absolute_time()*base.numer//base.denom
samples=[]
for _ in range(100):
    before=now();wall=time.time_ns();after=now()
    samples.append(dict(mach_before_ns=before,unix_ns=wall,mach_after_ns=after,
        offset_low_ns=wall-after,offset_high_ns=wall-before))
print(json.dumps(dict(timebase=dict(numer=base.numer,denom=base.denom),samples=samples),indent=2))
