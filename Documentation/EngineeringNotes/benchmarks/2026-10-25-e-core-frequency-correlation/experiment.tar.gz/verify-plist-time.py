"""Observe current CoreFoundation XML date precision without changing system state."""
import ctypes,json,plistlib
from pathlib import Path
lib=ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
ptr=ctypes.c_void_p
lib.CFDateCreate.argtypes=[ptr,ctypes.c_double];lib.CFDateCreate.restype=ptr
lib.CFPropertyListCreateData.argtypes=[ptr,ptr,ctypes.c_long,ctypes.c_ulong,ctypes.POINTER(ptr)];lib.CFPropertyListCreateData.restype=ptr
lib.CFDataGetLength.argtypes=[ptr];lib.CFDataGetLength.restype=ctypes.c_long
lib.CFDataGetBytePtr.argtypes=[ptr];lib.CFDataGetBytePtr.restype=ptr
lib.CFRelease.argtypes=[ptr]
rows=[]
for fraction in [.125,.5,.875]:
 value=lib.CFDateCreate(None,1792950492+fraction-978307200);error=ptr();data=None
 try:
  data=lib.CFPropertyListCreateData(None,value,100,0,ctypes.byref(error))
  if not data:raise RuntimeError('Cannot serialize date')
  xml=ctypes.string_at(lib.CFDataGetBytePtr(data),lib.CFDataGetLength(data))
  stamp=plistlib.loads(xml)
  assert stamp.second==12 and stamp.microsecond==0
  rows.append(dict(input_unix_seconds=1792950492+fraction,xml=xml.decode(),parsed_utc=stamp.isoformat()))
 finally:
  if data:lib.CFRelease(data)
  lib.CFRelease(value)
  if error.value:lib.CFRelease(error)
result=dict(scope='Current CoreFoundation XML plist date encoding discards subsecond precision for these positive timestamps. This checks serialization, not the exact powermetrics timestamp call site.',cases=rows)
Path('plist-time-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(cases=len(rows),all_truncated=True)))
