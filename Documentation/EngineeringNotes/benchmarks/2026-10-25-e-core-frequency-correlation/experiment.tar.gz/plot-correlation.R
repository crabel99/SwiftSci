args <- commandArgs(trailingOnly=TRUE)
root <- if (length(args)) args[[1]] else "."
native <- read.csv(file.path(root,"native.csv"))
hardware <- read.csv(file.path(root,"hardware.csv"))
native$time_s <- ((native$start_ns + native$end_ns)/2-min(native$start_ns))/1e9
full <- native[native$coverage_fraction > 1-1e-12,]
colors <- ifelse(native$phase %in% c(0,2),"#1764A1","#D65B24")
fullcolors <- ifelse(full$phase %in% c(0,2),"#1764A1","#D65B24")
draw <- function() {
    par(mfrow=c(2,1),mar=c(4.2,4.6,3.2,1.1),oma=c(1.7,0,0,0),family="sans")
    plot(hardware$time_s,hardware$hardware_ghz,type="l",col="#333333",lwd=1.7,
         xlim=c(0,max(native$time_s)+1),ylim=c(0.9,2.8),
         xlab="Seconds from first native loop",ylab="GHz or cycles per CPU ns",
         main="E-core clock scaling during identical native work")
    points(native$time_s,native$effective_ghz,pch=16,cex=0.5,col=colors)
    legend("bottomright",c("Apple E-cluster telemetry","Native counter rate, one worker","Native counter rate, four workers"),
           col=c("#333333","#1764A1","#D65B24"),lty=c(1,NA,NA),pch=c(NA,16,16),bty="n",cex=.8)
    plot(full$hardware_ghz,full$cpu_ms,pch=16,cex=.65,col=fullcolors,
         xlab="Window-weighted Apple E-cluster frequency (GHz)",ylab="Native CPU time (ms)",
         main="Slower CPU timing covaries with lower hardware clock rates")
    grid(col="#E4E4E4");points(full$hardware_ghz,full$cpu_ms,pch=16,cex=.65,col=fullcolors)
    x <- seq(min(full$hardware_ghz),max(full$hardware_ghz),length.out=200)
    lines(x,median(full$cycles)/x/1e6,lty=2,lwd=1.6,col="#333333")
    legend("topright",c("One worker","Four workers","Median cycles / reported GHz"),
           col=c("#1764A1","#D65B24","#333333"),pch=c(16,16,NA),lty=c(NA,NA,2),bty="n",cex=.8)
    mtext("239 fully covered runs; one partial edge run retained in data. Correlation is descriptive. No timing normalization or performance qualification.",
          outer=TRUE,side=1,line=.25,cex=.65)
}
png(file.path(root,"frequency-correlation.png"),width=1500,height=1300,res=155)
draw();dev.off()
pdf(file.path(root,"frequency-correlation.pdf"),width=9.7,height=8.4)
draw();dev.off()
