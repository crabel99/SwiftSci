import datetime,unittest
from correlate import timeline,weighted_window


class CorrelationTests(unittest.TestCase):
    def test_weighted_frequency_does_not_invent_missing_coverage(self):
        values=[dict(start_ns=10,end_ns=20,ghz=1),dict(start_ns=20,end_ns=30,ghz=3)]
        self.assertEqual(weighted_window(values,15,25),dict(coverage_fraction=1,hardware_ghz=2))
        self.assertEqual(weighted_window(values,0,20),dict(coverage_fraction=.5,hardware_ghz=1))
        self.assertEqual(weighted_window(values,31,40),dict(coverage_fraction=0,hardware_ghz=None))

    def test_whole_second_timestamps_bound_an_origin_not_an_exact_time(self):
        def row(second,elapsed):return dict(timestamp=datetime.datetime(1970,1,1,0,0,second),elapsed_ns=elapsed,
            processor=dict(clusters=[dict(name='E-Cluster',freq_hz=2e9,idle_ratio=0,dvfm_states=[])]))
        windows,clock=timeline([row(1,600_000_000),row(2,600_000_000)])
        self.assertEqual(clock['origin_low_ns'],800_000_000)
        self.assertEqual(clock['origin_high_ns'],1_400_000_000)
        self.assertEqual(windows[0]['start_ns'],1_100_000_000)
        self.assertEqual(windows[1]['end_ns'],2_300_000_000)
        with self.assertRaises(ValueError):timeline([row(1,600_000_000),row(4,600_000_000)])

    def test_invalid_or_unresolved_times_are_rejected(self):
        with self.assertRaises(ValueError):weighted_window([],10,10)
        with self.assertRaises(ValueError):timeline([dict(elapsed_ns=0)])


if __name__=='__main__':unittest.main()
