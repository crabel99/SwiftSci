from pathlib import Path
import json,subprocess
R=Path(__file__).resolve().parent;I=Path('/private/tmp/swiftsci-csv-external-20261023/inputs')
reads=[];streams=[]
for path in sorted(I.glob('*.json')):
 for policy in ['serial','parallel']:
  for storage in ['optional','compact']:
   for label,cmd,out in [('eager',[str(R/'build/ResourceProbe'),str(path),'known','fresh','1',policy,storage],reads),('stream',[str(R/'build/StreamProbe'),str(path),'10000',policy,storage],streams)]:
    p=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=90);x=json.loads(p.stdout);assert x['validated']
    x.update(policy=policy,storage=storage);out.append(x)
(R/'strict-inputs.json').write_text(json.dumps(reads,indent=2)+'\n')
(R/'stream-checks.json').write_text(json.dumps({'validated':True,'responses':streams,'accepted_timing':False},indent=2)+'\n')
print('Exact reference checks:',len(reads),'eager,',len(streams),'streamed',flush=True)
