import Foundation
import SwiftDataFrame
import Darwin
import CryptoKit

struct Input: Decodable {
    let id: String, path: String, delimiter: String
    let rows: Int
    let names: [String], types: [String], hashes: [String]
    let null_tokens: [String]
    let integral: [Bool]
    let max_rows: Int?
    let date_formats: [String: String]?
}
func cpu() -> Int64 {
    var r = rusage(); getrusage(RUSAGE_SELF, &r)
    return Int64(r.ru_utime.tv_sec + r.ru_stime.tv_sec) * 1_000_000_000 + Int64(r.ru_utime.tv_usec + r.ru_stime.tv_usec) * 1_000
}
func resident() -> Int64 {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<integer_t>.size)
    let result = withUnsafeMutablePointer(to: &info) { pointer in
        pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    precondition(result == KERN_SUCCESS)
    return Int64(info.resident_size)
}
func heap() -> Int64 {
    var s = malloc_statistics_t(); malloc_zone_statistics(nil, &s)
    return Int64(s.size_in_use)
}
func peak() -> Int64 { var r = rusage(); getrusage(RUSAGE_SELF, &r); return Int64(r.ru_maxrss) }
struct Digest {
    var hash = SHA256(), buffer = Data(), nulls = 0
    mutating func integer<T: FixedWidthInteger>(_ value: T) {
        var value = value.littleEndian
        withUnsafeBytes(of: &value) { buffer.append(contentsOf: $0) }
    }
    mutating func append<T>(_ value: T?, encode: (inout Digest, T) -> Void) {
        if let value { buffer.append(1); encode(&self, value) }
        else { buffer.append(0); nulls += 1 }
        if buffer.count >= 65536 { hash.update(data: buffer); buffer.removeAll(keepingCapacity: true) }
    }
    mutating func finish() -> String {
        hash.update(data: buffer)
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
func validate(_ df: DataFrame, input: Input, mode: String) -> [String: Any] {
    var failures = [String](), details = [[String: Any]]()
    if df.shape.rows != input.rows { failures.append("row count") }
    if df.columnNames != input.names { failures.append("column names/order") }
    for (j, name) in input.names.enumerated() {
        let type = df.dtypes[name]?.description ?? "absent"
        let expected = input.types[j]
        let allowed = type == expected || (mode == "infer" && expected == "Double" && type == "Int64" && input.integral[j])
        if !allowed { failures.append("type: \(name): \(type), expected \(expected)") }
        var d = Digest()
        switch type {
        case "Double":
            let c = df[column: name, as: Double.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer($1.bitPattern) } }
        case "Int64":
            let c = df[column: name, as: Int64.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer(Double($1).bitPattern) } }
        case "String":
            let c = df[column: name, as: String.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { digest, value in
                digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
            } }
        case "Bool":
            let c = df[column: name, as: Bool.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer(UInt8($1 ? 1 : 0)) } }
        case "Date":
            let c = df[column: name, as: Date.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer($1.timeIntervalSince1970.bitPattern) } }
        default: failures.append("unsupported output: \(name): \(type)")
        }
        let actual = d.finish()
        if actual != input.hashes[j] { failures.append("values/nulls: \(name)") }
        details.append(["name":name,"type":type,"nulls":d.nulls,"sha256":actual])
    }
    return ["passed":failures.isEmpty,"failures":failures,"columns":details]
}

func fingerprint(_ df: DataFrame) -> [String: Any] {
    var columns = [[String: Any]]()
    for name in df.columnNames {
        var d = Digest()
        let type = df.dtypes[name]!.description
        switch type {
        case "Double":
            let c = df[column: name, as: Double.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1.bitPattern) } }
        case "Int64":
            let c = df[column: name, as: Int64.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1) } }
        case "String":
            let c = df[column: name, as: String.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { digest, value in
                digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
            } }
        default: preconditionFailure("Unsupported fixture type")
        }
        columns.append(["name": name, "type": type, "nulls": d.nulls, "sha256": d.finish()])
    }
    return ["rows": df.rowCount, "columns": columns]
}
@MainActor @main struct WorkflowProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: args[0])))
        let workflow = args[1], policy = args[2]
        var options = CSVReadOptions()
        #if CSV_STORAGE_CHOICE
        options.doubleStorage = args[3] == "compact" ? .compact : .optional
        #endif
        options.delimiter = Character(input.delimiter); options.nullValues = Set(input.null_tokens)
        options.columnConversionMode = policy == "serial" ? .serial : .parallel
        let mapping: [String: ColumnDType] = ["String": .utf8, "Double": .float64, "Int64": .int64]
        options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names, input.types).map { ($0.0, mapping[$0.1]!) })
        let numeric = zip(input.names, input.types).filter { $0.1 == "Double" || $0.1 == "Int64" }.map { $0.0 }
        let chosen = input.id.hasPrefix("energy") ? "Global_active_power" : "PM2.5"
        let key = input.id.hasPrefix("energy") ? "Date" : "station"
        let labels = input.id.hasPrefix("energy") ? ["16/12/2006", "17/12/2006"] : ["Aotizhongxin"]
        let lookup = try DataFrame(columns: [TypedColumn(name: key, values: labels + ["__unmatched_lookup_key__"]),
                                             TypedColumn<Int64>(name: "lookup_code", values: (0...labels.count).map(Int64.init))])
        let h0=heap(),r0=resident(),p0=peak(),c0=cpu(),t0=DispatchTime.now().uptimeNanoseconds
        var output: DataFrame? = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)
        let cRead=cpu(),tRead=DispatchTime.now().uptimeNanoseconds
        var matrix: PreparedNumericMatrix?
        var batch: PreparedNumericBatch?
        var exports = [[Double?]]()
        var selection: [Int]?
        var scalarBits: UInt64 = 0
        switch workflow {
        case "read": break
        case "batch":
            batch = try output!.prepareNumericBatch(numeric)
        case "matrix":
            matrix = try output!.prepareNumericMatrix(numeric)
        case "materialize":
            for name in numeric {
                if let column = output![column: name, as: Double.self] { exports.append(column.values) }
            }
        case "row-scan":
            for row in output!.rows {
                if let value = row[chosen] as? Double { scalarBits &+= value.bitPattern }
            }
        case "lag-matrix":
            output = try output!.withLaggedColumn(column: chosen, by: 3, newName: "lagged")
            matrix = try output!.prepareNumericMatrix(numeric + ["lagged"])
        case "filter-indices":
            selection = output![column: chosen, as: Double.self]!.filteredIndices(matching: .greaterThan(3.0))
        case "filter-materialize":
            output = try output!.filter(column: chosen, where: .greaterThan(3.0))
            for name in numeric {
                if let column = output![column: name, as: Double.self] { exports.append(column.values) }
            }
        case "filter-matrix":
            output = try output!.filter(column: chosen, where: .greaterThan(3.0))
            matrix = try output!.prepareNumericMatrix(numeric)
        case "gather-matrix":
            let indices = Array(stride(from: 0, to: output!.rowCount, by: 17))
            output = output!.gathered(at: indices)
            matrix = try output!.prepareNumericMatrix(numeric)
        case "sort-matrix":
            output = try output!.sortBy(chosen)
            matrix = try output!.prepareNumericMatrix(numeric)
        case "join-only", "join-materialize":
            output = try output!.join(lookup, on: key, how: .left)
            if workflow == "join-materialize" {
                for name in numeric {
                    if let column = output![column: name, as: Double.self] { exports.append(column.values) }
                }
            }
        case "join-matrix", "join-inner-matrix", "join-right-matrix", "join-outer-matrix":
            let kind: JoinKind = workflow == "join-inner-matrix" ? .inner : workflow == "join-right-matrix" ? .right : workflow == "join-outer-matrix" ? .outer : .left
            output = try output!.join(lookup, on: key, how: kind)
            matrix = try output!.prepareNumericMatrix(numeric)
        default: preconditionFailure("Unknown workflow")
        }
        let t1=DispatchTime.now().uptimeNanoseconds,c1=cpu(),h1=heap(),r1=resident(),p1=peak()
        let frameCheck = fingerprint(output!)
        var matrixCheck = "absent"
        if let matrix {
            var d = Digest()
            for value in matrix.values { d.append(Optional(value)) { $0.integer($1.bitPattern) } }
            matrixCheck = d.finish()
        }
        var batchCheck = [String]()
        if let batch {
            for column in 0..<batch.columnCount {
                var d = Digest()
                for row in 0..<batch.rowCount { d.append(batch[row, column]) { $0.integer($1.bitPattern) } }
                batchCheck.append(d.finish())
            }
        }
        var exportCheck = [String]()
        for column in exports {
            var d=Digest()
            for value in column { d.append(value) { $0.integer($1.bitPattern) } }
            exportCheck.append(d.finish())
        }
        var selectionCheck = "absent"
        if let selection {
            var d = Digest()
            for row in selection { d.append(Optional(Int64(row))) { $0.integer($1) } }
            selectionCheck = d.finish()
        }
        let t2=DispatchTime.now().uptimeNanoseconds,c2=cpu()
        output=nil;matrix=nil;batch=nil;exports=[];selection=nil
        let t3=DispatchTime.now().uptimeNanoseconds,c3=cpu()
        let result: [String: Any] = ["selection_sha256":selectionCheck,"frame":frameCheck,"matrix_sha256":matrixCheck,"export_sha256":exportCheck,"scalar_bits":scalarBits,"batch_sha256":batchCheck,
            "samples":[["total_cpu_ns":c1-c0+c3-c2,"total_ns":Int64(t1-t0+t3-t2),
                "read_cpu_ns":cRead-c0,"read_ns":Int64(tRead-t0),"operations_cpu_ns":c1-cRead,
                "heap_before_bytes":h0,"held_heap_bytes":h1,"heap_after_release_bytes":heap(),
                "rss_before_bytes":r0,"rss_held_bytes":r1,"process_peak_before_bytes":p0,"process_peak_held_bytes":p1]],
            "input":input.id,"workflow":workflow,"policy":policy,
            "scope":"CSV construction, requested public operations and release; held memory before full validation. Complete output hashes outside CPU/wall timing."]
        print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),as:UTF8.self))
    }
}
