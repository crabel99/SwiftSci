from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parent
for script,args in [('strict-check.py',[]),('run-panel.py',['preflight']),('run-panel.py',['measurement']),('audit.py',[])]:
 print('START',script,*args,flush=True)
 subprocess.run([sys.executable,str(R/script),*args],check=True)
