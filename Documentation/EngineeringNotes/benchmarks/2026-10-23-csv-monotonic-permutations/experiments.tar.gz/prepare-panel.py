from pathlib import Path
import json,subprocess,re,hashlib
R=Path(__file__).resolve().parent
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('original',Path('/private/tmp/swiftsci-csv-compact-sorting-20261023/build')),('prior',Path('/private/tmp/swiftsci-csv-sort-buffer-allocation-20261023/build')),('current',R/'build')]:
 cmd=[a.replace(str(F),str(D)) for a in base]
 cmd=[str(R/'WorkflowProbe.swift') if a.endswith('/ResourceProbe.swift') else str(R/(label+'-workflow')) if a==str(D/'ResourceProbe') else a for a in cmd]
 if label in ['original','prior','current']:cmd+=['-D','CSV_STORAGE_CHOICE']
 cmd+=['-Rmodule-loading']
 with (R/(label+'-workflow-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'-workflow-build.log')).read_text()[-3500:]);raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-workflow-build.log')).read_text()))
 assert loaded.get('SwiftDataFrame')==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-workflow-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':hashlib.sha256((R/'WorkflowProbe.swift').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((R/(label+'-workflow')).read_bytes()).hexdigest(),'storage_capability':{'original':'explicit choice','prior':'explicit choice','current':'explicit choice'}[label]},indent=2)+'\n')
 print(label,'client built with matching interface',flush=True)
