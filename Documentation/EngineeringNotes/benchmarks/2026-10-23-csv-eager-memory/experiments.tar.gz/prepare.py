from pathlib import Path
import json,hashlib,subprocess,re,difflib
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((F/'build.json').read_text())
assert all(h(S/p)==digest for p,digest in receipt['sources'].items())
source=Path('/private/tmp/swiftsci-csv-prefix-selection-20261022/ResourceProbe.swift').read_text().split('@MainActor @main')[0]
source+=r'''
func checkpoint(_ stage: String, extra: [String: Any] = [:]) {
    var record = extra
    record["stage"] = stage; record["pid"] = getpid()
    record["heap_bytes"] = heap(); record["rss_bytes"] = resident(); record["peak_bytes"] = peak()
    print(String(decoding: try! JSONSerialization.data(withJSONObject: record, options: [.sortedKeys]), as: UTF8.self))
    fflush(stdout)
    precondition(readLine() == "continue", "Controller must acknowledge checkpoint")
}
func storage<T>(_ column: TypedColumn<T>) -> [String: Any] {
    ["name": column.name, "count": column.count, "capacity": column.values.capacity,
     "element_size": MemoryLayout<T?>.size, "element_stride": MemoryLayout<T?>.stride,
     "payload_bytes": column.count * MemoryLayout<T?>.stride,
     "capacity_bytes": column.values.capacity * MemoryLayout<T?>.stride]
}
@MainActor @main struct MemoryProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: args[0])))
        var options = CSVReadOptions()
        options.delimiter = Character(input.delimiter); options.nullValues = Set(input.null_tokens)
        options.maxRows = input.max_rows
        options.columnConversionMode = args[1] == "serial" ? .serial : .parallel
        let mapping: [String: ColumnDType] = ["String": .utf8, "Double": .float64, "Int64": .int64, "Date": .date32, "Bool": .boolean]
        options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names, input.types).map { ($0.0, mapping[$0.1]!) })
        options.columnDateFormats = input.date_formats ?? [:]
        checkpoint("baseline")
        var output: DataFrame? = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)
        checkpoint("held")
        var columns = [[String: Any]]()
        for name in input.names {
            if let c = output![column: name, as: Double.self] { columns.append(storage(c)) }
            else if let c = output![column: name, as: String.self] { columns.append(storage(c)) }
            else if let c = output![column: name, as: Int64.self] { columns.append(storage(c)) }
        }
        let checks = validate(output!, input: input, mode: "known")
        precondition(checks["passed"] as? Bool == true)
        output = nil
        checkpoint("released", extra: ["columns": columns, "checks": checks])
        let relieved = malloc_zone_pressure_relief(nil, 0)
        checkpoint("pressure_relief", extra: ["allocator_reported_relieved_bytes": relieved])
    }
}
'''
(R/'MemoryProbe.swift').write_text(source)
# Instrument only a frozen source copy. The source worktree stays byte-identical.
D=R/'diagnostic';D.mkdir(exist_ok=True)
for p in receipt['sources']:
 dest=D/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((S/p).read_bytes())
p=D/'Sources/SwiftDataFrame/IO/CSVReader.swift'
old=p.read_text();new=old.replace('return try CSVEagerReader.read(buffer: buffer, options: options)', '''let frame = try CSVEagerReader.read(buffer: buffer, options: options)
            print("{\\"stage\\":\\"mapped_output\\"}")
            fflush(stdout)
            precondition(readLine() == "continue")
            return frame''')
assert new!=old;p.write_text(new)
(R/'diagnostic.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='CSVReader.swift',tofile='CSVReader.swift (diagnostic only)')))
def run(name,cmd,expected=None):
 with (R/(name+'.log')).open('w') as f: proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 if proc.returncode: print((R/(name+'.log')).read_text()[-4000:]);raise SystemExit(proc.returncode)
 verified={}
 if expected:
  loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(name+'.log')).read_text()))
  for key,value in expected.items():assert loaded.get(key)==value,(key,loaded.get(key),value)
  verified=expected
 binary=Path(cmd[cmd.index('-o')+1])
 (R/(name+'-build.json')).write_text(json.dumps({'command':cmd,'binary_sha256':h(binary),'module_paths_verified':verified},indent=2)+'\n')
 print(name,'built',flush=True)
cmd=[a.replace(str(S),str(D)).replace(str(F),str(D)) for a in receipt['commands'][0]]
run('diagnostic-module',cmd)
for label,directory in [('actual',F),('diagnostic',D)]:
 cmd=receipt['commands'][1].copy()
 cmd=[str(R/'MemoryProbe.swift') if a.endswith('/ResourceProbe.swift') else str(R/(label+'-probe')) if a==str(F/'ResourceProbe') else a.replace(str(F),str(directory)) for a in cmd]
 cmd+=['-Rmodule-loading']
 run(label,cmd,{'SwiftDataFrame':str(directory/'SwiftDataFrame.swiftmodule')})
(R/'source-receipt.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'sources':receipt['sources'],'actual_object_sha256':h(F/'SwiftDataFrame.o'),'harness_sha256':h(R/'MemoryProbe.swift'),'diagnostic_patch_sha256':h(R/'diagnostic.patch')},indent=2)+'\n')
