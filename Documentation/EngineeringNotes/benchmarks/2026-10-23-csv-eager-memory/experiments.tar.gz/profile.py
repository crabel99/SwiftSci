from pathlib import Path
import subprocess,json,time,selectors
R=Path(__file__).resolve().parent
inputs=Path('/private/tmp/swiftsci-csv-external-20261023/inputs')
records=[]
for label,policy,case,native in [('actual','serial','energy-common',True),('diagnostic','serial','energy-common',True),('actual','parallel','energy-common',True),('diagnostic','parallel','energy-common',True),('actual','serial','Aotizhongxin-default',False),('actual','serial','energy-common',False),('actual','parallel','energy-common',False)]:
 name=f'{len(records):02d}-{label}-{policy}-{case}';D=R/name;D.mkdir(exist_ok=True)
 command=[str(R/(label+'-probe')),str(inputs/(case+'.json')),policy]
 with (D/'stderr.txt').open('w') as err:
  proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
  events=[]
  try:
   while True:
    selector=selectors.DefaultSelector();selector.register(proc.stdout,selectors.EVENT_READ)
    assert selector.select(45), 'Checkpoint timeout';selector.close()
    line=proc.stdout.readline()
    if not line:break
    event=json.loads(line);events.append(event);stage=event['stage'];print(name,stage,flush=True)
    if native:
     for tool,args in [('vmmap',['-wide']),('heap',['--sortBySize','--noContent'])]:
      started=time.monotonic()
      with (D/(stage+'-'+tool+'.txt')).open('w') as out:
       result=subprocess.run(['/usr/bin/'+tool,*args,str(proc.pid)],stdout=out,stderr=subprocess.STDOUT,timeout=25)
      event[tool]={'exit_code':result.returncode,'seconds':time.monotonic()-started}
    proc.stdin.write('continue\n');proc.stdin.flush()
   rc=proc.wait(timeout=15)
   assert rc==0,(name,rc,(D/'stderr.txt').read_text())
  finally:
   if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
 record={'id':name,'command':command,'events':events,'diagnostic_only':True,'accepted_timing':False}
 (D/'lifecycle.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 (R/'profiles.json').write_text(json.dumps(records,indent=2)+'\n')
print('completed',len(records),'lifecycle runs')
