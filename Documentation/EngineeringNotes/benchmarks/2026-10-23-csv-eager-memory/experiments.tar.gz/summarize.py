from pathlib import Path
import json,re,hashlib,statistics
R=Path(__file__).resolve().parent
profiles=json.loads((R/'profiles.json').read_text())
summary=[]
for p in profiles:
 stages={e['stage']:e for e in p['events']}
 assert stages['released']['checks']['passed']
 cols=stages['released']['columns'];payload=sum(c['payload_bytes'] for c in cols);capacity=sum(c['capacity_bytes'] for c in cols)
 native=[]
 for event in p['events']:
  stage=event['stage'];file=R/p['id']/(stage+'-vmmap.txt')
  if not file.exists():continue
  assert event['vmmap']['exit_code']==event['heap']['exit_code']==0
  lines=file.read_text().splitlines()
  mapped=[x for x in lines if 'household_power_consumption.txt' in x]
  native.append({'stage':stage,'input_mapping_regions':mapped,'footprint_lines':[x for x in lines if x.startswith('Physical footprint')], 'large_allocation_summary':[x for x in lines if x.startswith('Malloc Large') and '[' not in x]})
 if 'diagnostic' in p['id']:
  assert next(x for x in native if x['stage']=='mapped_output')['input_mapping_regions']
  assert not next(x for x in native if x['stage']=='held')['input_mapping_regions']
  m=next(x for x in native if x['stage']=='mapped_output')['input_mapping_regions'][0]
  assert '[126.8M 126.8M     0K' in m
 summary.append({'run':p['id'],'columns':cols,'logical_payload_bytes':payload,'capacity_bytes':capacity,'excess_capacity_bytes':capacity-payload,'native':native,'stages':[{k:v for k,v in e.items() if k in ['stage','heap_bytes','rss_bytes','peak_bytes','allocator_reported_relieved_bytes']} for e in p['events']]})
# Held allocations from the native heap tool identify all nine large array objects.
for name in ['00-actual-serial-energy-common','01-diagnostic-serial-energy-common','02-actual-parallel-energy-common','03-diagnostic-parallel-energy-common']:
 held=(R/name/'held-heap.txt').read_text();released=(R/name/'released-heap.txt').read_text()
 assert re.search(r'7\s+232472576\s+33210368.0\s+Swift._ContiguousArrayStorage<Swift.Optional<Swift.Double>>',held)
 assert re.search(r'2\s+66420736\s+33210368.0\s+Swift._ContiguousArrayStorage<Swift.Optional<Swift.String>>',held)
 assert 'Swift._ContiguousArrayStorage<Swift.Optional<Swift.Double>>' not in released
 assert 'Swift._ContiguousArrayStorage<Swift.Optional<Swift.String>>' not in released
repeat=[]
for policy in ['serial','parallel']:
 r=json.loads((R/('repeat-'+policy+'.json')).read_text());assert r['validated'] and len(r['samples'])==6
 assert max(s['heap_after_release_bytes'] for s in r['samples'])<128*1024
 repeat.append({'policy':policy,'total_reads':8,'warmup_reads':2,'recorded_reads':6,'heap_after_release_bytes':[s['heap_after_release_bytes'] for s in r['samples']],'max_peak_bytes':max(s['process_peak_held_bytes'] for s in r['samples'])})
rows=2075259
out={'accepted_timing':False,'source_changed':False,'lifecycle_runs':len(profiles),'native_snapshots':sum(len(r['native'])*2 for r in summary),'profiles':summary,'repeated_lifetimes':repeat,'illustrative_not_measured':{'rows':rows,'current_logical_payload_bytes':rows*16*9,'packed_payload_bytes':rows*(16*2+8*7)+((rows+7)//8)*7,'excludes':'Allocator granularity, metadata, bitmap alignment, API materialization, and effects on compute speed.'}}
(R/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
audit={'passed':True,'checks':['Seven strict lifecycle reads passed every column digest, native type, shape, header and order check.','Actual and frozen diagnostic clients import the same interface as their linked reader object.','Both diagnostic conversions show a clean 126.8 MiB input mapping before return and no input mapping after return.','Both actual conversion policies have seven Double? arrays and two String? arrays held, none after release.','All 36 native profiler invocations completed successfully.','Six recorded post-warmup reads in each policy retain less than 128 KiB live heap after release.','All data are diagnostic; no timing regression or performance claim is inferred.']}
(R/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['lifecycle_runs','native_snapshots','illustrative_not_measured']}));print('audit passed')
