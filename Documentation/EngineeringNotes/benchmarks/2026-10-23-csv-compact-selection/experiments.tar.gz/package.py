from pathlib import Path
import json,subprocess,tarfile,hashlib,gzip,shutil,ast,re
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-compact-selection'
if T.exists():assert {p.name for p in T.iterdir()} <= {'README.md','results.md','audit.json','comparator-provenance.json','changes.patch.gz','experiments.tar.gz','artifact-sha256.json'}
T.mkdir(parents=True,exist_ok=True)
audit=json.loads((R/'audit.json').read_text());assert audit['all_outputs_match']
summary=json.loads((R/'measurement/summary.json').read_text())
flows=['read','materialize','filter-matrix','gather-matrix','sort-matrix','join-matrix','row-scan','lag-matrix','matrix','batch']
rows=[];stage=[]
for flow in flows:
 g={x['engine']:x['medians'] for x in summary if x['case']=='energy-common/serial/'+flow}
 trip=lambda key,scale:' / '.join(f'{g[label][key]/scale:.2f}' for label in ['original','prior','current'])
 rows.append(f"| {flow} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
 stage.append(f"| {flow} | {trip('operations_cpu_ns',1e6)} |")
selection=[c for c in json.loads((R/'measurement/plan.json').read_text())['cases'] if c['workflow'] in ['filter-matrix','gather-matrix','sort-matrix']]
cpu_savings=[];heap_savings=[];peak_savings=[]
for case in selection:
 key='/'.join(case.values());g={x['engine']:x['medians'] for x in summary if x['case']==key}
 cpu_savings.append(100*(1-g['current']['total_cpu_ns']/g['prior']['total_cpu_ns']))
 heap_savings.append(100*(1-g['current']['held_heap_bytes']/g['prior']['held_heap_bytes']))
 peak_savings.append(100*(1-g['current']['process_peak_held_bytes']/g['prior']['process_peak_held_bytes']))
head=audit['current_head']
readme=f'''# Compact storage through row selection

Row selection now reuses `CompactNumericColumn.gathered(at:)` for compact Double columns. The change avoids exporting the entire source column as optional values and keeps the selected result compact. It adds three dispatch lines to `TypedColumn<Double>.vGather(at:)`. The optional-backed path, gather kernel, sort algorithm and worker scheduling remain unchanged.

This is a child experiment of [compact numerical consumers](../2026-10-23-csv-compact-consumers/README.md). It does not promote a production default.

## Comparison versions

- Original is the qualified optional-array CSV reader at `5d1f89a961106104757f2d8d0b8faba79487d100`.
- Prior is the compact reader with specialized exports and direct numerical consumers at `5a3523aaff`.
- Current is `codex/csv-compact-selection` at `{head}`.
- Twin runs the exact current executable again to check measurement variability.

## Complete workflows on reference data

The table reports the 2,075,259-row household dataset with serial column conversion. Each entry lists original, prior and current medians. CPU includes CSV construction, the requested operation and release. Held heap includes the complete selected frame and requested numerical output. Peak RSS captures the process peak before fingerprint validation. All three measure different costs.

| Workflow | CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |
|---|---:|---:|---:|
{chr(10).join(rows)}

[The full table](results.md) includes both reference datasets, serial and parallel conversion, and all ten workflows. The household data uses the same eleven null tokens for every version, including `?`. The air-quality data uses the same default ten tokens. Both use explicit native schemas. No worker cap or dataset-specific optimization was added.

## What the results support

Across all twelve filtering, gathering and sorting combinations, current uses **{min(cpu_savings):.1f}% to {max(cpu_savings):.1f}% less CPU** and **{min(heap_savings):.1f}% to {max(heap_savings):.1f}% less held heap** than prior. Peak RSS savings range from {min(peak_savings):.1f}% to {max(peak_savings):.1f}%, so a smaller retained payload does not imply a large peak reduction in every workflow.

Against the original optional-array reader, current nearly recovers household filtering and gathering CPU while retaining lower memory use. Household sorting uses less CPU in both conversion modes. The original reader remains cheaper for some other workflows, and joining is still approximately 2.5 times its CPU cost. This patch is a useful integration step, not evidence that the compact prototype is ready for general promotion.

The sort case's held malloc bytes differ between the current and twin medians despite identical executables. Those values cover allocator live bytes beyond the logical payload. This experiment does not isolate the reason for that variation. Both control labels pass the fixed CPU and peak-RSS checks, and the raw records retain the difference.

## Operation CPU within the same workers

These medians use the operation stage recorded by each worker. They are not differences between unrelated workflow medians. CSV reading and output release are outside this stage.

| Workflow | Operation CPU original / prior / current, ms |
|---|---:|
{chr(10).join(stage)}

## Correctness and measurement checks

Three focused regression tests failed before the patch because the selected Double column no longer used compact storage. All three pass afterward. They check empty selections, repeated and unordered rows, bitmap boundaries through 261 output rows, all-missing and all-present columns, NaN payload bits, signed zero and infinities. Public frame filtering, gathering and both sort directions match optional-backed results. Selected Double buffers pass directly to prepared batches, and native Int64 values above 2^53 remain exact.

Release, Debug and Address Sanitizer each pass all 406 dataframe tests, with no failures or skips. Fourteen eager reference checks and fourteen streaming checks pass their pinned types, values, null positions and order. All 160 workflow preflights and 1,280 measured processes match the original output fingerprints. Derived-workflow equivalence is a regression check against the original implementation, not independent mathematical certification.

Eight balanced orders give every label every position twice and every ordered adjacent pair twice. The current and twin labels run the same executable. The fixed policy flags more than 10% median CPU difference or peak-memory differences beyond 5% plus 8 MiB. Flags are retained and disqualify the affected comparison. The audit records `quality_passed={audit['quality_passed']}` and these flags: `{json.dumps(audit['quality_flags'])}`.

Tests and builds finished before measurements. AC power was checked at both ends. All comparator clients use identical source compiled against their matching module interfaces and objects. Build receipts verify the imported module paths. Validation fingerprints run outside timing.

## Limits and next work

The change addresses ordinary row gathering. It does not implement compact-aware nullable join gathering or remove materialization from every numeric predicate and sorting helper. The join workflow remains in the panel so its regression stays visible. Read-only, export, matrix and batch workflows remain as controls against collateral changes.

CPU is process user plus system time. RSS and malloc live bytes describe different memory properties. These results do not measure energy, cache activity or FLOPs. No cache mechanism or universal leak-freedom claim follows from them. This experiment has not been pushed or submitted for production integration.

## Evidence and reproduction

- [Full resource results](results.md).
- [Independent audit](audit.json).
- [Comparator source provenance](comparator-provenance.json).
- [Exact experimental patch](changes.patch.gz).
- [Scripts, raw outputs, source snapshots and receipts](experiments.tar.gz).
- [Artifact hashes](artifact-sha256.json).

Restore the recorded prior commit, decompress and apply the patch, restore its pinned dependencies, and update the scripts' machine-specific paths. `verify.py` runs dataframe tests. `validate.py` runs three configurations and builds the module and clients. `measure.py` runs streaming checks, exact preflights, measurements and the audit. The archive excludes executables, caches, result bundles and large reference CSVs. Engineering records stay on `codex/engineering-notes`; only implementation and tests belong to the experiment branch.
'''
(T/'README.md').write_text(readme)
for name in ['results.md','audit.json','comparator-provenance.json']:shutil.copy2(R/name,T/name)
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as out:out.write((R/'changes.patch').read_bytes())
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==(R/'changes.patch').read_bytes()
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.txt','.log','.md','.patch','.jsonl'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for p in (S/'Sources/SwiftDataFrame').rglob('*.swift'):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 tar.add(S/'Tests/SwiftDataFrameTests/CompactSelectionTests.swift',arcname='final-source/Tests/SwiftDataFrameTests/CompactSelectionTests.swift')
 for label,root,filename in [('original','/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata','build.json'),('prior','/private/tmp/swiftsci-csv-compact-consumers-20261023','module-build.json')]:
  tar.add(Path(root)/filename,arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',readme):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
assert '—' not in readme
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'}
(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(T/k)==v for k,v in manifest.items())
print(T);print('Verified evidence hashes, patch bytes, links, archive paths and script syntax')
