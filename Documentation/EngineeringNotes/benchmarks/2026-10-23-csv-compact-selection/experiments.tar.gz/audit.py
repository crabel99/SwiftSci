from pathlib import Path
import json,hashlib,statistics,subprocess,collections
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
D=R/'measurement';plan=json.loads((D/'plan.json').read_text())
assert plan==json.loads((R/'preflight/plan.json').read_text())
assert plan['controller_sha256']==h(R/'run-panel.py')
assert len(plan['cases'])==40 and len(plan['orders'])==8
pairs=collections.Counter((a,b) for order in plan['orders'] for a,b in zip(order,order[1:]))
assert len(pairs)==12 and set(pairs.values())=={2}
for label in ['original','prior','current','twin']:
 assert collections.Counter(order.index(label) for order in plan['orders'])=={0:2,1:2,2:2,3:2}
 assert h(R/(('current' if label=='twin' else label)+'-workflow'))==plan['binaries'][label]
module=json.loads((R/'module-build.json').read_text());assert all(h(S/p)==v for p,v in module['sources'].items())
assert h(R/'build/SwiftDataFrame.o')==module['object_sha256']
for label in ['original','prior','current']:
 receipt=json.loads((R/(label+'-workflow-build.json')).read_text());assert receipt['source_sha256']==h(R/'WorkflowProbe.swift')
strict=json.loads((R/'preflight/strict-inputs.json').read_text());assert len(strict)==14 and all(x['validated'] for x in strict)
for r in strict:
 c=plan['contracts'][r['input']];assert [x['sha256'] for x in r['checks']['columns']]==c['hashes']
 assert [x['nulls'] for x in r['checks']['columns']]==c['null_counts']
pre=json.loads((R/'preflight/decision.json').read_text());assert pre['passed'] and pre['workers']==160
expect=json.loads((R/'preflight/expectations.json').read_text())
rows=[json.loads(line) for line in (D/'workers.jsonl').read_text().splitlines()];assert len(rows)==1280
assert len(set((r['case'],r['engine'],r['round']) for r in rows))==1280
for r in rows:
 assert r['engine']==plan['orders'][r['round']][r['position']]
 assert {k:r[k] for k in ['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256']}==expect[r['case']]
summary=json.loads((D/'summary.json').read_text());flags=[]
for r in summary:
 samples=[x['samples'][0] for x in rows if x['case']==r['case'] and x['engine']==r['engine']]
 assert len(samples)==r['workers']==8
 for k,v in r['medians'].items():
  xs=[x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in samples] if k=='peak_above_baseline_bytes' else [x[k] for x in samples]
  assert statistics.median(xs)==v
for c in plan['cases']:
 key='/'.join(c.values());xs={x['engine']:x['medians'] for x in summary if x['case']==key};a,b=xs['current'],xs['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append({'case':key,'reason':'identical-binary CPU','ratio':ratio})
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':key,'reason':'identical-binary memory'})
assert flags==json.loads((D/'decision.json').read_text())['quality_flags']
provenance=[]
for label,base,root,name in [('original','5d1f89a961106104757f2d8d0b8faba79487d100',Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata'),'build.json'),('prior','5a3523aaff',Path('/private/tmp/swiftsci-csv-compact-consumers-20261023'),'module-build.json')]:
 receipt=json.loads((root/name).read_text())
 for path,digest in receipt['sources'].items():
  source=subprocess.check_output(['git','show',base+':'+path],cwd=S);assert hashlib.sha256(source).hexdigest()==digest
 if label=='prior':assert h(root/'build/SwiftDataFrame.o')==receipt['object_sha256']
 else:assert h(root/'ResourceProbe')==receipt['binary_sha256']
 provenance.append({'label':label,'base':subprocess.check_output(['git','rev-parse',base],cwd=S,text=True).strip(),'all_recorded_sources_match':True,'receipt_sha256':h(root/name)})
(R/'comparator-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
tests={}
for label in ['final-release','final-debug','final-asan']:
 rec=json.loads((R/(label+'-command.json')).read_text());test=json.loads((R/(label+'-summary.json')).read_text())
 assert rec['exit_code']==0 and test['passedTests']==406 and test['failedTests']==test['skippedTests']==0
 assert all(h(S/p)==v for p,v in rec['source_sha256'].items())
 tests[label]={k:test[k] for k in ['passedTests','failedTests','skippedTests']}
stream=json.loads((R/'stream-checks.json').read_text());assert stream['validated'] and len(stream['responses'])==14 and all(x['validated'] for x in stream['responses'])
red=json.loads((R/'gather-red-command.json').read_text());assert red['exit_code']==65
red_log=(R/'gather-red.log').read_text();assert red_log.count('Expectation failed: actual.compactNumericStorage')==3
green=json.loads((R/'gather-green-summary.json').read_text());assert green['passedTests']==3 and green['failedTests']==0
base=subprocess.check_output(['git','rev-parse','5a3523aaff'],cwd=S,text=True).strip()
for path,digest in red['source_sha256'].items():
 if path.startswith('Sources/'):
  before=subprocess.check_output(['git','show',base+':'+path],cwd=S);assert hashlib.sha256(before).hexdigest()==digest
assert subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)==''
audit={'all_outputs_match':True,'strict_csv_reads':14,'strict_stream_reads':14,'preflight_workflows':160,'measured_workers':1280,'case_combinations':40,'replicates_per_label':8,'quality_passed':not flags,'quality_flags':flags,'tests':tests,'branch':subprocess.check_output(['git','branch','--show-current'],cwd=S,text=True).strip(),'prototype_base':'5a3523aaff','change':'compact gather dispatch','production_promotion':False,'current_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'red_tests':3,'green_tests':3}
(R/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
lines=['# Compact selection resource results','','Eight fresh processes per label. CPU includes public CSV construction, requested operations and release. Full output validation is outside timing. All outputs match the original reader. Original is the qualified optional-array reader; prior includes specialization and direct numerical access; current also preserves compact storage through gathering.','','| Case | CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |','|---|---:|---:|---:|']
for c in plan['cases']:
 key='/'.join(c.values());xs={x['engine']:x['medians'] for x in summary if x['case']==key}
 trip=lambda k,den:' / '.join(f'{xs[x][k]/den:.2f}' for x in ['original','prior','current'])
 lines.append(f"| {key} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
lines+=['','Identical-binary flags: '+json.dumps(flags)+'. Flagged cases remain unqualified. These are CPU and allocation measurements, not energy, FLOP or cache measurements.','']
(R/'results.md').write_text('\n'.join(lines));print(json.dumps(audit,indent=2))
