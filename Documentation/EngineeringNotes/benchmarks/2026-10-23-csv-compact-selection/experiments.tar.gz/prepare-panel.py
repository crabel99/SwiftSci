from pathlib import Path
import json,subprocess,re,hashlib
R=Path(__file__).resolve().parent
old=Path('/private/tmp/swiftsci-csv-compact-double-20261023')
s=(old/'WorkflowProbe.swift').read_text()
s=s.replace('var matrix: PreparedNumericMatrix?', 'var matrix: PreparedNumericMatrix?\n        var batch: PreparedNumericBatch?')
s=s.replace('''        case "materialize":''','''        case "batch":
            batch = try output!.prepareNumericBatch(numeric)
        case "matrix":
            matrix = try output!.prepareNumericMatrix(numeric)
        case "materialize":''')
s=s.replace('''        var exportCheck = [String]()''','''        var batchCheck = [String]()
        if let batch {
            for column in 0..<batch.columnCount {
                var d = Digest()
                for row in 0..<batch.rowCount { d.append(batch[row, column]) { $0.integer($1.bitPattern) } }
                batchCheck.append(d.finish())
            }
        }
        var exportCheck = [String]()''')
s=s.replace('output=nil;matrix=nil;exports=[]', 'output=nil;matrix=nil;batch=nil;exports=[]')
s=s.replace('"scalar_bits":scalarBits,', '"scalar_bits":scalarBits,"batch_sha256":batchCheck,')
(R/'WorkflowProbe.swift').write_text(s)
# Recompile every comparator from exactly the same client source and correct interface/object pairs.
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('original',F),('prior',Path('/private/tmp/swiftsci-csv-compact-consumers-20261023/build')),('current',R/'build')]:
 cmd=[a.replace(str(F),str(D)) for a in base]
 cmd=[str(R/'WorkflowProbe.swift') if a.endswith('/ResourceProbe.swift') else str(R/(label+'-workflow')) if a==str(D/'ResourceProbe') else a for a in cmd]+['-Rmodule-loading']
 with (R/(label+'-workflow-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'-workflow-build.log')).read_text()[-3000:]);raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-workflow-build.log')).read_text()))
 assert loaded.get('SwiftDataFrame')==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-workflow-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':hashlib.sha256((R/'WorkflowProbe.swift').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((R/(label+'-workflow')).read_bytes()).hexdigest()},indent=2)+'\n')
 print(label,'client built with matching interface',flush=True)
