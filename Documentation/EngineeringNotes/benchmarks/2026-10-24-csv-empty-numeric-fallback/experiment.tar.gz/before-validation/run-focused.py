from pathlib import Path
import subprocess,json,time,hashlib
r=Path(__file__).parent
binary=Path('/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/Debug/SwiftDataFrameTests.xctest/Contents/MacOS/SwiftDataFrameTests')
digest=hashlib.sha256(binary.read_bytes()).hexdigest();bundle=r/'focused-tests.xcresult'
cmd=['xcodebuild','test-without-building','-xctestrun','/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/SwiftSci-Package_SwiftSci-Package_macosx27.0-arm64.xctestrun','-destination','platform=macOS,arch=arm64','-parallel-testing-enabled','NO','-only-testing:SwiftDataFrameTests/CSVEmptyNumericTests','-enableCodeCoverage','NO','-resultBundlePath',str(bundle)]
t=time.time()
with (r/'focused-tests.log').open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=300)
summary=json.loads(subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(bundle),'--format','json'],text=True))
assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
(r/'focused-tests.json').write_text(json.dumps(dict(command=cmd,seconds=time.time()-t,exit_code=p.returncode,binary_sha256=digest,summary=summary),indent=2)+'\n')
print({k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests']});assert p.returncode==0 and summary['totalTestCount']>0 and summary['failedTests']==summary['skippedTests']==0
