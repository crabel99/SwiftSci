from pathlib import Path
import hashlib,json,statistics,sys
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
R=Path(__file__).parent
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
from Benchmarks.CPUThroughput.budget import jobs_for
from Benchmarks.CPUThroughput.audit import control_flags
from runner import power_state
from schema_contract import effective_options
D=R/'fallback-reference-workflows';D.mkdir()
binaries={'parent':Path('/private/tmp/swiftsci-csv-scan-20261024/nibble-build/worker'),'candidate':R/'fallback-build/worker'}
reference=json.loads(Path('/private/tmp/swiftsci-cpu-throughput-panel-20261024/plan.json').read_text())
cases=reference['cases']
expected_path=Path('/private/tmp/swiftsci-sort-closeout-20261023/comparison-initialized/expected.json')
expected=json.loads(expected_path.read_text())
receipts={name:json.loads(binary.with_name('build.json').read_text()) for name,binary in binaries.items()}
assert receipts['parent']['dependencies']==receipts['candidate']['dependencies']
assert [k for k in receipts['parent']['sources'] if receipts['parent']['sources'][k]!=receipts['candidate']['sources'].get(k)]==['Sources/SwiftDataFrame/IO/CSVColumnConversion.swift']
for name,binary in binaries.items():
 run.verify_uninstrumented(binary)
 assert run.digest(binary)==receipts[name]['binary_sha256']
for k,v in receipts['candidate']['sources'].items():assert run.digest(S/k)==v
contracts={c['contract']:json.loads(Path(c['contract']).read_text()) for c in cases}
for path,contract in contracts.items():assert run.digest(Path(contract['path']))==contract['sha256']
effective={name:effective_options(receipt,contracts) for name,receipt in receipts.items()}
assert effective["parent"]==effective["candidate"]
labels=[name+'_'+storage for storage in ['optional','compact'] for name in binaries]
labels=labels+[x+'_twin' for x in labels]
orders=[labels[i:]+labels[:i] for i in range(8)]
limits=dict(twin_cpu_deviation=.10,twin_wall_deviation=.10,twin_peak_relative=1.05,twin_peak_slack_per_caller_bytes=8*2**20)
plan=dict(binaries={k:str(v) for k,v in binaries.items()},receipts=receipts,effective_read_options=effective,cases=cases,contracts=contracts,expected_sha256=run.digest(expected_path),orders=orders,callers=4,copies_per_case=32,quality_policy=limits,power=run.power(),power_settings=power_state(),environment=run.environment(),state=run.system_state(),scope='Fixed 128-job queue; native CPU parallelism; same contracts and output checks; no timing-driven tuning during panel')
run.save(D/'plan.json',plan);run.save(D/'expected.json',expected)
for name,binary in binaries.items():
 d=D/(name+'-preflight');d.mkdir();run.preflight(binary,cases,expected,d)
records=[]
try:
 for i,order in enumerate(orders):
  run.power()
  for label in order:
   run.power()
   base=label.removesuffix('_twin');name,storage=base.split('_')
   directory=D/f'r{i}-{label}'
   summary=run.batch(binaries[name],storage,jobs_for(cases,32,i),4,directory,rss_limit_bytes=4*2**30)
   records.append(dict(round=i,label=label,summary=summary))
   run.save(D/'records.json',records)
  print('round',i+1,'of',len(orders),flush=True)
 for name,binary in binaries.items():
  d=D/(name+'-postflight');d.mkdir();run.preflight(binary,cases,expected,d)
 end=dict(power=run.power(),power_settings=power_state(),state=run.system_state())
 run.save(D/'end.json',end)
 assert end['power_settings']==plan['power_settings'],'Power policy changed during panel'
except BaseException as e:
 run.save(D/'failure.json',dict(error=str(e)));raise
metrics=['charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes','completed_per_minute','sampled_resident_byte_seconds','retained_rss_bytes']
medians={label:{key:statistics.median(r['summary'][key] for r in records if r['label']==label) for key in metrics} for label in labels}
flags=control_flags(medians,limits,{label:4 for label in labels})
pooled={label:{key:statistics.median(r['summary'][key] for r in records if r['label'].removesuffix('_twin')==label) for key in metrics} for label in labels[:4]}
case_cpu={}
for label in labels[:4]:
 queues=[]
 for r in records:
  if r['label'].removesuffix('_twin')!=label:continue
  raw=json.loads((D/f"r{r['round']}-{r['label']}"/'result.json').read_text())
  queues.append({case['input']+'/'+case['workflow']:statistics.mean(j['cpu_ns'] for j in raw['jobs'] if (j['input'],j['workflow'])==(case['input'],case['workflow'])) for case in cases})
 case_cpu[label]={key:statistics.median(q[key] for q in queues) for key in queues[0]}
paired={}
for storage in ['optional','compact']:
 ratios=[]
 for i in range(8):
  row={}
  for name in binaries:
   row[name]=statistics.median(r['summary']['charged_cpu_ns'] for r in records if r['round']==i and r['label'].removesuffix('_twin')==name+'_'+storage)
  ratios.append(row['candidate']/row['parent'])
 paired[storage]=dict(cpu_ratios=ratios,median=statistics.median(ratios),rounds_lower_cpu=sum(x<1 for x in ratios))
result=dict(paired=paired,qualified=not flags,flags=flags,queues=len(records),jobs=128*len(records),medians=pooled,per_case_operation_cpu_ns=case_cpu)
bounds=[]
for r in records:
 raw=json.loads((D/f"r{r['round']}-{r['label']}"/'result.json').read_text())
 bounds.append(dict(round=r['round'],label=r['label'],sum_kernel_peak_bytes=sum(x['peak_bytes'] for x in raw['after'])))
run.save(D/'kernel-bounds.json',bounds)
result['max_sum_kernel_peak_bytes']=max(x['sum_kernel_peak_bytes'] for x in bounds)
result['all_kernel_peak_sums_within_4GiB']=all(x['sum_kernel_peak_bytes']<=4*2**30 for x in bounds)
run.save(D/'decision.json',result)
print(json.dumps(result,indent=2))
