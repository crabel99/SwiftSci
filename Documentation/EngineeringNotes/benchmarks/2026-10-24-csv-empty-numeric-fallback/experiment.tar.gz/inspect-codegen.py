from pathlib import Path
import subprocess,json
r=Path(__file__).parent
paths={'parent':Path('/private/tmp/swiftsci-csv-scan-20261024/nibble-build/SwiftDataFrame.o'),'guards':r/'candidate-build/SwiftDataFrame.o','fallback':r/'fallback-build/SwiftDataFrame.o'}
sets={}
for key,path in paths.items():
 raw=subprocess.check_output(['nm','-nm',str(path)],text=True)
 text=subprocess.check_output(['xcrun','swift-demangle'],input=raw,text=True);(r/(key+'-symbols.txt')).write_text(text)
 records=[]
 for line in text.splitlines():
  if '(__TEXT,__text)' not in line:continue
  address,rest=line.split(' (__TEXT,__text) ',1);records.append((int(address,16),rest))
 records.sort();addresses=sorted({p[0] for p in records});next_address=dict(zip(addresses,addresses[1:]));functions={}
 for address,name in records:
  if 'CSVColumnAttempt' in name and ('appendRows' in name or 'CSVColumnAttempt.append' in name) and address in next_address:
   # Symbol-to-next-symbol extent, not runtime instruction counts or cache measurements.
   name=name[name.index('generic specialization'):] if 'generic specialization' in name else name
   functions[name]=dict(address=address,symbol_extent_bytes=next_address[address]-address)
 sets[key]=functions
common=set.intersection(*(set(x) for x in sets.values()))
result=dict(method='Matched emitted CSVColumnAttempt append/appendRows specializations, using nm symbol-to-next-symbol extents. Not retired instructions or measured instruction-cache usage.',matched_functions=len(common),totals={key:sum(f[name]['symbol_extent_bytes'] for name in common) for key,f in sets.items()},functions={name:{key:f[name] for key,f in sets.items()} for name in sorted(common)})
(r/'codegen-summary.json').write_text(json.dumps(result,indent=2)+'\n');print({k:result[k] for k in ['matched_functions','totals']})
