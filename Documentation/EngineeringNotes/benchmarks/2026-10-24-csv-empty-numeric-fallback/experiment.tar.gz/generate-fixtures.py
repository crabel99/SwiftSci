"""Generate fixed diagnostic inputs and independent native-bit output fingerprints."""
from pathlib import Path
import csv,hashlib,io,json,struct,sys
r=Path(sys.argv[1]);r.mkdir(parents=True,exist_ok=False)
names=['x']+[f'x{i}' for i in range(1,16)]
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
fixtures=[('empty-double',[''],'Double',['?']),('empty-int',[''],'Int64',['?']),
 ('valid-double',['123.125'],'Double',['?']),('empty-default',[''],'Double',['','NA','na','N/A','n/a','null','NULL','NaN','nan','None']),
 ('mixed-double',['0','123.125','','?','-0.0','1.5e2','  2.25 ','"3.5"'],'Double',['?']),
 ('mixed-int',['0','123','','?','-42','+15','  25 ','"35"'],'Int64',['?']),('valid-int',['123'],'Int64',['?'])]
expected={};cases=[]
for i,(kind,values,typ,nulls) in enumerate(fixtures):
 text=','.join(names)+'\n'+'\n'.join(','.join(values[(row+col)%len(values)] for col in range(16)) for row in range(1003))+'\n'
 f=r/(kind+'.csv');f.write_text(text)
 contract=dict(id=kind,path=str(f),rows=1003,names=names,types=[typ]*16,null_tokens=nulls,delimiter=',',sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 p=r/(kind+'.json');save(p,contract);columns=[];rows=list(csv.reader(io.StringIO(text)))[1:]
 for col,name in enumerate(names):
  encoded=bytearray();missing=0
  for row in rows:
   token=row[col].strip()
   if token in nulls or not token:encoded.append(0);missing+=1
   else:encoded.append(1);encoded.extend(struct.pack('<d',float(token)) if typ=='Double' else struct.pack('<q',int(token)))
  columns.append(dict(name=name,type=typ,nulls=missing,sha256=hashlib.sha256(encoded).hexdigest()))
 expected[kind+'/read']=dict(frame=dict(rows=1003,columns=columns),matrix_sha256='absent')
 cases.append(dict(id=i,contract=str(p),workflow='read',input=kind,key='x',verify=False))
save(r/'expected.json',expected);save(r/'cases.json',cases)
