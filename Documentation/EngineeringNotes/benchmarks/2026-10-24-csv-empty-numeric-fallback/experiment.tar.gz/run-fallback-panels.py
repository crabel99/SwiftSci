from pathlib import Path
import subprocess,json,sys
r=Path(__file__).parent
for stage,directory in [('diagnostics','fallback-diagnostics'),('controls','fallback-control-workflows'),('reference','fallback-reference-workflows')]:
 with (r/('fallback-'+stage+'.log')).open('w') as out:
  p=subprocess.run([sys.executable,str(r/('fallback-'+stage+'.py'))],stdout=out,stderr=subprocess.STDOUT,timeout=900)
 assert p.returncode==0,stage
 subprocess.run([sys.executable,str(r/'audit-workflows.py'),directory],check=True)
 d=json.loads((r/directory/'decision.json').read_text());print(stage,'qualified',d['qualified'],d['flags'],flush=True)
 assert d['qualified'],stage
