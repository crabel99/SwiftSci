from pathlib import Path
import json,subprocess,hashlib
r=Path(__file__).parent;s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
def load(p):return json.loads((r/p).read_text())
final=load('fallback-reference-workflows/decision.json');diagnostic=load('fallback-diagnostics/decision.json');controls=load('fallback-control-workflows/decision.json');guards=load('reference-workflows/decision.json')
for d in [final,diagnostic,controls]:assert d['qualified'] and not d['flags']
tests={mode:load('after-validation/compact-'+mode+'-tests.json') for mode in ['debug','release']}
for d in tests.values():assert d['exit_code']==0 and d['summary']['failedTests']==d['summary']['skippedTests']==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();receipt=load('fallback-build/build.json')
for p,h in receipt['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+p],cwd=s)).hexdigest()==h
summary=dict(branch='codex/csv-empty-numeric-fallback',head=head,parent='2a8f1230667eaa86cd72a67b5e78b2b3830f2c23',selected_variant='shared non-inlined numeric fallback',native_tests={m:{k:d['summary'][k] for k in ['totalTestCount','passedTests','failedTests','skippedTests']} for m,d in tests.items()},reference=final,diagnostic=diagnostic,isolated_controls=controls,first_guard_variant=guards,source_matches_measured_commit=True)
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
def table(d,case):
 rows=[]
 for storage in ['optional','compact']:
  a=d['per_case_operation_cpu_ns']['parent_'+storage][case];b=d['per_case_operation_cpu_ns']['candidate_'+storage][case]
  rows.append(f'| {case.removesuffix("/read")} | {storage} | {a/1e6:.3f} | {b/1e6:.3f} | {(b/a-1)*100:+.2f}% |')
 return '\n'.join(rows)
reference=[]
for storage in ['optional','compact']:
 a=final['medians']['parent_'+storage];b=final['medians']['candidate_'+storage]
 reference.append(f'| {storage} | {a["charged_cpu_ns"]/128/1e6:.2f} | {b["charged_cpu_ns"]/128/1e6:.2f} | {(b["charged_cpu_ns"]/a["charged_cpu_ns"]-1)*100:+.2f}% | {(b["completed_per_minute"]/a["completed_per_minute"]-1)*100:+.2f}% | {a["sampled_peak_rss_bytes"]/2**20:.1f} → {b["sampled_peak_rss_bytes"]/2**20:.1f} |')
ctrl=[]
for storage in ['optional','compact']:
 for key,a in controls['per_case_operation_cpu_ns']['parent_'+storage].items():
  b=controls['per_case_operation_cpu_ns']['candidate_'+storage][key];ctrl.append(f'| {key.removesuffix("/read")} | {storage} | {(b/a-1)*100:+.2f}% |')
text=f'''# Empty numeric CSV fields avoid the string fallback

Retain the shared-fallback implementation locally as `{head}` on `codex/csv-empty-numeric-fallback`, based on the [retained structural-scanner change](../2026-10-24-csv-structural-mask/README.md) at `2a8f1230667eaa86cd72a67b5e78b2b3830f2c23`. No branch was pushed and no PR was opened. Engineering evidence remains on `codex/engineering-notes`.

The demonstrated benefit is narrow and substantial. Raw empty numeric fields with a custom null list containing only `?` use about 98% less CPU in the matched diagnostic. Ordinary real-data workflows are close to neutral, with nominal aggregate CPU reductions of about 1% in one qualified panel. No universal CSV speedup or new memory reduction is established.

## Remove unnecessary work without changing null policy

A custom null list replaces the defaults. If it excludes the empty string, a raw empty field is an invalid numeric value. An explicit numeric schema converts it to nil. Inference must reject that numeric candidate and preserve the original text when it falls back to a String column. Calling it missing unconditionally would change the API contract.

Previously, both numeric decoders could construct a String and invoke whitespace trimming before arriving at nil. A private generic function now handles this fallback for Int64 and Double. It returns nil for a zero-length field before constructing a String. The existing decoder performs null matching first and maps nil to invalid for inference. Recognized missing fields keep their existing classification.

`@inline(never)` keeps this conversion outside the inlined numeric decoders. Successful byte parsing still returns directly. The compiler emits two specialized fallback functions. Quoted-empty and whitespace-only fields retain their original conversion behavior; their performance is not optimized here. No public API, storage default, package minimum, framing rule, numerical parser, or concurrency policy changes.

## Targeted mixed queue

Six fixed cases use 1,003 rows and 16 numeric columns. They cover empty Int64 and Double fields, mixed valid/empty/custom-null/quoted/whitespace numeric fields, valid Doubles, and recognized empty defaults. Each queue has 384 reads and four concurrent callers. Eight rotated rounds include an identical-binary twin for each build and storage mode, for 24,576 completed reads and 48 full-output checks.

| Case | Storage | Parent CPU ms/read | Candidate CPU ms/read | CPU change |
| --- | --- | ---: | ---: | ---: |
{table(diagnostic,'empty-double/read')}
{table(diagnostic,'empty-int/read')}
{table(diagnostic,'mixed-double/read')}
{table(diagnostic,'mixed-int/read')}

These are operation CPU costs inside the mixed queue. Valid-only/default-null jobs also appear cheaper while running alongside the repaired empty-field jobs. That observation does not establish faster numeric parsing. Separate isolated controls remove those expensive neighbors.

| Isolated control | Storage | Operation CPU change |
| --- | --- | ---: |
{chr(10).join(ctrl)}

The isolated panel completes 49,152 reads and 24 full-output checks. CPU is close to the parent across these controls. All fixtures and expected native-bit fingerprints reproduce exactly with `generate-fixtures.py`.

## Complete real-data workflows

The reference panel completes 8,192 jobs in 64 queues, with four callers, 128 jobs per queue, and 32 full-output checks. It uses 35,064 Aotizhongxin observations and 2,075,259 household electricity records. Each input is read alone or read, stably sorted, and converted to its numeric matrix.

| Storage | Parent CPU ms/job | Candidate CPU ms/job | CPU change | Throughput change | Peak RSS MiB, parent → candidate |
| --- | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(reference)}

Both reference null lists include the empty string, so raw empty fields already exit through recognized-null handling. This panel is primarily a regression check for the changed decoder code, not direct evidence that bypassing empty-string conversion accelerates these inputs. Some individual cases move slightly in either direction. One panel does not establish a general 1% gain.

The final diagnostic, isolated-control, and reference panels pass the unchanged 10% twin CPU/wall limits and 5% plus 8 MiB-per-caller RSS limits. Every conservative sum of kernel-reported worker peaks remains below 4 GiB. RSS is effectively unchanged. Raw accounting is recomputed independently of the reported medians.

## The first implementation remains in the record

The first candidate put four empty checks directly in the inlined decoders. Its qualified diagnostic also removes most empty-field CPU work. Its real-data panel, however, measures 1.52% more charged CPU with optional storage and 1.10% more with compact storage. That version is not retained.

A first short diagnostic fails repeatability, with three twin CPU/wall flags. It is preserved as unqualified. A conservative cost forecast allows a longer diagnostic; no tolerance changes were made. The forecast is an estimate, not a runtime guarantee.

Fifteen matched append/appendRows specializations have symbol-to-next-symbol extents totaling 37,404 bytes in the parent, 37,040 in the direct-guard candidate, and 35,140 in the shared-fallback candidate. The first candidate's functions did not simply grow. These code-size observations do not prove why its timing differs, measure instruction-cache utilization, or establish a causal cache explanation.

## Correctness, build identity, and scope

The three new semantic test functions pass against the unchanged parent before implementation. They protect missing-versus-invalid classification, explicit-schema nil values, quoted-empty and whitespace behavior, both Double storage modes, and preservation of late empty text after the inference sample. There is no failing-before semantic test because the original results were correct. The reproduced defect is unnecessary resource consumption.

All {tests['debug']['summary']['passedTests']} dataframe tests pass in Debug and all {tests['release']['summary']['passedTests']} pass in Release, with no failures or skips. The baseline build succeeded; an initial local runner path replacement failed before test execution, then the corrected runner executed the focused suite successfully. Both runner records are preserved. No full MLX suite, hosted CI, or coverage result is claimed.

Independent fingerprints check every output column's type, values, native numeric bits, null counts, and matrix output before and after each qualified panel. Timed work receives shape/type checks; hashing is outside timing. All workers use a complete explicit schema. Inference semantics are tested, but inference speed is not measured.

All 51 parent source hashes match the scanner commit. Both candidates have the same dependency hashes and reviewed worker source; only `CSVColumnConversion.swift` differs among measured library sources. The final local commit maps to the exact source hashes recorded during compilation. Historical build heads and dirty-source receipts remain unchanged.

Timing panels run sequentially, without experiment compilation, tests, or native sampling. Native test builds start after timing completes. AC power and recorded power settings are unchanged within each panel. CPU parallelism is native; the four callers are not four pinned cores. CPU measures summed worker user/system time plus measured controller CPU, including cleanup. It is not FLOPs, normalized P/E-core work, or energy. Sampled RSS can miss short peaks and double-count shared pages. No GPU, Neural Engine, cold disk, or cache efficiency claim follows.

## Reproduce and inspect

[Summary](summary.json), [artifact hashes](artifact-sha256.json), and [experiment archive](experiment.tar.gz) preserve source snapshots, source patches, compiler receipts, fixture generation, independent fingerprints, all seven panels including the unqualified short panel, raw job/CPU/RSS records, code-size inspection, and test summaries/logs. Executables, objects, module caches, raw CSVs, and xcresult bundles are excluded.

Restore the recorded source and matching dependencies, remap absolute paths, regenerate diagnostic inputs, and obtain the reference files matching the recorded SHA256 values. Build immutable workers with `Benchmarks/CPUThroughput/build.py`. Run `fallback-diagnostics.py`, `fallback-controls.py`, and `fallback-reference.py` sequentially in fresh directories, then recompute each with `audit-workflows.py`. Run the preserved native validation script separately from timing. The measured host/compiler/deployment settings are in the receipts; no other host or older runtime result is implied.
'''
(r/'README.md').write_text(text)
print('Report and summary written for',head)
