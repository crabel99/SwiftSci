from pathlib import Path
import json,subprocess,hashlib,time
R=Path(__file__).resolve().parent
P=Path('/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/Release')
M=P.parent.parent/'Intermediates.noindex/GeneratedModuleMaps/ArrowC.modulemap'
A=Path('/Users/crabel/Library/Caches/SwiftSci/xcode-packages/checkouts/swift-atomics/Sources/_AtomicsShims/include/module.modulemap')
SDK=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()
common=['-package-name','SwiftSci','-O','-whole-module-optimization','-swift-version','6','-enable-upcoming-feature','ExistentialAny','-target','arm64-apple-macos14.0','-sdk',SDK,'-I',str(P),'-Xcc','-fmodule-map-file='+str(M),'-Xcc','-fmodule-map-file='+str(A),'-module-cache-path',str(R/'module-cache')]
variants=json.loads((R/'variants.json').read_text());objects=[];includes=[];receipts=[]
for label,v in variants.items():
 D=R/'build'/label;D.mkdir(parents=True,exist_ok=True)
 sources=sorted((Path(v['path'])/'Sources/SwiftDataFrame').rglob('*.swift'))
 hashes={str(s.relative_to(v['path'])):hashlib.sha256(s.read_bytes()).hexdigest() for s in sources}
 if label=='actual':
  old=json.loads(Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata/build.json').read_text())
  assert hashes==old['sources'],'actual source changed'
  obj=Path(v['object']);includes.extend(['-I',str(obj.parent)]);objects.append(str(obj));receipts.append({'label':label,'reuse_verified':True,'sources':hashes,'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest()});continue
 obj=D/(v['module']+'.o')
 cmd=['xcrun','swiftc',*common,'-parse-as-library','-module-name',v['module'],'-emit-module','-emit-module-path',str(D/(v['module']+'.swiftmodule')),'-emit-object','-o',str(obj),*[str(s) for s in sources]]
 receipt={'label':label,'command':cmd,'sources':hashes};path=D/'receipt.json'
 if not path.exists() or any(json.loads(path.read_text()).get(k)!=receipt[k] for k in receipt):
  start=time.time()
  with (D/'build.log').open('w') as f: result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  if result.returncode:print((D/'build.log').read_text()[-6000:]);raise SystemExit(result.returncode)
  receipt['seconds']=time.time()-start;receipt['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest();path.write_text(json.dumps(receipt,indent=2)+'\n')
  print(label,'compiled',round(receipt['seconds'],1),flush=True)
 includes.extend(['-I',str(D)]);objects.append(str(obj));receipts.append(json.loads(path.read_text()))
cmd=['xcrun','swiftc',*common,*includes,'-parse-as-library',str(R/'PairedProbe.swift'),*objects,*[str(P/(s+'.o')) for s in ['Arrow','ArrowC','FlatBuffers','Atomics','_AtomicsShims']],'-framework','Accelerate','-lcompression','-o',str(R/'PairedProbe')]
with (R/'link.log').open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
if result.returncode:print((R/'link.log').read_text()[-8000:]);raise SystemExit(result.returncode)
(R/'build.json').write_text(json.dumps({'modules':receipts,'link_command':cmd,'probe_sha256':hashlib.sha256((R/'PairedProbe.swift').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((R/'PairedProbe').read_bytes()).hexdigest()},indent=2)+'\n')
print('paired binary linked',flush=True)
