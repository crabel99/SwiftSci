from pathlib import Path
import json,subprocess,hashlib
R=Path(__file__).resolve().parent
s=(R/'PairedProbe.swift').read_text()
s=s.replace('let tokens = Set(input.null_tokens)','let tokens = Set(input.null_tokens)\n        let mode = args[3]\n        precondition(["shared","independent"].contains(mode))\n        let baselineTokens = mode == "shared" ? tokens : Set(input.null_tokens)\n        let cloneTokens = mode == "shared" ? tokens : Set(input.null_tokens)')
s=s.replace('options_baseline(input,tokens:tokens,','options_baseline(input,tokens:baselineTokens,').replace('options_clone(input,tokens:tokens,','options_clone(input,tokens:cloneTokens,')
s=s.replace('"validated":true,"input":input.id','"table_mode":mode,"table_iteration_orders_match":[Array(actual.nullValues) == Array(baseline.nullValues),Array(actual.nullValues) == Array(clone.nullValues)],"validated":true,"input":input.id')
(R/'PairedTableProbe.swift').write_text(s)
old=json.loads((R/'build.json').read_text());cmd=[a.replace('/PairedProbe.swift','/PairedTableProbe.swift').replace('/PairedProbe','/PairedTableProbe') for a in old['link_command']]
with (R/'table-link.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
if p.returncode:print((R/'table-link.log').read_text()[-5000:]);raise SystemExit(p.returncode)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(R/'table-build.json').write_text(json.dumps({'module_receipt_sha256':h(R/'build.json'),'link_command':cmd,'harness_sha256':h(R/'PairedTableProbe.swift'),'binary_sha256':h(R/'PairedTableProbe')},indent=2)+'\n')
(R/'table-plan.json').write_text(json.dumps({'prediction':'If local Set-table setup explains the remaining difference, independent immutable tables should increase paired CPU-ratio spread or warnings relative to shared tables. Native global hashing remains shared within each worker, so this does not isolate cross-process global hash variation.','sampling':'60 independent workers per case and table mode, interleaved over all six combinations. Same three cases and paired control definitions. No thresholds changed.','memory':'No independent memory qualification in a combined binary.','proof':'Shared mode passes one immutable Set value to all options and plans without mutation. Independent mode builds three Sets before warmup. Iteration-order equality is an observable consistency check, not a public storage-identity API.'},indent=2)+'\n')
# Reuse the audited reducer and measurement loop, extending only the grouping and mode argument.
s=(R/'run.py').read_text()
s=s.replace("D=R/'paired'","cases=[dict(c,table_mode=mode) for c in cases for mode in ['shared','independent']]\nD=R/'table-control'")
s=s.replace("R/'PairedProbe'","R/'PairedTableProbe'").replace("R/'build.json'","R/'table-build.json'")
s=s.replace("R/'plan.json'","R/'table-plan.json'")
s=s.replace('for i in range(3):','for i in range(6):').replace('cases[(rnd+i)%3]','cases[(rnd+i)%6]')
s=s.replace("str(rnd%6)]","str(rnd%6),c['table_mode']]")
s=s.replace("r['policy']==c['policy']]","r['policy']==c['policy'] and r['table_mode']==c['table_mode']]")
s=s.replace("'input':c['id'],'policy':c['policy'],","'input':c['id'],'policy':c['policy'],'table_mode':c['table_mode'],")
s=s.replace("x['input'],x['policy'],x['comparison']","x['input'],x['policy'],x['table_mode'],x['comparison']")
(R/'run-table-control.py').write_text(s)
print('table-control binary linked')
