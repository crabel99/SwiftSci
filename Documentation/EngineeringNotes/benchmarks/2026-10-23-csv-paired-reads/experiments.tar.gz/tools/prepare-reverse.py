from pathlib import Path
import json,subprocess,hashlib
R=Path(__file__).resolve().parent
s=(R/'PairedTableProbe.swift').read_text()
s=s.replace('let b = comparison == "same" ? "actual" : comparison == "namespace" ? "clone" : "baseline"','let b = comparison == "same" ? "actual" : comparison == "namespace" ? "baseline" : "clone"')
assert s!=(R/'PairedTableProbe.swift').read_text()
(R/'ReverseProbe.swift').write_text(s)
old=json.loads((R/'table-build.json').read_text())
original='/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata'
replacement='/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/cleanup'
cmd=[a.replace('/PairedTableProbe.swift','/ReverseProbe.swift').replace('/PairedTableProbe','/ReverseProbe').replace(original,replacement) for a in old['link_command']]
with (R/'reverse-link.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
if p.returncode:print((R/'reverse-link.log').read_text()[-5000:]);raise SystemExit(p.returncode)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(R/'reverse-build.json').write_text(json.dumps({'alias_module_receipt_sha256':h(R/'build.json'),'actual_baseline_receipt_sha256':h(Path(replacement)/'build.json'),'actual_baseline_object_sha256':h(Path(replacement)/'SwiftDataFrame.o'),'link_command':cmd,'harness_sha256':h(R/'ReverseProbe.swift'),'binary_sha256':h(R/'ReverseProbe')},indent=2)+'\n')
(R/'reverse-plan.json').write_text(json.dumps({'purpose':'Reciprocal module identity control. Actual SwiftDataFrame is now the frozen cleanup object, CSVBaseline is the same-source baseline alias, CSVClone is the candidate alias.','prediction':'If module naming or code layout explains the original warning, reversing which implementation keeps its production name changes the candidate-to-baseline ratio. Shared-table same-implementation and baseline-namespace controls must pass.','sampling':'Same interleaved 60 workers per case and table mode. All three cases, native global hashing and scheduling.','ratio':'Summary normalizes candidate-to-baseline CPU for the change comparison by swapping A and B during reduction. Controls stay A divided by B.','limits':'Diagnostic evidence only. Retain earlier warnings and independent memory limitations.'},indent=2)+'\n')
s=(R/'run-table-control.py').read_text().replace("R/'table-control'","R/'reverse-control'").replace("R/'PairedTableProbe'","R/'ReverseProbe'").replace("R/'table-build.json'","R/'reverse-build.json'").replace("R/'table-plan.json'","R/'reverse-plan.json'")
s=s.replace("observations.append({'worker'", "if comp=='change':a,b=b,a\n   observations.append({'worker'")
(R/'run-reverse.py').write_text(s)
print('reciprocal binary linked')
