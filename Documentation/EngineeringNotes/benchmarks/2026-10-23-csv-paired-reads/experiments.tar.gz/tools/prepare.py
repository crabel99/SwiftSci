from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
prior=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022')
base=Path('/private/tmp/swiftsci-csv-prefix-selection-20261022/variants/cleanup')
candidate=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
spec={'baseline':{'path':str(base),'module':'CSVBaseline','commit':'f9a99ce54c77909bdd6f95fadd5fa3b5d15490f2'},'clone':{'path':str(candidate),'module':'CSVClone','commit':'5d1f89a961106104757f2d8d0b8faba79487d100'},'actual':{'path':str(candidate),'module':'SwiftDataFrame','object':str(prior/'build/metadata/SwiftDataFrame.o'),'commit':'5d1f89a961106104757f2d8d0b8faba79487d100'}}
(R/'variants.json').write_text(json.dumps(spec,indent=2)+'\n')
plan={'purpose':'Diagnose the recurring 3392-row parallel streaming CPU difference, not replace prior acceptance results.','hypotheses':[{'rank':1,'cause':'Independent native hash-table setup','prediction':'Paired native workers sharing one immutable token Set reduce the variation compared with independent workers.'},{'rank':2,'cause':'Module identity or generated-code layout','prediction':'An actual-versus-same-source-alias control differs while actual-versus-actual does not.'},{'rank':3,'cause':'Order, allocator, asynchronous scheduling or carry-over state','prediction':'ABBA and BAAB observations differ by position or both same-implementation labels show a warning.'},{'rank':4,'cause':'Production implementation regression','prediction':'Candidate remains over 10 percent more CPU than cleanup while both same-implementation and same-source module controls pass.'}], 'prospective_cases':[{'rows':3392,'nulls':0,'policy':'parallel'},{'rows':3392,'nulls':0,'policy':'serial'},{'rows':3456,'nulls':0,'policy':'parallel'}], 'controls':['actual versus actual, identical adapter function','actual versus same-source CSVClone alias','actual versus cleanup CSVBaseline alias'], 'sampling':'Each worker constructs one immutable native Set and all options retain copies without mutation. Two warmup ABBA blocks, then eight balanced ABBA/BAAB blocks per comparison. Every timed stream checks row count. Full native output digests checked before and after timings per module. Independent native-hash workers, native scheduling. No fixed hashing. Comparison order rotates per worker.', 'thresholds':{'cpu_relative':0.10,'memory_relative':0.05,'memory_absolute_bytes':8388608},'memory_limit':'Single-process high water cannot isolate implementation peak memory. RSS and heap observations describe shared-process state only. No promotion from paired timing alone.','namespace_limit':'Recompiling snapshots under aliases changes mangled names and linked layout. Same-source alias control is mandatory. Actual candidate object remains unmodified.'}
(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
source=Path('/private/tmp/swiftsci-csv-prefix-selection-20261022/StreamRepeatProbe.swift').read_text()
header=source[:source.index('func validate(')].replace('import SwiftDataFrame','import SwiftDataFrame\nimport CSVBaseline\nimport CSVClone')
functions=[]
for label,mod in [('actual','SwiftDataFrame'),('baseline','CSVBaseline'),('clone','CSVClone')]:
 checked=source[source.index('func checkedStream('):source.index('func consume(')].replace('func checkedStream(',f'func checked_{label}(').replace('AsyncThrowingStream<DataFrame,','AsyncThrowingStream<'+mod+'.DataFrame,')
 consume=source[source.index('func consume('):source.index('@MainActor @main')].replace('func consume(',f'func consume_{label}(').replace('AsyncThrowingStream<DataFrame,','AsyncThrowingStream<'+mod+'.DataFrame,')
 options=f'''func options_{label}(_ input: Input, tokens: Set<String>, parallel: Bool) -> {mod}.CSVReadOptions {{
    var options = {mod}.CSVReadOptions()
    options.nullValues = tokens
    options.columnConversionMode = parallel ? .parallel : .serial
    options.delimiter = Character(input.delimiter)
    options.maxRows = input.max_rows
    let mapping: [String: {mod}.ColumnDType] = ["String":.utf8,"Double":.float64,"Int64":.int64,"Date":.date32]
    options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names,input.types).map {{ ($0.0,mapping[$0.1]!) }})
    options.columnDateFormats = input.date_formats ?? [:]
    return options
}}
'''
 functions.append(checked+consume+options)
main='''@MainActor @main struct PairedProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        precondition(ProcessInfo.processInfo.environment["SWIFT_DETERMINISTIC_HASHING"] == nil)
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath:args[0])))
        let parallel = args[1] == "parallel", rotation = Int(args[2])!
        let tokens = Set(input.null_tokens)
        let actual = options_actual(input,tokens:tokens,parallel:parallel)
        let baseline = options_baseline(input,tokens:tokens,parallel:parallel)
        let clone = options_clone(input,tokens:tokens,parallel:parallel)
        let url = URL(fileURLWithPath:input.path)
        func read(_ implementation: String) async throws -> Int {
            switch implementation {
            case "baseline": return try await consume_baseline(CSVBaseline.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:baseline))
            case "clone": return try await consume_clone(CSVClone.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:clone))
            default: return try await consume_actual(SwiftDataFrame.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:actual))
            }
        }
        func check() async throws -> Bool {
            let a = try await checked_actual(SwiftDataFrame.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:actual),input:input)
            let b = try await checked_baseline(CSVBaseline.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:baseline),input:input)
            let c = try await checked_clone(CSVClone.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:clone),input:input)
            return a && b && c
        }
        precondition(try await check())
        var samples = [[String:Any]]()
        let comparisons = ["same","namespace","change"]
        for k in 0..<3 {
            let comparison = comparisons[(rotation+k)%3]
            let b = comparison == "same" ? "actual" : comparison == "namespace" ? "clone" : "baseline"
            for block in -2..<8 {
                let order = (block + rotation) % 2 == 0 ? ["A","B","B","A"] : ["B","A","A","B"]
                for (position,label) in order.enumerated() {
                    let implementation = label == "A" ? "actual" : b
                    let r0 = resident(), h0 = heap(), c0 = cpu(), t0 = DispatchTime.now().uptimeNanoseconds
                    let rows = try await read(implementation)
                    let t1 = DispatchTime.now().uptimeNanoseconds, c1 = cpu(), h1 = heap(), r1 = resident()
                    precondition(rows == input.rows)
                    if block >= 0 { samples.append(["comparison":comparison,"label":label,"implementation":implementation,"block":block,"position":position,"cpu_ns":c1-c0,"elapsed_ns":Int64(t1-t0),"rss_before":r0,"rss_after":r1,"heap_before":h0,"heap_after":h1]) }
                }
            }
        }
        precondition(try await check())
        let result: [String:Any] = ["validated":true,"input":input.id,"policy":args[1],"rotation":rotation,"samples":samples,"native_hash_fingerprint":input.null_tokens.prefix(4).map { $0.hashValue },"process_peak_bytes":peak(),"token_set_count":tokens.count]
        print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),as:UTF8.self))
    }
}
'''
# precondition's autoclosure cannot await or throw.
main=main.replace('precondition(try await check())','let validBefore = try await check()\n        precondition(validBefore)',1)
pos=main.rfind('precondition(try await check())')
main=main[:pos]+main[pos:].replace('precondition(try await check())','let validAfter = try await check()\n        precondition(validAfter)',1)
(R/'PairedProbe.swift').write_text(header+'\n'.join(functions)+main)
