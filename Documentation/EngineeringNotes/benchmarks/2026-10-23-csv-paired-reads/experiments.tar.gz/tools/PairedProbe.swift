import Foundation
import SwiftDataFrame
import CSVBaseline
import CSVClone
import Darwin
import CryptoKit

struct Input: Decodable {
    let id: String, path: String, delimiter: String
    let rows: Int
    let names: [String], types: [String], hashes: [String]
    let null_tokens: [String]
    let integral: [Bool]
    let max_rows: Int?
    let date_formats: [String: String]?
}
func cpu() -> Int64 {
    var r = rusage(); getrusage(RUSAGE_SELF, &r)
    return Int64(r.ru_utime.tv_sec + r.ru_stime.tv_sec) * 1_000_000_000 + Int64(r.ru_utime.tv_usec + r.ru_stime.tv_usec) * 1_000
}
func resident() -> Int64 {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<integer_t>.size)
    let result = withUnsafeMutablePointer(to: &info) { pointer in
        pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    precondition(result == KERN_SUCCESS)
    return Int64(info.resident_size)
}
func heap() -> Int64 {
    var s = malloc_statistics_t(); malloc_zone_statistics(nil, &s)
    return Int64(s.size_in_use)
}
func peak() -> Int64 { var r = rusage(); getrusage(RUSAGE_SELF, &r); return Int64(r.ru_maxrss) }
struct Digest {
    var hash = SHA256(), buffer = Data(), nulls = 0
    mutating func integer<T: FixedWidthInteger>(_ value: T) {
        var value = value.littleEndian
        withUnsafeBytes(of: &value) { buffer.append(contentsOf: $0) }
    }
    mutating func append<T>(_ value: T?, encode: (inout Digest, T) -> Void) {
        if let value { buffer.append(1); encode(&self, value) }
        else { buffer.append(0); nulls += 1 }
        if buffer.count >= 65536 { hash.update(data: buffer); buffer.removeAll(keepingCapacity: true) }
    }
    mutating func finish() -> String {
        hash.update(data: buffer)
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
func checked_actual(_ stream: AsyncThrowingStream<SwiftDataFrame.DataFrame, any Error>, input: Input) async throws -> Bool {
    var hashes = input.names.map { _ in Digest() }
    var rows = 0
    for try await frame in stream {
        guard frame.columnNames == input.names else { return false }
        rows += frame.rowCount
        for (j, name) in input.names.enumerated() {
            guard frame.dtypes[name]?.description == input.types[j] else { return false }
            switch input.types[j] {
            case "Double":
                for value in frame[column: name, as: Double.self]!.values {
                    hashes[j].append(value) { $0.integer($1.bitPattern) }
                }
            case "Int64":
                for value in frame[column: name, as: Int64.self]!.values {
                    hashes[j].append(value) { $0.integer(Double($1).bitPattern) }
                }
            case "Date":
                for value in frame[column: name, as: Date.self]!.values {
                    hashes[j].append(value) { $0.integer($1.timeIntervalSince1970.bitPattern) }
                }
            case "String":
                for value in frame[column: name, as: String.self]!.values {
                    hashes[j].append(value) { digest, value in
                        digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
                    }
                }
            default: return false
            }
        }
    }
    guard rows == input.rows else { return false }
    for j in hashes.indices {
        guard hashes[j].finish() == input.hashes[j] else { return false }
    }
    return true
}
func consume_actual(_ frames: AsyncThrowingStream<SwiftDataFrame.DataFrame, any Error>) async throws -> Int {
    var count = 0
    for try await frame in frames { count += frame.rowCount }
    return count
}
func options_actual(_ input: Input, tokens: Set<String>, parallel: Bool) -> SwiftDataFrame.CSVReadOptions {
    var options = SwiftDataFrame.CSVReadOptions()
    options.nullValues = tokens
    options.columnConversionMode = parallel ? .parallel : .serial
    options.delimiter = Character(input.delimiter)
    options.maxRows = input.max_rows
    let mapping: [String: SwiftDataFrame.ColumnDType] = ["String":.utf8,"Double":.float64,"Int64":.int64,"Date":.date32]
    options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names,input.types).map { ($0.0,mapping[$0.1]!) })
    options.columnDateFormats = input.date_formats ?? [:]
    return options
}

func checked_baseline(_ stream: AsyncThrowingStream<CSVBaseline.DataFrame, any Error>, input: Input) async throws -> Bool {
    var hashes = input.names.map { _ in Digest() }
    var rows = 0
    for try await frame in stream {
        guard frame.columnNames == input.names else { return false }
        rows += frame.rowCount
        for (j, name) in input.names.enumerated() {
            guard frame.dtypes[name]?.description == input.types[j] else { return false }
            switch input.types[j] {
            case "Double":
                for value in frame[column: name, as: Double.self]!.values {
                    hashes[j].append(value) { $0.integer($1.bitPattern) }
                }
            case "Int64":
                for value in frame[column: name, as: Int64.self]!.values {
                    hashes[j].append(value) { $0.integer(Double($1).bitPattern) }
                }
            case "Date":
                for value in frame[column: name, as: Date.self]!.values {
                    hashes[j].append(value) { $0.integer($1.timeIntervalSince1970.bitPattern) }
                }
            case "String":
                for value in frame[column: name, as: String.self]!.values {
                    hashes[j].append(value) { digest, value in
                        digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
                    }
                }
            default: return false
            }
        }
    }
    guard rows == input.rows else { return false }
    for j in hashes.indices {
        guard hashes[j].finish() == input.hashes[j] else { return false }
    }
    return true
}
func consume_baseline(_ frames: AsyncThrowingStream<CSVBaseline.DataFrame, any Error>) async throws -> Int {
    var count = 0
    for try await frame in frames { count += frame.rowCount }
    return count
}
func options_baseline(_ input: Input, tokens: Set<String>, parallel: Bool) -> CSVBaseline.CSVReadOptions {
    var options = CSVBaseline.CSVReadOptions()
    options.nullValues = tokens
    options.columnConversionMode = parallel ? .parallel : .serial
    options.delimiter = Character(input.delimiter)
    options.maxRows = input.max_rows
    let mapping: [String: CSVBaseline.ColumnDType] = ["String":.utf8,"Double":.float64,"Int64":.int64,"Date":.date32]
    options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names,input.types).map { ($0.0,mapping[$0.1]!) })
    options.columnDateFormats = input.date_formats ?? [:]
    return options
}

func checked_clone(_ stream: AsyncThrowingStream<CSVClone.DataFrame, any Error>, input: Input) async throws -> Bool {
    var hashes = input.names.map { _ in Digest() }
    var rows = 0
    for try await frame in stream {
        guard frame.columnNames == input.names else { return false }
        rows += frame.rowCount
        for (j, name) in input.names.enumerated() {
            guard frame.dtypes[name]?.description == input.types[j] else { return false }
            switch input.types[j] {
            case "Double":
                for value in frame[column: name, as: Double.self]!.values {
                    hashes[j].append(value) { $0.integer($1.bitPattern) }
                }
            case "Int64":
                for value in frame[column: name, as: Int64.self]!.values {
                    hashes[j].append(value) { $0.integer(Double($1).bitPattern) }
                }
            case "Date":
                for value in frame[column: name, as: Date.self]!.values {
                    hashes[j].append(value) { $0.integer($1.timeIntervalSince1970.bitPattern) }
                }
            case "String":
                for value in frame[column: name, as: String.self]!.values {
                    hashes[j].append(value) { digest, value in
                        digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
                    }
                }
            default: return false
            }
        }
    }
    guard rows == input.rows else { return false }
    for j in hashes.indices {
        guard hashes[j].finish() == input.hashes[j] else { return false }
    }
    return true
}
func consume_clone(_ frames: AsyncThrowingStream<CSVClone.DataFrame, any Error>) async throws -> Int {
    var count = 0
    for try await frame in frames { count += frame.rowCount }
    return count
}
func options_clone(_ input: Input, tokens: Set<String>, parallel: Bool) -> CSVClone.CSVReadOptions {
    var options = CSVClone.CSVReadOptions()
    options.nullValues = tokens
    options.columnConversionMode = parallel ? .parallel : .serial
    options.delimiter = Character(input.delimiter)
    options.maxRows = input.max_rows
    let mapping: [String: CSVClone.ColumnDType] = ["String":.utf8,"Double":.float64,"Int64":.int64,"Date":.date32]
    options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names,input.types).map { ($0.0,mapping[$0.1]!) })
    options.columnDateFormats = input.date_formats ?? [:]
    return options
}
@MainActor @main struct PairedProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        precondition(ProcessInfo.processInfo.environment["SWIFT_DETERMINISTIC_HASHING"] == nil)
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath:args[0])))
        let parallel = args[1] == "parallel", rotation = Int(args[2])!
        let tokens = Set(input.null_tokens)
        let actual = options_actual(input,tokens:tokens,parallel:parallel)
        let baseline = options_baseline(input,tokens:tokens,parallel:parallel)
        let clone = options_clone(input,tokens:tokens,parallel:parallel)
        let url = URL(fileURLWithPath:input.path)
        func read(_ implementation: String) async throws -> Int {
            switch implementation {
            case "baseline": return try await consume_baseline(CSVBaseline.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:baseline))
            case "clone": return try await consume_clone(CSVClone.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:clone))
            default: return try await consume_actual(SwiftDataFrame.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:actual))
            }
        }
        func check() async throws -> Bool {
            let a = try await checked_actual(SwiftDataFrame.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:actual),input:input)
            let b = try await checked_baseline(CSVBaseline.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:baseline),input:input)
            let c = try await checked_clone(CSVClone.DataFrame.readCSVStream(contentsOf:url,chunkSize:input.rows,options:clone),input:input)
            return a && b && c
        }
        let validBefore = try await check()
        precondition(validBefore)
        var samples = [[String:Any]]()
        let comparisons = ["same","namespace","change"]
        for k in 0..<3 {
            let comparison = comparisons[(rotation+k)%3]
            let b = comparison == "same" ? "actual" : comparison == "namespace" ? "clone" : "baseline"
            for block in -2..<8 {
                let order = (block + rotation) % 2 == 0 ? ["A","B","B","A"] : ["B","A","A","B"]
                for (position,label) in order.enumerated() {
                    let implementation = label == "A" ? "actual" : b
                    let r0 = resident(), h0 = heap(), c0 = cpu(), t0 = DispatchTime.now().uptimeNanoseconds
                    let rows = try await read(implementation)
                    let t1 = DispatchTime.now().uptimeNanoseconds, c1 = cpu(), h1 = heap(), r1 = resident()
                    precondition(rows == input.rows)
                    if block >= 0 { samples.append(["comparison":comparison,"label":label,"implementation":implementation,"block":block,"position":position,"cpu_ns":c1-c0,"elapsed_ns":Int64(t1-t0),"rss_before":r0,"rss_after":r1,"heap_before":h0,"heap_after":h1]) }
                }
            }
        }
        let validAfter = try await check()
        precondition(validAfter)
        let result: [String:Any] = ["validated":true,"input":input.id,"policy":args[1],"rotation":rotation,"samples":samples,"native_hash_fingerprint":input.null_tokens.prefix(4).map { $0.hashValue },"process_peak_bytes":peak(),"token_set_count":tokens.count]
        print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),as:UTF8.self))
    }
}
