from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
P=Path('/private/tmp/swiftsci-csv-compact-sorting-20261023');F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(S/'Sources/SwiftDataFrame/Columns/TypedColumn.swift').read_text()
helper='''
private func traceSortArray<T>(_ label: String, _ values: [T]) {
    values.withUnsafeBufferPointer { buffer in
        let entry: [String: Any] = ["event": label, "count": values.count,
            "capacity": values.capacity, "stride": MemoryLayout<T>.stride,
            "pointer": buffer.baseAddress.map { String(UInt(bitPattern: $0), radix: 16) } ?? "nil"]
        var data = try! JSONSerialization.data(withJSONObject: entry, options: [.sortedKeys])
        data.append(10)
        FileHandle.standardError.write(data)
    }
}
'''
source+=helper
source=source.replace('    tagged.reserveCapacity(validCount)','    tagged.reserveCapacity(validCount)\n    traceSortArray("adaptive-reserve", tagged)')
source=source.replace('            tagged.removeAll(keepingCapacity: false)','            traceSortArray("adaptive-before-release", tagged)\n            tagged.removeAll(keepingCapacity: false)\n            traceSortArray("adaptive-after-release", tagged)')
source=source.replace('    var keys = [UInt64](repeating: 0, count: values.count)','    var keys = [UInt64](repeating: 0, count: values.count)\n    traceSortArray("radix-keys", keys)')
a='''            return TypedColumn(name: name, compactColumn: compact.gathered(at: indices))'''
b='''            let output = compact.gathered(at: indices)
            traceSortArray("gather-" + name, output.values)
            return TypedColumn<Double>(name: name, compactColumn: output)'''
assert source.count(a)==1;source=source.replace(a,b)
D=R/'trace-build';D.mkdir(exist_ok=True);overlay=D/'TypedColumn.swift';overlay.write_text(source)
base=json.loads((F/'build.json').read_text());cmd=[a.replace(str(F),str(D)) for a in base['commands'][0]]
cmd=[str(overlay) if a.endswith('/Sources/SwiftDataFrame/Columns/TypedColumn.swift') else a for a in cmd]
with (R/'trace-module.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
client=[a.replace(str(F),str(D)) for a in base['commands'][1]]
client=[str(P/'WorkflowProbe.swift') if a.endswith('/ResourceProbe.swift') else str(R/'trace-workflow') if a==str(D/'ResourceProbe') else a for a in client]+['-D','CSV_STORAGE_CHOICE','-Rmodule-loading']
with (R/'trace-client.log').open('w') as log:subprocess.run(client,stdout=log,stderr=subprocess.STDOUT,check=True)
loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/'trace-client.log').read_text()));assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
receipt={'accepted_timing':False,'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'module_command':cmd,'client_command':client,'overlay_sha256':h(overlay),'object_sha256':h(D/'SwiftDataFrame.o'),'client_sha256':h(R/'trace-workflow'),'verified_module':loaded['SwiftDataFrame'],'sources':{p:h(S/p) for p in base['sources']}}
(R/'trace-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
cmd=[str(R/'trace-workflow'),'/private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json','sort-matrix','serial','compact']
p=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=60)
(R/'allocation-trace.jsonl').write_text(p.stderr);out=json.loads(p.stdout)
expect=json.loads((P/'preflight/expectations.json').read_text())['energy-common/serial/compact/sort-matrix'];assert {k:out[k] for k in expect}==expect
(R/'trace-output.json').write_text(json.dumps(out,indent=2)+'\n')
rows=[json.loads(x) for x in p.stderr.splitlines()]
for x in rows:print(x)
