from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parent
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
P=Path('/private/tmp/swiftsci-csv-compact-sorting-20261023')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(R/'WorkflowProbe.swift').read_text()
helper='''func bufferCapacities(_ frame: DataFrame, numeric: [String]) throws -> [[String: Any]] {
    let batch = try frame.prepareNumericBatch(numeric)
    return batch.columns.enumerated().map { index, column in
        ["name": numeric[index], "value_count": column.values.count,
         "value_capacity": column.values.capacity, "validity_count": column.validity?.count ?? 0,
         "validity_capacity": column.validity?.capacity ?? 0, "null_count": column.nullCount]
    }
}
'''
s=s.replace('@MainActor @main struct WorkflowProbe',helper+'@MainActor @main struct WorkflowProbe').replace('let frameCheck = fingerprint(output!)','let capacities = try bufferCapacities(output!, numeric: numeric)\n        let frameCheck = fingerprint(output!)').replace('"selection_sha256":selectionCheck,','"buffer_capacities":capacities,"selection_sha256":selectionCheck,')
source=R/'CapacityProbe.swift';source.write_text(s)
base=json.loads((F/'build.json').read_text())['commands'][1]
receipts={}
for label,D in [('prior',P/'build'),('current',R/'build')]:
 cmd=[a.replace(str(F),str(D)) for a in base]
 cmd=[str(source) if a.endswith('/ResourceProbe.swift') else str(R/(label+'-capacity')) if a==str(D/'ResourceProbe') else a for a in cmd]+['-D','CSV_STORAGE_CHOICE','-Rmodule-loading']
 with (R/(label+'-capacity-build.log')).open('w') as out:subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-capacity-build.log')).read_text()))
 assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
 receipts[label]={'command':cmd,'verified_module':loaded['SwiftDataFrame'],'binary_sha256':h(R/(label+'-capacity')),'source_sha256':h(source)}
print('Capacity clients built with matching interfaces',flush=True)
expected=json.loads((R/'preflight/expectations.json').read_text());rows=[]
for round_index in range(3):
 for flow in ['sort-indices','sort-matrix','sort-materialize']:
  for label in (['prior','current'] if round_index%2==0 else ['current','prior']):
   cmd=[str(R/(label+'-capacity')),'/private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json',flow,'serial','compact']
   x=json.loads(subprocess.check_output(cmd,text=True,timeout=45))
   key='energy-common/serial/compact/'+flow
   assert {k:x[k] for k in expected[key]}==expected[key]
   rows.append(dict(round=round_index,workflow=flow,engine=label,accepted_timing=False,output=x))
(R/'capacity-diagnostic.json').write_text(json.dumps({'accepted_timing':False,'purpose':'Inspect retained numeric buffer capacities without production changes','clients':receipts,'responses':rows},indent=2)+'\n')
for flow in ['sort-indices','sort-matrix','sort-materialize']:
 for label in ['prior','current']:
  xs=[x['output']['buffer_capacities'] for x in rows if x['workflow']==flow and x['engine']==label]
  patterns={json.dumps(x,sort_keys=True) for x in xs}
  print(flow,label,'capacity patterns',len(patterns),xs[0],flush=True)
summary=[]
for x in rows:
 cs=x['output']['buffer_capacities'];sample=x['output']['samples'][0]
 summary.append({'workflow':x['workflow'],'engine':x['engine'],'round':x['round'],
  'logical_value_count':sum(c['value_count'] for c in cs),
  'value_capacity':sum(c['value_capacity'] for c in cs),
  'value_capacity_bytes':sum(c['value_capacity']*8 for c in cs),
  'validity_capacity_bytes':sum(c['validity_capacity']*8 for c in cs),
  'held_heap_bytes':sample['held_heap_bytes'],
  'oversized_columns':[{'name':c['name'],'count':c['value_count'],'capacity':c['value_capacity']}
    for c in cs if c['value_capacity']>c['value_count']*1.5]})
(R/'capacity-summary.json').write_text(json.dumps({'accepted_timing':False,'responses':summary},indent=2)+'\n')
