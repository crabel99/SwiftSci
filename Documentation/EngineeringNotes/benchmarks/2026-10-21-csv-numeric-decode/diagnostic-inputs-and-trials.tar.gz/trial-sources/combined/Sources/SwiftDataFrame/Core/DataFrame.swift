import Foundation

/// A tabular data structure with named, typed columns.
/// Columns are stored in-order; all columns must have the same `count`.
/// `DataFrame` is a value type — all mutations return new instances.
public struct DataFrame: Sendable {

    // MARK: – Internal storage

    /// Ordered columns (order preserved from initialisation).
    internal let _columns: [String: any AnyColumn]
    internal let _columnOrder: [String]

    // MARK: – Static helpers

    /// A dataframe with no rows and no columns.
    public static let empty = DataFrame(_columns: [:], _columnOrder: [])

    private init(_columns: [String: any AnyColumn], _columnOrder: [String]) {
        self._columns      = _columns
        self._columnOrder  = _columnOrder
    }

    // MARK: – Initialisation

    /// Creates an empty DataFrame.
    public init() {
        self._columns = [:]
        self._columnOrder = []
    }

    /// Creates a DataFrame from an ordered list of columns.
    /// - Throws: `DataFrameError.emptySchema` if `columns` is empty.
    ///           `DataFrameError.columnLengthMismatch` if columns differ in length.
    ///           `DataFrameError.duplicateColumnName` if two columns share a name.
    public init(columns: [any AnyColumn]) throws {
        guard !columns.isEmpty else { throw SwiftMLError.emptySchema }

        let expectedCount = columns[0].count
        var colMap: [String: any AnyColumn] = [:]
        var colOrder: [String] = []

        for col in columns {
            guard col.count == expectedCount else {
                throw SwiftMLError.columnLengthMismatch(
                    expected: expectedCount, got: col.count, column: col.name
                )
            }
            guard colMap[col.name] == nil else {
                throw SwiftMLError.duplicateColumnName(col.name)
            }
            colMap[col.name] = col
            colOrder.append(col.name)
        }

        self._columns     = colMap
        self._columnOrder = colOrder
    }

    /// Creates a DataFrame by reading a CSV file.
    public init(csv url: URL, options: CSVReadOptions = .default) async throws {
        let df = try await CSVReader.read(url: url, options: options)
        self = df
    }

    /// Reads a CSV file as owned chunks, creating each chunk on consumer demand.
    /// The unfinished stream retains its mapped source. Returned chunks own their values.
    /// Row counts limit each chunk, not its byte size. Retaining chunks retains their storage.
    /// - Parameters:
    ///   - url: The CSV file URL.
    ///   - chunkSize: Maximum rows per chunk. Must be positive.
    ///   - options: CSV parsing, type inference, and row-limit options.
    /// - Returns: A stream of frames that can throw file, parameter, or cancellation errors.
    public static func readCSVStream(
        contentsOf url: URL,
        chunkSize: Int = 10000,
        options: CSVReadOptions = .default
    ) -> AsyncThrowingStream<DataFrame, any Error> {
        CSVReader.readStream(url: url, options: options, chunkSize: chunkSize)
    }

    /// Creates a DataFrame by reading a JSON file (array of objects).
    public init(json url: URL) async throws {
        let df = try await JSONReader.read(url: url)
        self = df
    }

    /// Creates a DataFrame by reading a Feather / Arrow IPC binary file.
    public init(feather url: URL) async throws {
        let df = try await FeatherReader.read(url: url)
        self = df
    }

    /// Reads a Feather / Arrow IPC binary file into a DataFrame.
    /// - Parameters:
    ///   - url: File or network URL endpoint.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public static func readFeather(from url: URL) async throws -> DataFrame {
        try await FeatherReader.read(url: url)
    }

    /// Creates a DataFrame by reading an Apache Parquet binary file.
    public init(parquet url: URL) async throws {
        let df = try await ParquetReader.read(url: url)
        self = df
    }

    /// Reads an Apache Parquet binary file into a DataFrame.
    /// - Parameters:
    ///   - url: File or network URL endpoint.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public static func readParquet(from url: URL) async throws -> DataFrame {
        try await ParquetReader.read(url: url)
    }

    /// Reads an Apache Parquet binary file into a DataFrame from a file system path.
    /// - Parameter path: File system path string.
    /// - Returns: Ingested DataFrame.
    public static func readParquet(_ path: String) async throws -> DataFrame {
        try await readParquet(from: URL(fileURLWithPath: path))
    }


    /// Downloads a dataset directly from an HTTP/HTTPS URL into a DataFrame.
    /// - Parameters:
    ///   - url: Remote URL pointing to a CSV or JSON dataset.
    ///   - options: CSV reading options.
    /// - Returns: Ingested DataFrame.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    public static func readURL(_ url: URL, options: CSVReadOptions = .default) async throws -> DataFrame {
        if url.isFileURL {
            if url.pathExtension.lowercased() == "json" {
                return try await DataFrame(json: url)
            }
            return try await DataFrame(csv: url, options: options)
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw SwiftMLError.parseError(line: 0, description: "Failed to download dataset from URL: \(url.absoluteString)")
        }
        
        let isJSON = url.pathExtension.lowercased() == "json" || (httpResponse.mimeType?.contains("json") ?? false)
        let ext = isJSON ? ".json" : ".csv"
        
        let tempDir = FileManager.default.temporaryDirectory
        let tempFile = tempDir.appendingPathComponent(UUID().uuidString + ext)
        try data.write(to: tempFile)
        defer { try? FileManager.default.removeItem(at: tempFile) }
        
        if isJSON {
            return try await DataFrame(json: tempFile)
        } else {
            return try await DataFrame(csv: tempFile, options: options)
        }
    }

    /// Creates a DataFrame by downloading dataset content directly from a remote HTTP/HTTPS URL.
    public init(remoteURL url: URL, options: CSVReadOptions = .default) async throws {
        let df = try await DataFrame.readURL(url, options: options)
        self = df
    }

    // MARK: – Metadata

    /// The shape.
    public var shape: (rows: Int, columns: Int) {
        (rows: _columns.first.map { $0.value.count } ?? 0,
         columns: _columnOrder.count)
    }

    /// The row count.
    public var rowCount: Int { shape.rows }

    /// The column names.
    public var columnNames: [String] { _columnOrder }

    /// The dtypes.
    public var dtypes: [String: ColumnDType] {
        _columns.mapValues { $0.dtype }
    }

    /// All columns in their original order.
    public var columns: [any AnyColumn] {
        _columnOrder.compactMap { _columns[$0] }
    }

    /// Schema.
    /// - Returns: A `Schema` result.
    public func schema() -> Schema {
        Schema(fields: columns.map { col in
            Schema.Field(name: col.name, dtype: col.dtype, nullable: col.nullCount > 0)
        })
    }

    // MARK: – Subscript access

    /// Accesses the element at the given index.
    public subscript(column name: String) -> (any AnyColumn)? {
        _columns[name]
    }

    /// Accesses the column with the given name.
    public subscript(_ name: String) -> (any AnyColumn)? {
        _columns[name]
    }

    /// Accesses the element at the given index.
    public subscript<T: SupportedType>(column name: String, as type: T.Type) -> TypedColumn<T>? {
        _columns[name] as? TypedColumn<T>
    }

    /// Returns the row at `index` as a dictionary.
    /// - Parameters:
    ///   - index: Zero-based integer index position.
    /// - Returns: The computed [String: Any?] result instance.
    public func rowDictionary(at index: Int) -> [String: Any?] {
        guard index >= 0 && index < shape.rows else { return [:] }
        var result: [String: Any?] = [:]
        for col in columns { result[col.name] = col.value(at: index) }
        return result
    }

    // MARK: – Selection

    /// Returns a new DataFrame with only the specified columns.
    /// - Parameters:
    ///   - names: Array of column identifiers or feature names.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func select(_ names: String...) throws -> DataFrame {
        try selectArray(names)
    }

    /// Selects specified columns by an array of column names.
    /// - Parameter names: Array of column names to select.
    /// - Throws: `DataFrameError.columnNotFound` if any column is missing.
    /// - Returns: A new `DataFrame` containing only the requested columns.
    public func select(_ names: [String]) throws -> DataFrame {
        try selectArray(names)
    }

    private func selectArray(_ names: [String]) throws -> DataFrame {
        var cols: [any AnyColumn] = []
        for name in names {
            guard let col = _columns[name] else {
                throw SwiftMLError.columnNotFound(name)
            }
            cols.append(col)
        }
        return try DataFrame(columns: cols)
    }

    /// Returns a new DataFrame without the specified columns.
    /// - Parameters:
    ///   - names: Array of column identifiers or feature names.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func drop(_ names: String...) throws -> DataFrame {
        try dropArray(names)
    }

    /// Drops specified columns by an array of column names.
    /// - Parameter names: Array of column names to drop.
    /// - Throws: `DataFrameError.columnNotFound` if any column is missing.
    /// - Returns: A new `DataFrame` without the specified columns.
    public func drop(_ names: [String]) throws -> DataFrame {
        try dropArray(names)
    }

    private func dropArray(_ names: [String]) throws -> DataFrame {
        let nameSet = Set(names)
        for n in names {
            guard _columns[n] != nil else { throw SwiftMLError.columnNotFound(n) }
        }
        let remaining = _columnOrder.filter { !nameSet.contains($0) }
        let cols = remaining.compactMap { _columns[$0] }
        guard !cols.isEmpty else { return DataFrame.empty }
        return try DataFrame(columns: cols)
    }

    /// Returns the first `n` rows.
    /// - Parameters:
    ///   - n: Sample size, count, or dimension parameter.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func head(_ n: Int = 5) -> DataFrame {
        slice(from: 0, count: n)
    }

    /// Returns the last `n` rows.
    /// - Parameters:
    ///   - n: Sample size, count, or dimension parameter.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func tail(_ n: Int = 5) -> DataFrame {
        let total = shape.rows
        let from  = Swift.max(0, total - n)
        return slice(from: from, count: total - from)
    }

    /// Returns a random sample of `n` rows.
    /// - Parameters:
    ///   - n: Number of rows to sample.
    ///   - seed: Optional random seed for reproducible sampling.
    ///   - ordered: If `true`, returns sampled rows in their original index order. If `false` (default), returns rows in randomized shuffle order.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func sample(n: Int, seed: UInt64? = nil, ordered: Bool = false) -> DataFrame {
        let total = shape.rows
        guard n > 0 && total > 0 else { return gathered(at: []) }
        let actualN = Swift.min(n, total)

        var rng = SeededRNG(seed: seed ?? UInt64(Date().timeIntervalSince1970 * 1000))
        var indices = Array(0..<total)
        // Fisher-Yates shuffle first `actualN` elements
        for i in 0..<actualN {
            let j = i + Int(rng.next() % UInt64(total - i))
            indices.swapAt(i, j)
        }
        let selectedPrefix = Array(indices.prefix(actualN))
        let selected = ordered ? selectedPrefix.sorted() : selectedPrefix
        return gathered(at: selected)
    }

    /// Returns a new `DataFrame` containing only unique rows (deduplicated), preserving order of first appearance.
    public var unique: DataFrame {
        guard shape.rows > 0 else { return self }
        
        var seenRows = Set<String>()
        var keepIndices: [Int] = []
        keepIndices.reserveCapacity(shape.rows)
        
        for i in 0..<shape.rows {
            var rowRepresentation = ""
            for colName in _columnOrder {
                if let col = _columns[colName] {
                    if let val = col.value(at: i) {
                        rowRepresentation.append("\(val)|")
                    } else {
                        rowRepresentation.append("nil|")
                    }
                }
            }
            if seenRows.insert(rowRepresentation).inserted {
                keepIndices.append(i)
            }
        }
        
        return gathered(at: keepIndices)
    }

    // MARK: – Filtering

    /// Filters rows using a predicate closure over raw row index (zero allocation).
    /// - Parameters:
    ///   - predicate: Filtering boolean closure applied to elements.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func filterRows(by predicate: (Int) -> Bool) -> DataFrame {
        let rows = shape.rows
        guard rows > 0 else { return self }
        var passingIndices = [Int]()
        passingIndices.reserveCapacity(rows)
        for i in 0..<rows {
            if predicate(i) {
                passingIndices.append(i)
            }
        }
        return gathered(at: passingIndices)
    }

    /// Filters rows using a predicate closure.
    ///
    /// The row view resolves column values lazily, so predicates that only
    /// read one or two columns avoid materializing the full row.
    /// - Parameters:
    ///   - predicate: Filtering boolean closure applied to elements.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func filter(_ predicate: (DataFrameRow) -> Bool) -> DataFrame {
        guard shape.rows > 0 else { return self }
        let map = _columns
        let names = columnNames
        var mask = [Bool](repeating: false, count: shape.rows)
        var row = DataFrameRow(columnNames: names, index: 0, columnMap: map)
        for i in 0..<shape.rows {
            row.index = i
            mask[i] = predicate(row)
        }
        return applyMask(mask)
    }

    /// Returns a zero-allocation lightweight row view at the specified index.
    /// - Parameters:
    ///   - index: Zero-based integer index position.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func row(at index: Int) -> DataFrameRow {
        DataFrameRow(columnNames: columnNames, index: index, columnMap: _columns)
    }

    /// Returns a zero-allocation lazy sequence over the DataFrame's rows.
    public var rows: DataFrameRowSequence {
        DataFrameRowSequence(count: shape.rows, columnNames: columnNames, columnMap: _columns)
    }

    /// Filters rows by a condition on a single column.
    /// - Parameters:
    ///   - name: Name or identifier string.
    ///   - condition: Boolean evaluation filter condition.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func filter(column name: String, where condition: FilterCondition) throws -> DataFrame {
        guard let col = _columns[name] else {
            throw SwiftMLError.columnNotFound(name)
        }

        // Bitmap-free fast path for direct index filtering
        if let indices = col.filteredIndices(matching: condition) {
            return gathered(at: indices)
        }

        // Fallback mask path
        var mask = [Bool](repeating: false, count: shape.rows)
        for i in 0..<shape.rows {
            mask[i] = condition.evaluate(value: col.value(at: i))
        }
        return applyMask(mask)
    }

    // MARK: – Transformation

    /// Returns a new DataFrame with the column replaced or added.
    /// - Parameters:
    ///   - name: Name or identifier string.
    ///   - column: Target column identifier.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func withColumn(_ name: String, column: any AnyColumn) throws -> DataFrame {
        let expectedRows = _columnOrder.isEmpty ? column.count : shape.rows
        guard column.count == expectedRows else {
            throw SwiftMLError.columnLengthMismatch(
                expected: expectedRows, got: column.count, column: name
            )
        }
        let newCol = column.renamed(to: name)
        var newMap   = _columns
        var newOrder = _columnOrder

        newMap[name] = newCol
        if !newOrder.contains(name) { newOrder.append(name) }

        return DataFrame(_columns: newMap, _columnOrder: newOrder)
    }

    /// Returns a new DataFrame with a lagged column added.
    /// - Parameters:
    ///   - name: Name or identifier string.
    ///   - offset: Byte or element offset within the buffer.
    ///   - newName: Replacement column name identifier.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func withLaggedColumn(column name: String, by offset: Int, newName: String) throws -> DataFrame {
        guard let col = _columns[name] else { throw SwiftMLError.columnNotFound(name) }
        let laggedCol = col.lagged(by: offset).renamed(to: newName)
        return try withColumn(newName, column: laggedCol)
    }

    /// Returns a new DataFrame with a column renamed.
    /// - Parameters:
    ///   - old: Original identifier or substring to be replaced.
    ///   - new: New replacement identifier or substring.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func renameColumn(_ old: String, to new: String) throws -> DataFrame {
        guard let col = _columns[old] else { throw SwiftMLError.columnNotFound(old) }
        var newMap   = _columns
        var newOrder = _columnOrder

        newMap.removeValue(forKey: old)
        newMap[new] = col.renamed(to: new)
        if let idx = newOrder.firstIndex(of: old) { newOrder[idx] = new }

        return DataFrame(_columns: newMap, _columnOrder: newOrder)
    }

    /// Adds a new column computed using a row-level closure.
    /// - Parameters:
    ///   - name: Name or identifier string.
    ///   - type: Data type or category specification.
    ///   - closure: Processing closure to execute.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func addColumn<T: SupportedType>(_ name: String, as type: T.Type = T.self, using closure: (DataFrameRow) -> T?) throws -> DataFrame {
        let names = columnNames
        let map = _columns
        let total = shape.rows
        var values = [T?]()
        values.reserveCapacity(total)
        
        for i in 0..<total {
            let row = DataFrameRow(columnNames: names, index: i, columnMap: map)
            values.append(closure(row))
        }
        
        let newCol = TypedColumn<T>(name: name, values: values)
        return try withColumn(name, column: newCol)
    }

    /// Casts a column to a new type.
    /// - Parameters:
    ///   - name: Name or identifier string.
    ///   - type: Data type or category specification.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func castColumn<T: SupportedType>(_ name: String, to type: T.Type = T.self) throws -> DataFrame {
        guard let col = _columns[name] else { throw SwiftMLError.columnNotFound(name) }

        var failedCount = 0
        var sourceNonNull = 0

        let newValues: [T?] = (0..<col.count).map { i in
            guard let v = col.value(at: i) else { return nil }
            sourceNonNull += 1
            if let direct = v as? T { return direct }
            let str = "\(v)"
            if let parsed = T.parse(from: str) {
                return parsed
            } else {
                failedCount += 1
                return nil
            }
        }

        if sourceNonNull > 0 && failedCount == sourceNonNull {
            throw SwiftMLError.castFailed(column: name, targetType: "\(T.self)")
        }
        if failedCount > 0 {
            throw SwiftMLError.partialCastFailure(column: name, targetType: "\(T.self)", failed: failedCount, total: sourceNonNull)
        }

        let newCol = TypedColumn<T>(name: name, values: newValues)
        return try withColumn(name, column: newCol)
    }

    /// Casts a column to the specified `ColumnDType`.
    /// - Parameters:
    ///   - name: Name of the column to cast.
    ///   - dtype: Target `ColumnDType`.
    /// - Throws: `SwiftMLError` if column is not found or cast fails.
    /// - Returns: A new `DataFrame` with the casted column.
    public func cast(column name: String, to dtype: ColumnDType) throws -> DataFrame {
        switch dtype {
        case .int32:   return try castColumn(name, to: Int32.self)
        case .int64:   return try castColumn(name, to: Int64.self)
        case .float32: return try castColumn(name, to: Float.self)
        case .float64: return try castColumn(name, to: Double.self)
        case .boolean: return try castColumn(name, to: Bool.self)
        case .utf8:    return try castColumn(name, to: String.self)
        case .date32:  return try castColumn(name, to: Date.self)
        }
    }

    /// Returns a new DataFrame sorted by the given column.
    /// - Parameters:
    ///   - column: Target column identifier.
    ///   - ascending: Whether sorting is performed in ascending order.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func sortBy(_ column: String, ascending: Bool = true) throws -> DataFrame {
        guard let col = _columns[column] else { throw SwiftMLError.columnNotFound(column) }
        let indices = col.sortedIndices(ascending: ascending)
        return gathered(at: indices)
    }

    /// Returns a `GroupedDataFrame` for aggregation.
    /// - Parameters:
    ///   - columns: List of column names to select or transform.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func groupBy(_ columns: String...) -> GroupedDataFrame {
        GroupedDataFrame(dataFrame: self, groupColumns: columns)
    }

    // MARK: – I/O

    /// Writes the DataFrame to a CSV file.
    /// - Parameters:
    ///   - url: File or network URL endpoint.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    public func writeCSV(to url: URL) async throws {
        try await CSVWriter.write(self, to: url)
    }

    /// Writes the DataFrame to a Feather / Arrow IPC binary file.
    /// - Parameters:
    ///   - url: File or network URL endpoint.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    public func writeFeather(to url: URL) async throws {
        try await FeatherWriter.write(self, to: url)
    }

    /// Serializes the DataFrame into Feather / Arrow IPC binary Data.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: Raw serialized binary data representation.
    public func writeFeatherData() throws -> Data {
        try FeatherWriter.write(self)
    }

    /// Writes the DataFrame to an Apache Parquet binary file.
    /// - Parameters:
    ///   - url: File or network URL endpoint.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    public func writeParquet(to url: URL) async throws {
        try await ParquetWriter.write(dataFrame: self, to: url)
    }

    /// Writes the DataFrame to an Apache Parquet binary file at the specified file system path.
    /// - Parameter path: File system path string.
    public func writeParquet(to path: String) async throws {
        try await writeParquet(to: URL(fileURLWithPath: path))
    }


    /// Prints a formatted table to stdout.
    /// - Parameters:
    ///   - maxRows: Maximum number of rows to format or process.
    public func debugPrint(maxRows: Int = 20) {
        let names  = columnNames
        let rows   = Swift.min(shape.rows, maxRows)

        // Column widths
        var widths = names.map { $0.count }
        for i in 0..<rows {
            for (ci, col) in columns.enumerated() {
                let s = col.value(at: i).map { "\($0)" } ?? "null"
                widths[ci] = Swift.max(widths[ci], s.count)
            }
        }

        func pad(_ s: String, _ w: Int) -> String { s + String(repeating: " ", count: w - s.count) }
        let header = names.enumerated().map { pad($0.element, widths[$0.offset]) }.joined(separator: " | ")
        let sep    = widths.map { String(repeating: "-", count: $0) }.joined(separator: "-+-")

        print(header)
        print(sep)
        for i in 0..<rows {
            let row = columns.enumerated().map { (ci, col) in
                pad(col.value(at: i).map { "\($0)" } ?? "null", widths[ci])
            }.joined(separator: " | ")
            print(row)
        }
        if shape.rows > maxRows {
            print("... (\(shape.rows - maxRows) more rows)")
        }
        print("\n[\(shape.rows) rows × \(shape.columns) columns]")
    }

    // MARK: – Private helpers

    private func slice(from start: Int, count n: Int) -> DataFrame {
        let total  = shape.rows
        guard total > 0, n > 0 else { return gathered(at: []) }
        let upper  = Swift.min(start + n, total)
        let indices = Array(start..<upper)
        return gathered(at: indices)
    }

    /// Gathers rows at specified row indices (supports concurrent parallel gather for large datasets).
    /// Preserves column names, order, and types, including when the selection is empty.
    /// - Parameter indices: Array of row indices to include in the resulting DataFrame.
    /// - Returns: A new `DataFrame` containing the gathered rows in the given index order.
    public func gathered(at indices: [Int]) -> DataFrame {
        let sourceColumns = columns
        guard !sourceColumns.isEmpty else { return self }
        let numCols = sourceColumns.count
        let rowBytes = sourceColumns.reduce(0) { bytes, column in
            switch column.dtype {
            case .int32: return bytes + MemoryLayout<Int32?>.stride
            case .int64: return bytes + MemoryLayout<Int64?>.stride
            case .float32: return bytes + MemoryLayout<Float?>.stride
            case .float64: return bytes + MemoryLayout<Double?>.stride
            case .boolean: return bytes + MemoryLayout<Bool?>.stride
            case .utf8: return bytes + MemoryLayout<String?>.stride
            case .date32: return bytes + MemoryLayout<Date?>.stride
            }
        }
        // Estimate output work without multiplying potentially large dimensions.
        let parallelRows = (512 * 1024) / max(rowBytes, 1)
        if numCols >= 2 && indices.count >= max(parallelRows, 1) {
            // Each iteration writes to a unique index — no data race.
            var newCols: [(any AnyColumn)?] = Array(repeating: nil, count: numCols)
            newCols.withUnsafeMutableBufferPointer { buf in
                guard let base = buf.baseAddress else { return }
                let address = Int(bitPattern: base)
                DispatchQueue.concurrentPerform(iterations: numCols) { colIdx in
                    let ptr = UnsafeMutablePointer<(any AnyColumn)?>(bitPattern: address)!
                    ptr[colIdx] = sourceColumns[colIdx].gathered(at: indices)
                }
            }
            do {
                return try DataFrame(columns: newCols.compactMap { $0 })
            } catch {
                preconditionFailure("Failed to gather rows concurrently: \(error)")
            }
        } else {
            let newCols: [any AnyColumn] = sourceColumns.map { $0.gathered(at: indices) }
            do {
                return try DataFrame(columns: newCols)
            } catch {
                preconditionFailure("Failed to gather rows for indices: \(error)")
            }
        }
    }

    private func applyMask(_ mask: [Bool]) -> DataFrame {
        var indices: [Int] = []
        indices.reserveCapacity(mask.count / 2)
        for (i, keep) in mask.enumerated() where keep {
            indices.append(i)
        }
        return gathered(at: indices)
    }

    /// Transforms values of a typed column functional-style, returning a new DataFrame.
    /// - Parameters:
    ///   - name: Name or identifier string.
    ///   - type: Data type or category specification.
    ///   - transform: Transformation closure or mapping function.
    /// - Throws: `SwiftMLError` or `DataFrameError` if column lengths mismatch, names collide, or I/O fails.
    /// - Returns: A new `DataFrame` containing the transformed columns and computed results.
    public func mapColumn<T: SupportedType>(
        _ name: String,
        as type: T.Type = T.self,
        transform: (T?) -> T?
    ) throws -> DataFrame {
        guard let col = _columns[name] as? TypedColumn<T> else {
            throw SwiftMLError.columnNotFound(name)
        }
        let newValues = col.values.map { transform($0) }
        return try withColumn(name, column: TypedColumn<T>(name: name, values: newValues))
    }
}

// MARK: – Factory helper

/// Reconstruct a typed AnyColumn from raw Any? values.
internal func makeColumn(name: String, dtype: ColumnDType, rawValues: [Any?]) -> any AnyColumn {
    switch dtype {
    case .int64:
        return TypedColumn<Int64>(name: name, values: rawValues.map { $0 as? Int64 })
    case .int32:
        return TypedColumn<Int32>(name: name, values: rawValues.map { $0 as? Int32 })
    case .float64:
        return TypedColumn<Double>(name: name, values: rawValues.map { $0 as? Double })
    case .float32:
        return TypedColumn<Float>(name: name, values: rawValues.map { $0 as? Float })
    case .boolean:
        return TypedColumn<Bool>(name: name, values: rawValues.map { $0 as? Bool })
    case .date32:
        return TypedColumn<Date>(name: name, values: rawValues.map { $0 as? Date })
    case .utf8:
        return TypedColumn<String>(name: name,
            values: rawValues.map { v in v.map { "\($0)" } })
    }
}

// MARK: – Seeded RNG (for reproducible sample)

private struct SeededRNG {
    private var state: UInt64

    init(seed: UInt64) { self.state = seed == 0 ? 1 : seed }

    mutating func next() -> UInt64 {
        // xorshift64
        state ^= state << 13
        state ^= state >> 7
        state ^= state << 17
        return state
    }
}
