from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
load=lambda p:json.loads(p.read_text())
parent=load(r/'baseline-build/build.json');candidate=load(r/'sequential-build/build.json')
base='575f2f63cbd3c35c0611ba3a977b066b2e4fd390'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()
assert head!=base
for receipt,commit in [(parent,base),(candidate,head)]:
 for name,sha in receipt['sources'].items():
  content=subprocess.check_output(['git','show',commit+':'+name],cwd=s)
  assert hashlib.sha256(content).hexdigest()==sha
assert parent['dependencies']==candidate['dependencies']
changed=[name for name in parent['sources'] if parent['sources'][name]!=candidate['sources'][name]]
assert changed==['Sources/SwiftDataFrame/IO/VectorizedByteParsers.swift']
tests={mode:load(r/('validation/green/compact-'+mode+'-tests.json')) for mode in ['debug','release']}
assert all(t['exit_code']==0 and t['summary']['failedTests']==t['summary']['skippedTests']==0 for t in tests.values())
red=load(r/'validation/compact-debug-tests.json');assert red['exit_code']!=0 and red['summary']['failedTests']>0
assert all(x['passed'] for x in load(r/'green-final-public/results.json'))
corpus=load(r/'corpus-final/results.json');assert all(x['passed'] for x in corpus['results'])
panels={k:load(r/(k+'/decision.json')) for k in ['integer-workflows','integer-final-workflows','reference-final-workflows']}
audits={k:load(r/(k+'/audit.json')) for k in panels}
assert all(a['source_and_binary_receipts_match'] for a in audits.values())
assert all(a['qualified'] for k,a in audits.items() if k!='integer-workflows')
provenance=dict(parent_commit=base,source_commit=head,changed_measured_sources=changed,measured_source_files=len(candidate['sources']),historical_receipts_preserved=True,all_measured_hashes_match_named_commits=True,dependencies_equal=True,source_test_sha256=hashlib.sha256((s/'Tests/SwiftDataFrameTests/CSVIntegerBoundaryTests.swift').read_bytes()).hexdigest())
(r/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
summary=dict(provenance=provenance,failing_before=dict(exit_code=red['exit_code'],summary=red['summary']),native_tests={m:t['summary'] for m,t in tests.items()},corpus=dict(rows=corpus['rows'],nulls=corpus['nulls'],storage_modes=2),panels=panels,audits=audits)
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# CSV signed-integer overflow fix','',f'Retain `{head}` on local branch `codex/csv-integer-overflow`, based on `{base}`. Nothing is pushed and no PR is opened. Engineering records stay on `codex/engineering-notes`.','',
'The byte parser now accepts the smallest signed integer and returns nil for out-of-range input. The retained implementation avoids the first candidate\'s extra overflow-flag work. The final integer queues use 0.7% less CPU with optional storage and 0.2% more with compact storage. The larger reference queues use 0.4–1.9% more. The detailed cases below retain both improvements and increases.','',
'## Failure and correction','',
'The old parser builds a positive magnitude with trapping arithmetic, then applies the sign. The magnitude of Int.min cannot fit in Int. Both larger positive and smaller negative decimal values also trap before the CSV decoder can apply its existing invalid-value handling.','',
'The focused native regression fails before the patch with an arithmetic-overflow crash. In separate public CSV processes, Int64.max passes while Int64.min and the two adjacent out-of-range values terminate with SIGTRAP. All four pass after the fix.','',
'The patch accumulates negative digits with reporting-overflow arithmetic. Each overflow check immediately follows its arithmetic operation. Negative input returns that value directly. Positive input uses checked negation. Quotes, signs, whitespace, full-token validation, null matching, inference rules, and storage representation stay as before. There is no public API change or new allocation.','',
'## Correctness checks','',
f'The full dataframe suite passes {tests["debug"]["summary"]["passedTests"]} Debug and {tests["release"]["summary"]["passedTests"]} Release tests, with no failures or skips. Seven small regression tests cover signed limits, out-of-range decimals, formatting, malformed tokens, long zero padding, serial and parallel explicit schemas, and exact inferred integer limits.','',
f'An independent Python integer and range oracle checks all native values and nulls in a deterministic {corpus["rows"]:,}-row corpus in both Double storage modes. It includes random signed integers, signed-boundary neighborhoods, up to 200-digit decimals, malformed tokens, Unicode whitespace, ASCII whitespace, and long zero padding. Expected null count is {corpus["nulls"]}. Each complete output hash matches.','',
'The first corpus check exposed a mistake in the auxiliary String-column oracle: it encoded a UInt64 length instead of the worker\'s UInt32 length. Integer hashes and null counts already matched. The corrected oracle follows the unchanged worker format. Both the failed diagnostic and corrected results are retained.','',
'## Matched integer resource comparison','',
'Five fixed inputs contain 8,192 rows and eight columns. Four use varied short, long, whitespace-padded, or mixed and null integers. The fifth is a Double control. Every build gets the same full schema, native output checks, custom null set, native CPU parallelism, and power policy. Eight rotated rounds include twins, four callers, and 640 reads per queue. No tolerance or worker-budget change was made.','',
'| Input | Storage | Parent CPU ms/read | Fixed CPU ms/read | Change |','| --- | --- | ---: | ---: | ---: |']
def table(d):
 for storage in ['optional','compact']:
  a=d['per_case_operation_cpu_ns']['parent_'+storage];b=d['per_case_operation_cpu_ns']['candidate_'+storage]
  for name,v in a.items():lines.append(f'| {name} | {storage} | {v/1e6:.3f} | {b[name]/1e6:.3f} | {100*(b[name]/v-1):+.2f}% |')
table(panels['integer-final-workflows'])
lines+=['','These are summed operation CPU milliseconds, not wall time, energy, FLOPs, or normalized work across performance and efficiency cores. Negative changes use less CPU. Small differences are observations on this machine and link layout, not universal speed claims.','',
'## Complete reference workflows','',
'The larger panel uses the existing 35,064-row Aotizhongxin air-quality dataset and 2,075,259-row household-electricity dataset. Each read and read-sort-matrix workflow retains identical schemas, null policies, input hashes, native values, stable sorting, and matrix hashes for both builds. It uses eight rotated rounds, twins, four callers, and fixed 128-job queues.','',
'| Input and workflow | Storage | Parent CPU ms/job | Fixed CPU ms/job | Change |','| --- | --- | ---: | ---: | ---: |']
table(panels['reference-final-workflows'])
lines+=['','## Queue CPU and memory','',
'| Panel | Storage | Charged CPU change | Wall-time change | Parent sampled peak MiB | Fixed sampled peak MiB |','| --- | --- | ---: | ---: | ---: | ---: |']
for name in ['integer-final-workflows','reference-final-workflows']:
 d=panels[name]
 for storage in ['optional','compact']:
  a=d['medians']['parent_'+storage];b=d['medians']['candidate_'+storage]
  lines.append(f'| {name} | {storage} | {100*(b["charged_cpu_ns"]/a["charged_cpu_ns"]-1):+.2f}% | {100*(b["elapsed_ns"]/a["elapsed_ns"]-1):+.2f}% | {a["sampled_peak_rss_bytes"]/2**20:.2f} | {b["sampled_peak_rss_bytes"]/2**20:.2f} |')
lines+=['','Charged CPU includes worker and measured controller CPU. Sampled RSS is the combined resident size of the four callers. Conservative sums of per-process kernel peaks remain below the unchanged 4 GiB ceiling. These are upper bounds, not simultaneous peak measurements. The patch changes no data storage and does not establish a memory reduction.','',
'## Rejected first candidate','',
'The first correct candidate checks both overflow flags together. Its qualified integer panel uses 5.5–6.7% more charged CPU. Generated instructions materialize overflow Booleans before testing them. Checking immediately after each arithmetic operation removes that extra flag handling. The initial larger reference run was interrupted after this diagnosis and is excluded from acceptance evidence. Its partial records and interruption are retained.','',
'## Receipts and scope','',
'Both final panels pass the existing twin CPU, wall-time, and memory controls. The audit recomputes queued jobs, charged CPU, raw memory summaries, source hashes, binary hashes, and every preflight and postflight full-output check. The final worker\'s 51 measured source hashes match the final source commit. The parent differs only in the parser among those measured files. Historical build receipts are unchanged. provenance.json maps their exact source hashes to the named commits.','',
'Only the parser and regression test belong to the source commit. This record, raw measurements, compiler evidence, and reproducible experiment scripts belong to the notes branch. The archive omits compiled binaries, caches, raw CSVs, and xcresult bundles. It contains their hashes, commands, contracts, and summaries.','',
'This validates the dataframe slice locally. It does not claim the full MLX-dependent suite, hosted CI, or Codecov have passed. The original baseline crash is resolved here, not waived or retroactively removed from the earlier report.']
(r/'README.md').write_text('\n'.join(lines)+'\n')
print(dict(source_commit=head,debug=tests['debug']['summary']['passedTests'],release=tests['release']['summary']['passedTests'],panels={k:dict(qualified=a['qualified'],jobs=a['jobs'],checks=a['full_output_checks']) for k,a in audits.items()}))
