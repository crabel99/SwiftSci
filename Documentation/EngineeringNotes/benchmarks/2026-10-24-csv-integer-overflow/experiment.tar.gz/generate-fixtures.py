from pathlib import Path
import csv,hashlib,io,json,random,struct
r=Path(__file__).parent/'fixtures';r.mkdir(exist_ok=False)
rng=random.Random(20261024)
names=['x']+[f'x{i}' for i in range(1,8)]
short=[str(rng.randrange(-100000,100000)) for _ in range(127)]
long=[str(rng.randrange(-(2**63)+1,2**63)) for _ in range(127)]
fixtures=[('short-integers',short,'Int64'),('long-integers',long,'Int64'),
 ('formatted-integers',['" \t'+v+' \t"' for v in short],'Int64'),
 ('mixed-integers',short+['?','','""','+00015','-00042'],'Int64'),
 ('double-control',['123.125','-1.5','0.0','?'],'Double')]
expected={};cases=[]
for kind,values,typ in fixtures:
 text=','.join(names)+'\n'+'\n'.join(','.join(values[(row+col)%len(values)] for col in range(8)) for row in range(8192))+'\n'
 f=r/(kind+'.csv');f.write_text(text)
 contract=dict(id=kind,path=str(f),rows=8192,names=names,types=[typ]*8,null_tokens=['?'],delimiter=',',sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 p=r/(kind+'.json');p.write_text(json.dumps(contract,indent=2)+'\n');columns=[];rows=list(csv.reader(io.StringIO(text)))[1:]
 for col,name in enumerate(names):
  encoded=bytearray();missing=0
  for row in rows:
   token=row[col].strip();value=None
   if token and token!='?':value=float(token) if typ=='Double' else int(token)
   if value is None:encoded.append(0);missing+=1
   else:encoded.append(1);encoded.extend(struct.pack('<d',value) if typ=='Double' else struct.pack('<q',value))
  columns.append(dict(name=name,type=typ,nulls=missing,sha256=hashlib.sha256(encoded).hexdigest()))
 expected[kind+'/read']=dict(frame=dict(rows=8192,columns=columns),matrix_sha256='absent')
 cases.append(dict(id=len(cases),contract=str(p),workflow='read',input=kind,key='x',verify=False))
(r/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(r/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
