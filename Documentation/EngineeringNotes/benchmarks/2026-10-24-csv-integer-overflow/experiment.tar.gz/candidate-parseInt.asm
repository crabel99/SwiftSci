
/private/tmp/swiftsci-csv-integer-overflow-20261024/candidate-build/SwiftDataFrame.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000007823c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n>:
   7823c: f100045f     	cmp	x2, #0x1
   78240: 540001cd     	b.le	0x78278 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x3c>
   78244: 38616808     	ldrb	w8, [x0, x1]
   78248: 7100891f     	cmp	w8, #0x22
   7824c: 540001a1     	b.ne	0x78280 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x44>
   78250: ab020028     	adds	x8, x1, x2
   78254: 54000d46     	b.vs	0x783fc <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1c0>
   78258: f1000508     	subs	x8, x8, #0x1
   7825c: 54000d26     	b.vs	0x78400 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1c4>
   78260: 38686808     	ldrb	w8, [x0, x8]
   78264: 7100891f     	cmp	w8, #0x22
   78268: 540000c1     	b.ne	0x78280 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x44>
   7826c: b1000421     	adds	x1, x1, #0x1
   78270: 54000ca6     	b.vs	0x78404 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1c8>
   78274: d1000842     	sub	x2, x2, #0x2
   78278: f100045f     	cmp	x2, #0x1
   7827c: 5400062b     	b.lt	0x78340 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x104>
   78280: ab02002a     	adds	x10, x1, x2
   78284: 54000ba6     	b.vs	0x783f8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1bc>
   78288: eb0a003f     	cmp	x1, x10
   7828c: 5400042b     	b.lt	0x78310 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xd4>
   78290: 5280000b     	mov	w11, #0x0               ; =0
   78294: eb0a003f     	cmp	x1, x10
   78298: 5400054a     	b.ge	0x78340 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x104>
   7829c: 38616808     	ldrb	w8, [x0, x1]
   782a0: 5100c108     	sub	w8, w8, #0x30
   782a4: 12001d09     	and	w9, w8, #0xff
   782a8: 7100253f     	cmp	w9, #0x9
   782ac: 1a9f97ec     	cset	w12, hi
   782b0: 540004e9     	b.ls	0x7834c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x110>
   782b4: d280000d     	mov	x13, #0x0               ; =0
   782b8: 91000428     	add	x8, x1, #0x1
   782bc: eb08015f     	cmp	x10, x8
   782c0: 9a81c548     	csinc	x8, x10, x1, gt
   782c4: 52800029     	mov	w9, #0x1                ; =1
   782c8: d284c00e     	mov	x14, #0x2600            ; =9728
   782cc: f2c0002e     	movk	x14, #0x1, lsl #32
   782d0: 3861680f     	ldrb	w15, [x0, x1]
   782d4: 710081ff     	cmp	w15, #0x20
   782d8: 9acf212f     	lsl	x15, x9, x15
   782dc: 8a0e01ef     	and	x15, x15, x14
   782e0: fa4099e4     	ccmp	x15, #0x0, #0x4, ls
   782e4: 54000680     	b.eq	0x783b4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x178>
   782e8: 91000421     	add	x1, x1, #0x1
   782ec: eb0a003f     	cmp	x1, x10
   782f0: 54ffff0b     	b.lt	0x782d0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x94>
   782f4: aa0803e1     	mov	x1, x8
   782f8: 1400002f     	b	0x783b4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x178>
   782fc: 7100251f     	cmp	w8, #0x9
   78300: 54fffc81     	b.ne	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   78304: 91000421     	add	x1, x1, #0x1
   78308: f1000442     	subs	x2, x2, #0x1
   7830c: 540001a0     	b.eq	0x78340 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x104>
   78310: 38616808     	ldrb	w8, [x0, x1]
   78314: 71007d1f     	cmp	w8, #0x1f
   78318: 54ffff2d     	b.le	0x782fc <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xc0>
   7831c: 7100811f     	cmp	w8, #0x20
   78320: 54ffff20     	b.eq	0x78304 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xc8>
   78324: 7100ad1f     	cmp	w8, #0x2b
   78328: 54000620     	b.eq	0x783ec <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1b0>
   7832c: 7100b51f     	cmp	w8, #0x2d
   78330: 54fffb01     	b.ne	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   78334: 91000421     	add	x1, x1, #0x1
   78338: 5280002b     	mov	w11, #0x1               ; =1
   7833c: 17ffffd6     	b	0x78294 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x58>
   78340: d2800008     	mov	x8, #0x0                ; =0
   78344: 52800029     	mov	w9, #0x1                ; =1
   78348: 14000026     	b	0x783e0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1a4>
   7834c: d2800009     	mov	x9, #0x0                ; =0
   78350: cb28012d     	sub	x13, x9, w8, uxtb
   78354: 91000421     	add	x1, x1, #0x1
   78358: eb0a003f     	cmp	x1, x10
   7835c: 54000280     	b.eq	0x783ac <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x170>
   78360: 5280014e     	mov	w14, #0xa               ; =10
   78364: 38616808     	ldrb	w8, [x0, x1]
   78368: 5100c109     	sub	w9, w8, #0x30
   7836c: 7100293f     	cmp	w9, #0xa
   78370: 54fffa42     	b.hs	0x782b8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x7c>
   78374: d2800008     	mov	x8, #0x0                ; =0
   78378: 9b4e7daf     	smulh	x15, x13, x14
   7837c: 8b0d09ad     	add	x13, x13, x13, lsl #2
   78380: d37ff9ad     	lsl	x13, x13, #1
   78384: eb8dfdff     	cmp	x15, x13, asr #63
   78388: 1a9f07f0     	cset	w16, ne
   7838c: eb2901ad     	subs	x13, x13, w9, uxtb
   78390: 1a9f77ef     	cset	w15, vs
   78394: 52800029     	mov	w9, #0x1                ; =1
   78398: 37000250     	tbnz	w16, #0x0, 0x783e0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1a4>
   7839c: 3700022f     	tbnz	w15, #0x0, 0x783e0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1a4>
   783a0: 91000421     	add	x1, x1, #0x1
   783a4: eb01015f     	cmp	x10, x1
   783a8: 54fffde1     	b.ne	0x78364 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x128>
   783ac: 5280000c     	mov	w12, #0x0               ; =0
   783b0: aa0a03e1     	mov	x1, x10
   783b4: eb0a003f     	cmp	x1, x10
   783b8: 1a9f0589     	csinc	w9, w12, wzr, eq
   783bc: 2a090168     	orr	w8, w11, w9
   783c0: 7100013f     	cmp	w9, #0x0
   783c4: 9a8d13ea     	csel	x10, xzr, x13, ne
   783c8: eb0d03eb     	negs	x11, x13
   783cc: 1a9f77ec     	cset	w12, vs
   783d0: 9a8b63eb     	csel	x11, xzr, x11, vs
   783d4: 7200011f     	tst	w8, #0x1
   783d8: 9a8b1148     	csel	x8, x10, x11, ne
   783dc: 1a8c1129     	csel	w9, w9, w12, ne
   783e0: aa0803e0     	mov	x0, x8
   783e4: aa0903e1     	mov	x1, x9
   783e8: d65f03c0     	ret
   783ec: 5280000b     	mov	w11, #0x0               ; =0
   783f0: 91000421     	add	x1, x1, #0x1
   783f4: 17ffffa8     	b	0x78294 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x58>
   783f8: d4200020     	brk	#0x1
   783fc: d4200020     	brk	#0x1
   78400: d4200020     	brk	#0x1
   78404: d4200020     	brk	#0x1
