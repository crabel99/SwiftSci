from pathlib import Path
import json,sys,statistics
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent;D=R/(sys.argv[1] if len(sys.argv)>1 else 'pair-workflows')
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
from Benchmarks.CPUThroughput.budget import jobs_for
from schema_contract import effective_options
Q=Path(sys.argv[2]) if len(sys.argv)>2 else S
plan=json.loads((D/'plan.json').read_text());records=json.loads((D/'records.json').read_text());decision=json.loads((D/'decision.json').read_text());expected=json.loads((D/'expected.json').read_text())
for name,receipt in plan["receipts"].items():
 assert plan["effective_read_options"][name]==effective_options(receipt,plan["contracts"])
assert (D/'end.json').exists() and not (D/'failure.json').exists()
assert run.digest(D/'expected.json')==plan['expected_sha256']
for name,binary in plan['binaries'].items():assert run.digest(Path(binary))==plan['receipts'][name]['binary_sha256']
actual_sources={str(p.relative_to(Q)) for p in (Q/'Sources/SwiftDataFrame').rglob('*.swift')} | {'Benchmarks/CPUThroughput/Worker.swift'}
assert actual_sources==set(plan['receipts']['candidate']['sources'])
for source,sha in plan['receipts']['candidate']['sources'].items():assert run.digest(Q/source)==sha
required={(i,label) for i,order in enumerate(plan['orders']) for label in order}
assert len(records)==len(required)==64
assert {(r['round'],r['label']) for r in records}==required
jobs=0
for r in records:
 raw=json.loads((D/f"r{r['round']}-{r['label']}"/'result.json').read_text());summary=raw['summary'];queued=jobs_for(plan['cases'],plan['copies_per_case'],r['round'])
 assert summary==r['summary']
 recomputed=run.summarize(raw['jobs'],summary['elapsed_ns'],raw['memory_samples'],queued)
 assert all(summary[k]==v for k,v in recomputed.items())
 assert summary['worker_cpu_ns']==sum(b['cpu_ns']-a['cpu_ns'] for a,b in zip(raw['before'],raw['after']))
 assert summary['charged_cpu_ns']==summary['worker_cpu_ns']+summary['controller_cpu_ns']
 storage=r['label'].removesuffix('_twin').split('_')[1]
 assert all(x['storage']==storage for x in raw['jobs'])
 assert len(raw['before'])==len(raw['after'])==plan['callers']
 jobs+=len(raw['jobs'])
checks=0
for name in plan['binaries']:
 for phase in ['preflight','postflight']:
  raw=json.loads((D/(name+'-'+phase)/'checks.json').read_text())
  assert len(raw)==2*len(plan['cases'])
  assert {(x['storage'],x['input'],x['workflow']) for x in raw}=={(storage,c['input'],c['workflow']) for storage in ['optional','compact'] for c in plan['cases']}
  assert all(x['check']==expected[x['input']+'/'+x['workflow']] for x in raw)
  checks+=len(raw)
assert jobs==decision['jobs']==len(records)*len(plan['cases'])*plan['copies_per_case']
from Benchmarks.CPUThroughput.audit import control_flags
medians={label:{key:statistics.median(r['summary'][key] for r in records if r['label']==label) for key in ['charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes']} for label in plan['orders'][0]}
flags=control_flags(medians,plan['quality_policy'],{label:plan['callers'] for label in plan['orders'][0]})
assert flags==decision['flags'] and decision['qualified']==(not flags)
result=dict(queues=len(records),jobs=jobs,full_output_checks=checks,qualified=decision['qualified'],source_and_binary_receipts_match=True,quality_policy_recomputed=True)
run.save(D/'audit.json',result);print(json.dumps(result,indent=2))
