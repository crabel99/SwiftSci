
/private/tmp/swiftsci-csv-normalized-empty-20261024/candidate-build/SwiftDataFrame.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000007823c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n>:
   7823c: f100045f     	cmp	x2, #0x1
   78240: 540001cd     	b.le	0x78278 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x3c>
   78244: 38616808     	ldrb	w8, [x0, x1]
   78248: 7100891f     	cmp	w8, #0x22
   7824c: 540001a1     	b.ne	0x78280 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x44>
   78250: ab020028     	adds	x8, x1, x2
   78254: 54000cc6     	b.vs	0x783ec <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1b0>
   78258: f1000508     	subs	x8, x8, #0x1
   7825c: 54000ca6     	b.vs	0x783f0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1b4>
   78260: 38686808     	ldrb	w8, [x0, x8]
   78264: 7100891f     	cmp	w8, #0x22
   78268: 540000c1     	b.ne	0x78280 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x44>
   7826c: b1000421     	adds	x1, x1, #0x1
   78270: 54000c46     	b.vs	0x783f8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1bc>
   78274: d1000842     	sub	x2, x2, #0x2
   78278: f100045f     	cmp	x2, #0x1
   7827c: 540006cb     	b.lt	0x78354 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x118>
   78280: ab020028     	adds	x8, x1, x2
   78284: 54000b26     	b.vs	0x783e8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1ac>
   78288: eb08003f     	cmp	x1, x8
   7828c: 540004ab     	b.lt	0x78320 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xe4>
   78290: 52800029     	mov	w9, #0x1                ; =1
   78294: eb08003f     	cmp	x1, x8
   78298: 540005ea     	b.ge	0x78354 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x118>
   7829c: 3861680a     	ldrb	w10, [x0, x1]
   782a0: 5100c14b     	sub	w11, w10, #0x30
   782a4: 7100297f     	cmp	w11, #0xa
   782a8: 1a9f27ea     	cset	w10, lo
   782ac: 7100257f     	cmp	w11, #0x9
   782b0: 54000588     	b.hi	0x78360 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x124>
   782b4: 92401d6b     	and	x11, x11, #0xff
   782b8: 91000421     	add	x1, x1, #0x1
   782bc: eb08003f     	cmp	x1, x8
   782c0: 54000200     	b.eq	0x78300 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xc4>
   782c4: 5280014c     	mov	w12, #0xa               ; =10
   782c8: 3861680d     	ldrb	w13, [x0, x1]
   782cc: 5100c1ad     	sub	w13, w13, #0x30
   782d0: 710029bf     	cmp	w13, #0xa
   782d4: 54000482     	b.hs	0x78364 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x128>
   782d8: 9b4c7d6e     	smulh	x14, x11, x12
   782dc: 8b0b096b     	add	x11, x11, x11, lsl #2
   782e0: d37ff96b     	lsl	x11, x11, #1
   782e4: eb8bfddf     	cmp	x14, x11, asr #63
   782e8: 540007c1     	b.ne	0x783e0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1a4>
   782ec: ab2d016b     	adds	x11, x11, w13, uxtb
   782f0: 540007a6     	b.vs	0x783e4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1a8>
   782f4: 91000421     	add	x1, x1, #0x1
   782f8: eb01011f     	cmp	x8, x1
   782fc: 54fffe61     	b.ne	0x782c8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x8c>
   78300: 5280002a     	mov	w10, #0x1               ; =1
   78304: aa0803e1     	mov	x1, x8
   78308: 14000027     	b	0x783a4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x168>
   7830c: 7100253f     	cmp	w9, #0x9
   78310: 54fffc01     	b.ne	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   78314: 91000421     	add	x1, x1, #0x1
   78318: f1000442     	subs	x2, x2, #0x1
   7831c: 540001c0     	b.eq	0x78354 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x118>
   78320: 38616809     	ldrb	w9, [x0, x1]
   78324: 71007d3f     	cmp	w9, #0x1f
   78328: 54ffff2d     	b.le	0x7830c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xd0>
   7832c: 7100813f     	cmp	w9, #0x20
   78330: 54ffff20     	b.eq	0x78314 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xd8>
   78334: 7100ad3f     	cmp	w9, #0x2b
   78338: 540004c0     	b.eq	0x783d0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x194>
   7833c: 7100b53f     	cmp	w9, #0x2d
   78340: 54fffa81     	b.ne	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   78344: 91000421     	add	x1, x1, #0x1
   78348: 92800009     	mov	x9, #-0x1               ; =-1
   7834c: eb08003f     	cmp	x1, x8
   78350: 54fffa6b     	b.lt	0x7829c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x60>
   78354: d2800000     	mov	x0, #0x0                ; =0
   78358: 52800021     	mov	w1, #0x1                ; =1
   7835c: d65f03c0     	ret
   78360: d280000b     	mov	x11, #0x0               ; =0
   78364: 9100042c     	add	x12, x1, #0x1
   78368: eb0c011f     	cmp	x8, x12
   7836c: 9a81c50c     	csinc	x12, x8, x1, gt
   78370: 5280002d     	mov	w13, #0x1               ; =1
   78374: d284c00e     	mov	x14, #0x2600            ; =9728
   78378: f2c0002e     	movk	x14, #0x1, lsl #32
   7837c: 3861680f     	ldrb	w15, [x0, x1]
   78380: 710081ff     	cmp	w15, #0x20
   78384: 9acf21af     	lsl	x15, x13, x15
   78388: 8a0e01ef     	and	x15, x15, x14
   7838c: fa4099e4     	ccmp	x15, #0x0, #0x4, ls
   78390: 540000a0     	b.eq	0x783a4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x168>
   78394: 91000421     	add	x1, x1, #0x1
   78398: eb08003f     	cmp	x1, x8
   7839c: 54ffff0b     	b.lt	0x7837c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x140>
   783a0: aa0c03e1     	mov	x1, x12
   783a4: d2800000     	mov	x0, #0x0                ; =0
   783a8: 3400018a     	cbz	w10, 0x783d8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x19c>
   783ac: eb08003f     	cmp	x1, x8
   783b0: 52800021     	mov	w1, #0x1                ; =1
   783b4: 540000c1     	b.ne	0x783cc <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x190>
   783b8: 9b097d60     	mul	x0, x11, x9
   783bc: 9b497d68     	smulh	x8, x11, x9
   783c0: eb80fd1f     	cmp	x8, x0, asr #63
   783c4: 54000181     	b.ne	0x783f4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1b8>
   783c8: 52800001     	mov	w1, #0x0                ; =0
   783cc: d65f03c0     	ret
   783d0: 91000421     	add	x1, x1, #0x1
   783d4: 17ffffaf     	b	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   783d8: 52800021     	mov	w1, #0x1                ; =1
   783dc: d65f03c0     	ret
   783e0: d4200020     	brk	#0x1
   783e4: d4200020     	brk	#0x1
   783e8: d4200020     	brk	#0x1
   783ec: d4200020     	brk	#0x1
   783f0: d4200020     	brk	#0x1
   783f4: d4200020     	brk	#0x1
   783f8: d4200020     	brk	#0x1
