
/private/tmp/swiftsci-csv-integer-overflow-20261024/sequential-build/SwiftDataFrame.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000007823c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n>:
   7823c: f100045f     	cmp	x2, #0x1
   78240: 540001cd     	b.le	0x78278 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x3c>
   78244: 38616808     	ldrb	w8, [x0, x1]
   78248: 7100891f     	cmp	w8, #0x22
   7824c: 540001a1     	b.ne	0x78280 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x44>
   78250: ab020028     	adds	x8, x1, x2
   78254: 54000ca6     	b.vs	0x783e8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1ac>
   78258: f1000508     	subs	x8, x8, #0x1
   7825c: 54000c86     	b.vs	0x783ec <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1b0>
   78260: 38686808     	ldrb	w8, [x0, x8]
   78264: 7100891f     	cmp	w8, #0x22
   78268: 540000c1     	b.ne	0x78280 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x44>
   7826c: b1000421     	adds	x1, x1, #0x1
   78270: 54000c06     	b.vs	0x783f0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1b4>
   78274: d1000842     	sub	x2, x2, #0x2
   78278: f100045f     	cmp	x2, #0x1
   7827c: 54000aeb     	b.lt	0x783d8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x19c>
   78280: ab020028     	adds	x8, x1, x2
   78284: 54000b06     	b.vs	0x783e4 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x1a8>
   78288: eb08003f     	cmp	x1, x8
   7828c: 5400042b     	b.lt	0x78310 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xd4>
   78290: 52800009     	mov	w9, #0x0                ; =0
   78294: eb08003f     	cmp	x1, x8
   78298: 54000a0a     	b.ge	0x783d8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x19c>
   7829c: 3861680a     	ldrb	w10, [x0, x1]
   782a0: 5100c14b     	sub	w11, w10, #0x30
   782a4: 12001d6a     	and	w10, w11, #0xff
   782a8: 7100255f     	cmp	w10, #0x9
   782ac: 1a9f97ea     	cset	w10, hi
   782b0: 54000489     	b.ls	0x78340 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x104>
   782b4: d280000b     	mov	x11, #0x0               ; =0
   782b8: 9100042c     	add	x12, x1, #0x1
   782bc: eb0c011f     	cmp	x8, x12
   782c0: 9a81c50c     	csinc	x12, x8, x1, gt
   782c4: 5280002d     	mov	w13, #0x1               ; =1
   782c8: d284c00e     	mov	x14, #0x2600            ; =9728
   782cc: f2c0002e     	movk	x14, #0x1, lsl #32
   782d0: 3861680f     	ldrb	w15, [x0, x1]
   782d4: 710081ff     	cmp	w15, #0x20
   782d8: 9acf21af     	lsl	x15, x13, x15
   782dc: 8a0e01ef     	and	x15, x15, x14
   782e0: fa4099e4     	ccmp	x15, #0x0, #0x4, ls
   782e4: 540003c0     	b.eq	0x7835c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x120>
   782e8: 91000421     	add	x1, x1, #0x1
   782ec: eb08003f     	cmp	x1, x8
   782f0: 54ffff0b     	b.lt	0x782d0 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x94>
   782f4: aa0c03e1     	mov	x1, x12
   782f8: 14000019     	b	0x7835c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x120>
   782fc: 7100253f     	cmp	w9, #0x9
   78300: 54fffc81     	b.ne	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   78304: 91000421     	add	x1, x1, #0x1
   78308: f1000442     	subs	x2, x2, #0x1
   7830c: 54000660     	b.eq	0x783d8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x19c>
   78310: 38616809     	ldrb	w9, [x0, x1]
   78314: 71007d3f     	cmp	w9, #0x1f
   78318: 54ffff2d     	b.le	0x782fc <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xc0>
   7831c: 7100813f     	cmp	w9, #0x20
   78320: 54ffff20     	b.eq	0x78304 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0xc8>
   78324: 7100ad3f     	cmp	w9, #0x2b
   78328: 54000320     	b.eq	0x7838c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x150>
   7832c: 7100b53f     	cmp	w9, #0x2d
   78330: 54fffb01     	b.ne	0x78290 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x54>
   78334: 91000421     	add	x1, x1, #0x1
   78338: 52800029     	mov	w9, #0x1                ; =1
   7833c: 17ffffd6     	b	0x78294 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x58>
   78340: d280000c     	mov	x12, #0x0               ; =0
   78344: cb2b018b     	sub	x11, x12, w11, uxtb
   78348: 91000421     	add	x1, x1, #0x1
   7834c: eb08003f     	cmp	x1, x8
   78350: 54000241     	b.ne	0x78398 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x15c>
   78354: 5280000a     	mov	w10, #0x0               ; =0
   78358: aa0803e1     	mov	x1, x8
   7835c: eb08003f     	cmp	x1, x8
   78360: 1a9f0548     	csinc	w8, w10, wzr, eq
   78364: 2a080129     	orr	w9, w9, w8
   78368: 7100011f     	cmp	w8, #0x0
   7836c: 9a8b13ea     	csel	x10, xzr, x11, ne
   78370: eb0b03eb     	negs	x11, x11
   78374: 1a9f77ec     	cset	w12, vs
   78378: 9a8b63eb     	csel	x11, xzr, x11, vs
   7837c: 7200013f     	tst	w9, #0x1
   78380: 9a8b1140     	csel	x0, x10, x11, ne
   78384: 1a8c1101     	csel	w1, w8, w12, ne
   78388: d65f03c0     	ret
   7838c: 52800009     	mov	w9, #0x0                ; =0
   78390: 91000421     	add	x1, x1, #0x1
   78394: 17ffffc0     	b	0x78294 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x58>
   78398: 5280014c     	mov	w12, #0xa               ; =10
   7839c: 3861680d     	ldrb	w13, [x0, x1]
   783a0: 5100c1ad     	sub	w13, w13, #0x30
   783a4: 710029bf     	cmp	w13, #0xa
   783a8: 54fff882     	b.hs	0x782b8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x7c>
   783ac: 9b4c7d6e     	smulh	x14, x11, x12
   783b0: 8b0b096b     	add	x11, x11, x11, lsl #2
   783b4: d37ff96b     	lsl	x11, x11, #1
   783b8: eb8bfddf     	cmp	x14, x11, asr #63
   783bc: 540000e1     	b.ne	0x783d8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x19c>
   783c0: eb2d016b     	subs	x11, x11, w13, uxtb
   783c4: 540000a6     	b.vs	0x783d8 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x19c>
   783c8: 91000421     	add	x1, x1, #0x1
   783cc: eb01011f     	cmp	x8, x1
   783d0: 54fffe61     	b.ne	0x7839c <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x160>
   783d4: 17ffffe0     	b	0x78354 <_$s14SwiftDataFrame21VectorizedByteParsersO8parseInt6buffer6offsetSiSgSRys5UInt8VG_AA14CSVFieldOffsetVtFZTf4nnd_nTf4xx_n+0x118>
   783d8: d2800000     	mov	x0, #0x0                ; =0
   783dc: 52800021     	mov	w1, #0x1                ; =1
   783e0: d65f03c0     	ret
   783e4: d4200020     	brk	#0x1
   783e8: d4200020     	brk	#0x1
   783ec: d4200020     	brk	#0x1
   783f0: d4200020     	brk	#0x1
