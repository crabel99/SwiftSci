print("Full native validation deferred until the arithmetic-cost investigation is complete.", flush=True)
