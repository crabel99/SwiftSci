"""Public CSV boundary check; nonzero exit preserves a crash or wrong native result."""
from pathlib import Path
import argparse,json,hashlib,struct,sys
s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(s))
from Benchmarks.CPUThroughput.run import Worker,save
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False)
results=[]
for name,text,value in [('max','9223372036854775807',2**63-1),('min','-9223372036854775808',-2**63),('above-max','9223372036854775808',None),('below-min','-9223372036854775809',None)]:
 csv=a.out/(name+'.csv');csv.write_text('x\n'+text+'\n');contract=a.out/(name+'.json')
 save(contract,dict(id=name,path=str(csv),rows=1,names=['x'],types=['Int64'],null_tokens=['?'],delimiter=',',sha256=hashlib.sha256(csv.read_bytes()).hexdigest()))
 encoded=b'\0' if value is None else b'\1'+struct.pack('<q',value)
 expected=dict(frame=dict(rows=1,columns=[dict(name='x',type='Int64',nulls=int(value is None),sha256=hashlib.sha256(encoded).hexdigest())]),matrix_sha256='absent')
 worker=Worker(a.binary,'optional',a.out/(name+'.log'))
 try:
  actual=worker.ask(dict(id=0,contract=str(contract),workflow='read',key='x',verify=True))
  result=dict(case=name,expected=expected,passed=actual['check']==expected,result=actual)
 except Exception as error:result=dict(case=name,expected=expected,passed=False,error=str(error),exit_code=worker.process.poll())
 finally:worker.close()
 results.append(result);save(a.out/'results.json',results);print({k:v for k,v in result.items() if k not in ['expected','result']},flush=True)
sys.exit(0 if all(r['passed'] for r in results) else 1)
