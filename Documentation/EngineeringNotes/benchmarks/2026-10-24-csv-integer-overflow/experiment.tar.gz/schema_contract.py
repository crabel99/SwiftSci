"""Effective options for one reviewed, immutable throughput worker implementation."""
WORKER = "Benchmarks/CPUThroughput/Worker.swift"
REVIEWED_SHA256 = "4d9c46bf307e59a68e7998140a5067ad5456044879d1bbf35bb88f867ac21867"

def effective_options(receipt, contracts):
    if receipt["sources"].get(WORKER) != REVIEWED_SHA256:
        raise ValueError("Unreviewed worker: inspect its effective CSV options before timing")
    result = {}
    for path, contract in contracts.items():
        names, types = contract["names"], contract["types"]
        if len(names) != len(types) or len(set(names)) != len(names):
            raise ValueError("Invalid complete schema")
        if not set(types) <= {"String", "Double", "Int64"}:
            raise ValueError("Unsupported worker dtype")
        result[path] = dict(schema_mode="full_explicit", type_inference=False,
            column_type_overrides=dict(zip(names, types)),
            column_conversion="parallel", delimiter=contract["delimiter"],
            null_tokens=contract["null_tokens"], storage_modes=["optional", "compact"])
    return dict(proof="Reviewed worker source pinned by build-receipt SHA256; static, not runtime introspection",
        worker_sha256=REVIEWED_SHA256, contracts=result)
