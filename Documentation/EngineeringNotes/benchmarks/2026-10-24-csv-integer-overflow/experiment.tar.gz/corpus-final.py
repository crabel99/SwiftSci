from pathlib import Path
import argparse,csv,hashlib,json,random,struct,sys
s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(s))
from Benchmarks.CPUThroughput.run import Worker,save,digest
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);a=p.parse_args()
r=Path(__file__).parent/'corpus-final';r.mkdir(exist_ok=False)
rng=random.Random(20261024);tokens=[str(x) for x in range(-100,101)]
tokens += [str(x) for edge in [-(2**63),2**63-1] for x in range(edge-20,edge+21)]
tokens += [str(rng.randrange(-(2**63),2**63)) for _ in range(4000)]
tokens += [('-' if rng.randrange(2) else '')+''.join(str(rng.randrange(10)) for _ in range(rng.randrange(20,201))) for _ in range(500)]
tokens += ['', '?', '+', '-', '1x', '1.0', '1e3', '--1', '+-1', '1 2']
original=tokens.copy()
for i,t in enumerate(original[:1000]):
 tokens.extend([' \t'+t+' \t','\u00a0'+t+'\u00a0'])
tokens += ['0'*100+'1','-'+'0'*100+'1','+'+'0'*100+'1']
f=r/'integers.csv'
with f.open('w',newline='') as out:
 w=csv.writer(out);w.writerow(['x','label']);w.writerows((t,'row') for t in tokens)
encoded=bytearray();labels=bytearray();nulls=0
for t in tokens:
 try:
  stripped=t.strip();value=int(stripped) if stripped and all(c in '+-0123456789' for c in stripped) else None
 except ValueError:value=None
 if value is not None and not -(2**63)<=value<2**63:value=None
 if value is None:encoded.append(0);nulls+=1
 else:encoded.append(1);encoded.extend(struct.pack('<q',value))
 labels.append(1);labels.extend(struct.pack('<I',3));labels.extend(b'row')
c=r/'contract.json';save(c,dict(id='corpus',path=str(f),rows=len(tokens),names=['x','label'],types=['Int64','String'],null_tokens=['?'],delimiter=',',sha256=digest(f)))
expected=dict(frame=dict(rows=len(tokens),columns=[dict(name='x',type='Int64',nulls=nulls,sha256=hashlib.sha256(encoded).hexdigest()),dict(name='label',type='String',nulls=0,sha256=hashlib.sha256(labels).hexdigest())]),matrix_sha256='absent')
save(r/'expected.json',expected);results=[]
for storage in ['optional','compact']:
 worker=Worker(a.binary,storage,r/(storage+'.log'))
 try:
  actual=worker.ask(dict(id=0,contract=str(c),workflow='read',key='x',verify=True))
  results.append(dict(storage=storage,passed=actual['check']==expected,result=actual))
 finally:worker.close()
save(r/'results.json',dict(rows=len(tokens),nulls=nulls,results=results))
print(dict(rows=len(tokens),nulls=nulls,passed=all(x['passed'] for x in results)),flush=True)
assert all(x['passed'] for x in results)
