# Representative Core ML inference

These are development benchmarks on frozen repository splits. Training, model compilation, source-batch construction and reference calculations are outside the Swift inference timer. Loading is recorded separately and may use Core ML caches. Prediction includes input packing, execution and owned output extraction. Python controls separately include fitted scaling. No application acceptance threshold is established.

| Dataset | Rows | Mode | Load ms | First ms | Warm median ms | Warm p95 ms | Max absolute error | Strict reference | Peak RSS MiB |
|---|---:|---|---:|---:|---:|---:|---:|---|---:|
| wdbc | 1 | coreml-all-matrix | 34.847 | 0.210 | 0.015 | 0.019 | 5.42543e-07 | pass | 20.0 |
| wdbc | 1 | coreml-all-matrix-adapter | 35.327 | 0.235 | 0.019 | 0.024 | 5.42543e-07 | pass | 20.2 |
| wdbc | 1 | coreml-cpu | 3.149 | 0.222 | 0.019 | 0.022 | 5.42543e-07 | pass | 17.4 |
| wdbc | 1 | coreml-cpu-matrix | 3.040 | 0.202 | 0.015 | 0.018 | 5.42543e-07 | pass | 17.1 |
| wdbc | 1 | coreml-cpu-matrix-adapter | 3.178 | 0.208 | 0.020 | 0.023 | 5.42543e-07 | pass | 17.3 |
| wdbc | 1 | coreml-gpu-matrix | 12.896 | 0.384 | 0.041 | 0.080 | 5.42543e-07 | pass | 19.9 |
| wdbc | 1 | coreml-gpu-matrix-adapter | 11.661 | 0.342 | 0.046 | 0.061 | 5.42543e-07 | pass | 20.1 |
| wdbc | 1 | coreml-neural-matrix | 32.783 | 0.330 | 0.014 | 0.015 | 5.42543e-07 | pass | 19.9 |
| wdbc | 1 | coreml-neural-matrix-adapter | 33.110 | 0.211 | 0.019 | 0.027 | 5.42543e-07 | pass | 20.0 |
| wdbc | 1 | mlx-cpu | 9.929 | 0.475 | 0.041 | 0.058 | 4.11132e-07 | pass | 28.0 |
| wdbc | 1 | mlx-gpu | 7.930 | 8.422 | 0.297 | 0.539 | 5.42543e-07 | pass | 30.9 |
| wdbc | 32 | coreml-all-matrix | 37.089 | 0.335 | 0.025 | 0.051 | 2.69969e-06 | pass | 20.4 |
| wdbc | 32 | coreml-all-matrix-adapter | 37.933 | 0.354 | 0.032 | 0.091 | 2.69969e-06 | pass | 20.7 |
| wdbc | 32 | coreml-cpu | 2.575 | 0.508 | 0.274 | 0.283 | 3.39163e-06 | pass | 17.4 |
| wdbc | 32 | coreml-cpu-matrix | 2.726 | 0.347 | 0.025 | 0.058 | 2.69969e-06 | pass | 17.4 |
| wdbc | 32 | coreml-cpu-matrix-adapter | 2.550 | 0.384 | 0.029 | 0.078 | 2.69969e-06 | pass | 17.7 |
| wdbc | 32 | coreml-gpu-matrix | 10.426 | 0.374 | 0.055 | 0.130 | 2.69969e-06 | pass | 20.2 |
| wdbc | 32 | coreml-gpu-matrix-adapter | 14.280 | 0.317 | 0.066 | 0.161 | 2.69969e-06 | pass | 20.4 |
| wdbc | 32 | coreml-neural-matrix | 34.093 | 0.301 | 0.024 | 0.050 | 2.69969e-06 | pass | 20.3 |
| wdbc | 32 | coreml-neural-matrix-adapter | 30.083 | 0.278 | 0.027 | 0.060 | 2.69969e-06 | pass | 20.4 |
| wdbc | 32 | mlx-cpu | 9.446 | 0.350 | 0.046 | 0.059 | 2.47754e-06 | pass | 28.1 |
| wdbc | 32 | mlx-gpu | 9.553 | 312.310 | 0.277 | 0.553 | 3.17815e-06 | pass | 31.2 |
| wdbc | 126 | coreml-all-matrix | 38.318 | 0.251 | 0.030 | 0.033 | 6.70589e-06 | pass | 20.4 |
| wdbc | 126 | coreml-all-matrix-adapter | 35.464 | 0.272 | 0.033 | 0.036 | 6.70589e-06 | pass | 20.6 |
| wdbc | 126 | coreml-cpu | 3.395 | 1.510 | 1.046 | 1.098 | 3.39163e-06 | pass | 17.6 |
| wdbc | 126 | coreml-cpu-matrix | 3.592 | 0.436 | 0.031 | 0.035 | 6.70589e-06 | pass | 17.4 |
| wdbc | 126 | coreml-cpu-matrix-adapter | 2.753 | 0.243 | 0.033 | 0.047 | 6.70589e-06 | pass | 17.7 |
| wdbc | 126 | coreml-gpu-matrix | 10.731 | 0.320 | 0.055 | 0.087 | 6.70589e-06 | pass | 20.2 |
| wdbc | 126 | coreml-gpu-matrix-adapter | 11.847 | 0.308 | 0.067 | 0.097 | 6.70589e-06 | pass | 20.5 |
| wdbc | 126 | coreml-neural-matrix | 32.011 | 0.231 | 0.030 | 0.035 | 6.70589e-06 | pass | 20.3 |
| wdbc | 126 | coreml-neural-matrix-adapter | 33.153 | 0.316 | 0.034 | 0.038 | 6.70589e-06 | pass | 20.4 |
| wdbc | 126 | mlx-cpu | 9.167 | 0.482 | 0.058 | 0.093 | 6.70589e-06 | pass | 28.4 |
| wdbc | 126 | mlx-gpu | 9.475 | 8.344 | 0.335 | 0.650 | 3.86277e-06 | pass | 31.2 |
| wine | 1 | coreml-all-matrix | 33.529 | 0.229 | 0.016 | 0.019 | 1.33956e-06 | pass | 19.9 |
| wine | 1 | coreml-all-matrix-adapter | 33.362 | 0.204 | 0.018 | 0.027 | 1.33956e-06 | pass | 20.0 |
| wine | 1 | coreml-cpu | 3.654 | 0.228 | 0.017 | 0.023 | 1.33956e-06 | pass | 17.3 |
| wine | 1 | coreml-cpu-matrix | 6.303 | 0.199 | 0.015 | 0.017 | 1.33956e-06 | pass | 17.0 |
| wine | 1 | coreml-cpu-matrix-adapter | 3.142 | 0.200 | 0.019 | 0.031 | 1.33956e-06 | pass | 17.2 |
| wine | 1 | coreml-gpu-matrix | 10.526 | 0.264 | 0.038 | 0.057 | 1.33956e-06 | pass | 19.8 |
| wine | 1 | coreml-gpu-matrix-adapter | 10.026 | 0.342 | 0.044 | 0.079 | 1.33956e-06 | pass | 19.9 |
| wine | 1 | coreml-neural-matrix | 32.618 | 0.227 | 0.016 | 0.025 | 1.33956e-06 | pass | 19.8 |
| wine | 1 | coreml-neural-matrix-adapter | 33.245 | 0.305 | 0.020 | 0.026 | 1.33956e-06 | pass | 19.9 |
| wine | 1 | mlx-cpu | 8.889 | 0.332 | 0.040 | 0.053 | 6.83905e-07 | pass | 27.9 |
| wine | 1 | mlx-gpu | 10.383 | 465.015 | 0.297 | 0.580 | 1.10114e-06 | pass | 31.1 |
| wine | 32 | coreml-all-matrix | 38.739 | 0.304 | 0.022 | 0.049 | 2.12545e-06 | pass | 20.3 |
| wine | 32 | coreml-all-matrix-adapter | 37.216 | 0.322 | 0.028 | 0.061 | 2.12545e-06 | pass | 20.6 |
| wine | 32 | coreml-cpu | 3.684 | 0.560 | 0.264 | 0.277 | 2.42593e-06 | pass | 17.3 |
| wine | 32 | coreml-cpu-matrix | 2.888 | 0.287 | 0.023 | 0.045 | 2.12545e-06 | pass | 17.4 |
| wine | 32 | coreml-cpu-matrix-adapter | 4.011 | 0.339 | 0.027 | 0.040 | 2.12545e-06 | pass | 17.6 |
| wine | 32 | coreml-gpu-matrix | 11.370 | 0.308 | 0.049 | 0.099 | 2.12545e-06 | pass | 20.1 |
| wine | 32 | coreml-gpu-matrix-adapter | 9.769 | 0.295 | 0.053 | 0.106 | 2.12545e-06 | pass | 20.2 |
| wine | 32 | coreml-neural-matrix | 32.544 | 0.273 | 0.022 | 0.072 | 2.12545e-06 | pass | 20.1 |
| wine | 32 | coreml-neural-matrix-adapter | 36.371 | 0.318 | 0.029 | 0.058 | 2.12545e-06 | pass | 20.3 |
| wine | 32 | mlx-cpu | 8.853 | 0.315 | 0.045 | 0.060 | 2.34245e-06 | pass | 28.0 |
| wine | 32 | mlx-gpu | 8.764 | 7.919 | 0.467 | 0.542 | 1.39131e-06 | pass | 31.0 |
| wine | 342 | coreml-all-matrix | 39.787 | 0.473 | 0.036 | 0.040 | 4.24979e-06 | pass | 20.4 |
| wine | 342 | coreml-all-matrix-adapter | 32.912 | 0.260 | 0.042 | 0.047 | 4.24979e-06 | pass | 20.7 |
| wine | 342 | coreml-cpu | 2.705 | 3.225 | 2.775 | 2.936 | 2.6609e-06 | pass | 17.8 |
| wine | 342 | coreml-cpu-matrix | 3.398 | 0.245 | 0.036 | 0.040 | 4.24979e-06 | pass | 17.5 |
| wine | 342 | coreml-cpu-matrix-adapter | 2.850 | 0.269 | 0.043 | 0.046 | 4.24979e-06 | pass | 17.6 |
| wine | 342 | coreml-gpu-matrix | 12.383 | 0.332 | 0.067 | 0.101 | 4.24979e-06 | pass | 20.6 |
| wine | 342 | coreml-gpu-matrix-adapter | 11.177 | 0.302 | 0.071 | 0.106 | 4.24979e-06 | pass | 20.5 |
| wine | 342 | coreml-neural-matrix | 33.114 | 0.252 | 0.036 | 0.040 | 4.24979e-06 | pass | 20.3 |
| wine | 342 | coreml-neural-matrix-adapter | 32.961 | 0.243 | 0.042 | 0.046 | 4.24979e-06 | pass | 20.3 |
| wine | 342 | mlx-cpu | 9.846 | 0.434 | 0.079 | 0.152 | 2.00013e-06 | pass | 28.8 |
| wine | 342 | mlx-gpu | 8.457 | 10.485 | 0.349 | 0.607 | 1.90512e-06 | pass | 31.3 |

Task quality compares actual held-out predictions, not the numerical tolerance above. CPU, GPU and Neural Engine names in this table mean allowed compute units. Actual placement requires separate inspected trace events.

## wdbc held-out quality

Training-only scaling, frozen Float32-shared weights, 563 optimizer iterations. Warnings: [].

```json
{
  "independent": {
    "validation": {
      "accuracy": 0.9739130434782609,
      "roc_auc": 0.9886578449905482,
      "log_loss": 0.15465557542180874
    },
    "test": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139446194663
    },
    "constant_test": {
      "accuracy": 0.6031746031746031,
      "roc_auc": 0.5,
      "log_loss": 0.6757114938572296
    }
  },
  "measured": {
    "coreml-neural-matrix-adapter": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "coreml-gpu-matrix": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "mlx-cpu": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.27511394842408643
    },
    "coreml-cpu": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.27511394891687874
    },
    "coreml-all-matrix-adapter": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "coreml-all-matrix": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "coreml-gpu-matrix-adapter": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "mlx-gpu": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139258109234
    },
    "coreml-cpu-matrix": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "coreml-neural-matrix": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    },
    "coreml-cpu-matrix-adapter": {
      "accuracy": 0.9603174603174603,
      "roc_auc": 0.9878947368421053,
      "log_loss": 0.2751139307226327
    }
  }
}
```

## wine held-out quality

Training-only scaling, frozen Float32-shared weights, 1000 optimizer iterations. Warnings: ['lbfgs failed to converge after 1000 iteration(s) (status=1):\nSTOP: TOTAL NO. OF ITERATIONS REACHED LIMIT\n\nIncrease the number of iterations to improve the convergence (max_iter=1000).\nYou might also want to scale the data as shown in:\n    https://scikit-learn.org/stable/modules/preprocessing.html'].

```json
{
  "independent": {
    "validation": {
      "rmse": 0.9834412637491623,
      "mae": 0.7499498737291701,
      "r2": -0.4399762812606751
    },
    "test": {
      "rmse": 0.956911548863585,
      "mae": 0.7360075706623465,
      "r2": -0.40119265627623824
    },
    "constant_test": {
      "rmse": 0.8095095293084176,
      "mae": 0.6733561397410801,
      "r2": -0.002762746956975759
    }
  },
  "measured": {
    "mlx-cpu": {
      "rmse": 0.9569115420555662,
      "mae": 0.7360075787725264,
      "r2": -0.4011926363384586
    },
    "coreml-gpu-matrix": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-all-matrix-adapter": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-gpu-matrix-adapter": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-neural-matrix-adapter": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-cpu-matrix-adapter": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-neural-matrix": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-cpu": {
      "rmse": 0.9569115253421331,
      "mae": 0.7360075289491298,
      "r2": -0.40119258739195063
    },
    "coreml-cpu-matrix": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "coreml-all-matrix": {
      "rmse": 0.9569114847403466,
      "mae": 0.7360075195055936,
      "r2": -0.401192468486661
    },
    "mlx-gpu": {
      "rmse": 0.9569115423075399,
      "mae": 0.736007561441889,
      "r2": -0.4011926370763821
    }
  }
}
```

