from pathlib import Path
import json,subprocess,tarfile,hashlib,gzip,shutil,ast,re
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-double-storage-choice'
if T.exists():assert {p.name for p in T.iterdir()} <= {'README.md','results.md','audit.json','comparator-provenance.json','changes.patch.gz','experiments.tar.gz','artifact-sha256.json'}
T.mkdir(parents=True,exist_ok=True)
audit=json.loads((R/'audit.json').read_text());assert audit['all_outputs_match']
summary=json.loads((R/'measurement/summary.json').read_text())
rows=[]
for storage in ['optional','compact']:
 for flow in ['join-materialize','batch']:
  g={x['engine']:x['medians'] for x in summary if x['case']=='energy-common/serial/'+storage+'/'+flow}
  trip=lambda key,scale:' / '.join(f'{g[label][key]/scale:.2f}' for label in ['original','prior','current'])
  rows.append(f"| {storage} / {flow} | {trip('total_cpu_ns',1e6)} | {trip('held_heap_bytes',2**20)} | {trip('process_peak_held_bytes',2**20)} |")
choice_rows=[]
for flow in ['join-materialize','batch']:
 groups={storage:{x['engine']:x['medians'] for x in summary if x['case']=='energy-common/serial/'+storage+'/'+flow} for storage in ['optional','compact']}
 cells=[]
 for storage in ['optional','compact']:
  g=groups[storage]['current'];cells.append(f"{g['total_cpu_ns']/1e6:.2f} ms / {g['held_heap_bytes']/2**20:.2f} MiB / {g['process_peak_held_bytes']/2**20:.2f} MiB")
 choice_rows.append('| '+flow+' | '+' | '.join(cells)+' |')
head=audit['current_head']
readme=f'''# Choosing CSV Double storage

CSV callers can now choose the physical representation of native Double columns with `CSVReadOptions.doubleStorage`. The default is `.optional`, preserving the original reader's optional arrays and shared `.values` exports. `.compact` explicitly selects dense Double values and validity bits for direct numerical preparation. Both choices preserve values, nulls and native types. Int64 values are not converted to Double.

This is a child of [compact nullable joins](../2026-10-23-csv-compact-join/README.md), which measured a memory penalty when a caller retained a compact frame alongside optional exports. The choice is explicit because the preferred representation depends on those consumer lifetimes.

## Public interface

```swift
var options = CSVReadOptions()
options.doubleStorage = .optional
let legacy = try await DataFrame(csv: url, options: options)

options.doubleStorage = .compact
let numerical = try await DataFrame(csv: url, options: options)
let batch = try numerical.prepareNumericBatch(["feature"])
```

Optional storage keeps `.values` exports shared through copy-on-write. Compact storage materializes an optional array on each `.values` request. Retaining those exports alongside the compact column retains both representations. Eager and streamed reads honor the same option, with either serial or parallel column conversion. Inference retries retain the policy when a sampled integer column promotes to Double.

## One parser, two existing builders

`CSVValueDecoder` no longer owns a builder type or factory. `CSVColumnAttempt` accepts an independent builder and shares its existing conversion, rejection, reset and finalization loops. The column plan selects the existing optional or compact Double builder once per attempt. Both Double paths use the same decoder and validation loop. No storage-policy branch was added inside the row loop, and no legacy factory or decoder wrapper was retained.

## Matched reference comparison

- Original is the fixed optional-array reader at `5d1f89a961106104757f2d8d0b8faba79487d100`.
- Prior is the fixed compact join prototype at `a95ef036982e91d87dcddf50f972a64a27f20a74`.
- Current is `codex/csv-double-storage-choice` at `{head}` and honors the policy in each case.
- Twin repeats the exact current executable with the same policy.

All versions use identical client source, input contracts, lookup contents and operation scope. Historical interfaces lack the new property, so only the current client enables `CSV_STORAGE_CHOICE`, which sets the option before timing. This flag changes neither compiler optimization settings nor timed workload code. Each worker records its effective storage, including the fixed historical representations. Physical representation is the deliberate variable in this experiment. Input values, null tokens, schema, row order and full output fingerprints remain equal.

The table reports the 2,075,259-row household dataset with serial column conversion. Each entry lists original, prior and current medians. `join-materialize` retains a complete left-joined frame and all requested optional Double exports. `batch` retains the CSV frame and its prepared numerical batch.

| Current choice and workflow | CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |
|---|---:|---:|---:|
{chr(10).join(rows)}

[Full resource results](results.md) include both reference datasets, both conversion modes and both storage choices. Household parsing uses the same eleven declared null tokens, including `?`, for every version. Air-quality parsing uses the same ten default tokens. Schemas are explicit and identical. Native CPU scheduling is unchanged, and no worker cap or dataset-specific threshold was added.

## The tradeoff in the current implementation

These are both choices in the same current executable, using household data with serial conversion. Each entry reports total CPU, held heap and peak RSS.

| Workflow | Optional CPU / held heap / peak RSS | Compact CPU / held heap / peak RSS |
|---|---:|---:|
{chr(10).join(choice_rows)}

For the joined frame plus optional exports, optional storage avoids about 113 MiB of retained heap, but uses about 241 ms more CPU and 92 MiB more peak RSS than compact storage. Compact storage retains both representations in this workload. For the numerical batch, compact storage avoids about 222 MiB of held heap with similar total CPU. These measurements support a caller-visible choice rather than a universal resource score or an automatic size threshold.

## Validation and measurement

The default-export regression fails before the change because the prior prototype retains compact storage and creates separate arrays on repeated `.values` exports. It passes afterward. Public tests check both policies under explicit and inferred schemas, streamed chunks, selections and outer joins. They verify exact integer identifiers above 2^53, missing values, signed zero, valid NaNs and infinities. Optional exports share storage, compact exports have separate arrays, and mutations preserve snapshots. Late integer-to-Double promotion, rejection to text and explicit conversion failures retain their existing semantics and the requested layout.

Release, Debug and Address Sanitizer each pass all 413 dataframe tests with no failures or skips. Twenty-eight eager reference checks and twenty-eight streaming checks cover both policies with pinned native types, value and null hashes and ordering. All 64 workflow preflights and 512 measured processes match the original output fingerprints. Derived-workflow equivalence is a regression check, not independent mathematical certification.

Eight balanced orders give each label each position twice and each ordered adjacent pair twice. The unchanged quality policy flags more than 10% current/twin median CPU difference or peak-memory differences beyond 5% plus 8 MiB. Flags remain disqualifying for affected comparisons. The audit records `quality_passed={audit['quality_passed']}` with these flags: `{json.dumps(audit['quality_flags'])}`.

All tests and builds finished before accepted measurements. AC power was checked at both ends. Each comparator client imports the matching module interface for its linked object. Build receipts, source hashes and binary hashes are archived. Full output validation is outside timing. The audit recomputes medians and checks fingerprints, effective storage and power receipts.

CPU means process user plus system time. Held heap measures malloc live bytes, and peak RSS measures a different process memory cost. The experiment does not measure energy, FLOPs or cache activity. Address Sanitizer does not establish universal leak freedom. These changes remain local and have not been pushed or submitted as a PR.

## Evidence and reproduction

- [Full results](results.md).
- [Independent audit](audit.json).
- [Comparator source provenance](comparator-provenance.json).
- [Exact source patch](changes.patch.gz).
- [Scripts, sources, raw records and receipts](experiments.tar.gz).
- [Artifact hashes](artifact-sha256.json).

Restore the recorded prior commit, decompress and apply the patch, restore pinned dependencies, and update machine-specific paths. Run the Release dataframe tests with `verify.py`, then `validate.py` for Debug, Address Sanitizer and client builds. `measure.py` runs both-policy reference checks, workflow preflights, measurements and the audit. The archive excludes executables, caches, result bundles and large reference CSVs. Engineering records stay on `codex/engineering-notes`; source and tests stay on the experiment branch.
'''
(T/'README.md').write_text(readme)
for name in ['results.md','audit.json','comparator-provenance.json']:shutil.copy2(R/name,T/name)
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as out:out.write((R/'changes.patch').read_bytes())
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==(R/'changes.patch').read_bytes()
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.txt','.log','.md','.patch','.jsonl'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for p in (S/'Sources/SwiftDataFrame').rglob('*.swift'):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 for name in ['CSVDoubleStorageDefaultTests.swift','CSVDoubleStorageModeTests.swift','CSVDoubleStorageInferenceTests.swift','CSVBatchBuilderStateTests.swift']:
  tar.add(S/'Tests/SwiftDataFrameTests'/name,arcname='final-source/Tests/SwiftDataFrameTests/'+name)
 for label,root,filename in [('original','/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata','build.json'),('prior','/private/tmp/swiftsci-csv-compact-join-20261023','module-build.json')]:
  tar.add(Path(root)/filename,arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',readme):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
assert '—' not in readme
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'}
(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(T/k)==v for k,v in manifest.items())
print(T);print('Verified evidence hashes, patch bytes, links, archive paths and script syntax')
