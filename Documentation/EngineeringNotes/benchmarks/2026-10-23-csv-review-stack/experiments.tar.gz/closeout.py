from pathlib import Path
import json,subprocess,re,hashlib,tarfile,shutil,datetime
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
W=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
N=W/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-review-stack'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,cwd=S):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
original=git('rev-parse','bc87628ce1');upstream=git('rev-parse','upstream/main')
assert git('branch','--show-current',cwd=W)=='codex/engineering-notes'
assert not git('status','--porcelain',cwd=W)
records={}
for label in ['ingestion','compact']:
 s=Path('/private/tmp/swiftsci-csv-'+label+'-review-20261023');r=R/label;head=git('rev-parse','HEAD',cwd=s)
 assert not git('status','--porcelain',cwd=s)
 base=upstream if label=='ingestion' else records['ingestion']['head']
 files=git('diff','--name-only',base,head,cwd=s).splitlines()
 assert not any('EngineeringNotes' in f or 'Reproductions' in f for f in files)
 native={};warnings=[]
 for mode in ['release','debug']:
  b=load(r/f'{mode}-build.json');t=load(r/f'{mode}-tests.json');q=t['summary']
  assert b['head']==t['head']==head and b['exit_code']==t['exit_code']==0
  assert q['totalTestCount']==q['passedTests'] and q['failedTests']==q['skippedTests']==0
  for name,h in b['sources'].items():assert sha(s/name)==h
  native[mode]={k:q[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests']}
  marker='/'+s.name+'/'
  for line in (r/f'{mode}-build.log').read_text().splitlines():
   if 'warning:' in line and 'type-check' in line and marker in line and line.split(marker,1)[1].split(':',1)[0] in files:warnings.append(line)
 assert not warnings,warnings
 controllers=(r/'controllers.log').read_text();assert 'Ran 226 tests' in controllers and re.search(r'\nOK\s*$',controllers) and 'skipped=' not in controllers
 targets=load(r/'test-target-coverage.json');assert targets['all_declared_targets_present'] and len(targets['declared_test_targets'])==15
 p=load(r/'cpu-policy/regression-policy.json');a=load(r/'cpu-policy/acceptance.json')
 assert p['status']=='passed' and not p['blocking'] and len(p['known_failures'])==4
 assert a['status']=='failed' and a['coverage_complete'] and a['source']['commit']==head
 assert p['acceptance_sha256']==sha(r/'cpu-policy/acceptance.json')
 assert p['baseline_sha256']==sha(s/'Benchmarks/Specs/known-failures.json')
 assert load(s/'Benchmarks/Specs/known-failures.json')['entries']==json.loads(subprocess.check_output(['git','show','a74f5c3b5e:Benchmarks/Specs/known-failures.json'],cwd=S))['entries']
 executions=sum(q['engine_cases'] for q in a['profiles']);assert executions==404
 doc=(r/'documentation.log').read_text();m=re.search(r'\((\d+)/(\d+) symbols documented\)',doc);assert m
 tests=[f for f in files if f.startswith('Tests/') and f.endswith('.swift')]
 records[label]={'worktree':str(s),'head':head,'branch':git('branch','--show-current',cwd=s),'base':base,'commits':int(git('rev-list','--count',base+'..'+head,cwd=s)),'changed_files':len(files),'files':files,'native_tests':native,'declared_test_targets':15,'controller_tests':226,'controller_skips':0,'cpu_executions':executions,'swiftsci_passed':202,'pandas_passed':198,'policy_status':p['status'],'strict_conformance_status':a['status'],'known_failures':p['known_failures'],'failure_entries_unchanged':True,'changed_file_typecheck_warnings':warnings,'largest_changed_swift_test_lines':max(len((s/f).read_text().splitlines()) for f in tests),'documentation':{'documented':int(m[1]),'total':int(m[2]),'actual_percentage':100*int(m[1])/int(m[2])}}
assert not git('diff','--name-only','5d1f89a961','codex/csv-ingestion-review','--','Sources','Package.swift','Package.resolved','Benchmarks/Worker','Benchmarks/Support')
assert git('rev-parse','codex/csv-compact-review^{tree}')==git('rev-parse',original+'^{tree}')
assert git('rev-parse','codex/csv-compact-integration')==original
summary={'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstream':upstream,'original_integration':original,'original_integration_preserved':True,'final_tree_identical':True,'reviews':records,'hosted_ci_run':False,'pushed':False,'pull_requests_created':False,'performance_remeasured':False}
(R/'audit.json').write_text(json.dumps(summary,indent=2)+'\n')
N.mkdir(parents=True,exist_ok=False)
for name in ['audit.json','scope.json'] :shutil.copyfile(R/name,N/name)
for label in records:
 (N/label).mkdir()
 for name in ['test-target-coverage.json','tree-equivalence.json','formal-build.json','cpu-policy-command.json']:
  p=R/label/name
  if p.exists():shutil.copyfile(p,N/label/name)
 for name in ['acceptance.json','regression-policy.json']:shutil.copyfile(R/label/'cpu-policy'/name,N/label/name)
with tarfile.open(N/'experiments.tar.gz','w:gz') as archive:
 for p in sorted(R.rglob('*')):
  if p.is_file() and not any(part.endswith('.xcresult') or part=='__pycache__' for part in p.relative_to(R).parts):archive.add(p,arcname=str(p.relative_to(R)),recursive=False)
subprocess.run(['git','bundle','create',str(N/'review-source.bundle'),'codex/csv-ingestion-review','codex/csv-compact-review','^upstream/main'],cwd=S,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','bundle','verify',str(N/'review-source.bundle')],cwd=S,check=True,stdout=subprocess.DEVNULL)
i=records['ingestion'];c=records['compact']
text=f'''# CSV review stack validation

Two local review branches now separate the reader and comparison contracts from selectable compact Double storage. Each branch passes its own full package tests and formal CPU regression policy. No branch was pushed and no PR was created.

## Review order and scope

| Order | Branch | Head | Commits in this review | Changed files |
|---|---|---|---:|---:|
| 1 | `{i['branch']}` | `{i['head']}` | {i['commits']} | {i['changed_files']} |
| 2 | `{c['branch']}` | `{c['head']}` | {c['commits']} | {c['changed_files']} |

The first branch starts from upstream `main` at `{upstream}`. It contains the 43 reader and comparison-contract commits through `5d1f89a961`, then the acceptance-request and reviewed coverage-fingerprint fixes. Record discovery, eager and streaming reads, inference validation, explicit date formats, and selectable conversion concurrency stay together with the matched-schema benchmark contracts. This cut also contains the earlier borrowed radix buffers and scalar column-gather changes used by the reader-to-sort path.

The second branch starts at the first branch's head. It adds the 13 compact-storage and consumer commits through `a74f5c3b5e`, then the test type-inference cleanup. Gathering, joining, filtering, numeric preparation, and stable sorting retain compact Double storage when the caller selects it. Optional storage remains the default.

Review the second branch against the first until the first lands. Then refresh it onto upstream `main` and validate the refreshed head. Do not submit both as independent diffs against the old upstream base.

## Independent validation results

| Check | Ingestion cut | Compact cut |
|---|---:|---:|
| Release native tests | {i['native_tests']['release']['passedTests']} passed | {c['native_tests']['release']['passedTests']} passed |
| Debug native tests | {i['native_tests']['debug']['passedTests']} passed | {c['native_tests']['debug']['passedTests']} passed |
| Native failures and skips | 0 | 0 |
| Declared test targets included | 15 of 15 | 15 of 15 |
| Benchmark controllers with Metal enabled | 226 passed, no skips | 226 passed, no skips |
| Formal CPU regression policy | Passed | Passed |
| SwiftSci strict CPU cases | 202 of 202 passed | 202 of 202 passed |
| pandas strict CPU cases | 198 of 202 passed | 198 of 202 passed |
| New or blocking policy failures | 0 | 0 |
| Long type-check warnings in changed Swift files | 0 | 0 |

Each branch has a separately built, uninstrumented benchmark worker with a verified source and binary receipt. Each CPU run covers 16 profiles and 404 engine executions. Both runs retain the four reviewed pandas Wampler accuracy failures as failed strict conformance. A passing regression policy does not mean full numerical conformance.

Native tests use the pinned MLX dependency, a hash-verified tokenizer, and strict ONNX prerequisites. Controller runs enable the four optional Metal checks. Their single-worker Polars correctness setting is not a performance comparison. ASan was not rerun for these review cuts.

Actual documentation coverage is {i['documentation']['documented']} of {i['documentation']['total']} declarations for ingestion and {c['documentation']['documented']} of {c['documentation']['total']} for compact storage. Both round to 98.66%. The existing script's incorrect 100% success sentence remains a tooling limitation. Hosted CodeQL and Codecov have not run. Local compile diagnostics and test size checks do not replace those checks.

## Preserve the measured checkpoints

The compact review tree is byte-for-byte identical to the validated integration tree at `{original}`. The original integration branch and experiment checkpoints remain unchanged. The new history moves the two acceptance fixes before the compact work, without changing the final source tree.

The [reference performance report](../2026-10-23-csv-sort-closeout/README.md) still identifies `a74f5c3b5e0e511bf5bb69886a40cbae48b28d99` as its measured compact head and `5d1f89a961106104757f2d8d0b8faba79487d100` as its pre-compact baseline. Those fingerprints are unchanged. No performance timings were remeasured or relabeled for the review branches.

For the representative household dataset, compact storage reduced peak memory by 25.6% for reading and 31.8% for the complete read, stable sort, and matrix path. Read CPU time increased by 4.9%, while complete-path CPU time decreased by 4.4%. These are observations from the recorded comparison, not an upstream-main speedup claim. Compact storage remains a caller choice.

## Evidence and recovery

The [audit](audit.json) records the actual heads, scopes, tests, and failure inventories. Each branch has its own [ingestion acceptance evidence](ingestion/acceptance.json) or [compact acceptance evidence](compact/acceptance.json), with matching regression-policy records. The [experiment archive](experiments.tar.gz) preserves validation drivers, build logs, requests, outputs, certificates, and receipts. It excludes xcresult bundles, compiled binaries, environments, and model weights.

The [source bundle](review-source.bundle) preserves both review branches relative to upstream. The [artifact hashes](artifact-sha256.json) identify the retained files. All reports and raw evidence remain on `codex/engineering-notes` and are absent from both source diffs.
'''
(N/'README.md').write_text(text)
manifest={str(p.relative_to(N)):sha(p) for p in sorted(N.rglob('*')) if p.is_file()};(N/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:{'head':v['head'],'commits':v['commits'],'files':v['changed_files'],'release_tests':v['native_tests']['release']['passedTests'],'debug_tests':v['native_tests']['debug']['passedTests']} for k,v in records.items()},indent=2))
print(N)
