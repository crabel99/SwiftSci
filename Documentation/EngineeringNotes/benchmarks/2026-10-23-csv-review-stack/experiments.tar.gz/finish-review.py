from pathlib import Path
import subprocess,json,time,os,plistlib,re
r=Path(__file__).resolve().parent
base=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');s=Path('/private/tmp/swiftsci-csv-ingestion-review-20261023');c=Path('/private/tmp/swiftsci-csv-compact-review-20261023')
py='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
def run(args,cwd=s,**kw):return subprocess.run(args,cwd=cwd,check=True,**kw)
def git(*args,cwd=s):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
start=time.monotonic()
while not (r/'ingestion/debug-tests.json').exists():
 if time.monotonic()-start>1800:raise TimeoutError('Ingestion native validation did not finish')
 time.sleep(5)
run(['python3',str(r/'validate-policy.py'),'ingestion'])
print('Ingestion review unit validated. Creating compact review branch.',flush=True)
run(['git','worktree','add','-b','codex/csv-compact-review',str(c),'codex/csv-ingestion-review'],cwd=base)
commits=git('rev-list','--reverse','5d1f89a961..a74f5c3b5e',cwd=base).splitlines();assert len(commits)==13
run(['git','cherry-pick',*commits,'bc87628ce1'],cwd=c)
assert git('rev-parse','HEAD^{tree}',cwd=c)==git('rev-parse','bc87628ce1^{tree}',cwd=base)
run(['git','diff','--exit-code','bc87628ce1','HEAD'],cwd=c)
(r/'compact/tree-equivalence.json').write_text(json.dumps({'head':git('rev-parse','HEAD',cwd=c),'original_integration':git('rev-parse','bc87628ce1',cwd=base),'tree':git('rev-parse','HEAD^{tree}',cwd=c),'identical':True},indent=2)+'\n')
run(['python3',str(r/'compact/validate.py')],cwd=c)
env=dict(os.environ,SWIFTSCI_MLX_TEST_GPU='1',POLARS_MAX_THREADS='1')
cmd=[py,'-m','unittest','discover','-s','Benchmarks/Tests']
with (r/'compact/controllers.log').open('x') as out:run(cmd,cwd=c,env=env,stdout=out,stderr=subprocess.STDOUT)
with (r/'compact/documentation.log').open('x') as out:run(['python3','scripts/verify_doc_coverage.py'],cwd=c,stdout=out,stderr=subprocess.STDOUT)
x=plistlib.loads(Path('/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/SwiftSci-Package_SwiftSci-Package_macosx27.0-arm64.xctestrun').read_bytes())
declared=re.findall(r'\.testTarget\(\s*name:\s*"([^"]+)"',(c/'Package.swift').read_text());targets=[v['BlueprintName'] for config in x['TestConfigurations'] for v in config['TestTargets']];assert set(declared)==set(targets)
(r/'compact/test-target-coverage.json').write_text(json.dumps({'declared_test_targets':declared,'executed_scheme_targets':targets,'all_declared_targets_present':True},indent=2)+'\n')
run(['python3',str(r/'validate-policy.py'),'compact'],cwd=c)
print('Both review units independently validated.',flush=True)
