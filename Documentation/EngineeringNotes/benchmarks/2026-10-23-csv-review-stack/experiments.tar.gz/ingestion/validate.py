from pathlib import Path
import subprocess,json,time,hashlib
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-ingestion-review-20261023')
base=json.loads(Path('/private/tmp/swiftsci-csv-integration-20261023/build-command.json').read_text())['command']
for mode in ['Release','Debug']:
 cmd=base.copy();cmd[cmd.index('-configuration')+1]=mode
 record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'command':cmd,'sources':{str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['Sources','Tests','Benchmarks/Worker','Benchmarks/Support'] for p in (S/folder).rglob('*.swift')}}
 start=time.time()
 with (R/(mode.lower()+'-build.log')).open('w') as out:p=subprocess.run(cmd,cwd=S,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
 record.update(exit_code=p.returncode,seconds=time.time()-start);(R/(mode.lower()+'-build.json')).write_text(json.dumps(record,indent=2)+'\n');print(mode,'build',p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 subprocess.run(['python3',str(R/'run-tests.py'),mode],check=True)
