from pathlib import Path
import subprocess,json,sys,time,plistlib,hashlib
ROOT=Path(__file__).resolve().parent
label=sys.argv[1];assert label in ['ingestion','compact']
s=Path('/private/tmp/swiftsci-csv-'+label+'-review-20261023');r=ROOT/label
py='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()
for mode in ['release','debug']:
 b=json.loads((r/(mode+'-build.json')).read_text());t=json.loads((r/(mode+'-tests.json')).read_text());summary=t['summary']
 assert b['head']==t['head']==head and b['exit_code']==t['exit_code']==0
 assert summary['passedTests']==summary['totalTestCount'] and summary['skippedTests']==summary['failedTests']==0
cmd=[py,'Benchmarks/Tools/bench.py','build']
start=time.time()
with (r/'formal-build.log').open('x') as out:result=subprocess.run(cmd,cwd=s,stdout=out,stderr=subprocess.STDOUT,timeout=1800)
(r/'formal-build.json').write_text(json.dumps({'head':head,'command':cmd,'exit_code':result.returncode,'seconds':time.time()-start},indent=2)+'\n')
print(label,'formal build',result.returncode,flush=True);assert result.returncode==0
worker='/Users/crabel/Library/Caches/SwiftSci/standardized-benchmarks/derived/Build/Products/Release/SwiftSciBenchmarkWorker'
(r/'formal-worker.build.json').write_bytes(Path(worker+'.build.json').read_bytes())
cmd=[py,'Benchmarks/Tools/acceptance.py','--tier','cpu','--check-baseline','--swift-worker',worker,'--python',py,'--output',str(r/'cpu-policy')]
start=time.time()
with (r/'cpu-policy.log').open('x') as out:result=subprocess.run(cmd,cwd=s,stdout=out,stderr=subprocess.STDOUT,timeout=1800)
(r/'cpu-policy-command.json').write_text(json.dumps({'head':head,'command':cmd,'exit_code':result.returncode,'seconds':time.time()-start},indent=2)+'\n')
policy=json.loads((r/'cpu-policy/regression-policy.json').read_text())
assert result.returncode==0 and policy['status']=='passed' and not policy['blocking'] and len(policy['known_failures'])==4
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==head
print(label,'CPU regression policy passed; four known strict conformance failures retained',flush=True)
