from pathlib import Path
import json,subprocess,sys,hashlib,statistics as st,time
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,PRODUCTION_MODE
from runner import power_state
D=R/'duckdb-api-check';D.mkdir(exist_ok=False)
old=R/'python-probe.py';new=R/'python-probe-current.py';source=old.read_text();needle='relation.fetch_record_batch(rows_per_batch=chunk)';assert needle in source;new.write_text(source.replace(needle,'relation.to_arrow_reader(batch_size=chunk)'))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=[c['id'] for c in json.loads((R/'plan.json').read_text())['contracts']]
(D/'plan.json').write_text(json.dumps({'cases':cases,'scope':'stream','rounds':6,'orders':[['legacy','current'],['current','legacy']]*3,'criterion':'Two-sided 10 percent CPU review. Exact same schema/nulls/native full-output validation and 10000-row bounds. New stage does not replace original comparison.','old_worker_sha256':h(old),'current_worker_sha256':h(new),'started_unix':time.time()},indent=2)+'\n')
rows=[];python='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
with (D/'workers.jsonl').open('x') as out:
 for case in cases:
  for rnd in range(6):
   for label in (['legacy','current'] if rnd%2==0 else ['current','legacy']):
    assert power_state()['source']=='AC';worker=old if label=='legacy' else new
    p=subprocess.run([python,str(worker),'duckdb',str(R/'inputs'/(case+'.json')),'stream'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=300);assert p.returncode==0,p.stderr
    d=json.loads(p.stdout);assert d['validated'];d.update(case=case,label=label,round=rnd);rows.append(d);out.write(json.dumps(d)+'\n');out.flush()
  print(case,'current DuckDB API validated',flush=True)
summary=[];flags=[]
for case in cases:
 xs={label:[r['samples'][0] for r in rows if r['case']==case and r['label']==label] for label in ['legacy','current']}
 a=st.median(x['total_cpu_ns'] for x in xs['legacy']);b=st.median(x['total_cpu_ns'] for x in xs['current']);ratio=b/a
 s={'case':case,'legacy_cpu_ns':a,'current_cpu_ns':b,'cpu_ratio':ratio,'legacy_elapsed_ns':st.median(x['total_ns'] for x in xs['legacy']),'current_elapsed_ns':st.median(x['total_ns'] for x in xs['current']),'cpu_review':abs(ratio-1)>.1};summary.append(s)
 if s['cpu_review']:flags.append(s)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'decision.json').write_text(json.dumps({'workers':len(rows),'all_outputs_validated':True,'flags':flags,'current_api_cpu_within_review':not flags},indent=2)+'\n')
for s in summary:print(s['case'],round((s['cpu_ratio']-1)*100,2),'percent current API CPU versus legacy',flush=True)
