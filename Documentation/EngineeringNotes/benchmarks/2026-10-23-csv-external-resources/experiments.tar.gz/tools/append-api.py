from pathlib import Path
import json,statistics as st,hashlib,gzip,tarfile,re
R=Path(__file__).resolve().parent;D=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-external-resources');T=D/'duckdb-api-check';T.mkdir(exist_ok=False)
rows=[json.loads(l) for l in (R/'duckdb-api-check/workers.jsonl').read_text().splitlines()];summaries=json.loads((R/'duckdb-api-check/summary.json').read_text());plan=json.loads((R/'plan.json').read_text());assert len(rows)==84
for r in rows:
 c=next(c for c in plan['contracts'] if c['id']==r['case']);assert r['validated'];assert [x['sha256'] for x in r['checks']['columns']]==c['hashes'];assert [x['nulls'] for x in r['checks']['columns']]==c['null_counts'];assert r['checks']['max_chunk_rows']<=10000
for s in summaries:
 a=[r['samples'][0]['total_cpu_ns'] for r in rows if r['case']==s['case'] and r['label']=='legacy'];b=[r['samples'][0]['total_cpu_ns'] for r in rows if r['case']==s['case'] and r['label']=='current'];assert len(a)==len(b)==6;assert s['cpu_ratio']==st.median(b)/st.median(a)
for name in ['plan.json','summary.json','decision.json']:(T/name).write_bytes((R/'duckdb-api-check'/name).read_bytes())
raw=(R/'duckdb-api-check/workers.jsonl').read_bytes()
with gzip.GzipFile(filename=str(T/'workers.jsonl.gz'),mode='wb',mtime=0) as f:f.write(raw)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index=json.loads((D/'worker-index.json').read_text());index.append({'stage':'duckdb-api-check','responses_including_failure_records':84,'uncompressed_sha256':hashlib.sha256(raw).hexdigest()});(D/'worker-index.json').write_text(json.dumps(index,indent=2)+'\n')
old=D/'experiments.tar.gz';new=D/'experiments.updated.tar.gz'
with tarfile.open(old,'r:gz') as src,tarfile.open(new,'w:gz') as dst:
 for m in src.getmembers():dst.addfile(m,src.extractfile(m) if m.isfile() else None)
 for name in ['check-current-duckdb.py','python-probe-current.py','append-api.py']:dst.add(R/name,arcname='tools/'+name)
new.replace(old)
p=D/'README.md';s=p.read_text();needle='## What timing and memory include';addition='''## Current DuckDB streaming API check

The primary run reused `fetch_record_batch`, which emits a deprecation warning in the installed DuckDB version. That warning is included in its timed call. A separate 84-worker check compares it with the supported `to_arrow_reader(batch_size=10000)` replacement across all seven complete streamed contracts. Every output matches, and current-versus-legacy CPU median changes range from -1.45% to +0.59%, within the predeclared two-sided 10% review threshold.

The supported replacement does not materially change the observed DuckDB resource position in this check. The original balanced comparison remains intact; the supplemental check does not replace selected rows or erase the warning. [Its plan, observations, and decision](duckdb-api-check/decision.json) remain separate from the primary study.

''';assert needle in s;s=s.replace(needle,addition+needle);p.write_text(s)
for p in D.rglob('*.md'):
 text=p.read_text();assert '\u2014' not in text and '\u2013' not in text
 for t in re.findall(r'\]\(([^)]+)\)',text):
  if not t.startswith(('http:','https:','#')):assert (p.parent/t).exists(),t
manifest={str(p.relative_to(D)):h(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='artifact-sha256.json'};(D/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(D/name)==v for name,v in manifest.items())
print('Supplementary current-API observations and summaries independently verified')
