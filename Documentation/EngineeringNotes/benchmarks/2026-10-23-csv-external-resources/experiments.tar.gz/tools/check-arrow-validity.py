import pyarrow as pa
values=pa.array([1.0,None,2.0])
try:
 values.is_valid().to_numpy()
except pa.ArrowInvalid:
 print('Original validity conversion reproduces ArrowInvalid')
else:raise AssertionError('Expected the explicit-copy requirement')
assert values.is_valid().to_numpy(zero_copy_only=False).tolist()==[True,False,True]
assert pa.chunked_array([values]).is_valid().to_numpy(zero_copy_only=False).tolist()==[True,False,True]
print('Explicit untimed validity copy handles Array and ChunkedArray')
