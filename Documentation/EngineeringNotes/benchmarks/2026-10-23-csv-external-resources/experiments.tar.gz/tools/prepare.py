from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;I=R/'inputs';I.mkdir(exist_ok=False)
old=Path('/private/tmp/swiftsci-csv-matched-20261021/inputs');defaults=Path('/private/tmp/swiftsci-csv-string-cost-20261022/inputs')
configs=[('Aotizhongxin',old/'Aotizhongxin.json',None),('Aotizhongxin-default',defaults/'Aotizhongxin-default.json',None),('Wanliu',old/'Wanliu.json',None),('Wanliu-default',old/'Wanliu.json','default'),('energy',old/'energy.json',None),('energy-common',defaults/'energy-default.json','extended'),('energy-date-full',old/'energy-date-full.json',None)]
common=json.loads((defaults/'energy-default.json').read_text())['null_tokens'];contracts=[]
for name,path,mode in configs:
 c=json.loads(path.read_text());c['id']=name
 if mode=='default':c['null_tokens']=common
 if mode=='extended':c['null_tokens']=common+['?']
 if 'Date' in c['types']:c.update(date_formats={'Date':'d/M/yyyy'},reference_date_formats={'Date':'%d/%m/%Y'})
 digest=hashlib.sha256(Path(c['path']).read_bytes()).hexdigest();assert digest==c.get('sha256',c.get('source_sha256'));c['source_sha256']=digest
 (I/(name+'.json')).write_text(json.dumps(c,indent=2)+'\n');contracts.append(c)
engines=['swift-parallel','swift-twin','swift-serial','pandas','polars','duckdb']
orders=[engines[i:]+engines[:i] for i in range(6)];orders+=list(map(list,map(reversed,orders.copy())))
assert all(sum(o.index(a)<o.index(b) for o in orders)==6 for a in engines for b in engines if a!=b)
plan={'source_head':'5d1f89a961106104757f2d8d0b8faba79487d100','contracts':contracts,'cases':[{'case':c['id'],'scope':scope} for c in contracts for scope in ['eager','stream']],'orders':orders,'rounds':12,'chunk_size':10000,'hypotheses':[{'prediction':'Qualified SwiftSci retains exact native outputs under complete schema and an identical explicit null list in each language.'},{'prediction':'CPU and memory rankings can differ from elapsed rankings, so all are recorded independently.'},{'prediction':'Native streamed output delivery changes resource costs relative to eager reads and cannot be extrapolated to lazy native reductions.'}],'criteria':{'comparison':'CPU backend, native library parallelism, no core pinning or worker caps. Swift parallel is native production policy; serial disables column-conversion workers only, not all CPU use. pandas native C reader, Polars native CPU pool, DuckDB native pool.','scope':'Fresh runtime-prepared processes, one public eager read and release after validation; stream creates reader, drains complete native outputs and releases them, then separate untimed full validation. Warm file bytes. Imports/configuration and full-value checks outside timing.','schema':'Complete explicit schema for every engine; inference is not measured. Numeric float64 bit patterns, exact small int64 values, strings, null positions/counts and ordered columns/rows must match. Dates use explicit supplied formats and native caches where supported.','nulls':'A shared extended null list for energy-common includes question mark for every engine. This is not Swift default configuration. Original two-token cases remain separate. No ignore-errors, casts replacing native dtypes, malformed-row skipping or data rewriting.','stream':'Native public chunk APIs, maximum 10000 output rows, original order and every column. Polars scan_csv plus collect_batches streaming, not a native sink. DuckDB Arrow record batches. No projection to count pushed into the reader.','memory':'Baseline RSS and high water after imports/configuration, read-held RSS and peak before validation, post-release RSS. Report absolute process peak and increase above baseline high water; Python validation imports contribute to baseline. Not allocation counts.','conditions':'AC, sequential workers, no benchmark-time task builds/tests/profilers, no outlier trimming. Library versions pinned as installed. External native hashing is not fixed or physically shareable across languages.'}}
plan['criteria']['quality']='Same actual-head standalone binary under swift-parallel and swift-twin labels. Two-sided 10 percent CPU, and peak RSS 5 percent plus 8 MiB. Keep all warnings. External speed is not a correctness gate.'
(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
# Adapt existing eager setup, preserving reader flags and canonical digest encoding.
s=Path('/private/tmp/swiftsci-csv-ingestion-checks-20261021/python-probe.py').read_text();s=s[:s.index('def validate(frame):')]
s=s.replace("engine=sys.argv[1];input_path=Path(sys.argv[2]);case=json.loads(input_path.read_text())","engine=sys.argv[1];input_path=Path(sys.argv[2]);case=json.loads(input_path.read_text());scope=sys.argv[3];chunk=10000")
s=s.replace("versions['polars']=pl.__version__;pools['polars']=pl.thread_pool_size()","versions['polars']=pl.__version__")
s += '''
def frames():
 if engine=='pandas':
  with pd.read_csv(case['path'],chunksize=chunk,**kwargs) as reader:
   for frame in reader:
    yield frame
    del frame
 elif engine=='polars':
  query=pl.scan_csv(case['path'],**kwargs)
  if is_date:query=query.with_columns([pl.col(name).str.strptime(pl.Datetime('us'),format=fmt,strict=True,exact=True,cache=True) for name,fmt in date_formats.items()])
  batches=query.collect_batches(chunk_size=chunk,maintain_order=True,engine='streaming',lazy=True)
  try:
   for frame in batches:
    yield frame
    del frame
  finally:del batches
 else:
  relation=connection.read_csv(case['path'],**kwargs)
  with relation.fetch_record_batch(rows_per_batch=chunk) as reader:
   for frame in reader:
    yield frame
    del frame

def validate(outputs):
 hashes=[hashlib.sha256() for _ in case['names']];nulls=[0]*len(hashes);failures=[];rows=0;chunks=0;max_chunk=0;dtypes=[None]*len(hashes)
 for frame in outputs:
  names=list(frame.columns) if engine!='duckdb' else frame.schema.names
  if names!=case['names']:failures.append('column names/order')
  count=len(frame);rows+=count;chunks+=1;max_chunk=max(max_chunk,count)
  if scope=='stream' and count>chunk:failures.append('output chunk bound')
  for j,(name,kind) in enumerate(zip(case['names'],case['types'])):
   col=frame[name];dtype=str(col.dtype) if engine!='duckdb' else str(col.type);dtypes[j]=dtype
   if engine=='pandas':matches={'Double':pd.api.types.is_float_dtype(col) and col.dtype.itemsize==8,'Int64':pd.api.types.is_integer_dtype(col) and col.dtype.itemsize==8,'String':pd.api.types.is_string_dtype(col),'Date':pd.api.types.is_datetime64_any_dtype(col)}[kind]
   elif engine=='polars':matches=col.dtype=={'Double':pl.Float64,'Int64':pl.Int64,'String':pl.String,'Date':pl.Datetime('us')}[kind]
   else:matches=col.type=={'Double':pa.float64(),'Int64':pa.int64(),'String':pa.string(),'Date':pa.timestamp('us')}[kind]
   if not matches:failures.append('native type '+name+': '+dtype)
   for start in range(0,count,65536):
    if engine=='pandas':
     part=col.iloc[start:start+65536];valid=~part.isna().to_numpy();values=part.tolist() if kind=='String' else part.to_numpy()
    elif engine=='polars':
     part=col.slice(start,65536);valid=part.is_not_null().to_numpy();values=part.to_list() if kind=='String' else part.to_numpy()
    else:
     part=col.slice(start,65536);valid=part.is_valid().to_numpy(zero_copy_only=False);values=part.to_pylist() if kind=='String' else part.to_numpy(zero_copy_only=False)
    nulls[j]+=int((~valid).sum())
    if kind=='String':
     buf=bytearray()
     for value,ok in zip(values,valid):
      if ok:
       b=value.encode('utf-8');buf+=b'\\1'+struct.pack('<I',len(b))+b
      else:buf+=b'\\0'
     hashes[j].update(buf)
    else:
     if kind=='Int64':assert np.all(np.abs(np.asarray(values)[valid])<=2**53),'Integer digest requires exact float64 embedding'
     numbers=values.astype('datetime64[s]').astype(np.int64).astype(np.float64) if kind=='Date' else np.asarray(values,dtype=np.float64)
     packed=np.empty((len(valid),9),dtype=np.uint8);packed[:,0]=valid;packed[:,1:]=np.ascontiguousarray(numbers,dtype='<f8').view(np.uint8).reshape(-1,8)
     keep=np.ones(packed.shape,dtype=bool);keep[~valid,1:]=False;hashes[j].update(packed[keep].tobytes())
  del frame
 if rows!=case['rows']:failures.append('row count')
 details=[dict(name=n,type=dtypes[j],nulls=nulls[j],sha256=hashes[j].hexdigest()) for j,n in enumerate(case['names'])]
 for j,d in enumerate(details):
  if d['sha256']!=case['hashes'][j] or d['nulls']!=case['null_counts'][j]:failures.append('values/nulls '+d['name'])
 return dict(passed=not failures,failures=failures,columns=details,rows=rows,chunks=chunks,max_chunk_rows=max_chunk)

r0=rss();p0=peak();c0=cpu();t0=time.perf_counter_ns()
if scope=='eager':
 output=read();t1=time.perf_counter_ns();c1=cpu();r1=rss();p1=peak();checks=validate([output])
 c2=cpu();t2=time.perf_counter_ns();del output;t3=time.perf_counter_ns();c3=cpu()
else:
 count=0;chunks=0;max_chunk=0
 for output in frames():
  n=len(output);count+=n;chunks+=1;max_chunk=max(max_chunk,n);del output
 t1=time.perf_counter_ns();c1=cpu();r1=rss();p1=peak();c2=c3=c1;t2=t3=t1
 assert count==case['rows'] and max_chunk<=chunk
 checks=validate(frames());checks['timed_chunks']=chunks;checks['timed_max_chunk_rows']=max_chunk
sample=dict(call_ns=t1-t0,call_cpu_ns=c1-c0,release_ns=t3-t2,release_cpu_ns=c3-c2,total_ns=t1-t0+t3-t2,total_cpu_ns=c1-c0+c3-c2,rss_before_bytes=r0,rss_held_bytes=r1,rss_held_delta_bytes=r1-r0,rss_after_release_bytes=rss(),process_peak_before_bytes=p0,process_peak_held_bytes=p1)
if engine=='polars':pools['polars']=pl.thread_pool_size()
if engine=='duckdb':connection.close()
print(json.dumps(dict(engine=engine,input=case['id'],scope=scope,validated=checks['passed'],checks=checks,samples=[sample],versions=versions,pools=pools,options=kwargs),default=str))
'''
(R/'python-probe.py').write_text(s)
print('Prepared',len(contracts),'strict full-data contracts and native adapters')
