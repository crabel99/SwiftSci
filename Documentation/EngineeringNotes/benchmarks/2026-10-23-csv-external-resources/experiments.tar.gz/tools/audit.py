from pathlib import Path
import json,statistics as st,hashlib,subprocess,sys
R=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((R/'plan.json').read_text());D=R/'measurement';receipt=json.loads((D/'plan.json').read_text())
assert receipt['source_plan_sha256']==h(R/'plan.json') and receipt['python_probe_sha256']==h(R/'python-probe.py') and receipt['controller_sha256']==h(R/'run.py')
pre=json.loads((R/'preflight/decision.json').read_text());assert pre['passed'] and pre['workers']==84
assert pre['source_plan_sha256']==h(R/'plan.json') and pre['python_probe_sha256']==h(R/'python-probe.py')
rows=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()];summaries=json.loads((D/'summary.json').read_text());assert len(rows)==1008
keys=[tuple(r[k] for k in ['case','scope','engine','round']) for r in rows];assert len(keys)==len(set(keys));assert all(r['validated'] for r in rows)
for r in rows:
 c=next(c for c in plan['contracts'] if c['id']==r['case']);assert r['engine']==plan['orders'][r['round']][r['position']]
 assert len(r['samples'])==1
 sample=r['samples'][0];assert sample['total_cpu_ns']>0 and sample['total_ns']>0
 if 'checks' in r:
  checks=r['checks'];assert checks['passed'];assert [x['sha256'] for x in checks['columns']]==c['hashes'];assert [x['nulls'] for x in checks['columns']]==c['null_counts']
  if r['scope']=='stream':assert checks['rows']==c['rows'] and checks['max_chunk_rows']<=10000 and checks['timed_max_chunk_rows']<=10000
 else:assert r['scope']=='stream' and r['engine'].startswith('swift-') and r['rows']==c['rows'] and r['chunk_size']==10000
for s in summaries:
 xs=[r['samples'][0] for r in rows if all(r[k]==s[k] for k in ['case','scope','engine'])];assert len(xs)==s['workers']==12
 for key,value in s['medians'].items():
  raw=[max(0,x['process_peak_held_bytes']-x['process_peak_before_bytes']) for x in xs] if key=='read_peak_above_baseline_bytes' else [x[key] for x in xs]
  assert st.median(raw)==value,(s['case'],s['scope'],s['engine'],key)
flags=[]
for case in plan['cases']:
 xs={r['engine']:r['medians'] for r in summaries if all(r[k]==case[k] for k in ['case','scope'])};a=xs['swift-parallel'];b=xs['swift-twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append(dict(**case,reason='identical-binary CPU',ratio=ratio))
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append(dict(**case,reason='identical-binary memory'))
assert flags==json.loads((D/'decision.json').read_text())['quality_flags']
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==plan['source_head'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
versions={engine:next(r['versions'] for r in rows if r['engine']==engine) for engine in ['pandas','polars','duckdb']}
out={'accepted_workers':len(rows),'strict_preflight_workers':84,'preserved_failed_preflight_workers':7,'case_scope_combinations':14,'engine_labels':6,'all_outputs_validated':True,'all_summary_fields_recomputed':True,'quality_passed':not flags,'quality_flags':flags,'versions':versions,'source_head':plan['source_head'],'production_changed':False,'promotion_allowed':False,'interpretation':'A resource comparison with pinned installed library versions and exact contracts. Speed versus external libraries is not a correctness gate. Small differences are descriptive, not a proven general ranking.'}
(R/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if flags:raise SystemExit(1)
