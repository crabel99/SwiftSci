from pathlib import Path
import json,hashlib,tarfile,io
R=Path(__file__).resolve().parent;D=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-external-resources')
summary=json.loads((R/'measurement/summary.json').read_text());L={(s['case'],s['scope'],s['engine']):s['medians'] for s in summary}
intro='''## What the measurements imply

Both Swift policies have lower CPU medians than each measured reference engine in all fourteen case-and-scope combinations. That is a result for this sample and these pinned configurations. It is not proof that SwiftSci is generally more efficient than every alternative.

The household case with the shared eleven-token null list makes the CPU and latency tradeoff clear:

| Scope | Engine | CPU ms | Elapsed ms | Process peak MiB | Read peak increase MiB |
|---|---|---:|---:|---:|---:|
'''
for scope in ['eager','stream']:
 for label in ['swift-serial','swift-parallel','pandas','polars','duckdb']:
  m=L['energy-common',scope,label];intro+=f"| {scope} | {label} | {m['total_cpu_ns']/1e6:.1f} | {m['total_ns']/1e6:.1f} | {m['process_peak_held_bytes']/2**20:.1f} | {m['read_peak_above_baseline_bytes']/2**20:.1f} |\n"
intro+='''
Swift's serial eager read uses about 37% less CPU than Polars here, while Polars finishes about 7.4 times sooner. The parallel Swift read narrows that elapsed gap while using somewhat more CPU than serial. This supports keeping CPU cost and completion time separate when choosing an execution policy.

Eager memory remains a visible opportunity. Swift serial adds about 414 MiB above its baseline high water, versus about 347 MiB for Polars in this case. Swift's streamed process peak is much smaller than Polars' batch-delivery peak. pandas streamed peak is higher than Swift's absolute peak, but its increase above the larger Python baseline is smaller. Those are different memory comparisons, so neither should replace the other.

RSS does not separate mapped file pages, private allocations, shared runtime pages, or reclaimable memory. A private-allocation and mapping profile is needed before attributing the eager difference to storage layout or claiming a total system-memory saving. It is not evidence of a leak.

The eleven-token household configuration explicitly recognizes `?`. Its absolute times must not be compared as a code-only improvement over the preceding ten-token Swift-default qualification. The source head is unchanged, and this configuration changes how those numeric fields are handled.

'''
p=D/'README.md';s=p.read_text();needle='## Equal inputs and explicit configuration';assert needle in s;s=s.replace(needle,intro+needle);p.write_text(s)
# Keep the reproduction tool for the interpretation beside the original packager.
archive=D/'experiments.tar.gz';tmp=D/'experiments.updated.tar.gz'
with tarfile.open(archive,'r:gz') as src,tarfile.open(tmp,'w:gz') as dst:
 for m in src.getmembers():dst.addfile(m,src.extractfile(m) if m.isfile() else None)
 dst.add(R/'interpret.py',arcname='tools/interpret.py')
tmp.replace(archive)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={str(p.relative_to(D)):h(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='artifact-sha256.json'};(D/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Added the resource interpretation without replacing raw evidence')
