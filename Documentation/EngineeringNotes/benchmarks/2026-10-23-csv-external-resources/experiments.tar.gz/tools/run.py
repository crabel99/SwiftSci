from pathlib import Path
import sys,json,hashlib,subprocess,time,statistics as st
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,PRODUCTION_MODE
from runner import environment,power_state,verify_uninstrumented
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1];assert mode in ['preflight','measurement'];plan=json.loads((R/'plan.json').read_text());D=R/mode;D.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==plan['source_head'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
root=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata');binaries={};receipts={}
for scope,name in [('eager','ResourceProbe'),('stream','StreamProbe')]:
 b=root/name;recpath=root/('build.json' if scope=='eager' else name+'.build.json');rec=json.loads(recpath.read_text());assert h(b)==rec['binary_sha256'];verify_uninstrumented(b)
 cmd=rec.get('command',rec.get('commands',[])[-1] if rec.get('commands') else None);assert Path(cmd[cmd.index('-I')+1]).resolve()==root.resolve()
 binaries[scope]=b;receipts[scope]={'path':str(b),'sha256':h(b),'receipt_sha256':h(recpath),'first_module_import':cmd[cmd.index('-I')+1]}
for c in plan['contracts']:assert h(Path(c['path']))==c['source_sha256']
if mode=='measurement':
 pre=json.loads((R/'preflight/decision.json').read_text());assert pre['passed'] and pre['workers']==84
 assert pre['source_plan_sha256']==h(R/'plan.json') and pre['python_probe_sha256']==h(R/'python-probe.py')
(D/'plan.json').write_text(json.dumps({'source_plan_sha256':h(R/'plan.json'),'python_probe_sha256':h(R/'python-probe.py'),'controller_sha256':h(Path(__file__)),'receipts':receipts,'environment':environment(),'power':power_state(),'started_unix':time.time(),'scope':mode},indent=2)+'\n')
python='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python';rows=[];failures=[]
with (D/'workers.jsonl').open('x') as out:
 for case in plan['cases']:
  contract=R/'inputs'/(case['case']+'.json');inp=json.loads(contract.read_text())
  orders=plan['orders'][:1] if mode=='preflight' else plan['orders']
  for rnd,order in enumerate(orders):
   assert power_state()['source']=='AC'
   with Path(inp['path']).open('rb') as f:
    while f.read(1024*1024):pass
   for label in order:
    if label.startswith('swift-'):
     policy='serial' if label=='swift-serial' else 'parallel'
     args=[str(contract),'known','fresh','1',policy] if case['scope']=='eager' else [str(contract),'10000',policy]
     cmd=[str(binaries[case['scope']]),*args]
    else:cmd=[python,str(R/'python-probe.py'),label,str(contract),case['scope']]
    start=time.time();p=subprocess.run(cmd,capture_output=True,text=True,env=worker_environment(PRODUCTION_MODE),timeout=300)
    stderrname=case['case']+'-'+case['scope']+'-'+str(rnd)+'-'+label+'.stderr';(D/stderrname).write_text(p.stderr)
    if p.returncode:
     fail=dict(case=case['case'],scope=case['scope'],engine=label,round=rnd,exit=p.returncode,stderr=p.stderr[-2000:]);failures.append(fail);out.write(json.dumps(fail)+'\n');out.flush();print('FAILED',case['case'],case['scope'],label,p.stderr[-200:],flush=True)
     if mode=='measurement':raise RuntimeError(fail)
     continue
    d=json.loads(p.stdout)
    if not d['validated']:
     failures.append(dict(case=case['case'],scope=case['scope'],engine=label,checks=d.get('checks')))
     if mode=='measurement':raise RuntimeError(failures[-1])
    if 'checks' in d and d['validated']:
     assert [x['sha256'] for x in d['checks']['columns']]==inp['hashes'];assert [x['nulls'] for x in d['checks']['columns']]==inp['null_counts']
    if label.startswith('swift-') and case['scope']=='stream':
     sample={k:d[k] for k in ['total_ns','total_cpu_ns','rss_before_bytes','rss_after_bytes','peak_before_bytes','peak_after_bytes']}
     sample.update(rss_held_bytes=d['rss_after_bytes'],rss_held_delta_bytes=d['rss_growth_bytes'],process_peak_before_bytes=d['peak_before_bytes'],process_peak_held_bytes=d['peak_after_bytes']);d['samples']=[sample]
    d.update(case=case['case'],scope=case['scope'],engine=label,round=rnd,position=order.index(label),worker_seconds=time.time()-start);rows.append(d);out.write(json.dumps(d)+'\n');out.flush()
   print(mode,case['case'],case['scope'],rnd+1,'of',len(orders),'complete',flush=True)
summary=[]
for c in plan['cases']:
 for label in plan['orders'][0]:
  rs=[r for r in rows if all(r[k]==c[k] for k in ['case','scope']) and r['engine']==label]
  if not rs:continue
  samples=[r['samples'][0] for r in rs]
  names=['total_cpu_ns','total_ns','rss_before_bytes','rss_held_bytes','rss_held_delta_bytes','process_peak_before_bytes','process_peak_held_bytes']
  values={n:st.median(x[n] for x in samples) for n in names}
  values['read_peak_above_baseline_bytes']=st.median(max(0,x['process_peak_held_bytes']-x['process_peak_before_bytes']) for x in samples)
  summary.append(dict(**c,engine=label,workers=len(rs),medians=values))
quality=[]
if mode=='measurement':
 for c in plan['cases']:
  xs={r['engine']:r for r in summary if all(r[k]==c[k] for k in ['case','scope'])};a=xs['swift-parallel']['medians'];b=xs['swift-twin']['medians'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
  if abs(ratio-1)>.10:quality.append(dict(**c,reason='identical-binary CPU',ratio=ratio))
  for x,y in [(a,b),(b,a)]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:quality.append(dict(**c,reason='identical-binary memory'))
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'decision.json').write_text(json.dumps({'passed':not failures,'workers':len(rows),'failures':failures,'quality_passed':not quality,'quality_flags':quality,'source_plan_sha256':h(R/'plan.json'),'python_probe_sha256':h(R/'python-probe.py'),'completed_unix':time.time()},indent=2)+'\n')
print(mode,len(rows),'validated responses',len(failures),'failures;',len(quality),'quality flags',flush=True)
if failures:raise SystemExit(1)
