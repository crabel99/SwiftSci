from pathlib import Path
import json,gzip,hashlib,tarfile,shutil,re,statistics as st
R=Path(__file__).resolve().parent;N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018');D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-external-resources'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((R/'audit.json').read_text());D.mkdir(exist_ok=False)
for name in ['plan.json','audit.json','adapter-correction.json','reproduction-smoke.json']:shutil.copy2(R/name,D/name)
index=[]
for stage in ['preflight-initial','preflight','measurement']:
 T=D/stage;T.mkdir()
 for name in ['plan.json','decision.json','summary.json']:shutil.copy2(R/stage/name,T/name)
 raw=(R/stage/'workers.jsonl').read_bytes()
 with gzip.GzipFile(filename=str(T/'workers.jsonl.gz'),mode='wb',mtime=0) as f:f.write(raw)
 assert gzip.decompress((T/'workers.jsonl.gz').read_bytes())==raw
 index.append({'stage':stage,'responses_including_failure_records':len(raw.splitlines()),'uncompressed_sha256':hashlib.sha256(raw).hexdigest()})
(D/'worker-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(D/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.glob('*.py')):tar.add(p,arcname='tools/'+p.name)
 for p in sorted((R/'inputs').glob('*.json')):tar.add(p,arcname='inputs/'+p.name)
 for stage in ['preflight-initial','preflight','measurement']:
  for p in sorted((R/stage).glob('*.stderr')):
   if p.stat().st_size:tar.add(p,arcname=stage+'/'+p.name)
 root=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
 for name in ['build.json','StreamProbe.build.json']:
  p=root/name;tar.add(p,arcname='swift-client/'+name);r=json.loads(p.read_text());cmd=r.get('command',r.get('commands',[])[-1] if r.get('commands') else [])
  for a in cmd:
   if a.endswith('/ResourceProbe.swift') or a.endswith('/StreamProbe.swift'):tar.add(a,arcname='swift-client/'+Path(a).name)
summary=json.loads((R/'measurement/summary.json').read_text());rows=[json.loads(l) for l in (R/'measurement/workers.jsonl').read_text().splitlines()]
lookup={(s['case'],s['scope'],s['engine']):s['medians'] for s in summary}
lines=['# Exact CSV resource comparisons','','Every row has 12 independent fresh-process workers. Medians use complete known-schema reads with matching null tokens and exact outputs. CPU is process user plus system time during the operation. Elapsed time is separate. Peak is captured before validation.','','Baseline peak includes imported runtime and validation dependencies. Read peak increase is the median nonnegative difference between post-read and pre-read high-water marks. A zero increase can occur when import-time peak exceeds read peak; it does not mean zero read allocation. Held RSS delta is also reported for eager outputs. Streaming RSS after draining is not retained-output memory.','','| Case | Scope | Engine | CPU ms | Elapsed ms | Baseline peak MiB | Process read peak MiB | Read peak increase MiB | Held or drained RSS change MiB |','|---|---|---|---:|---:|---:|---:|---:|---:|']
for c in json.loads((R/'plan.json').read_text())['cases']:
 for label in ['swift-parallel','swift-serial','pandas','polars','duckdb']:
  m=lookup[c['case'],c['scope'],label]
  lines.append(f"| {c['case']} | {c['scope']} | {label} | {m['total_cpu_ns']/1e6:.3f} | {m['total_ns']/1e6:.3f} | {m['process_peak_before_bytes']/2**20:.2f} | {m['process_peak_held_bytes']/2**20:.2f} | {m['read_peak_above_baseline_bytes']/2**20:.2f} | {m['rss_held_delta_bytes']/2**20:+.2f} |")
lines+=['','## Identical-binary controls','','`swift-twin` launches exactly the same standalone binary and arguments as `swift-parallel`. Values below use independent processes and native hashing. They do not physically share a null-token Set.','','| Case | Scope | Twin CPU change | Peak change MiB |','|---|---|---:|---:|']
for c in json.loads((R/'plan.json').read_text())['cases']:
 a=lookup[c['case'],c['scope'],'swift-parallel'];b=lookup[c['case'],c['scope'],'swift-twin'];lines.append(f"| {c['case']} | {c['scope']} | {(b['total_cpu_ns']/a['total_cpu_ns']-1)*100:+.2f}% | {(b['process_peak_held_bytes']-a['process_peak_held_bytes'])/2**20:+.2f} |")
(D/'results.md').write_text('\n'.join(lines)+'\n')
# Preserve ratios without assigning one score to CPU, latency, and memory.
comparisons=[]
for c in json.loads((R/'plan.json').read_text())['cases']:
 for swift in ['swift-parallel','swift-serial']:
  for ref in ['pandas','polars','duckdb']:
   a=lookup[c['case'],c['scope'],swift];b=lookup[c['case'],c['scope'],ref]
   comparisons.append(dict(**c,swift_policy=swift,reference=ref,cpu_ratio=a['total_cpu_ns']/b['total_cpu_ns'],elapsed_ratio=a['total_ns']/b['total_ns'],process_peak_difference_mib=(a['process_peak_held_bytes']-b['process_peak_held_bytes'])/2**20,read_peak_increase_difference_mib=(a['read_peak_above_baseline_bytes']-b['read_peak_above_baseline_bytes'])/2**20))
(D/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
versions={e:audit['versions'][e][e] for e in ['pandas','polars','duckdb']};quality='passes' if audit['quality_passed'] else 'requires review'
readme=f'''# Qualified CSV reads against pandas, Polars, and DuckDB

The comparison completes 1,008 measured workers after 84 strict preflight reads. Every accepted output matches its independent contract. The identical-binary quality check {quality}, with {len(audit['quality_flags'])} flags retained in [the audit](audit.json). This measures local SwiftSci commit `5d1f89a961106104757f2d8d0b8faba79487d100`, pandas {versions['pandas']}, Polars {versions['polars']}, and DuckDB {versions['duckdb']}.

CPU, elapsed time, and memory remain separate in [the full result table](results.md). The result is for these public read APIs and configurations, not an aggregate ranking of the libraries or a full application benchmark. No production code changes during this follow-up.

## Equal inputs and explicit configuration

Seven immutable contracts use full Aotizhongxin and Wanliu air-quality files and the full 2,075,259-row household-energy file. They cover original two-token null sets, the default multi-token sets on air-quality data, an extended multi-token set on household data, and explicit parsed dates. Each has eager and streamed scopes. Every engine receives the same bytes, complete logical schema, explicit null tokens, row count, and output order for its case.

The household extended set includes `?` for every engine. This matters because SwiftSci can coerce that invalid numeric field to missing under its default settings, whereas the strict reference readers reject it unless declared null. The new `energy-common` configuration has eleven tokens and is not SwiftSci's ten-token default configuration. No input is rewritten, malformed row skipped, parse error ignored, or tolerance relaxed.

The [frozen plan](plan.json) records every case before measurement. The full schemas and expected native-value hashes are part of those contracts. Int64 reference values are in the exact float64 embedding range, which the Python digest validator checks. Strings and null positions are hashed independently, Float64 bits must match, and parsed dates use the supplied format and exact epoch values. Native output types are checked as well.

## Native readers and CPU policies

| Engine | Measured configuration |
|---|---|
| SwiftSci parallel | Actual qualified standalone reader and module object; native column-conversion workers |
| SwiftSci serial | Same reader with column-conversion workers disabled; other internal work remains native |
| pandas | Native C reader, explicit dtypes and null list, default null list disabled, round-trip float conversion, explicit date format and native date cache |
| Polars eager | Native `read_csv`, complete schema and explicit null list, explicit cached date conversion inside timing |
| Polars streamed | Native `scan_csv` with complete schema, then ordered CPU `collect_batches` delivering complete frames |
| DuckDB | Native connection and CPU pool, complete schema and explicit null list, insertion order preserved; eager Arrow materialization or streamed Arrow record batches |

All use the CPU backend and native library parallelism. There is no core pinning or imposed equal worker count. The serial Swift result is an additional caller policy, not an equal-thread-count comparison with Polars. Runtime versions, observed native pool settings, and actual options remain in every reference response. pandas's Arrow engine is not measured.

[Polars documents that complete schema avoids inference](https://docs.pola.rs/api/python/stable/reference/api/polars.read_csv.html). [pandas 3.0 documents the null, float, and date controls used here](https://pandas.pydata.org/pandas-docs/version/3.0/reference/api/pandas.read_csv.html). Installed API signatures and strict output preflight also verify the configurations.

## Streamed output has a specific contract

Each streamed reader delivers every column in original order, in output frames of at most 10,000 rows. The consumer counts rows and releases frames without retaining the dataset. Full native value and null validation occurs on a separate untimed repeat. A lazy query reduced to a count would not perform this task and is not substituted for it.

The Polars batch API is version-pinned and marked unstable. [Its documentation warns that returning batches is slower than native sinks](https://docs.pola.rs/api/python/stable/reference/lazyframe/api/polars.LazyFrame.collect_batches.html). These results therefore describe public frame delivery, not all Polars streaming operations. The installed wrapper has no public `stop` method; every iterator is fully drained and released. pandas readers and DuckDB Arrow batch readers close through their public context managers.

## What timing and memory include

The runtime is imported and caller configuration prepared before timing. File bytes are explicitly warmed outside each round. Twelve cyclic and reversed engine orders balance pairwise position. Each engine gets twelve independent fresh-process observations per case and scope. Repeated reads from one worker are not counted as extra independent samples.

Eager timing adds the public read and output release phases. Full output validation occurs in the gap and is excluded from CPU and elapsed measurements. Memory is captured while the native result is held, before validation. Stream timing includes reader creation, full consumption and output release, followed by an untimed full validation repeat.

CPU is process user-plus-system time during these measured phases. It is not a FLOP count, core-utilization percentage, energy measurement, or whole worker-lifetime cost. The execution policy uses AC power and native scheduling. Our task runs no builds, tests, or profilers concurrently with accepted measurements; unrelated host activity remains uncontrolled.

Process peak RSS includes the runtime. Python workers also import NumPy for validation before measurement. To expose that baseline, the table includes pre-read high water, post-read high water, the increase above that baseline, and held or drained RSS change. These measures are not allocation counts. A zero peak increase does not prove that reading allocated no memory, and post-validation release RSS can include validation buffers and library caches.

## Validation and reproducibility

Initial preflight found seven failures in the untimed DuckDB streamed validator. Arrow Array validity masks cannot provide the requested zero-copy NumPy boolean conversion. The eager ChunkedArray case had allowed copying by default. An explicit `zero_copy_only=False` fixes the validator without changing native reads, expected types, hashes, or tolerances. [The correction record](adapter-correction.json) and initial failed responses remain preserved. All 84 preflight reads then pass before any accepted timing.

[The independent audit](audit.json) recomputes every summary field from raw observations, verifies the balanced schedule, checks exact output digests and chunk bounds, and recomputes identical-binary CPU and memory flags. The control remains two-sided 10% CPU and 5% plus 8 MiB peak memory. Small differences remain descriptive; the study does not prove a general ranking at that scale.

The [isolated reproduction check](reproduction-smoke.json) regenerates the exact frozen plan and Python adapter. Standalone Swift build receipts verify that the reader module import precedes the general dependency directory, avoiding the cached-interface mistake corrected in [the preceding qualification](../2026-10-23-csv-paired-panel/README.md). The production worktree stays clean at the tested head. Nothing is pushed or submitted.

- [All resource results and identical-binary controls](results.md)
- [Ratios for each Swift policy and reference](comparisons.json)
- [Independent audit](audit.json) and [measured-run decision](measurement/decision.json)
- [Frozen contracts and sampling plan](plan.json)
- [Preflight decision](preflight/decision.json) and [adapter correction](adapter-correction.json)
- [Worker counts and uncompressed hashes](worker-index.json)
- [Scripts, input contracts, client receipts, and nonempty error logs](experiments.tar.gz)
- [Artifact hashes](artifact-sha256.json)

Full source datasets remain with their existing owner and are identified by hashes. The archive retains recorded paths and dependency identities; redirect declared paths to reproduce elsewhere. Raw worker JSONL is stored as exact gzip streams. Native binaries and build caches are not committed.
'''
(D/'README.md').write_text(readme)
for p in D.rglob('*.md'):
 text=p.read_text();assert '\u2014' not in text and '\u2013' not in text
 for t in re.findall(r'\]\(([^)]+)\)',text):
  if not t.startswith(('http:','https:','#')) and t!='artifact-sha256.json':assert (p.parent/t).exists(),t
manifest={str(p.relative_to(D)):h(p) for p in sorted(D.rglob('*')) if p.is_file()};(D/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(D);print(sum(p.stat().st_size for p in D.rglob('*') if p.is_file()),'bytes')
