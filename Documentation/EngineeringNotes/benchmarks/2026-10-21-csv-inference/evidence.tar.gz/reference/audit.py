from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('/private/tmp/swiftsci-csv-reference-20261021')
D=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/swiftsci-csv-inference-20261021/Benchmarks/Tools')
from execution_policy import worker_environment,PRODUCTION_MODE
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((D/'build/fixed/build.json').read_text())
assert h(D/'ResourceProbe.swift')==build['harness_sha256']==h(R/'ReferenceProbe.swift')
binary=D/'build/fixed/ResourceProbe'
assert h(binary)==build['binary_sha256']
prior=[json.loads(s) for s in (R/'audit.jsonl').read_text().splitlines()]
cases=json.loads((R/'cases.json').read_text())
results=[]
with (D/'audit.jsonl').open('x') as out:
 for case in cases:
  assert h(Path(case['path']))==case['sha256']
  for mode in ['known','infer']:
   p=subprocess.run([str(binary),str(R/'inputs'/(case['id']+'.json')),mode,'audit','1'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=240)
   assert p.returncode==0,p.stderr
   record=json.loads(p.stdout)
   expected=next(r for r in prior if r['input']==case['id'] and r['mode']==mode and r['variant']=='scoped')
   assert record['validated'] and record['checks']['passed'],(case['id'],mode,record['checks'])
   if expected['validated']:assert record['checks']==expected['checks']
   results.append(record);out.write(json.dumps(record)+'\n');out.flush()
  print(case['id'],'both schema modes match original oracle',flush=True)
p=subprocess.run([str(binary),str(R/'energy-date-diagnostic.json'),'infer','audit','1'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=240)
assert p.returncode==0,p.stderr
record=json.loads(p.stdout)
prior_date=json.loads((R/'date-audit.jsonl').read_text().splitlines()[0])
assert not record['validated'] and record['checks']==prior_date['checks']
(D/'date-audit.json').write_text(json.dumps(record,indent=2)+'\n')
summary={'all_supplied_and_numeric_inferred_cases_match_oracle':True,'valid_cases':sum(r['validated'] for r in results),'remaining_numeric_inference_failures':sum(not r['validated'] for r in results),'existing_date_inference_failure_unchanged':True,'audit_sha256':h(D/'audit.jsonl'),'build_sha256':h(D/'build/fixed/build.json'),'oracle_sha256':h(R/'oracle.py'),'cases_sha256':h(R/'cases.json')}
assert summary['valid_cases']==26 and summary['remaining_numeric_inference_failures']==0
(D/'audit-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
