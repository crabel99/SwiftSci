from pathlib import Path
import hashlib,json,statistics as st,subprocess,sys
D=Path(__file__).resolve().parent
R=Path('/private/tmp/swiftsci-csv-reference-20261021')
B=Path('/private/tmp/swiftsci-csv-integration-checks-20261021/reference-final')
sys.path.insert(0,'/private/tmp/swiftsci-csv-inference-20261021/Benchmarks/Tools')
from runner import environment,power_state,verify_uninstrumented
from execution_policy import worker_environment,PRODUCTION_MODE
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={'before':B/'build/integrated/ResourceProbe','fixed':D/'build/fixed/ResourceProbe'}
builds={'before':json.loads((B/'build/integrated/build.json').read_text()),'fixed':json.loads((D/'build/fixed/build.json').read_text())}
assert builds['before']['dependency_objects']==builds['fixed']['dependency_objects']
assert builds['before']['harness_sha256']==builds['fixed']['harness_sha256']
for v,p in paths.items():verify_uninstrumented(p);assert h(p)==builds[v]['binary_sha256']
cases=[('energy','known'),('energy','infer'),('Aotizhongxin','known'),('Wanliu','known')]
inputs={c['id']:c for c in json.loads((R/'cases.json').read_text())}
previous=[json.loads(line) for line in (B/'audit.jsonl').read_text().splitlines()]
for name,mode in cases:
 assert h(Path(inputs[name]['path']))==inputs[name]['sha256']
 assert next(r for r in previous if r['input']==name and r['mode']==mode)['validated']
power=power_state();assert power['source']=='AC',power
out=D/'measurement';out.mkdir(exist_ok=False)
plan={'cases':cases,'inputs':{n:inputs[n] for n,_ in cases},'builds':builds,'binaries':{v:str(p) for v,p in paths.items()},'power_start':power,'environment':environment(),'timing_rounds':6,'memory_rounds':3,'samples_per_timing_worker':3,'warmups':2,'purpose':'Cost of validation on already-correct matched outputs; formerly failing inference cases are excluded from before/after speed claims.'}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
records=[]
with (out/'workers.jsonl').open('x') as f:
 for ci,(name,mode) in enumerate(cases):
  for phase,n in [('timing',6),('memory',3)]:
   for rnd in range(n):
    order=['before','fixed'] if (rnd+ci)%2==0 else ['fixed','before']
    for pos,v in enumerate(order):
     p=subprocess.run([str(paths[v]),str(R/'inputs'/(name+'.json')),mode,phase,'3'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=240)
     assert p.returncode==0,p.stderr
     r=json.loads(p.stdout);assert r['validated'] and r['checks']['passed']
     expected=next(x for x in previous if x['input']==name and x['mode']==mode)
     assert r['checks']==expected['checks']
     r.update(variant=v,round=rnd,position=pos);records.append(r);f.write(json.dumps(r)+'\n');f.flush()
  print(name,mode,'complete',flush=True)
power=power_state();assert power['source']=='AC';(out/'power-end.json').write_text(json.dumps(power,indent=2)+'\n')
rows=[]
for name,mode in cases:
 row={'input':name,'mode':mode,'variants':{},'ratios':{}}
 for v in paths:
  selected=[r for r in records if r['input']==name and r['mode']==mode and r['variant']==v]
  row['variants'][v]={}
  for key,phase in [('total_ns','timing'),('total_cpu_ns','timing'),('process_peak_held_bytes','memory'),('held_heap_delta_bytes','memory')]:
   group=sorted([r for r in selected if r['phase']==phase],key=lambda r:r['round'])
   row['variants'][v][key]=[st.median(s[key] for s in r['samples']) for r in group]
 for key in row['variants']['before']:
  ratios=[b/a for a,b in zip(row['variants']['before'][key],row['variants']['fixed'][key])]
  row['ratios'][key]={'median_ratio':st.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
 rows.append(row)
summary={'workers':len(records),'timing_samples':sum(len(r['samples']) for r in records if r['phase']=='timing'),'memory_samples':sum(len(r['samples']) for r in records if r['phase']=='memory'),'records_sha256':h(out/'workers.jsonl'),'rows':rows}
assert (summary['workers'],summary['timing_samples'],summary['memory_samples'])==(72,144,24)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in rows:print(r['input'],r['mode'],{k:round(100*(v['median_ratio']-1),2) for k,v in r['ratios'].items()})
