from pathlib import Path
import hashlib,itertools,json,os,statistics as st,subprocess,sys
D=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/swiftsci-csv-inference-20261021/Benchmarks/Tools')
from runner import power_state,environment
from execution_policy import worker_environment,PRODUCTION_MODE
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((D/'measurement/plan.json').read_text())
paths=dict(previous['binaries']);paths['control']=paths['before']
case=previous['inputs']['energy'];assert h(Path(case['path']))==case['sha256']
orders=list(itertools.permutations(['before','control','fixed']))
out=D/'control';out.mkdir(exist_ok=False)
power=power_state();assert power['source']=='AC'
plan={'purpose':'Identical-binary control and fixed candidate on the unstable energy supplied-schema workload. Original run retained. No source changes.','binaries':paths,'binary_sha256':{v:h(Path(p)) for v,p in paths.items()},'case':case,'mode':'known','orders':orders,'samples_per_worker':3,'warmups':2,'power_start':power,'environment':environment()}
assert plan['binary_sha256']['before']==plan['binary_sha256']['control']
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
records=[]
with (out/'workers.jsonl').open('x') as f:
 for rnd,order in enumerate(orders):
  for pos,v in enumerate(order):
   load=os.getloadavg()
   p=subprocess.run([paths[v],'/private/tmp/swiftsci-csv-reference-20261021/inputs/energy.json','known','timing','3'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=240)
   assert p.returncode==0,p.stderr
   r=json.loads(p.stdout);assert r['validated'] and r['checks']['passed']
   for i,col in enumerate(r['checks']['columns']):assert col['sha256']==case['hashes'][i] and col['nulls']==case['null_counts'][i]
   r.update(variant=v,round=rnd,position=pos,load_before=load);records.append(r);f.write(json.dumps(r)+'\n');f.flush()
  print('Control round',rnd+1,'complete',flush=True)
power=power_state();assert power['source']=='AC';(out/'power-end.json').write_text(json.dumps(power,indent=2)+'\n')
summary={'workers':len(records),'samples':sum(len(r['samples']) for r in records),'variants':{},'ratios':{},'records_sha256':h(out/'workers.jsonl')}
for v in paths:
 rs=sorted([r for r in records if r['variant']==v],key=lambda r:r['round'])
 summary['variants'][v]={k:[st.median(x[k] for x in r['samples']) for r in rs] for k in ['total_ns','total_cpu_ns']}
for v in ['control','fixed']:
 summary['ratios'][v]={}
 for k in ['total_ns','total_cpu_ns']:
  ratios=[b/a for a,b in zip(summary['variants']['before'][k],summary['variants'][v][k])]
  summary['ratios'][v][k]={'median_ratio':st.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
assert summary['workers']==18 and summary['samples']==54
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['ratios'],indent=2))
