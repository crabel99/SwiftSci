from pathlib import Path
import hashlib,json,statistics as st,subprocess
V=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-inference-20261021')
base='2be6fc01a80d520d637f85f9f4bbde0a855e309b';head='548a783f02678c95c027a733e3cbd51df363dc47'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
red=json.loads((V/'red-regression-summary.json').read_text());cmd=json.loads((V/'red-regression-command.json').read_text())
assert red['failedTests']==2 and red['passedTests']==340 and cmd['exit_code']!=0
assert {r['testIdentifierString'] for r in red['testFailures']}=={'CSVInferenceValidationTests/lateFraction(_:)','CSVInferenceValidationTests/lateText(_:)'}
f='Sources/SwiftDataFrame/IO/CSVReader.swift'
assert cmd['source_sha256'][f]==hashlib.sha256(subprocess.check_output(['git','show',base+':'+f],cwd=S)).hexdigest()
f='Tests/SwiftDataFrameTests/CSVInferenceValidationTests.swift';assert cmd['source_sha256'][f]==h(S/f)
for label in ['complete-green','release']:
 c=json.loads((V/(label+'-command.json')).read_text());r=json.loads((V/(label+'-summary.json')).read_text())
 assert c['exit_code']==0 and r['passedTests']==342 and r['failedTests']==r['skippedTests']==0
 for f,d in c['source_sha256'].items():assert h(S/f)==d
cov=json.loads((V/'patch-coverage.json').read_text());assert sum(x['covered'] for x in cov['results'])==31
for r in cov['results']:
 assert not r['uncovered'] and r['covered']==r['added_executable']
 assert h(S/'Sources/SwiftDataFrame/IO'/r['file'])==r['source_sha256']
 assert h(V/(r['file']+'.coverage.txt'))==r['coverage_sha256']
cert=json.loads((V/'tabular-smoke/certificate.json').read_text());run=json.loads((V/'tabular-smoke/run.json').read_text())
assert cert['status']==run['status']=='passed' and cert['validated_samples']==len(run['events'])==190
assert cert['source']['commit']==head and h(V/'tabular-smoke/run.json')==cert['run_sha256']
build=json.loads((V/'reference/build/fixed/build.json').read_text())
for f,d in build['sources'].items():assert h(S/f)==d
assert h(V/'reference/build/fixed/ResourceProbe')==build['binary_sha256']
audit=[json.loads(l) for l in (V/'reference/audit.jsonl').read_text().splitlines()]
assert len(audit)==26 and all(r['validated'] and r['checks']['passed'] for r in audit)
restored=json.loads((V/'restored-measurements.json').read_text());assert restored['restored_values']==398
date=json.loads((V/'reference/date-audit.json').read_text())
prior_date=json.loads(Path('/private/tmp/swiftsci-csv-reference-20261021/date-audit.jsonl').read_text().splitlines()[0])
assert not date['validated'] and date['checks']==prior_date['checks']
D=V/'reference/measurement';plan=json.loads((D/'plan.json').read_text());summary=json.loads((D/'summary.json').read_text())
records=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()]
expected={(name,mode,v,phase,rnd) for name,mode in plan['cases'] for v in plan['builds'] for phase,n in [('timing',6),('memory',3)] for rnd in range(n)}
assert len(records)==len(expected)==72
assert {(r['input'],r['mode'],r['variant'],r['phase'],r['round']) for r in records}==expected
assert plan['power_start']['source']==json.loads((D/'power-end.json').read_text())['source']=='AC'
for v,b in plan['builds'].items():assert h(Path(plan['binaries'][v]))==b['binary_sha256']
for c in plan['inputs'].values():assert h(Path(c['path']))==c['sha256']
for r in records:
 assert r['validated'] and r['checks']['passed'] and len(r['samples'])==(3 if r['phase']=='timing' else 1)
 c=plan['inputs'][r['input']]
 for i,col in enumerate(r['checks']['columns']):assert col['sha256']==c['hashes'][i] and col['nulls']==c['null_counts'][i]
 for x in r['samples']:
  assert x['total_ns']==x['call_ns']+x['release_ns']>0
  assert x['total_cpu_ns']==x['call_cpu_ns']+x['release_cpu_ns']>0
assert summary['records_sha256']==h(D/'workers.jsonl')
for row in summary['rows']:
 for k,metric in row['ratios'].items():
  ratios=[b/a for a,b in zip(row['variants']['before'][k],row['variants']['fixed'][k])]
  assert metric=={'median_ratio':st.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
result={'passed':True,'head':head,'failing_before_tests':2,'passing_after_debug_tests':342,'passing_release_tests':342,'added_executable_lines_covered':31,'standard_validated_samples':190,'original_file_modes_passed':26,'restored_values':398,'correct_output_comparison_workers':72,'timing_samples':144,'memory_samples':24,'measurement_summary_sha256':h(D/'summary.json')}
(V/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
