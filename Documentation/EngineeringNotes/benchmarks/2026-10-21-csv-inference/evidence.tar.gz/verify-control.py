from pathlib import Path
import hashlib,json,statistics as st
root=Path(__file__).resolve().parent;d=root/'reference/control'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((d/'plan.json').read_text());s=json.loads((d/'summary.json').read_text());rs=[json.loads(l) for l in (d/'workers.jsonl').read_text().splitlines()]
assert plan['binary_sha256']['before']==plan['binary_sha256']['control']
for k,p in plan['binaries'].items():assert h(Path(p))==plan['binary_sha256'][k]
assert plan['power_start']['source']==json.loads((d/'power-end.json').read_text())['source']=='AC'
assert len(rs)==18 and s['samples']==54 and s['records_sha256']==h(d/'workers.jsonl')
assert {(r['round'],r['variant']) for r in rs}=={(n,v) for n in range(6) for v in plan['binaries']}
for r in rs:
 assert plan['orders'][r['round']][r['position']]==r['variant']
 assert r['validated'] and r['checks']['passed'] and len(r['samples'])==3
 for i,c in enumerate(r['checks']['columns']):assert c['sha256']==plan['case']['hashes'][i] and c['nulls']==plan['case']['null_counts'][i]
for v in ['control','fixed']:
 for k,metric in s['ratios'][v].items():
  ratios=[b/a for a,b in zip(s['variants']['before'][k],s['variants'][v][k])]
  assert metric=={'median_ratio':st.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
(root/'control-verification.json').write_text(json.dumps({'passed':True,'workers':18,'timing_samples':54,'identical_binary_control':True,'summary_sha256':h(d/'summary.json')},indent=2)+'\n')
print('Control receipt and all 54 samples verified')
