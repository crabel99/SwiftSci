# Mixed CSV queue pilot

The fixed queue contains the same jobs at each concurrency. Workers use native CPU parallelism. Throughput includes queue dispatch, public CSV reading, stable sorting, matrix construction, and output release. Process startup and preflight validation are outside the queue. Full native-bit hashes match before and after the panel; timed outputs receive shape and type checks, not full hashes.

| Callers | Storage | Jobs/min | Charged CPU ms/job | Peak worker RSS MiB | Retained RSS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 1 | optional | 726.1 | 181.04 | 767.3 | 766.3 |
| 1 | compact | 714.2 | 178.34 | 521.5 | 521.5 |
| 2 | optional | 1073.7 | 187.19 | 1074.2 | 1074.2 |
| 2 | compact | 1042.8 | 182.86 | 719.9 | 719.9 |

CPU includes benchmark workers and the measured controller. RSS is the sampled sum of live worker residency; it is not private memory and may double-count shared pages. Ten-millisecond sampling can miss short peaks. Retained RSS includes allocator caches after all outputs are released. System paging and unrelated processes are recorded separately and cannot be attributed to this experiment.

Responses run from initial queue submission to result receipt, so they include queue waiting. Per-case p50 and p95 queue, service, and response times are in each result. These are finite CPU queue experiments, not energy, GPU, Neural Engine, or memory-exhaustion measurements.
