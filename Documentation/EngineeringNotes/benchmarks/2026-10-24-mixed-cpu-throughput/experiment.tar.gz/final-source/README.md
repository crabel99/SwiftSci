# CPU queue throughput experiment

This controller compares optional and compact Double storage on the same SwiftDataFrame build. Each finite queue mixes CSV reads with complete CSV, stable sort, and matrix workflows. It measures resource use and completion under increasing caller concurrency. It adds no production scheduling policy.

The [existing mixed-workload trial](../MixedWorkloads/README.md) covers CPU, GPU, and Core ML admission. This experiment isolates CPU dataframe callers. It reuses the [production-default execution policy](../Tools/execution_policy.py), which clears inherited thread caps. One, two, four, or eight persistent worker processes compete with their native internal parallelism.

## Work and correctness

Two input contracts describe the air-quality and household-energy reference CSVs. Contracts contain input paths and SHA-256 hashes, row counts, ordered column names and types, delimiters, and null tokens. Every engine or storage choice receives a complete schema. This experiment uses `PM2.5` and `Global_active_power` as sort keys.

Each full queue contains four copies of each dataset and workflow combination, for 16 jobs. Every concurrency processes the same queue. The controller rotates task order across eight rounds. Four labels, including an identical-binary twin of each storage mode, rotate through each position and its reverse. Caller-count order rotates too.

Both workflows read and materialize the complete frame. Sort-and-matrix jobs sort the complete frame stably with missing keys last, then construct an owned, contiguous, row-major Double matrix of numeric columns. Outputs are released before each job responds. No result crosses process boundaries.

Before and after the panel, both storage modes must match externally supplied native-bit fingerprints for every column and matrix. Use fingerprints independently checked against reference libraries, not hashes generated from this run. Each timed output receives row-count, column-order, type, and matrix-size checks. Full hashes are outside queue timing. The panel does not fully hash every timed result.

## Measurement boundaries

All jobs enter the queue at the same initial submission time. Response time includes time waiting for a worker, dispatch, the public operations, output release, and receipt. Separate queue and service times identify whether callers wait longer under contention. A finite burst does not model a sustained arrival distribution.

The controller starts fresh worker processes for every batch. Worker startup completes before timing. The first public API call in each worker remains inside timing. Process startup, full-hash preflight, and postflight are excluded. Repeated fixture reads follow preflight, so this is not a cold-disk test.

Metrics have distinct meanings:

- Jobs per minute is the fixed work total divided by whole-queue elapsed time. Jobs have different sizes, so this rate is comparable only with the same queue composition.
- Charged CPU is summed worker user and system time plus controller CPU during the queue. It includes dispatch and sampling. It is neither FLOPs nor energy.
- Operation CPU excludes request decoding and controller work. It includes frame construction, requested operations, shape checks, memory bookkeeping, and release.
- Peak worker RSS is the maximum sampled sum of concurrent process residency. It is not the sum of separate lifetime peaks. Shared pages can be counted more than once, so RSS does not measure unique physical memory.
- Retained RSS describes live workers after the queue and after output release. It includes runtime and allocator caches. It does not by itself establish a leak.
- Resident byte-seconds integrates sampled residency across queue time. This approximate memory occupancy accounts for how long workers retain memory.

Sampling targets 10 ms and records the largest observed gap. Short-lived peaks may be missed. An 8 GiB aggregate worker-RSS ceiling stops only this experiment's process groups. It is an experiment bound, not a recommended application memory limit. Cleanup closes every worker on completion and failure.

AC power is required at the start, before each batch, and at the end. System paging counters, swap use, and process activity are recorded at panel boundaries. These are system-wide observations and cannot identify the owner of paging. Background applications remain running.

The plan records source and dependency hashes, compiler commands, executable hash, toolchain, hardware, input contracts, independent fingerprint hash, and controller hash before measurements. Coverage-instrumented workers are rejected. The audit requires every planned job and batch and retains control failures. Identical-binary limits are 10% for CPU and elapsed time, and 5% plus 8 MiB per caller for sampled peak RSS. A small difference inside those limits is not automatically significant.

## Run the experiment

Build the worker against the existing uninstrumented Release dependency objects. Supply their directory and the ArrowC and Atomics module-map paths from the local package build.

```sh
python3 Benchmarks/CPUThroughput/build.py \
  --products /absolute/path/Release \
  --arrow-module-map /absolute/path/ArrowC.modulemap \
  --atomics-module-map /absolute/path/module.modulemap \
  --output /absolute/path/new-worker-directory
```

Run the short smoke panel first. All output directories must be new.

```sh
python3 Benchmarks/CPUThroughput/run.py \
  --worker /absolute/path/new-worker-directory/worker \
  --air-contract /absolute/path/air.json \
  --energy-contract /absolute/path/energy.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-results-directory \
  --smoke
```

Remove `--smoke` for eight rounds at all four caller counts. Audit the completed full panel separately.

```sh
python3 Benchmarks/CPUThroughput/audit.py /absolute/path/new-results-directory
python3 -m unittest discover -s Benchmarks/Tests -p test_cpu_throughput.py
```

Read `report.md` for medians, `audit.json` for control qualification, and each batch's `result.json` for task latency and raw memory samples. Full-hash receipts are under `preflight` and `postflight`. Keep engineering conclusions and measured artifacts on the engineering-notes branch.
