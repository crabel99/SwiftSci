# Mixed CSV queue pilot

The fixed queue contains the same jobs at each concurrency. Workers use native CPU parallelism. Throughput includes queue dispatch, public CSV reading, stable sorting, matrix construction, and output release. Process startup and preflight validation are outside the queue. Full native-bit hashes match before and after the panel; timed outputs receive shape and type checks, not full hashes.

| Callers | Storage | Jobs/min | Charged CPU ms/job | Peak worker RSS MiB | Retained RSS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 1 | optional | 667.5 | 181.77 | 896.7 | 770.3 |
| 1 | compact | 655.5 | 182.90 | 655.9 | 531.5 |
| 2 | optional | 1177.3 | 186.66 | 1670.4 | 1540.9 |
| 2 | compact | 1171.6 | 184.25 | 1179.9 | 1045.9 |
| 4 | optional | 1859.4 | 202.23 | 2859.6 | 2608.4 |
| 4 | compact | 1821.2 | 198.72 | 2022.8 | 1772.0 |
| 8 | optional | 2507.7 | 231.09 | 4268.9 | 4268.9 |
| 8 | compact | 2510.5 | 222.73 | 2858.6 | 2858.6 |

CPU includes benchmark workers and the measured controller. RSS is the sampled sum of live worker residency; it is not private memory and may double-count shared pages. Ten-millisecond sampling can miss short peaks. Retained RSS includes allocator caches after all outputs are released. System paging and unrelated processes are recorded separately and cannot be attributed to this experiment.

Responses run from initial queue submission to result receipt, so they include queue waiting. Per-case p50 and p95 queue, service, and response times are in each result. These are finite CPU queue experiments, not energy, GPU, Neural Engine, or memory-exhaustion measurements.
