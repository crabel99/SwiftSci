from pathlib import Path
import argparse,json,statistics,sys,hashlib
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
from Benchmarks.CPUThroughput.budget import jobs_for
p=argparse.ArgumentParser();p.add_argument('--worker',type=Path,required=True);p.add_argument('--trial',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--rounds',type=int,default=8);p.add_argument('--contract',type=Path);a=p.parse_args()
a.out.mkdir(parents=True,exist_ok=False)
case=json.loads(Path('/private/tmp/swiftsci-cpu-throughput-panel-20261024/plan.json').read_text())['cases'][2];case=dict(case,id=0)
if a.contract:
 manifest=json.loads(a.contract.read_text());case=dict(id=0,contract=str(a.contract),workflow='read',input=manifest['id'],key='x',verify=False)
labels=['optional','compact','optional_twin','compact_twin']
if a.trial:labels=['optional','compact','trial','optional_twin','compact_twin','trial_twin']
orders=[labels[i%len(labels):]+labels[:i%len(labels)] for i in range(a.rounds)]
run.save(a.out/'plan.json',dict(case=case,orders=orders,jobs_per_queue=4,callers=1,
 worker_sha256=run.digest(a.worker),trial_sha256=None if a.trial is None else run.digest(a.trial),power=run.power(),
 CPU_symptom_threshold=1.02,quality=dict(cpu_twin_deviation=.10,rss_relative=1.05,rss_slack_bytes=8*2**20)))
records=[]
for i,order in enumerate(orders):
 for label in order:
  run.power()
  worker=a.trial if label.startswith('trial') else a.worker
  storage='optional' if label.startswith('optional') else 'compact'
  row=run.batch(worker,storage,jobs_for([case],4,0),1,a.out/f'r{i}-{label}')
  records.append(dict(round=i,label=label,summary=row))
  run.save(a.out/'records.json',records)
med={label: {key:statistics.median(x['summary'][key] for x in records if x['label']==label) for key in ['charged_cpu_ns','sampled_peak_rss_bytes','completed_per_minute']} for label in labels}
flags=[]
for label in labels:
 if label.endswith('_twin'):continue
 x,y=med[label],med[label+'_twin']
 if abs(y['charged_cpu_ns']/x['charged_cpu_ns']-1)>.10:flags.append(label+' CPU drift')
 lo,hi=sorted((x['sampled_peak_rss_bytes'],y['sampled_peak_rss_bytes']))
 if hi>lo*1.05+8*2**20:flags.append(label+' RSS drift')
pooled={label:{key:statistics.median(x['summary'][key] for x in records if x['label'].removesuffix('_twin')==label) for key in med[label]} for label in labels if not label.endswith('_twin')}
ratio=pooled['compact']['charged_cpu_ns']/pooled['optional']['charged_cpu_ns']
result=dict(qualified=not flags,flags=flags,medians=pooled,compact_to_optional_cpu_ratio=ratio,symptom_present=ratio>1.02)
if a.trial:result['trial_to_compact_cpu_ratio']=pooled['trial']['charged_cpu_ns']/pooled['compact']['charged_cpu_ns']
run.save(a.out/'decision.json',result);print(json.dumps(result,indent=2))
if not a.trial and not flags and ratio>1.02:sys.exit(1)
