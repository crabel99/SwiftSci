from pathlib import Path
import subprocess,re,difflib,json
R=Path(__file__).parent
bins={'parent':Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker'),'pair':R/'pair-build/worker'}
functions=['11parseDouble','15parseLongDouble','12appendDouble']
report={}
for name,binary in bins.items():
 nm=subprocess.check_output(['xcrun','nm','-n',str(binary)],text=True)
 symbols=[line.split()[-1] for line in nm.splitlines() if any(f in line for f in functions)]
 report[name]={}
 for i,symbol in enumerate(symbols):
  text=subprocess.check_output(['xcrun','llvm-objdump','--no-show-raw-insn','--disassemble-symbols='+symbol,str(binary)],text=True)
  (R/(name+'-asm-'+str(i)+'.txt')).write_text(text)
  normalized=[]
  for line in text.splitlines():
   if not re.match(r'^[0-9a-f]+:',line):continue
   line=re.sub(r'^[0-9a-f]+:\s*','',line)
   line=re.sub(r'0x[0-9a-f]+ <[^>]+>','<target>',line)
   normalized.append(line)
  report[name][symbol]=normalized
(R/'assembly-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
for symbol,a in report['parent'].items():
 if symbol not in report['pair']:continue
 b=report['pair'][symbol]
 print(symbol,'instructions',len(a),len(b),'equal',a==b)
 if '15parseLongDouble' in symbol:print('\n'.join(difflib.unified_diff(a,b)))
