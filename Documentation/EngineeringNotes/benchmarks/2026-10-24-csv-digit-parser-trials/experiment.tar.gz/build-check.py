from pathlib import Path
import argparse,json,subprocess,hashlib
r=Path(__file__).parent;p=argparse.ArgumentParser();p.add_argument('build',type=Path);p.add_argument('name');a=p.parse_args()
build=json.loads((a.build/'build.json').read_text());cmd=build['commands'][1].copy();old=next(x for x in cmd if x.endswith('/CPUThroughput/Worker.swift'));cmd[cmd.index(old)]=str(r/'ParserCheck.swift');cmd[cmd.index('-o')+1]=str(r/(a.name+'-check'))
with (r/(a.name+'-check-build.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with (r/(a.name+'-check-output.log')).open('w') as f:subprocess.run([str(r/(a.name+'-check')),str(r/(a.name+'-results.bin'))],stdout=f,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt=dict(command=cmd,parser_build=build['binary_sha256'],client_sha256=sha(r/'ParserCheck.swift'),checker_sha256=sha(r/(a.name+'-check')),results_sha256=sha(r/(a.name+'-results.bin')),output=(r/(a.name+'-check-output.log')).read_text());(r/(a.name+'-check.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['output'],receipt['results_sha256'])
