import Foundation
import SwiftDataFrame

@main
struct ParserCheck {
    static func main() throws {
        var output = Data()
        var count = 0
        var oracleChecks = 0
        var state: UInt64 = 0x243f6a8885a308d3
        func emit(_ bytes: [UInt8], expected: Double?? = nil) {
            let padding = count & 7
            let padded = [UInt8](repeating: 120, count: padding) + bytes
            let actual = padded.withUnsafeBufferPointer { buffer in
                VectorizedByteParsers.parseDouble(buffer: buffer,
                    offset: CSVFieldOffset(startOffset: padding, length: bytes.count, escapedQuotesPresent: false))
            }
            if let expected {
                oracleChecks += 1
                precondition(actual?.bitPattern == expected?.bitPattern,
                    "Oracle mismatch at case \(count): \(String(decoding: bytes, as: UTF8.self))")
            }
            output.append(actual == nil ? 0 : 1)
            var bits = (actual?.bitPattern ?? 0).littleEndian
            withUnsafeBytes(of: &bits) { output.append(contentsOf: $0) }
            count += 1
        }
        func valid(_ text: String) {
            let expected = Double(text)!
            emit(Array(text.utf8), expected: .some(expected))
            emit(Array((" \t" + text + "\r\n").utf8), expected: .some(expected))
            emit(Array(("\" \t" + text + " \"").utf8), expected: .some(expected))
        }
        for a in 0...255 {
            for b in 0...255 {
                let pair = [UInt8(a), UInt8(b)]
                emit(pair)
                emit([49] + pair)
                emit([49, 46] + pair)
                emit(pair + [46, 53])
            }
        }
        for n in 0..<1000 {
            let text = String(n)
            valid(text)
            valid("-" + text)
            valid("+" + text)
            for i in 0...text.count {
                let index = text.index(text.startIndex, offsetBy: i)
                valid(String(text[..<index]) + "." + String(text[index...]))
            }
        }
        for i in 0..<20_000 {
            state = state &* 6364136223846793005 &+ 1442695040888963407
            let whole = String(state % 1_000_000_000_000_000)
            state = state &* 6364136223846793005 &+ 1442695040888963407
            let digits = 1 + Int(state % 22)
            let raw = String(state)
            let fraction = String(repeating: "0", count: max(0, digits - raw.count)) + String(raw.suffix(digits))
            let sign = i % 3 == 0 ? "-" : (i % 3 == 1 ? "+" : "")
            let literal = sign + whole + "." + fraction
            valid(literal)
            if i % 4 == 0 { valid(literal + "e" + String(Int(state % 801) - 400)) }
        }
        for text in ["", " ", "+", "-", ".", "1.2.3", "1e", "1e+", "1e-", "1e2x", "1 2", "0x1p0", "12_345", "nan", "inf"] {
            emit(Array(text.utf8), expected: .some(nil))
        }
        for text in ["-0", "-0.0", "000000000000001.23456", "9007199254740991", "9007199254740992", "9007199254740993", "18446744073709551615", "1.7976931348623157e308", "1e309", "5e-324", "1e-9999", "-1e-9999"] { valid(text) }
        try output.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
        print("cases=\(count) oracle_checks=\(oracleChecks) bytes=\(output.count)")
    }
}
