from pathlib import Path
import json,subprocess,sys
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
parent=Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker');worker=R/'compact-loop-build/worker'
a=json.loads(parent.with_name('build.json').read_text());b=json.loads(worker.with_name('build.json').read_text())
assert a['dependencies']==b['dependencies'];assert set(a['sources'])==set(b['sources'])
assert [k for k in a['sources'] if a['sources'][k]!=b['sources'][k]]==['Sources/SwiftDataFrame/IO/VectorizedByteParsers.swift']
subprocess.run(['python3',str(R/'build-check.py'),str(worker.parent),'compact-loop'],check=True)
assert (R/'compact-loop-results.bin').read_bytes()==(R/'baseline-expanded-results.bin').read_bytes()
reference=json.loads((R/'pair-workflows/plan.json').read_text());D=R/'compact-loop-preflight';D.mkdir()
run.preflight(worker,reference['cases'],json.loads((R/'pair-workflows/expected.json').read_text()),D)
subprocess.run(['python3',str(R/'confirm-format.py'),'--worker',str(parent),'--trial',str(worker),'--contract',str(R/'formats/long-fallback.json'),'--rounds','8','--out',str(R/'compact-loop-fallback')],check=True)
subprocess.run(['python3',str(R/'measure.py'),'--worker',str(parent),'--trial',str(worker),'--rounds','8','--out',str(R/'compact-loop-household')],check=True)
