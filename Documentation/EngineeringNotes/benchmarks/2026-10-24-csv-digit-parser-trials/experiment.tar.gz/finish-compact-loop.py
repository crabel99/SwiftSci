from pathlib import Path
import subprocess,json,shutil
R=Path(__file__).parent
V=R/'compact-loop-validation';V.mkdir()
shutil.copyfile(R/'validate.py',V/'validate.py')
for name in ['compare-workflows.py','compare-workflows-reversed.py']:
 s=(R/name).read_text().replace("R/'pair-workflows", "R/'compact-loop-workflows").replace("R/'pair-build/worker'", "R/'compact-loop-build/worker'")
 (R/('compact-loop-'+name)).write_text(s)
s=(R/'screen-formats.py').read_text().replace("R/'pair-formats'", "R/'compact-loop-formats'").replace("R/'pair-build/worker'", "R/'compact-loop-build/worker'")
(R/'compact-loop-screen-formats.py').write_text(s)
steps=[['python3',str(V/'validate.py')],['python3',str(R/'compact-loop-screen-formats.py')],['python3',str(R/'screen-density.py'),'compact-loop'],['python3',str(R/'compact-loop-compare-workflows.py')],['python3',str(R/'audit-workflows.py'),'compact-loop-workflows'],['python3',str(R/'compact-loop-compare-workflows-reversed.py')],['python3',str(R/'audit-workflows.py'),'compact-loop-workflows-reversed']]
for index,command in enumerate(steps):
 with (R/f'compact-loop-stage-{index}.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('completed',index,command[-1],flush=True)
(R/'compact-loop-completed.json').write_text(json.dumps(dict(steps=steps,complete=True),indent=2)+'\n')
