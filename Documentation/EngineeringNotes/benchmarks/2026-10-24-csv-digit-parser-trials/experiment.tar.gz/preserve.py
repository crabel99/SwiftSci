from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess,statistics
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-24-csv-digit-parser-trials';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commits=json.loads((R/'local-commits.json').read_text());analysis=json.loads((R/'analysis.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==commits['active_head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
for variant,head in commits['commits'].items():
 for name,digest in json.loads((R/(variant+'-build/build.json')).read_text())['sources'].items():
  content=subprocess.check_output(['git','show',head+':'+name],cwd=S)
  assert hashlib.sha256(content).hexdigest()==digest
for variant,prefix in [('pair',R),('compact-loop',R/'compact-loop-validation')]:
 for mode in ['debug','release']:
  d=json.loads((prefix/('compact-'+mode+'-tests.json')).read_text());assert d['exit_code']==0 and d['summary']['passedTests']==439 and d['summary']['failedTests']==d['summary']['skippedTests']==0
for name in ['baseline-expanded','pair','compact-loop']:
 d=json.loads((R/(name+'-check.json')).read_text());assert d['results_sha256']=='c1b0c406361b1f5548271b665571115ee09c61bda681cb405bdf7f8c4c21456f'
for name in ['pair-workflows','pair-workflows-reversed']:
 audit=json.loads((R/name/'audit.json').read_text());assert audit['jobs']==8192 and audit['full_output_checks']==32 and audit['qualified']
for key in ['pair-formats','compact-loop-formats','pair-densities','compact-loop-densities']:
 assert all(v['qualified'] and not v['flags'] for v in analysis[key].values())
confirmations={}
for name in ['long-fallback-confirm','compact-loop-fallback','compact-loop-one-digit-confirm']:
 d=json.loads((R/name/'decision.json').read_text());plan=json.loads((R/name/'plan.json').read_text());rows=json.loads((R/name/'records.json').read_text());assert d['qualified'] and len(rows)==48 and plan['jobs_per_queue']==32
 ratios=[]
 for i in range(8):
  cpu={label:statistics.median(x['summary']['charged_cpu_ns'] for x in rows if x['round']==i and x['label'].removesuffix('_twin')==label) for label in ['compact','trial']}
  ratios.append(cpu['trial']/cpu['compact'])
 confirmations[name]=dict(cpu_change_percent=100*(d['trial_to_compact_cpu_ratio']-1),median_paired_cpu_change_percent=100*(statistics.median(ratios)-1),rounds_more_cpu=sum(x>1 for x in ratios),paired_ratios=ratios,queues=48,reads=1536,qualified=True)
summary=dict(decision='Keep both candidates local and unpromoted; preserve production parser at 5b9c902977',commits=commits,tests_per_candidate=dict(Debug=439,Release=439,failures=0,skips=0),native_corpus_cases=417865,oracle_checks_subset=155721,corpus_results_sha256='c1b0c406361b1f5548271b665571115ee09c61bda681cb405bdf7f8c4c21456f',analysis=analysis,longer_confirmations=confirmations,interrupted_panel=dict(name='compact-loop-workflows',reason='Own driver intentionally interrupted to investigate one-digit regression; no qualified result or postflight claimed',completed_queues=len(json.loads((R/'compact-loop-workflows/records.json').read_text())),qualified=False),schema='full_explicit',inference_performance_claim=False,remote_actions=False)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Gather immutable source and reproduction inputs outside the measured source tree.
P=R/'provenance';P.mkdir(exist_ok=True)
shutil.copyfile(S/'Sources/SwiftDataFrame/IO/VectorizedByteParsers.swift',P/'parent-parser.swift')
for name in ['Package.swift','Package.resolved']:
 shutil.copyfile(S/name,P/name)
shutil.copyfile(Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/build.json'),P/'parent-build.json')
shutil.copyfile(Path('/private/tmp/swiftsci-compact-builder-20261024/density.py'),P/'original-density-generator.py')
for path in [*list((S/'Benchmarks/CPUThroughput').rglob('*.py')),S/'Benchmarks/CPUThroughput/Worker.swift',*list((S/'Benchmarks/Tools').glob('*.py'))]:
 dest=P/path.relative_to(S);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
# Tests from the unchanged parent plus the new trial test are sufficient for dataframe-suite source provenance.
for path in (S/'Tests/SwiftDataFrameTests').rglob('*.swift'):
 dest=P/path.relative_to(S);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
q=P/'Tests/SwiftDataFrameTests/CSVShortDigitPairTests.swift';shutil.copyfile(R/'pair-source/Tests/SwiftDataFrameTests/CSVShortDigitPairTests.swift',q)
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='archive-files.json':continue
 parts=p.relative_to(R).parts
 if any(x in {'module-cache','__pycache__'} or x.endswith('.xcresult') for x in parts):continue
 if p.suffix not in {'.json','.py','.swift','.txt','.log','.patch','.md'}:continue
 if p.name in {'compact-debug-build.log','compact-release-build.log'}:continue
 files.append(p)
# One complete golden presence/bit-pattern stream is data, not a compiled executable.
files.append(R/'baseline-expanded-results.bin')
manifest={str(p.relative_to(R)):sha(p) for p in files}
(R/'archive-files.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(R/'archive-files.json')
with tarfile.open(D/'experiment.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
print('Archived',len(files),'files;',round((D/'experiment.tar.gz').stat().st_size/2**20,2),'MiB')
