import Testing
@testable import SwiftDataFrame

@Suite("Short CSV digit accumulation")
struct CSVShortDigitPairTests {
    private func parse(_ bytes: [UInt8], padding: Int) -> Double? {
        let padded = [UInt8](repeating: 120, count: padding) + bytes
        return padded.withUnsafeBufferPointer { buffer in
            VectorizedByteParsers.parseDouble(buffer: buffer,
                offset: CSVFieldOffset(startOffset: padding, length: bytes.count, escapedQuotesPresent: false))
        }
    }

    @Test("Odd and even digit runs preserve rounding across formatting and offsets", arguments: [
        ".1", "1.", "1.0", "01.20", "0.0010", "12.3456789012", "1234567.890123",
        "999999999999999", "99999999999999.0", "-0", "-0.0", "+12.5",
        "1.25e-300", "1.7976931348623157e308", "5e-324"
    ])
    func formattedValues(_ literal: String) throws {
        let expected = try #require(Double(literal))
        let variants = [literal, " \t" + literal + "\r\n", "\" \t" + literal + " \""]
        for text in variants {
            let bytes = Array(text.utf8)
            for padding in 0..<8 {
                let actual = try #require(parse(bytes, padding: padding))
                #expect(actual.bitPattern == expected.bitPattern)
            }
        }
    }

    @Test("A nondigit in either position retains malformed-field rejection")
    func malformedPairs() {
        let pairs: [[UInt8]] = [
            [47, 57], [48, 47], [58, 48], [48, 58],
            [0, 49], [49, 128], [255, 57], [57, 255]
        ]
        let prefixes: [[UInt8]] = [[], [49], [49, 46]]
        for prefix in prefixes {
            for pair in pairs {
                let bytes = prefix + pair
                for padding in 0..<8 {
                    #expect(parse(bytes, padding: padding) == nil)
                }
            }
        }
        for text in ["1:0", "12:34", "123:45", "12.3.4", "1234e", "1.2e+", "1.23x", "12e+"] {
            #expect(parse(Array(text.utf8), padding: 0) == nil)
        }
    }
}
