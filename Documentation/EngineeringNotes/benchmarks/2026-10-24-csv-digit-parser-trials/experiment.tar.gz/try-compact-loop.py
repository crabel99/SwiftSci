from pathlib import Path
import subprocess,json
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
p=S/'Sources/SwiftDataFrame/IO/VectorizedByteParsers.swift'
(R/'pair-parser.swift').write_bytes(p.read_bytes())
(R/'pair.patch').write_bytes(subprocess.check_output(['git','diff','--','Sources/SwiftDataFrame/IO/VectorizedByteParsers.swift'],cwd=S))
s=p.read_text();a=s.index('        while index < end {',s.index('internal static func parseShortDigits'));b=s.index('\n    }\n',a)
s=s[:a]+'''        while end - index >= 2 {
            let first = buffer[index] &- 48
            let second = buffer[index + 1] &- 48
            guard first <= 9 && second <= 9 else { break }
            significand = significand &* 100 &+ UInt64(first) &* 10 &+ UInt64(second)
            index += 2
        }
        if index < end {
            let digit = buffer[index] &- 48
            guard digit <= 9 else { return }
            significand = significand &* 10 &+ UInt64(digit)
            index += 1
        }'''+s[b:]
p.write_text(s)
(R/'compact-loop-hypothesis.json').write_text(json.dumps(dict(prior_candidate='pair',observed_long_fallback_cpu_increase_percent=2.11832802638678,assembly='Compiled long fallback and the entry instructions through its dispatch are unchanged after address normalization; the specialized parseDouble grows from 145 to 183 instructions.',hypothesis='A smaller pair loop may retain the short-digit saving while avoiding a larger shared parser body. Code layout is a hypothesis, not established cause.',change='Replace nested pair branches with a pair loop and one scalar tail. Keep pair arithmetic, parsing cutoff, fallback, storage, schema, and rounding unchanged.',gates=['same 417865-case native-bit corpus','longer long-fallback replay','same real household read screen','inspect compiled function size'],promotion='No production promotion unless broad resource and semantic validation pass.'),indent=2)+'\n')
# Reuse the exact compiler/dependency invocation, changing only output.
receipt=json.loads((R/'pair-build/build.json').read_text())
cmd=['python3',str(S/'Benchmarks/CPUThroughput/build.py'),'--products','/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/Release','--arrow-module-map','/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Intermediates.noindex/GeneratedModuleMaps/ArrowC.modulemap','--atomics-module-map','/Users/crabel/Library/Caches/SwiftSci/xcode-packages/checkouts/swift-atomics/Sources/_AtomicsShims/include/module.modulemap','--output',str(R/'compact-loop-build')]
with (R/'compact-loop-build-output.log').open('w') as log:subprocess.run(cmd,cwd=S,stdout=log,stderr=subprocess.STDOUT,check=True)
