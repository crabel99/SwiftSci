from pathlib import Path
import json,subprocess,statistics as st,hashlib,sys,time
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022');sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,PRODUCTION_MODE
from runner import power_state,environment,verify_uninstrumented
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((R/'plan.json').read_text());cases=plan['cases'];D=R/'standalone-memory';D.mkdir(exist_ok=False)
roots={'cleanup':F/'build/cleanup','twin':F/'build/cleanup','candidate':F/'build/metadata'};receipts={}
for label,root in roots.items():
 receipts[label]={'module_build_receipt_sha256':h(root/'build.json'),'binaries':{}}
 for name in ['ResourceProbe','StreamProbe']:
  p=root/name;verify_uninstrumented(p)
  original=json.loads((root/('build.json' if name=='ResourceProbe' else 'StreamProbe.build.json')).read_text())
  command=original.get('command',original.get('commands',[])[-1] if original.get('commands') else None)
  first_import=Path(command[command.index('-I')+1]);assert first_import.resolve()==root.resolve()
  assert h(p)==original['binary_sha256']
  receipts[label]['binaries'][name]={'path':str(p),'sha256':h(p),'first_module_import':str(first_import),'original_build_receipt_sha256':h(root/('build.json' if name=='ResourceProbe' else 'StreamProbe.build.json'))}
assert receipts['cleanup']==receipts['twin']
(D/'plan.json').write_text(json.dumps({'source_plan_sha256':h(R/'plan.json'),'controller_sha256':h(Path(__file__)),'cases':cases,'workers_per_label_case':8,'receipts':receipts,'environment':environment(),'power':power_state(),'started_unix':time.time()},indent=2)+'\n')
labels=['cleanup','twin','candidate'];rs=[]
with (D/'workers.jsonl').open('x') as out:
 for case in cases:
  for rnd in range(8):
   order=labels[rnd%3:]+labels[:rnd%3]
   if rnd%2:order=list(reversed(order))
   for label in order:
    assert power_state()['source']=='AC'
    inp=json.loads(Path(case['path']).read_text())
    assert h(Path(inp['path']))==inp.get('source_sha256',inp.get('sha256'))
    root=roots[label]
    args=[case['path'],'known','fresh','1',case['policy']] if case['scope']=='eager' else [case['path'],str(case['chunk']),case['policy']]
    binary=root/('ResourceProbe' if case['scope']=='eager' else 'StreamProbe')
    p=subprocess.run([str(binary),*args],capture_output=True,text=True,timeout=300,env=worker_environment(PRODUCTION_MODE));assert p.returncode==0,(str(binary),p.stderr[-2000:])
    d=json.loads(p.stdout);assert d['validated'];d.update({k:case[k] for k in ['case','scope','policy','group']});d.update(label=label,worker=rnd)
    rs.append(d);out.write(json.dumps(d)+'\n');out.flush()
  print(case['case'],case['scope'],case['policy'],'memory workers validated',flush=True)
summary=[]
for c in cases:
 for label in labels:
  ws=[r for r in rs if all(r[k]==c[k] for k in ['case','scope','policy']) and r['label']==label]
  assert len(ws)==8;values=[r['samples'][0] if c['scope']=='eager' else r for r in ws];peak='process_peak_held_bytes' if c['scope']=='eager' else 'peak_after_bytes'
  summary.append({k:c[k] for k in ['case','scope','policy','group']}|{'label':label,'workers':8,'median_peak_bytes':st.median(v[peak] for v in values),'median_cpu_ns_diagnostic_only':st.median(v['total_cpu_ns'] for v in values),'median_elapsed_ns':st.median(v['total_ns'] for v in values)})
flags=[]
for c in cases:
 xs={s['label']:s for s in summary if all(s[k]==c[k] for k in ['case','scope','policy'])};base=xs['cleanup']['median_peak_bytes']
 for label in ['twin','candidate']:
  value=xs[label]['median_peak_bytes'];delta=value-base
  if delta>base*0.05+8*2**20 or (label=='twin' and -delta>value*0.05+8*2**20):flags.append({k:c[k] for k in ['case','scope','policy','group']}|{'label':label,'baseline_bytes':base,'value_bytes':value,'delta_bytes':delta})
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'decision.json').write_text(json.dumps({'validated_workers':len(rs),'quality_passed':not any(f['label']=='twin' for f in flags),'candidate_memory_passed':not any(f['label']=='candidate' for f in flags),'flags':flags,'cpu_acceptance':False,'completed_unix':time.time()},indent=2)+'\n')
print(len(rs),'validated standalone workers;',len(flags),'memory flags',flush=True)
