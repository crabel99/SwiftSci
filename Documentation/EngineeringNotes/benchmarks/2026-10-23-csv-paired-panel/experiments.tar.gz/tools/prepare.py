from pathlib import Path
import json,hashlib
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
R=Path(__file__).resolve().parent;Q=Path('/private/tmp/swiftsci-csv-paired-read-20261023');F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022')
source=(Q/'PairedProbe.swift').read_text()
resource=Path('/private/tmp/swiftsci-csv-prefix-selection-20261022/ResourceProbe.swift').read_text()
validation=resource[resource.index('func validate('):resource.index('@MainActor @main')]
helpers=[]
for label,module in [('actual','SwiftDataFrame'),('baseline','CSVBaseline'),('clone','CSVClone')]:
 helpers.append(validation.replace('func validate(',f'func validate_{label}(').replace('_ df: DataFrame,',f'_ df: {module}.DataFrame,'))
 helpers.append(f'''@inline(never) func eager_{label}(_ url: URL, options: {module}.CSVReadOptions) async throws -> Int {{
    let frame = try await {module}.DataFrame(csv:url,options:options)
    return frame.rowCount
}}
func checkedEager_{label}(_ url: URL, options: {module}.CSVReadOptions, input: Input) async throws -> Bool {{
    let frame = try await {module}.DataFrame(csv:url,options:options)
    return validate_{label}(frame,input:input,mode:"known")["passed"] as? Bool == true
}}
''')
source=source.replace('@MainActor @main','\n'.join(helpers)+'\n@MainActor @main')
source=source.replace('let tokens = Set(input.null_tokens)','let scope = args[3], chunkSize = Int(args[4])!, blocks = Int(args[5])!, warmups = Int(args[6])!\n        precondition(["eager","stream"].contains(scope) && blocks > 0 && warmups > 0)\n        let tokens = Set(input.null_tokens)')
needle='''        func read(_ implementation: String) async throws -> Int {
            switch implementation {'''
replacement='''        func read(_ implementation: String) async throws -> Int {
            if scope == "eager" {
                switch implementation {
                case "baseline": return try await eager_baseline(url,options:baseline)
                case "clone": return try await eager_clone(url,options:clone)
                default: return try await eager_actual(url,options:actual)
                }
            }
            switch implementation {'''
assert needle in source;source=source.replace(needle,replacement).replace('chunkSize:input.rows','chunkSize:chunkSize')
needle='''        func check() async throws -> Bool {
            let a ='''
replacement='''        func check() async throws -> Bool {
            if scope == "eager" {
                let a = try await checkedEager_actual(url,options:actual,input:input)
                let b = try await checkedEager_baseline(url,options:baseline,input:input)
                let c = try await checkedEager_clone(url,options:clone,input:input)
                return a && b && c
            }
            let a ='''
assert needle in source;source=source.replace(needle,replacement).replace('for block in -2..<8','for block in -warmups..<blocks')
source=source.replace('"validated":true,"input":input.id','"scope":scope,"chunk_size":chunkSize,"blocks":blocks,"warmups":warmups,"validated":true,"input":input.id')
(R/'PanelProbe.swift').write_text(source)
cases=[]
for c in json.loads((F/'metadata-calibration-panel.json').read_text())['cases']:
 d=json.loads(Path(c['path']).read_text());cases.append(dict(c,chunk=d['rows'],blocks=8,warmups=2,workers=24,group='boundary'))
for name,scopes in [('Aotizhongxin-default',['eager','stream']),('energy-default',['eager','stream']),('energy',['stream'])]:
 p=Path('/private/tmp/swiftsci-csv-string-cost-20261022/inputs')/(name+'.json')
 if not p.exists():p=Path('/private/tmp/swiftsci-csv-cpu-profile-20261021/inputs')/(name+'.json')
 for scope in scopes:
  for policy in ['parallel','serial']:cases.append({'case':name,'path':str(p),'scope':scope,'policy':policy,'chunk':10000,'blocks':2,'warmups':1,'workers':8,'group':'reference'})
for c in cases:
 d=json.loads(Path(c['path']).read_text());assert h(Path(d['path']))==d.get('source_sha256',d.get('sha256'))
plan={'source_head':'5d1f89a961106104757f2d8d0b8faba79487d100','baseline':'f9a99ce54c77909bdd6f95fadd5fa3b5d15490f2','cases':cases,'hypotheses':[{'rank':1,'prediction':'Shared immutable null tables keep same-source namespace and same-implementation CPU controls within 10 percent across boundary and reference reads.'},{'rank':2,'prediction':'Admitted prefix decoding reduces CPU when non-null field prefixes reject tokens, while high-null inputs remain within the existing CPU review limit.'},{'rank':3,'prediction':'Standalone candidate peak RSS stays within 5 percent plus 8 MiB of cleanup, with an identical-binary memory control passing in both directions.'}],'criteria':{'cpu':'Median worker paired ratio, candidate divided by cleanup. Review increases above 10 percent. Same-source and same-implementation controls are two-sided 10 percent. Native global hashing, one immutable shared Set, native scheduling.','memory':'Fresh standalone processes. 8 workers per label per case. Identical cleanup/twin binary, candidate actual-head binary. Native hash setup independent. Review median peak RSS above 5 percent plus 8 MiB; identical-binary control is two-sided. CPU from this stage is recorded, not a causal source-regression verdict.','validation':'Exact public API outputs, independent native types/values/null/order digests outside timing before and after each paired worker; row count on every timed read. Standalone memory capture precedes validation.','scope':'All 26 previous prospective boundary combinations, plus both policies and scopes for Aotizhongxin-default and full household-energy default tokens. Original two-token household stream retained as specialization control.','conditions':'AC power, sequential workers, no task build/test/profiler overlaps. No fixed hashing, worker caps, outlier deletion, changed tolerances, or dataset-specific production changes.','limits':'Aliases change linked code layout. Shared-process peak memory is not attribution. No production changes or promotion solely from these diagnostic modules.'}}
(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('panel prepared;',len(cases),'cases;',sum(c['workers'] for c in cases),'planned paired workers')
