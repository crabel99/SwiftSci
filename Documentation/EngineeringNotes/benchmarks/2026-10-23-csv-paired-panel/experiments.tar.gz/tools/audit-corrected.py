from pathlib import Path
from collections import Counter
import json,statistics as st,sys,hashlib
R=Path(__file__).resolve().parent
results=[];fingerprints=[];total=0
for stage in ['corrected-paired','corrected-table-control','corrected-reverse-control']:
 D=R/stage;rows=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()]
 summaries=json.loads((D/'summary.json').read_text());decision=json.loads((D/'decision.json').read_text())
 assert len(rows)==(180 if stage=='corrected-paired' else 360)
 keys=[]
 for w in rows:
  mode=w.get('table_mode','shared');keys.append((w['input'],w['policy'],mode,w['worker']))
  assert w['validated'] and len(w['samples'])==96
  assert len({w['input']})==1
  counts=Counter((s['comparison'],s['label']) for s in w['samples']);assert set(counts.values())=={16} and len(counts)==6
  for comp in ['same','namespace','change']:
   for block in range(8):
    samples=[s for s in w['samples'] if s['comparison']==comp and s['block']==block]
    assert [s['position'] for s in samples]==list(range(4))
    assert [s['label'] for s in samples] in [['A','B','B','A'],['B','A','A','B']]
    assert all(s['cpu_ns']>0 and s['elapsed_ns']>0 for s in samples)
    assert all(s['implementation']=='actual' for s in samples if comp=='same')
  if stage!='corrected-paired' and mode=='shared':assert all(w['table_iteration_orders_match'])
  fingerprints.append(tuple(w['native_hash_fingerprint']))
 assert len(keys)==len(set(keys))
 for s in summaries:
  ws=[w for w in rows if w['input']==s['input'] and w['policy']==s['policy'] and w.get('table_mode','shared')==s.get('table_mode','shared')];assert len(ws)==60
  ratios=[]
  for w in ws:
   a=[x['cpu_ns'] for x in w['samples'] if x['comparison']==s['comparison'] and x['label']=='A']
   b=[x['cpu_ns'] for x in w['samples'] if x['comparison']==s['comparison'] and x['label']=='B']
   if stage=='corrected-reverse-control' and s['comparison']=='change':a,b=b,a
   ratios.append(st.median(a)/st.median(b))
  ratio=st.median(ratios);assert abs(ratio-s['median_paired_cpu_ratio'])<1e-12
  assert s['cpu_review']==(abs(ratio-1)>0.10 if s['comparison']!='change' else ratio>1.10)
 for mode in sorted({s.get('table_mode','shared') for s in summaries}):
  xs=[s for s in summaries if s.get('table_mode','shared')==mode]
  flags=[s for s in xs if s['cpu_review']]
  quality=not any(s['cpu_review'] for s in xs if s['comparison']!='change')
  results.append({'stage':stage,'mode':mode,'workers':len([w for w in rows if w.get('table_mode','shared')==mode]),'quality_passed':quality,'flag_count':len(flags),'flags':[{'input':s['input'],'policy':s['policy'],'comparison':s['comparison'],'ratio':s['median_paired_cpu_ratio']} for s in flags]})
 assert decision['quality_passed']==(not any(s['cpu_review'] for s in summaries if s['comparison']!='change'))
 total+=len(rows)
assert len(set(fingerprints))==total
out={'validated_workers':total,'timed_reads':total*96,'warmup_reads':total*24,'full_native_validation_streams':total*6,'unique_native_hash_fingerprints':len(set(fingerprints)),'results':results,'all_raw_summaries_recomputed':True,'promotion_allowed':False}
(R/'corrected-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
if '--require-all-quality' in sys.argv and not all(r['quality_passed'] for r in results):raise SystemExit(1)
