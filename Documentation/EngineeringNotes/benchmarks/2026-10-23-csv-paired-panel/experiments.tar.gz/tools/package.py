from pathlib import Path
import json,gzip,hashlib,tarfile,shutil,re,subprocess
R=Path(__file__).resolve().parent;Q=Path('/private/tmp/swiftsci-csv-paired-read-20261023');N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-paired-panel'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((R/'audit.json').read_text());D.mkdir(exist_ok=False)
roots=['corrected-paired','corrected-table-control','corrected-reverse-control','expanded-boundary','expanded-reference','standalone-memory'];index=[]
for stage in roots:
 T=D/stage;T.mkdir()
 for name in ['plan.json','decision.json']:shutil.copy2(R/stage/name,T/name)
 xs=json.loads((R/stage/'summary.json').read_text());(T/'summary.json').write_text(json.dumps([{k:v for k,v in x.items() if k!='observations'} for x in xs],indent=2)+'\n')
 raw=(R/stage/'workers.jsonl').read_bytes()
 with gzip.GzipFile(filename=str(T/'workers.jsonl.gz'),mode='wb',mtime=0) as f:f.write(raw)
 assert gzip.decompress((T/'workers.jsonl.gz').read_bytes())==raw
 index.append({'stage':stage,'workers':len(raw.splitlines()),'uncompressed_sha256':hashlib.sha256(raw).hexdigest()})
for name in ['plan.json','audit.json','corrected-audit.json','build-correction.json','corrected-paired-build.json','corrected-table-control-build.json','corrected-reverse-control-build.json','panel-build.json','reproduction-smoke.json']:
 shutil.copy2(R/name,D/name)
(D/'worker-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(D/'experiments.tar.gz','w:gz') as tar:
 for pat in ['*.py','*.swift','*.log','*.stdout','*.stderr','original-*.json']:
  for p in sorted(R.glob(pat)):tar.add(p,arcname='tools/'+p.name)
 for p in [Q/'build.json',Q/'build/baseline/receipt.json',Q/'build/clone/receipt.json']:
  tar.add(p,arcname='prior-build/'+str(p.relative_to(Q)))
 # Preserve the original probe clients used by corrected repeats and standalone memory.
 for name in ['PairedProbe.swift','PairedTableProbe.swift','ReverseProbe.swift']:
  tar.add(Q/name,arcname='original-probes/'+name)
 F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022')
 for label in ['cleanup','metadata']:
  root=F/'build'/label
  for name in ['build.json','StreamProbe.build.json']:
   rec=json.loads((root/name).read_text());tar.add(root/name,arcname='standalone/'+label+'/'+name)
   cmd=rec.get('command',rec.get('commands',[])[-1] if rec.get('commands') else [])
   for source in cmd:
    if source.endswith('/ResourceProbe.swift') or source.endswith('/StreamProbe.swift'):
     tar.add(source,arcname='standalone/'+label+'/'+Path(source).name)
 # Exact boundary inputs are small generated fixtures; full reference files stay with their existing owner.
 for c in json.loads((R/'plan.json').read_text())['cases']:
  if c['group']!='boundary':continue
  p=Path(c['path']);csv=Path(json.loads(p.read_text())['path'])
  if p.name not in getattr(tar,'added_inputs',set()):
   tar.add(p,arcname='inputs/'+p.name);tar.add(csv,arcname='inputs/'+csv.name)
   tar.added_inputs=getattr(tar,'added_inputs',set())|{p.name}
 # Small frozen module snapshots make the alias builds inspectable without the current worktree.
 variants=json.loads((Q/'variants.json').read_text())
 for label in ['baseline','clone']:
  src=Path(variants[label]['path'])
  for p in sorted((src/'Sources/SwiftDataFrame').rglob('*.swift')):tar.add(p,arcname='snapshots/'+label+'/'+str(p.relative_to(src)))
contracts={}
for c in json.loads((R/'plan.json').read_text())['cases']:
 if c['case'] not in contracts:contracts[c['case']]=json.loads(Path(c['path']).read_text())
(D/'input-contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
boundary=json.loads((R/'expanded-boundary/summary.json').read_text());refs=json.loads((R/'expanded-reference/summary.json').read_text());memory=json.loads((R/'standalone-memory/summary.json').read_text())
lines=['# Matched CSV resource results','','CPU ratios use one immutable shared native null-token Set and correctly matched compiled interfaces and objects. Each worker contributes one paired ratio from its two read medians. CPU is process user plus system time. Elapsed time is separate. Memory is from independent fresh standalone processes and excludes validation from the captured peak.','','| Reference and scope | Policy | Cleanup CPU ms | Candidate CPU ms | Paired CPU change | Bootstrap 95% interval | Paired elapsed change | Cleanup / candidate peak MiB |','|---|---|---:|---:|---:|---|---:|---|']
for s in refs:
 if s['comparison']!='change':continue
 def mem(label):return next(x['median_peak_bytes']/2**20 for x in memory if x['label']==label and all(x[k]==s[k] for k in ['case','scope','policy']))
 ci=s['bootstrap_95_cpu_ratio'];lines.append(f"| {s['case']}, {s['scope']} | {s['policy']} | {s['b_median_cpu_ns']/1e6:.3f} | {s['a_median_cpu_ns']/1e6:.3f} | {(s['median_paired_cpu_ratio']-1)*100:+.2f}% | {(ci[0]-1)*100:+.2f}% to {(ci[1]-1)*100:+.2f}% | {(s['median_paired_elapsed_ratio']-1)*100:+.2f}% | {mem('cleanup'):.2f} / {mem('candidate'):.2f} |")
lines+=['','CPU columns are separate medians of worker medians. Their quotient need not equal the median paired ratio used for review. Each reference combination has eight independent workers and two timed blocks per comparison after one warmup block. Aotizhongxin and household-energy files are full inputs. Default and original two-token null configurations remain distinct.','','## Preparation boundaries','','Each boundary combination has 24 independent workers and eight timed blocks per comparison after two warmup blocks. Chunk size equals selected rows in streaming boundary cases; reference streams use 10,000 rows. The reader internal bound is unchanged.','','| Rows and injected-null percent | Scope | Policy | Paired CPU change | Paired elapsed change | Candidate CPU flag |','|---|---|---|---:|---:|---|']
for s in boundary:
 if s['comparison']!='change':continue
 name=s['case'].split('-rows-')[1].replace('-nulls-',', ')
 lines.append(f"| {name} | {s['scope']} | {s['policy']} | {(s['median_paired_cpu_ratio']-1)*100:+.2f}% | {(s['median_paired_elapsed_ratio']-1)*100:+.2f}% | {'flag' if s['cpu_review'] else 'within threshold'} |")
(D/'results.md').write_text('\n'.join(lines)+'\n')
change=[s for s in refs if s['comparison']=='change'];cpu=[(s['median_paired_cpu_ratio']-1)*100 for s in change]
maxmem=max(next(x['median_peak_bytes'] for x in memory if x['label']=='candidate' and all(x[k]==s[k] for k in ['case','scope','policy']))-s['median_peak_bytes'] for s in memory if s['label']=='cleanup')/2**20
flags=[f for r in audit['results'] for f in r['flags']]
quality=all(x['quality_passed'] for x in audit['results'])
readme=f'''# CSV boundaries, reference reads, and standalone memory

The corrected matched-interface panel completes 704 paired CPU workers and 864 fresh standalone memory workers. The independent audit records resource gates as **{'passed' if audit['expanded_resource_gates_passed'] else 'requiring review'}**, with {len(flags)} review flags. Full native outputs pass on every worker. These results compare cleanup `f9a99ce54c77909bdd6f95fadd5fa3b5d15490f2` with candidate `5d1f89a961106104757f2d8d0b8faba79487d100`.

Production source is unchanged. This is further qualification of the existing local CSV branch, not a new production optimization or a comparison with pandas or Polars. The broader earlier-parent results remain with [the previous resource study](../2026-10-22-csv-fallback-isolation/README.md).

## A diagnostic build error was corrected first

The eager extension exposed an import-order mistake in [the earlier paired study](../2026-10-23-csv-paired-reads/README.md). Its link commands searched a general dependency directory before the explicit reader-module directories. The compiler loaded a cached `SwiftDataFrame` interface while linking the candidate or cleanup object. The eager extension failed to link because that interface referenced an internal function not exported by the matched object.

The [correction record](build-correction.json) retains the failure and both module-loading paths. Corrected link commands put explicit modules first. Every new link emits a compiler module-loading log and asserts the paths of `SwiftDataFrame`, `CSVBaseline`, and `CSVClone`. This check is executable, so the lesson does not depend on another prose instruction. The standalone memory probes already prioritize their own modules, as their recorded commands confirm.

The earlier paired workers and their observed outputs remain preserved. Their performance interpretation is superseded by corrected repeats. All 900 controls were repeated before expansion, including the reciprocal binary that keeps cleanup's real module name. Shared-table candidate CPU stays within about 1.1% of cleanup on those targeted cases, and every corrected shared-table control passes.

Separate-table diagnostic comparisons still produce candidate CPU warnings in the recurring 3,392-row parallel case. Their same-source CPU-ratio distributions remain broad. They do not reproduce a matched-table source regression. The earlier 14.5% aggregate same-source warning is not a corrected-build qualification result and must not be reused as one. [Corrected controls](corrected-audit.json) and exact raw responses preserve that distinction.

## The expanded panel keeps the same constraints

All 26 prior boundary combinations remain in the panel. They include eager and streamed reads, both conversion policies, rows adjacent to prefix admission, and zero or high null injection. Another ten combinations use full Aotizhongxin air-quality data and full household-energy data. The original two-token household stream remains a specialization control alongside the default multi-token configuration.

The paired readers receive value copies of one immutable native Set without mutation. They use identical input bytes, schema, null tokens, row limits, and chunk sizes. Matching types, values, null positions, and row and column order are checked before and after timing. Every timed read checks its row count. Hashing and CPU scheduling remain native, and all runs require AC power. No observation is trimmed, worker budget capped, or tolerance relaxed.

Input files are warm from validation and warmup reads. Caller configuration is prepared outside the timed public API call. These results do not measure cold-disk startup.

Boundary combinations use 24 independent workers, two warmup blocks, and eight timed blocks per comparison. Reference combinations use eight independent workers, one warmup block, and two timed blocks. ABBA and BAAB blocks balance order; comparison order rotates between workers. Repeated reads within one worker are not independent samples. The unchanged CPU gate reviews candidate increases above 10%, and checks same-source and same-implementation controls in both directions.

## Resource results

The [complete table](results.md) keeps CPU, elapsed time, and independent peak memory separate. Across the ten reference combinations, paired median CPU changes range from {min(cpu):+.2f}% to {max(cpu):+.2f}%. Those configurations have different workloads, so that range is not an overall speedup or a weighted production average.

Peak memory comes from separate uninstrumented processes, using actual standalone cleanup and candidate objects and clients. Each case has eight workers per label. A second label runs the identical cleanup binary as a memory control. Peak RSS is captured before full-output validation. Eager output remains held for the capture; streaming consumes and releases chunks without consumer retention. The maximum candidate-minus-cleanup median peak difference across all 36 combinations is {maxmem:+.2f} MiB.

The memory gate remains 5% plus 8 MiB, with a two-sided identical-binary control. RSS is a process high-water mark, not an allocation count. CPU from the independent-process memory stage is retained as diagnostic data and is not substituted for the paired CPU verdict.

## Validation and disposition

The [independent audit](audit.json) recomputes all expanded resource flags from raw observations, checks counts and balanced order, and verifies module-loading logs and binary hashes. There are {audit['total_new_worker_responses']:,} new worker responses including corrected repeats. The 704 expanded paired workers complete 61,824 timed public reads and 4,224 full native validation reads. Standalone workers also validate every output against the independent contract.

The 394-test Release, Debug, and Address Sanitizer results remain with the actual head's earlier verification. No production source or compiled reader object changed during this follow-up, so those suites were not repeated. These CSV checks are not full numerical certification. Our builds finish before associated timing; unrelated host activity remains uncontrolled.

Module aliases and a combined linked client remain limits of the paired CPU method. Native table setup includes hashing and allocation layout. These experiments do not prove a particular hash-bucket, cache, SRAM, allocator, or scheduler mechanism. Prior flags remain historical observations, and the flawed-interface study remains visibly marked.

The work remains local. Nothing is pushed or submitted. The corrected resource evidence supports review of this candidate under the stated cases and controls; it does not establish that CSV optimization is exhausted.

- [Resource results](results.md) and [raw-data audit](audit.json)
- [Frozen case plan and hypotheses](plan.json)
- [Module-import correction](build-correction.json) and [verified panel build](panel-build.json)
- [Boundary decision](expanded-boundary/decision.json), [reference decision](expanded-reference/decision.json), and [memory decision](standalone-memory/decision.json)
- [Input contracts](input-contracts.json) and [worker counts and uncompressed hashes](worker-index.json)
- [Controllers, probe, source snapshots, generated boundary inputs, and build logs](experiments.tar.gz)
- [Artifact hashes](artifact-sha256.json)

The archive preserves recorded paths and pinned module dependencies. Full reference datasets stay with their existing owner and are identified by immutable hashes in the contracts. Redirect declared scratch and dependency paths when reproducing on another machine. Raw worker JSONL is stored as exact gzip streams. No binaries or build caches are committed.
'''
(D/'README.md').write_text(readme)
# Preserve the old results, but mark their interpretation visibly superseded.
old=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-paired-reads/README.md';s=old.read_text();pos=s.index('\n\n')+2
notice='Correction, 2026-10-23: A follow-up found that these diagnostic link commands could load a cached module interface ahead of the interface matching the linked reader object. The original observations remain preserved. Use [the corrected repeats and expanded qualification](../2026-10-23-csv-paired-panel/README.md) for actual-head performance conclusions. The earlier aggregate 14.5% control warning is not a corrected-build qualification result.\n\n'
old.write_text(s[:pos]+notice+s[pos:]);m=old.parent/'artifact-sha256.json';d=json.loads(m.read_text());d['README.md']=h(old);m.write_text(json.dumps(d,indent=2)+'\n')
for p in D.rglob('*.md'):
 text=p.read_text();assert '\u2014' not in text and '\u2013' not in text
 for target in re.findall(r'\]\(([^)]+)\)',text):
  if not target.startswith(('http:','https:','#')) and target!='artifact-sha256.json':assert (p.parent/target).exists(),target
manifest={str(p.relative_to(D)):h(p) for p in sorted(D.rglob('*')) if p.is_file()};(D/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(D);print(sum(p.stat().st_size for p in D.rglob('*') if p.is_file()),'bytes')
