from pathlib import Path
from collections import Counter
import json,statistics as st,hashlib,sys,subprocess
R=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((R/'plan.json').read_text());results=[];all_rows=[]
for stage in ['expanded-boundary','expanded-reference']:
 D=R/stage;rows=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()];summaries=json.loads((D/'summary.json').read_text());stageplan=json.loads((D/'plan.json').read_text())
 assert stageplan['source_plan_sha256']==h(R/'plan.json')
 assert stageplan['controller_sha256']==h(R/'run-panel.py')
 assert len(rows)==sum(c['workers'] for c in stageplan['cases'])
 keys=[(w['case'],w['scope'],w['policy'],w['worker']) for w in rows];assert len(keys)==len(set(keys))
 for w in rows:
  c=next(c for c in stageplan['cases'] if all(c[k]==w[k] for k in ['case','scope','policy']))
  assert w['validated'] and len(w['samples'])==12*c['blocks']
  assert w['chunk_size']==c['chunk'] and w['warmups']==c['warmups'] and w['blocks']==c['blocks']
  counts=Counter((s['comparison'],s['label']) for s in w['samples']);assert len(counts)==6 and set(counts.values())=={2*c['blocks']}
  for comp in ['same','namespace','change']:
   for block in range(c['blocks']):
    ss=[s for s in w['samples'] if s['comparison']==comp and s['block']==block]
    assert [s['position'] for s in ss]==list(range(4))
    assert [s['label'] for s in ss] in [['A','B','B','A'],['B','A','A','B']]
    assert all(s['cpu_ns']>0 and s['elapsed_ns']>0 for s in ss)
 for s in summaries:
  ws=[w for w in rows if all(w[k]==s[k] for k in ['case','scope','policy'])];assert len(ws)==s['workers']
  ratios=[]
  for w in ws:
   a=[x['cpu_ns'] for x in w['samples'] if x['comparison']==s['comparison'] and x['label']=='A'];b=[x['cpu_ns'] for x in w['samples'] if x['comparison']==s['comparison'] and x['label']=='B']
   ratios.append(st.median(a)/st.median(b))
  ratio=st.median(ratios);assert abs(ratio-s['median_paired_cpu_ratio'])<1e-12
  assert s['cpu_review']==(abs(ratio-1)>0.10 if s['comparison']!='change' else ratio>1.10)
 flags=[s for s in summaries if s['cpu_review']]
 results.append({'stage':stage,'validated_workers':len(rows),'timed_reads':sum(len(r['samples']) for r in rows),'warmup_reads':sum(12*r['warmups'] for r in rows),'full_native_validation_reads':6*len(rows),'quality_passed':not any(s['cpu_review'] for s in summaries if s['comparison']!='change'),'candidate_cpu_passed':not any(s['cpu_review'] for s in summaries if s['comparison']=='change'),'flags':flags})
 all_rows.extend(rows)
D=R/'standalone-memory';rows=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()];summaries=json.loads((D/'summary.json').read_text());sp=json.loads((D/'plan.json').read_text())
assert sp['source_plan_sha256']==h(R/'plan.json') and sp['controller_sha256']==h(R/'run-memory.py')
assert len(rows)==len(plan['cases'])*24
assert len({tuple(w[k] for k in ['case','scope','policy','label','worker']) for w in rows})==len(rows)
assert all(w['validated'] for w in rows)
for s in summaries:
 ws=[w for w in rows if all(w[k]==s[k] for k in ['case','scope','policy','label'])];assert len(ws)==8
 peak='process_peak_held_bytes' if s['scope']=='eager' else 'peak_after_bytes'
 values=[w['samples'][0][peak] if s['scope']=='eager' else w[peak] for w in ws]
 assert st.median(values)==s['median_peak_bytes']
flags=[]
for c in plan['cases']:
 xs={s['label']:s for s in summaries if all(s[k]==c[k] for k in ['case','scope','policy'])};b=xs['cleanup']['median_peak_bytes']
 for label in ['candidate','twin']:
  v=xs[label]['median_peak_bytes'];delta=v-b
  if delta>b*.05+8*2**20 or (label=='twin' and -delta>v*.05+8*2**20):flags.append({k:c[k] for k in ['case','scope','policy']}|{'label':label,'delta_bytes':delta})
results.append({'stage':'standalone-memory','validated_workers':len(rows),'quality_passed':not any(f['label']=='twin' for f in flags),'candidate_memory_passed':not any(f['label']=='candidate' for f in flags),'flags':flags})
corrected=json.loads((R/'corrected-audit.json').read_text());assert corrected['validated_workers']==900
# The deliberately independent table stage may still warn. Its flags remain diagnostic.
assert all(x['quality_passed'] for x in corrected['results'] if x['mode']=='shared')
fingerprints=[tuple(w['native_hash_fingerprint']) for w in all_rows];assert len(fingerprints)==len(set(fingerprints))
for rec in ['corrected-paired','corrected-table-control','corrected-reverse-control','panel']:
 d=json.loads((R/(rec+'-build.json')).read_text());assert h(R/(rec+'.log'))==d['module_loading_log_sha256'];assert len(d['module_paths_verified'])==3
 binary=Path(d['command'][d['command'].index('-o')+1]);assert h(binary)==d['binary_sha256']
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==plan['source_head'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
passed=all(x['quality_passed'] and x.get('candidate_cpu_passed',True) and x.get('candidate_memory_passed',True) for x in results)
out={'results':results,'corrected_control_workers':900,'expanded_native_fingerprint_count':len(set(fingerprints)),'total_new_worker_responses':sum(x['validated_workers'] for x in results)+900,'all_new_summaries_recomputed':True,'expanded_resource_gates_passed':passed,'production_changed':False,'promotion_allowed':False,'limits':'Aliases and compiled-client context remain diagnostic limitations. No push or PR authorization inferred. Prior warnings and the prior module-import mistake remain recorded.'}
(R/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if '--require-resources' in sys.argv and not passed:raise SystemExit(1)
