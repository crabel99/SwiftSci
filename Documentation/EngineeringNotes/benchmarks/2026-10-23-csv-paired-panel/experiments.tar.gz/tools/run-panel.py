from pathlib import Path
import json,subprocess,statistics as st,hashlib,sys,time,random
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,PRODUCTION_MODE
from runner import power_state,environment,verify_uninstrumented
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
group=sys.argv[1];assert group in ['boundary','reference'];plan=json.loads((R/'plan.json').read_text());cases=[c for c in plan['cases'] if c['group']==group]
D=R/('expanded-'+group);D.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==plan['source_head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
verify_uninstrumented(R/'PanelProbe');receipt=json.loads((R/'panel-build.json').read_text());assert h(R/'PanelProbe')==receipt['binary_sha256']
assert len(receipt['module_paths_verified'])==3
for c in cases:
 d=json.loads(Path(c['path']).read_text());assert h(Path(d['path']))==d.get('source_sha256',d.get('sha256'))
(D/'plan.json').write_text(json.dumps({'cases':cases,'source_plan_sha256':h(R/'plan.json'),'build_receipt_sha256':h(R/'panel-build.json'),'controller_sha256':h(Path(__file__)),'environment':environment(),'power':power_state(),'started_unix':time.time()},indent=2)+'\n')
rs=[]
with (D/'workers.jsonl').open('x') as f:
 for rnd in range(max(c['workers'] for c in cases)):
  order=cases[rnd%len(cases):]+cases[:rnd%len(cases)]
  if rnd%2:order=list(reversed(order))
  for c in order:
   if rnd>=c['workers']:continue
   assert power_state()['source']=='AC';env=worker_environment(PRODUCTION_MODE);assert not env.get('SWIFT_DETERMINISTIC_HASHING')
   cmd=[str(R/'PanelProbe'),c['path'],c['policy'],str(rnd%6),c['scope'],str(c['chunk']),str(c['blocks']),str(c['warmups'])]
   p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=300);assert p.returncode==0,(cmd,p.stderr[-4000:])
   d=json.loads(p.stdout);assert d['validated'] and len(d['samples'])==12*c['blocks'];d.update(worker=rnd,case=c['case'],group=group)
   rs.append(d);f.write(json.dumps(d)+'\n');f.flush()
   if group=='reference':print(rnd+1,c['case'],c['scope'],c['policy'],'validated',flush=True)
  if group=='boundary':print(rnd+1,'boundary workers per case complete',flush=True)
summary=[]
for c in cases:
 ws=[w for w in rs if all(w[k]==c[k] for k in ['case','scope','policy'])];assert len(ws)==c['workers']
 for comp in ['same','namespace','change']:
  ratios=[];elapsed=[];ac=[];bc=[];mean=[]
  for w in ws:
   a=[x for x in w['samples'] if x['comparison']==comp and x['label']=='A'];b=[x for x in w['samples'] if x['comparison']==comp and x['label']=='B']
   assert len(a)==len(b)==2*c['blocks']
   aa=st.median(x['cpu_ns'] for x in a);bb=st.median(x['cpu_ns'] for x in b)
   ratios.append(aa/bb);ac.append(aa);bc.append(bb);elapsed.append(st.median(x['elapsed_ns'] for x in a)/st.median(x['elapsed_ns'] for x in b));mean.append(st.mean(x['cpu_ns'] for x in a)/st.mean(x['cpu_ns'] for x in b))
  ratio=st.median(ratios);rng=random.Random(20261023);boot=sorted(st.median(rng.choices(ratios,k=len(ratios))) for _ in range(5000))
  summary.append({k:c[k] for k in ['case','scope','policy','group']}|{'comparison':comp,'workers':len(ws),'median_paired_cpu_ratio':ratio,'bootstrap_95_cpu_ratio':[boot[124],boot[4874]],'median_paired_elapsed_ratio':st.median(elapsed),'median_paired_mean_cpu_ratio':st.median(mean),'a_median_cpu_ns':st.median(ac),'b_median_cpu_ns':st.median(bc),'cpu_review':abs(ratio-1)>0.10 if comp!='change' else ratio>1.10})
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
flags=[s for s in summary if s['cpu_review']]
(D/'decision.json').write_text(json.dumps({'workers':len(rs),'timed_reads':sum(len(r['samples']) for r in rs),'quality_passed':not any(x['cpu_review'] for x in summary if x['comparison']!='change'),'candidate_cpu_passed':not any(x['cpu_review'] for x in summary if x['comparison']=='change'),'flags':flags,'promotion_allowed':False,'completed_unix':time.time()},indent=2)+'\n')
print(group,len(rs),'validated workers;',len(flags),'CPU review flags',flush=True)
for s in summary:
 if s['comparison']=='change' or s['cpu_review']:print(s['case'],s['scope'],s['policy'],s['comparison'],round((s['median_paired_cpu_ratio']-1)*100,2),'percent CPU',flush=True)
