from pathlib import Path
import json,subprocess,hashlib,re,shutil
R=Path(__file__).resolve().parent;Q=Path('/private/tmp/swiftsci-csv-paired-read-20261023')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P='/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/Release'
if (R/'build.log').exists() and not (R/'build-initial-failure.log').exists():shutil.copy2(R/'build.log',R/'build-initial-failure.log')
def corrected(cmd):
 i=cmd.index(P);assert cmd[i-1]=='-I';del cmd[i-1:i+1];return cmd+['-I',P,'-Rmodule-loading']
def run(label,cmd,expected):
 with (R/(label+'.log')).open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'.log')).read_text()[-3000:]);raise SystemExit(p.returncode)
 log=(R/(label+'.log')).read_text();loaded={m.group(1):m.group(2) for m in re.finditer(r"remark: loaded module '([^']+)'; source: '([^']+)'",log)}
 for name,path in expected.items():assert loaded.get(name)==path,(name,loaded.get(name),path)
 binary=Path(cmd[cmd.index('-o')+1]);receipt={'command':cmd,'binary_sha256':h(binary),'module_paths_verified':{name:loaded[name] for name in expected},'module_loading_log_sha256':h(R/(label+'.log'))}
 (R/(label+'-build.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,'loaded explicit modules',flush=True)
expected={'SwiftDataFrame':'/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata/SwiftDataFrame.swiftmodule','CSVBaseline':str(Q/'build/baseline/CSVBaseline.swiftmodule'),'CSVClone':str(Q/'build/clone/CSVClone.swiftmodule')}
for oldrec,oldprobe,newprobe,label,reverse in [('build.json','PairedProbe','CorrectedPairedProbe','corrected-paired',False),('table-build.json','PairedTableProbe','CorrectedTableProbe','corrected-table-control',False),('reverse-build.json','ReverseProbe','CorrectedReverseProbe','corrected-reverse-control',True)]:
 cmd=json.loads((Q/oldrec).read_text())['link_command'];cmd=[a.replace(str(Q/oldprobe),str(R/newprobe)) if a==str(Q/oldprobe) else a for a in cmd]
 ex=dict(expected)
 if reverse:ex['SwiftDataFrame']=ex['SwiftDataFrame'].replace('/metadata/','/cleanup/')
 run(label,corrected(cmd),ex)
old=json.loads((Q/'build.json').read_text())['link_command'];cmd=[a.replace(str(Q/'PairedProbe.swift'),str(R/'PanelProbe.swift')).replace(str(Q/'PairedProbe'),str(R/'PanelProbe')) for a in old]
run('panel',corrected(cmd),expected)
# Trace the old precedence separately without replacing any original binary.
cmd=json.loads((Q/'build.json').read_text())['link_command'];cmd=[str(R/'OldOrderProbe') if a==str(Q/'PairedProbe') else a for a in cmd]+['-Rmodule-loading']
with (R/'old-module-order.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
log=(R/'old-module-order.log').read_text();m=re.search(r"remark: loaded module 'SwiftDataFrame'; source: '([^']+)'",log);assert m and m.group(1).startswith(P)
correction={'problem':'Dependency import directory preceded explicit reader modules in the prior paired link commands. Compiler loaded cached SwiftDataFrame interface while linking a different actual-head object. Eager extension exposed undefined internal symbols.','previous_import':m.group(1),'corrected_import':expected['SwiftDataFrame'],'prior_notes_commit':'3cdea357c8','effect':'Earlier output checks remain factual, but the earlier paired timing interpretation is not qualified as an actual-head client. Repeat all controls with matched module interfaces before extending the panel.','prevention':'Every new diagnostic link emits a compiler module-loading log and asserts all three reader interface paths match the linked module objects.','production_source_changed':False}
(R/'build-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
for src,out,stage,probe,plan in [('run.py','repeat-paired.py','paired','PairedProbe','plan.json'),('run-table-control.py','repeat-tables.py','table-control','PairedTableProbe','table-plan.json'),('run-reverse.py','repeat-reverse.py','reverse-control','ReverseProbe','reverse-plan.json')]:
 s=(Q/src).read_text();newstage='corrected-'+stage;newprobe={'paired':'CorrectedPairedProbe','table-control':'CorrectedTableProbe','reverse-control':'CorrectedReverseProbe'}[stage]
 s=s.replace("D=R/'"+stage+"'","D=R/'"+newstage+"'").replace("R/'"+probe+"'","R/'"+newprobe+"'")
 rec={'paired':'build.json','table-control':'table-build.json','reverse-control':'reverse-build.json'}[stage]
 s=s.replace("R/'"+rec+"'","R/'"+newstage+"-build.json'")
 s=s.replace("R/'"+plan+"'","R/'original-"+plan+"'")
 shutil.copy2(Q/plan,R/('original-'+plan));(R/out).write_text(s)
s=(Q/'audit.py').read_text()
for old in ['reverse-control','table-control','paired']:s=s.replace("'"+old+"'","'corrected-"+old+"'")
s=s.replace("R/'audit.json'","R/'corrected-audit.json'")
(R/'audit-corrected.py').write_text(s)
# Preserve the frozen expanded plan from prepare.py without rebuilding its flawed command.
prep=(R/'prepare.py').read_text();tail=prep[prep.index('cases=[]'):];exec(tail,{'R':R,'F':Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022'),'Path':Path,'json':json,'h':h})
