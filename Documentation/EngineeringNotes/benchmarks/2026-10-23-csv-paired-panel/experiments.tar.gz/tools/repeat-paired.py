from pathlib import Path
import json,subprocess,statistics as st,hashlib,sys,time,random
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,PRODUCTION_MODE
from runner import power_state,environment,verify_uninstrumented
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[{'path':'/private/tmp/swiftsci-csv-prefix-selection-20261022/crossover-inputs/long-keys-64-rows-3392-nulls-0.json','policy':'parallel'},{'path':'/private/tmp/swiftsci-csv-prefix-selection-20261022/crossover-inputs/long-keys-64-rows-3392-nulls-0.json','policy':'serial'},{'path':'/private/tmp/swiftsci-csv-fallback-isolation-20261022/metadata-boundary-inputs/long-keys-64-rows-3456-nulls-0.json','policy':'parallel'}]
D=R/'corrected-paired';D.mkdir(exist_ok=False)
verify_uninstrumented(R/'CorrectedPairedProbe');receipt=json.loads((R/'corrected-paired-build.json').read_text());assert h(R/'CorrectedPairedProbe')==receipt['binary_sha256']
for c in cases:
 inp=json.loads(Path(c['path']).read_text());assert h(Path(inp['path']))==inp['source_sha256'];c['id']=inp['id']
(D/'plan.json').write_text(json.dumps({'cases':cases,'workers_per_case':60,'source_plan_sha256':h(R/'original-plan.json'),'build_receipt_sha256':h(R/'corrected-paired-build.json'),'controller_sha256':h(Path(__file__)),'environment':environment(),'power':power_state(),'started_unix':time.time()},indent=2)+'\n')
rs=[]
with (D/'workers.jsonl').open('x') as f:
 for rnd in range(60):
  for i in range(3):
   c=cases[(rnd+i)%3];assert power_state()['source']=='AC'
   env=worker_environment(PRODUCTION_MODE);assert not env.get('SWIFT_DETERMINISTIC_HASHING')
   p=subprocess.run([str(R/'CorrectedPairedProbe'),c['path'],c['policy'],str(rnd%6)],env=env,capture_output=True,text=True,timeout=90)
   assert p.returncode==0,p.stderr
   r=json.loads(p.stdout);assert r['validated'] and len(r['samples'])==96
   r['worker']=rnd;rs.append(r);f.write(json.dumps(r)+'\n');f.flush()
  if rnd%10==9:print(rnd+1,'workers per case complete',flush=True)
summary=[]
for c in cases:
 workers=[r for r in rs if r['input']==c['id'] and r['policy']==c['policy']]
 for comp in ['same','namespace','change']:
  observations=[]
  for w in workers:
   a=[x for x in w['samples'] if x['comparison']==comp and x['label']=='A'];b=[x for x in w['samples'] if x['comparison']==comp and x['label']=='B']
   observations.append({'worker':w['worker'],'ratio_cpu':st.median(x['cpu_ns'] for x in a)/st.median(x['cpu_ns'] for x in b),'a_cpu_ns':st.median(x['cpu_ns'] for x in a),'b_cpu_ns':st.median(x['cpu_ns'] for x in b),'ratio_elapsed':st.median(x['elapsed_ns'] for x in a)/st.median(x['elapsed_ns'] for x in b),'mean_ratio_cpu':st.mean(x['cpu_ns'] for x in a)/st.mean(x['cpu_ns'] for x in b)})
  ratio=st.median(x['ratio_cpu'] for x in observations)
  rng=random.Random(20261023);boot=sorted(st.median(rng.choices([x['ratio_cpu'] for x in observations],k=len(observations))) for _ in range(5000))
  summary.append({'input':c['id'],'policy':c['policy'],'comparison':comp,'workers':len(workers),'median_paired_cpu_ratio':ratio,'median_ratio_bootstrap_95':[boot[124],boot[4874]],'median_paired_elapsed_ratio':st.median(x['ratio_elapsed'] for x in observations),'median_paired_mean_cpu_ratio':st.median(x['mean_ratio_cpu'] for x in observations),'a_median_cpu_ns':st.median(x['a_cpu_ns'] for x in observations),'b_median_cpu_ns':st.median(x['b_cpu_ns'] for x in observations),'cpu_review':abs(ratio-1)>0.10 if comp!='change' else ratio>1.10,'observations':observations})
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
flags=[{k:v for k,v in x.items() if k!='observations'} for x in summary if x['cpu_review']]
quality=not any(x['cpu_review'] for x in summary if x['comparison']!='change')
(D/'decision.json').write_text(json.dumps({'validated_workers':len(rs),'timed_reads':sum(len(r['samples']) for r in rs),'quality_passed':quality,'cpu_flags':flags,'promotion_allowed':False,'reason':'Diagnostic module aliases and shared-process memory limits do not qualify production. Earlier native flags remain recorded.','completed_unix':time.time()},indent=2)+'\n')
for x in summary:print(x['input'],x['policy'],x['comparison'],round((x['median_paired_cpu_ratio']-1)*100,2),'percent CPU', 'FLAG' if x['cpu_review'] else 'within review threshold',flush=True)
