from pathlib import Path
R=Path(__file__).resolve().parent
source=Path('/private/tmp/swiftsci-csv-prefix-selection-20261022/ResourceProbe.swift').read_text().split('@MainActor @main')[0]
source+=r'''
func fingerprint(_ df: DataFrame) -> [String: Any] {
    var columns = [[String: Any]]()
    for name in df.columnNames {
        var d = Digest()
        let type = df.dtypes[name]!.description
        switch type {
        case "Double":
            let c = df[column: name, as: Double.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1.bitPattern) } }
        case "Int64":
            let c = df[column: name, as: Int64.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1) } }
        case "String":
            let c = df[column: name, as: String.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { digest, value in
                digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
            } }
        default: preconditionFailure("Unsupported fixture type")
        }
        columns.append(["name": name, "type": type, "nulls": d.nulls, "sha256": d.finish()])
    }
    return ["rows": df.rowCount, "columns": columns]
}
@MainActor @main struct WorkflowProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: args[0])))
        let workflow = args[1], policy = args[2]
        var options = CSVReadOptions()
        options.delimiter = Character(input.delimiter); options.nullValues = Set(input.null_tokens)
        options.columnConversionMode = policy == "serial" ? .serial : .parallel
        let mapping: [String: ColumnDType] = ["String": .utf8, "Double": .float64, "Int64": .int64]
        options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names, input.types).map { ($0.0, mapping[$0.1]!) })
        let numeric = zip(input.names, input.types).filter { $0.1 == "Double" || $0.1 == "Int64" }.map { $0.0 }
        let chosen = input.id.hasPrefix("energy") ? "Global_active_power" : "PM2.5"
        let key = input.id.hasPrefix("energy") ? "Date" : "station"
        let labels = input.id.hasPrefix("energy") ? ["16/12/2006", "17/12/2006"] : ["Aotizhongxin"]
        let lookup = try DataFrame(columns: [TypedColumn(name: key, values: labels),
                                             TypedColumn<Int64>(name: "lookup_code", values: labels.indices.map(Int64.init))])
        let h0=heap(),r0=resident(),p0=peak(),c0=cpu(),t0=DispatchTime.now().uptimeNanoseconds
        var output: DataFrame? = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)
        let cRead=cpu(),tRead=DispatchTime.now().uptimeNanoseconds
        var matrix: PreparedNumericMatrix?
        var exports = [[Double?]]()
        switch workflow {
        case "read": break
        case "materialize":
            for name in numeric {
                if let column = output![column: name, as: Double.self] { exports.append(column.values) }
            }
        case "filter-matrix":
            output = try output!.filter(column: chosen, where: .greaterThan(3.0))
            matrix = try output!.prepareNumericMatrix(numeric)
        case "gather-matrix":
            let indices = Array(stride(from: 0, to: output!.rowCount, by: 17))
            output = output!.gathered(at: indices)
            matrix = try output!.prepareNumericMatrix(numeric)
        case "sort-matrix":
            output = try output!.sortBy(chosen)
            matrix = try output!.prepareNumericMatrix(numeric)
        case "join-matrix":
            output = try output!.join(lookup, on: key, how: .left)
            matrix = try output!.prepareNumericMatrix(numeric)
        default: preconditionFailure("Unknown workflow")
        }
        let t1=DispatchTime.now().uptimeNanoseconds,c1=cpu(),h1=heap(),r1=resident(),p1=peak()
        let frameCheck = fingerprint(output!)
        var matrixCheck = "absent"
        if let matrix {
            var d = Digest()
            for value in matrix.values { d.append(Optional(value)) { $0.integer($1.bitPattern) } }
            matrixCheck = d.finish()
        }
        var exportCheck = [String]()
        for column in exports {
            var d=Digest()
            for value in column { d.append(value) { $0.integer($1.bitPattern) } }
            exportCheck.append(d.finish())
        }
        let t2=DispatchTime.now().uptimeNanoseconds,c2=cpu()
        output=nil;matrix=nil;exports=[]
        let t3=DispatchTime.now().uptimeNanoseconds,c3=cpu()
        let result: [String: Any] = ["frame":frameCheck,"matrix_sha256":matrixCheck,"export_sha256":exportCheck,
            "samples":[["total_cpu_ns":c1-c0+c3-c2,"total_ns":Int64(t1-t0+t3-t2),
                "read_cpu_ns":cRead-c0,"read_ns":Int64(tRead-t0),"operations_cpu_ns":c1-cRead,
                "heap_before_bytes":h0,"held_heap_bytes":h1,"heap_after_release_bytes":heap(),
                "rss_before_bytes":r0,"rss_held_bytes":r1,"process_peak_before_bytes":p0,"process_peak_held_bytes":p1]],
            "input":input.id,"workflow":workflow,"policy":policy,
            "scope":"CSV construction, requested public operations and release; held memory before full validation. Complete output hashes outside CPU/wall timing."]
        print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),as:UTF8.self))
    }
}
'''
(R/'WorkflowProbe.swift').write_text(source)
