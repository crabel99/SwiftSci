from pathlib import Path
import json,subprocess,re,hashlib
R=Path(__file__).resolve().parent
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('baseline',F),('prototype',R/'build')]:
 cmd=[a.replace(str(F),str(D)) for a in base]
 cmd=[str(R/'WorkflowProbe.swift') if a.endswith('/ResourceProbe.swift') else str(R/(label+'-workflow')) if a==str(D/'ResourceProbe') else a for a in cmd]+['-Rmodule-loading']
 with (R/(label+'-workflow-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'-workflow-build.log')).read_text()[-3000:]);raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-workflow-build.log')).read_text()))
 assert loaded.get('SwiftDataFrame')==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-workflow-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'binary_sha256':hashlib.sha256((R/(label+'-workflow')).read_bytes()).hexdigest()},indent=2)+'\n')
 print(label,'workflow client linked to matching module',flush=True)
