from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
p=S/'Sources/SwiftDataFrame/Columns/TypedColumn.swift'
s=p.read_text().replace('public var count: Int     { values.count }','''public var count: Int {
        switch storage {
        case .optional(let values): values.count
        case .dense(let values, _): values.count
        }
    }''')
s=s.replace('''    /// Raw values — `nil` means null.
    public let values: [T?]''','''    /// Optional values. Dense storage materializes an array on each request.
    public var values: [T?] {
        switch storage {
        case .optional(let values): return values
        case .dense(let values, let validity):
            guard let validity else { return values.map(Optional.some) }
            return values.indices.map { row in
                validity[row >> 6] & (UInt64(1) << (row & 63)) == 0 ? nil : values[row]
            }
        }
    }

    private enum Storage: Sendable {
        case optional([T?])
        case dense([T], validity: [UInt64]?)
    }
    private let storage: Storage''')
s=s.replace('self.values = values','self.storage = .optional(values)')
s=s.replace('public subscript(index: Int) -> T? { values[index] }','''public subscript(index: Int) -> T? {
        switch storage {
        case .optional(let values): return values[index]
        case .dense(let values, let validity):
            if let validity, validity[index >> 6] & (UInt64(1) << (index & 63)) == 0 { return nil }
            return values[index]
        }
    }''')
needle='extension TypedColumn where T == Double {'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
    internal init(name: String, compactColumn: CompactNumericColumn) {
        self.name = name
        self.dtype = .float64
        self.storage = .dense(compactColumn.values, validity: compactColumn.validity)
        self._nullCount = compactColumn.nullCount
    }
''')
p.write_text(s)
p=S/'Sources/SwiftDataFrame/IO/CSVColumnBuilder.swift';s=p.read_text()
s='''internal protocol CSVColumnBuilding<Value> {
    associatedtype Value: SupportedType
    init(capacity: Int)
    mutating func append(_ value: Value?)
    mutating func column(named name: String) -> TypedColumn<Value>
}

'''+s.replace('internal struct CSVColumnBuilder<T: SupportedType> {','internal struct CSVColumnBuilder<T: SupportedType>: CSVColumnBuilding {\n    typealias Value = T')
s+='''
/// Experimental direct construction using the numerical pipeline's existing buffers.
internal struct CSVCompactDoubleBuilder: CSVColumnBuilding {
    private var output = CompactNumericColumn([])
    private let expectedRows: Int

    init(capacity: Int) {
        expectedRows = capacity
        output.values.reserveCapacity(capacity)
    }

    mutating func append(_ value: Double?) {
        let row = output.values.count
        output.values.append(value ?? .nan)
        if value == nil {
            if output.validity == nil {
                output.validity = [UInt64](repeating: .max, count: (expectedRows + 63) / 64)
            }
            output.validity![row >> 6] &= ~(UInt64(1) << (row & 63))
            output.nullCount += 1
        }
    }

    mutating func column(named name: String) -> TypedColumn<Double> {
        defer { self = CSVCompactDoubleBuilder(capacity: 0) }
        return TypedColumn(name: name, compactColumn: output)
    }
}
'''
p.write_text(s)
p=S/'Sources/SwiftDataFrame/IO/CSVColumnConversion.swift';s=p.read_text()
s=s.replace('associatedtype Value: SupportedType\n    func decode', '''associatedtype Value: SupportedType
    associatedtype Builder: CSVColumnBuilding = CSVColumnBuilder<Value> where Builder.Value == Value
    func makeBuilder(capacity: Int) -> Builder
    func decode''')
needle='internal extension CSVValueDecoder {'
s=s.replace(needle,'''internal extension CSVValueDecoder where Builder == CSVColumnBuilder<Value> {
    func makeBuilder(capacity: Int) -> Builder { Builder(capacity: capacity) }
}

'''+needle)
s=s.replace('private var values: CSVColumnBuilder<Decoder.Value>','private var values: Decoder.Builder')
s=s.replace('values = CSVColumnBuilder(capacity: capacity)','values = decoder.makeBuilder(capacity: capacity)')
s=s.replace('var batchValues = CSVColumnBuilder<Decoder.Value>(capacity: 0)','var batchValues = decoder.makeBuilder(capacity: 0)')
s=s.replace('var batchValues = CSVColumnBuilder<Double>(capacity: 0)','var batchValues = decoder.makeBuilder(capacity: 0)')
s=s.replace('values = CSVColumnBuilder(capacity: 0)','values = decoder.makeBuilder(capacity: 0)')
s=s.replace('decoder: Decoder, validates: Bool, into values: inout CSVColumnBuilder<Decoder.Value>', 'decoder: Decoder, validates: Bool, into values: inout Decoder.Builder')
s=s.replace('internal struct CSVDoubleDecoder: CSVValueDecoder {','''internal struct CSVDoubleDecoder: CSVValueDecoder {
    typealias Builder = CSVCompactDoubleBuilder
    func makeBuilder(capacity: Int) -> Builder { Builder(capacity: capacity) }''')
s=s.replace('into values: inout CSVColumnBuilder<Double>', 'into values: inout CSVCompactDoubleBuilder')
p.write_text(s)
