from pathlib import Path
import json,hashlib,statistics,subprocess
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
D=R/'measurement';plan=json.loads((D/'plan.json').read_text());pre=json.loads((R/'preflight/decision.json').read_text())
assert pre['passed'] and pre['workers']==96
assert json.loads((R/'preflight/plan.json').read_text())==plan
assert plan['controller_sha256']==h(R/'run-panel.py')
assert all(h(R/(('baseline' if k=='twin' else k)+'-workflow'))==v for k,v in plan['binaries'].items())
module=json.loads((R/'module-build.json').read_text());assert all(h(S/p)==v for p,v in module['sources'].items())
assert h(R/'build/SwiftDataFrame.o')==module['object_sha256']
strict=json.loads((R/'preflight/strict-inputs.json').read_text());assert len(strict)==14 and all(x['validated'] for x in strict)
for result in strict:
 c=plan['contracts'][result['input']]
 assert [x['sha256'] for x in result['checks']['columns']]==c['hashes']
 assert [x['nulls'] for x in result['checks']['columns']]==c['null_counts']
rows=[json.loads(x) for x in (D/'workers.jsonl').read_text().splitlines()]
assert len(rows)==1152
keys=[(x['case'],x['engine'],x['round']) for x in rows];assert len(set(keys))==1152
expected=json.loads((R/'preflight/expectations.json').read_text())
for r in rows:
 assert r['engine']==plan['orders'][r['round']][r['position']]
 assert {k:r[k] for k in ['frame','matrix_sha256','export_sha256','scalar_bits']}==expected[r['case']]
 assert len(r['samples'])==1 and r['samples'][0]['total_cpu_ns']>0
summaries=json.loads((D/'summary.json').read_text())
for r in summaries:
 samples=[x['samples'][0] for x in rows if x['case']==r['case'] and x['engine']==r['engine']]
 assert len(samples)==r['workers']==12
 for k,v in r['medians'].items():
  raw=[x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in samples] if k=='peak_above_baseline_bytes' else [x[k] for x in samples]
  assert statistics.median(raw)==v
flags=[]
for case in plan['cases']:
 key='/'.join(case.values());group={x['engine']:x['medians'] for x in summaries if x['case']==key}
 a,b=group['baseline'],group['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append({'case':key,'reason':'identical-binary CPU','ratio':ratio})
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':key,'reason':'identical-binary memory'})
assert flags==json.loads((D/'decision.json').read_text())['quality_flags']
tests={}
for label in ['final-release','final-debug','final-asan']:
 rec=json.loads((R/(label+'-command.json')).read_text());summary=json.loads((R/(label+'-summary.json')).read_text())
 assert rec['exit_code']==0 and summary['failedTests']==summary['skippedTests']==0 and summary['passedTests']==399
 assert all(h(S/p)==v for p,v in rec['source_sha256'].items())
 tests[label]={k:summary[k] for k in ['passedTests','failedTests','skippedTests']}
stream=json.loads((R/'stream-compatibility.json').read_text());assert stream['validated'] and len(stream['responses'])==14 and all(x['validated'] for x in stream['responses'])
out={'all_outputs_match':True,'strict_reference_reads':14,'strict_stream_reference_reads':14,'preflight_workflow_reads':96,'measured_workers':1152,'quality_flags':flags,'quality_passed':not flags,'tests':tests,'source_branch':subprocess.check_output(['git','branch','--show-current'],cwd=S,text=True).strip(),'baseline_commit':'5d1f89a961106104757f2d8d0b8faba79487d100','production_promotion':False,'scope':'Experimental direct compact Double CSV construction with optional-array bulk consumers, direct scalar access, and storage-preserving renaming. CPU is process user plus system time. Native CPU scheduling; AC power.'}
(R/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
lines=['# Compact Double CSV resource trial','','Medians of 12 fresh processes per label. CPU is user plus system time. Held heap is live malloc allocations, not physical footprint. Peak RSS includes input file mappings. All final frames, matrices and exported arrays match the baseline fingerprints.','','| Input / policy / workflow | CPU baseline → prototype, ms | CPU change | Held heap baseline → prototype, MiB | Peak RSS baseline → prototype, MiB |','|---|---:|---:|---:|---:|']
for c in plan['cases']:
 key='/'.join(c.values());group={x['engine']:x['medians'] for x in summaries if x['case']==key};a,b=group['baseline'],group['prototype']
 lines.append(f"| {key} | {a['total_cpu_ns']/1e6:.2f} → {b['total_cpu_ns']/1e6:.2f} | {(b['total_cpu_ns']/a['total_cpu_ns']-1)*100:+.1f}% | {a['held_heap_bytes']/2**20:.2f} → {b['held_heap_bytes']/2**20:.2f} | {a['process_peak_held_bytes']/2**20:.2f} → {b['process_peak_held_bytes']/2**20:.2f} |")
lines+=['','Identical-binary quality flags: '+json.dumps(flags)+'. Differences in flagged cases are not qualified.','']
(R/'results.md').write_text('\n'.join(lines))
