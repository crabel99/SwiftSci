from pathlib import Path
import subprocess,json,hashlib,re
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
r=json.loads((F/'build.json').read_text());D=R/'build';D.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cmd=[a.replace(str(F),str(D)) for a in r['commands'][0]]
with (R/'module-build.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
if p.returncode:print((R/'module-build.log').read_text()[-6500:]);raise SystemExit(p.returncode)
out={'command':cmd,'sources':{p:h(S/p) for p in r['sources']},'object_sha256':h(D/'SwiftDataFrame.o')}
(R/'module-build.json').write_text(json.dumps(out,indent=2)+'\n')
for label,source in [('ResourceProbe','/private/tmp/swiftsci-csv-prefix-selection-20261022/ResourceProbe.swift'),('StreamProbe','/private/tmp/swiftsci-csv-fallback-isolation-20261022/StreamProbe.swift')]:
 cmd=[a.replace(str(F),str(D)) for a in r['commands'][1]]
 cmd=[source if a.endswith('/ResourceProbe.swift') else str(D/label) if a==str(D/'ResourceProbe') else a for a in cmd]+['-Rmodule-loading']
 with (R/(label+'-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'-build.log')).read_text()[-4500:]);raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-build.log')).read_text()))
 assert loaded.get('SwiftDataFrame')==str(D/'SwiftDataFrame.swiftmodule'),loaded.get('SwiftDataFrame')
 (R/(label+'-build.json')).write_text(json.dumps({'command':cmd,'binary_sha256':h(D/label),'harness_sha256':h(Path(source)),'verified_module':loaded['SwiftDataFrame']},indent=2)+'\n')
 print(label,'built with verified module',flush=True)
print('build passed')
