
/private/tmp/swiftsci-csv-empty-20261024/fallback-build/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010005b714 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZ>:
10005b714: aa0203e1    	mov	x1, x2
10005b718: aa0303e2    	mov	x2, x3
10005b71c: 14009279    	b	0x100080100 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n>
