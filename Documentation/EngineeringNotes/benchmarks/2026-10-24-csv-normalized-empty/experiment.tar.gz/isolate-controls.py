from pathlib import Path
import json,sys
s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');r=Path(__file__).parent;sys.path.insert(0,str(s))
from Benchmarks.CPUThroughput.run import Worker,save
cases=json.loads((r/'fixtures/control-cases.json').read_text());expected=json.loads((r/'fixtures/control-expected.json').read_text());results=[]
for name,binary in [('parent',Path('/private/tmp/swiftsci-csv-empty-20261024/fallback-build/worker')),('candidate',r/'candidate-build/worker')]:
 for case in cases:
  worker=Worker(binary,'optional',r/('isolation-'+name+'-'+case['input']+'.log'))
  try:
   value=worker.ask({k:v for k,v in case.items() if k!='input'}|{'verify':True})
   result=dict(build=name,input=case['input'],passed=value['check']==expected[case['input']+'/read'],result=value)
  except Exception as error:result=dict(build=name,input=case['input'],error=str(error),exit_code=worker.process.poll())
  finally:worker.close()
  results.append(result);save(r/'control-isolation.json',results);print({k:v for k,v in result.items() if k!='result'},flush=True)
