
/private/tmp/swiftsci-csv-normalized-empty-20261024/layout-parent/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100080100 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n>:
100080100: d10103ff    	sub	sp, sp, #0x40
100080104: a90157f6    	stp	x22, x21, [sp, #0x10]
100080108: a9024ff4    	stp	x20, x19, [sp, #0x20]
10008010c: a9037bfd    	stp	x29, x30, [sp, #0x30]
100080110: 9100c3fd    	add	x29, sp, #0x30
100080114: aa0103ea    	mov	x10, x1
100080118: eb010048    	subs	x8, x2, x1
10008011c: 5400010d    	b.le	0x10008013c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x3c>
100080120: 38616809    	ldrb	w9, [x0, x1]
100080124: 7100b53f    	cmp	w9, #0x2d
100080128: 54000080    	b.eq	0x100080138 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x38>
10008012c: aa0103ea    	mov	x10, x1
100080130: 7100ad3f    	cmp	w9, #0x2b
100080134: 54000041    	b.ne	0x10008013c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x3c>
100080138: 9100042a    	add	x10, x1, #0x1
10008013c: aa0a03e9    	mov	x9, x10
100080140: eb02015f    	cmp	x10, x2
100080144: 5400016a    	b.ge	0x100080170 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x70>
100080148: aa0a03e9    	mov	x9, x10
10008014c: 3869680b    	ldrb	w11, [x0, x9]
100080150: 7100bd7f    	cmp	w11, #0x2f
100080154: 54000149    	b.ls	0x10008017c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x7c>
100080158: 7100e97f    	cmp	w11, #0x3a
10008015c: 540003e2    	b.hs	0x1000801d8 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xd8>
100080160: 91000529    	add	x9, x9, #0x1
100080164: eb09005f    	cmp	x2, x9
100080168: 54ffff21    	b.ne	0x10008014c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x4c>
10008016c: aa0203e9    	mov	x9, x2
100080170: eb0a012a    	subs	x10, x9, x10
100080174: 54000367    	b.vc	0x1000801e0 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xe0>
100080178: d4200020    	brk	#0x1
10008017c: eb0a012a    	subs	x10, x9, x10
100080180: 54000c06    	b.vs	0x100080300 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x200>
100080184: 7100b97f    	cmp	w11, #0x2e
100080188: 540002c1    	b.ne	0x1000801e0 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xe0>
10008018c: 9100052b    	add	x11, x9, #0x1
100080190: aa0b03e9    	mov	x9, x11
100080194: eb02017f    	cmp	x11, x2
100080198: 5400012a    	b.ge	0x1000801bc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xbc>
10008019c: 3869680c    	ldrb	w12, [x0, x9]
1000801a0: 5100c18c    	sub	w12, w12, #0x30
1000801a4: 7100259f    	cmp	w12, #0x9
1000801a8: 540000a8    	b.hi	0x1000801bc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xbc>
1000801ac: 91000529    	add	x9, x9, #0x1
1000801b0: eb09005f    	cmp	x2, x9
1000801b4: 54ffff41    	b.ne	0x10008019c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x9c>
1000801b8: aa0203e9    	mov	x9, x2
1000801bc: eb0b012b    	subs	x11, x9, x11
1000801c0: 54000a46    	b.vs	0x100080308 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x208>
1000801c4: f100015f    	cmp	x10, #0x0
1000801c8: 5400010c    	b.gt	0x1000801e8 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xe8>
1000801cc: f100017f    	cmp	x11, #0x0
1000801d0: 5400086d    	b.le	0x1000802dc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1dc>
1000801d4: 14000005    	b	0x1000801e8 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0xe8>
1000801d8: eb0a012a    	subs	x10, x9, x10
1000801dc: 54000946    	b.vs	0x100080304 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x204>
1000801e0: f100055f    	cmp	x10, #0x1
1000801e4: 540007cb    	b.lt	0x1000802dc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1dc>
1000801e8: eb02013f    	cmp	x9, x2
1000801ec: 5400038a    	b.ge	0x10008025c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x15c>
1000801f0: 3869680a    	ldrb	w10, [x0, x9]
1000801f4: 321b014a    	orr	w10, w10, #0x20
1000801f8: 7101955f    	cmp	w10, #0x65
1000801fc: 54000301    	b.ne	0x10008025c <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x15c>
100080200: 9100052a    	add	x10, x9, #0x1
100080204: eb02015f    	cmp	x10, x2
100080208: 540000ea    	b.ge	0x100080224 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x124>
10008020c: 386a680b    	ldrb	w11, [x0, x10]
100080210: 7100b57f    	cmp	w11, #0x2d
100080214: 54000060    	b.eq	0x100080220 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x120>
100080218: 7100ad7f    	cmp	w11, #0x2b
10008021c: 54000041    	b.ne	0x100080224 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x124>
100080220: 9100092a    	add	x10, x9, #0x2
100080224: aa0a03e9    	mov	x9, x10
100080228: eb02015f    	cmp	x10, x2
10008022c: 5400014a    	b.ge	0x100080254 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x154>
100080230: aa0a03e9    	mov	x9, x10
100080234: 3869680b    	ldrb	w11, [x0, x9]
100080238: 5100c16b    	sub	w11, w11, #0x30
10008023c: 7100257f    	cmp	w11, #0x9
100080240: 540000a8    	b.hi	0x100080254 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x154>
100080244: 91000529    	add	x9, x9, #0x1
100080248: eb09005f    	cmp	x2, x9
10008024c: 54ffff41    	b.ne	0x100080234 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x134>
100080250: aa0203e9    	mov	x9, x2
100080254: eb09015f    	cmp	x10, x9
100080258: 5400042a    	b.ge	0x1000802dc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1dc>
10008025c: eb02013f    	cmp	x9, x2
100080260: 540003e1    	b.ne	0x1000802dc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1dc>
100080264: ab080028    	adds	x8, x1, x8
100080268: 54000486    	b.vs	0x1000802f8 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1f8>
10008026c: eb01005f    	cmp	x2, x1
100080270: 5400046b    	b.lt	0x1000802fc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1fc>
100080274: eb010108    	subs	x8, x8, x1
100080278: 5400042b    	b.lt	0x1000802fc <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1fc>
10008027c: 8b000029    	add	x9, x1, x0
100080280: f100001f    	cmp	x0, #0x0
100080284: 9a8903e0    	csel	x0, xzr, x9, eq
100080288: 9a8803e1    	csel	x1, xzr, x8, eq
10008028c: 940220dd    	bl	0x100108600 <_voucher_adopt+0x100108600>
100080290: aa0003e2    	mov	x2, x0
100080294: aa0103f3    	mov	x19, x1
100080298: f90007ff    	str	xzr, [sp, #0x8]
10008029c: b00005c3    	adrp	x3, 0x100139000 <_voucher_adopt+0x100139000>
1000802a0: f946c463    	ldr	x3, [x3, #0xd88]
1000802a4: 910023e0    	add	x0, sp, #0x8
1000802a8: aa0203e1    	mov	x1, x2
1000802ac: aa1303e2    	mov	x2, x19
1000802b0: d2800015    	mov	x21, #0x0               ; =0
1000802b4: 97ff8054    	bl	0x100060404 <_$sSfySfSgxcSyRzlufcSbSpySfGXEfU_SS_Tg5Tm>
1000802b8: aa0003f4    	mov	x20, x0
1000802bc: aa1303e0    	mov	x0, x19
1000802c0: 940224de    	bl	0x100109638 <_voucher_adopt+0x100109638>
1000802c4: f94007e8    	ldr	x8, [sp, #0x8]
1000802c8: 7200029f    	tst	w20, #0x1
1000802cc: 9a9f1100    	csel	x0, x8, xzr, ne
1000802d0: 52800028    	mov	w8, #0x1                ; =1
1000802d4: 0a340101    	bic	w1, w8, w20
1000802d8: 14000003    	b	0x1000802e4 <_$s14SwiftDataFrame21VectorizedByteParsersO15parseLongDouble6buffer5start3endSdSgSRys5UInt8VG_S2itFZTf4nnnd_nTf4xnn_n+0x1e4>
1000802dc: d2800000    	mov	x0, #0x0                ; =0
1000802e0: 52800021    	mov	w1, #0x1                ; =1
1000802e4: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1000802e8: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1000802ec: a94157f6    	ldp	x22, x21, [sp, #0x10]
1000802f0: 910103ff    	add	sp, sp, #0x40
1000802f4: d65f03c0    	ret
1000802f8: d4200020    	brk	#0x1
1000802fc: d4200020    	brk	#0x1
100080300: d4200020    	brk	#0x1
100080304: d4200020    	brk	#0x1
100080308: d4200020    	brk	#0x1
