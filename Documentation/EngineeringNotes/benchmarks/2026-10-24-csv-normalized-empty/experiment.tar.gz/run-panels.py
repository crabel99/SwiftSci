from pathlib import Path
import subprocess,json,sys
r=Path(__file__).parent
for group,copies in [('target',64),('mixed',64),('control',64)]:
 directory=group+'-workflows'
 command=[sys.executable,str(r/'panel.py'),'--candidate',str(r/'candidate-build/worker'),'--cases',str(r/'fixtures'/(group+'-cases.json')),'--expected',str(r/'fixtures'/(group+'-expected.json')),'--copies',str(copies),'--out',directory]
 with (r/(group+'-panel.log')).open('w') as out:p=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 assert p.returncode==0,group
 subprocess.run([sys.executable,str(r/'audit-workflows.py'),directory],check=True)
 d=json.loads((r/directory/'decision.json').read_text());print(group,'qualified',d['qualified'],d['flags'],flush=True);assert d['qualified'],group
with (r/'reference-panel.log').open('w') as out:p=subprocess.run([sys.executable,str(r/'reference.py')],stdout=out,stderr=subprocess.STDOUT,timeout=900)
assert p.returncode==0
subprocess.run([sys.executable,str(r/'audit-workflows.py'),'reference-workflows'],check=True)
d=json.loads((r/'reference-workflows/decision.json').read_text());print('reference qualified',d['qualified'],d['flags'],flush=True);assert d['qualified']
