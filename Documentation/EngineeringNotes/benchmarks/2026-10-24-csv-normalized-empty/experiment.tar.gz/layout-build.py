"""Diagnostic only: reuse exact library objects, align runtime stubs equally on both links."""
from pathlib import Path
import subprocess,json,hashlib,os
r=Path(__file__).parent;s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
page=os.sysconf('SC_PAGESIZE')
for name,original in [('parent',Path('/private/tmp/swiftsci-csv-empty-20261024/fallback-build')),('candidate',r/'candidate-build')]:
 d=r/('layout-'+name);d.mkdir();receipt=json.loads((original/'build.json').read_text());assert digest(original/'SwiftDataFrame.o')==receipt['object_sha256']
 cmd=receipt['commands'][1].copy();cmd[cmd.index('-o')+1]=str(d/'worker');cmd.extend(['-Xlinker','-sectalign','-Xlinker','__TEXT','-Xlinker','__stubs','-Xlinker',hex(page)])
 with (d/'build.log').open('w') as log:result=subprocess.run(cmd,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:print((d/'build.log').read_text()[-1200:]);raise SystemExit(result.returncode)
 load=subprocess.check_output(['otool','-l',str(d/'worker')],text=True);(d/'load-commands.txt').write_text(load)
 lines=load.splitlines();index=next(i for i,line in enumerate(lines) if line.strip()=='sectname __stubs');section='\n'.join(lines[index:index+8]);address=int(next(line.split()[-1] for line in lines[index:index+8] if line.strip().startswith('addr ')),16)
 assert address%page==0,section
 # New receipt records a link-only diagnostic, not a fresh compilation of library sources.
 fresh={k:v for k,v in receipt.items() if k!='commands'}
 fresh.update(commands=[cmd],binary_sha256=digest(d/'worker'),link_only_control=dict(original_build_receipt=str(original/'build.json'),original_build_receipt_sha256=digest(original/'build.json'),reused_object=str(original/'SwiftDataFrame.o'),reused_object_sha256=digest(original/'SwiftDataFrame.o'),section='__TEXT,__stubs',requested_alignment=page,actual_address=address))
 (d/'build.json').write_text(json.dumps(fresh,indent=2)+'\n');print(name,'verified stub address',hex(address),'alignment',page,flush=True)
