from pathlib import Path
import csv,hashlib,io,json,struct,sys
r=Path(sys.argv[1]);r.mkdir(parents=True,exist_ok=False)
names=['x']+[f'x{i}' for i in range(1,8)]
fixtures=[('quoted-double',['""'],'Double'),('space-double',[' \t'],'Double'),('quoted-int',['""'],'Int64'),('space-int',[' \t'],'Int64'),
 ('mixed-double',['""',' \t','" \t"','123.125','?','-0.0','1.5e2','"3.5"'],'Double'),
 ('mixed-int',['""',' \t','" \t"','123','?','-42','+15','"35"'],'Int64'),
 ('raw-double',[''],'Double'),('valid-double',['123.125'],'Double'),('valid-int',['123'],'Int64'),
 ('fallback-double',['1.2345678901234567890123456789'],'Double'),('unicode-double',['\u00a01.25\u00a0'],'Double'),('invalid-int',['9223372036854775808'],'Int64')]
expected={};cases=[]
for i,(kind,values,typ) in enumerate(fixtures):
 text=','.join(names)+'\n'+'\n'.join(','.join(values[(row+col)%len(values)] for col in range(8)) for row in range(1003))+'\n'
 f=r/(kind+'.csv');f.write_text(text)
 contract=dict(id=kind,path=str(f),rows=1003,names=names,types=[typ]*8,null_tokens=['?'],delimiter=',',sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 p=r/(kind+'.json');p.write_text(json.dumps(contract,indent=2)+'\n');columns=[];rows=list(csv.reader(io.StringIO(text)))[1:]
 for col,name in enumerate(names):
  encoded=bytearray();missing=0
  for row in rows:
   token=row[col].strip();value=None
   if token and token!='?':
    value=float(token) if typ=='Double' else int(token)
    if typ=='Int64' and not -(2**63)<=value<2**63:value=None
   if value is None:encoded.append(0);missing+=1
   else:encoded.append(1);encoded.extend(struct.pack('<d',value) if typ=='Double' else struct.pack('<q',value))
  columns.append(dict(name=name,type=typ,nulls=missing,sha256=hashlib.sha256(encoded).hexdigest()))
 expected[kind+'/read']=dict(frame=dict(rows=1003,columns=columns),matrix_sha256='absent')
 cases.append(dict(id=i,contract=str(p),workflow='read',input=kind,key='x',verify=False))
for group,kinds in [('target',['quoted-double','space-double','quoted-int','space-int']),('mixed',['mixed-double','mixed-int']),('control',['raw-double','valid-double','valid-int','fallback-double','unicode-double','invalid-int'])]:
 selected=[dict(c,id=i) for i,c in enumerate(c for c in cases if c['input'] in kinds)]
 (r/(group+'-cases.json')).write_text(json.dumps(selected,indent=2)+'\n')
 (r/(group+'-expected.json')).write_text(json.dumps({k:v for k,v in expected.items() if k.split('/')[0] in kinds},indent=2)+'\n')
safe=[dict(c,id=i) for i,c in enumerate(c for c in cases if c['input'] in ['raw-double','valid-double','valid-int','fallback-double','unicode-double'])]
(r/'safe-control-cases.json').write_text(json.dumps(safe,indent=2)+'\n')
(r/'safe-control-expected.json').write_text(json.dumps({k:v for k,v in expected.items() if k.split('/')[0] in [c['input'] for c in safe]},indent=2)+'\n')
