from pathlib import Path
import json,subprocess,hashlib
r=Path(__file__).parent;s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
def load(p):return json.loads((r/p).read_text())
names=['baseline-screen','baseline-confirm','target-workflows','mixed-workflows','safe-control-workflows','reference-workflows','safe-control-reversed','layout-controls']
decisions={name:load(name+'/decision.json') for name in names};audits={name:load(name+'/audit.json') for name in names}
assert all(d['qualified'] for name,d in decisions.items() if name!='baseline-screen')
tests={mode:load('validation/compact-'+mode+'-tests.json') for mode in ['debug','release']}
for d in tests.values():assert d['exit_code']==0 and d['summary']['failedTests']==d['summary']['skippedTests']==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();receipt=load('candidate-build/build.json')
for p,h in receipt['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+p],cwd=s)).hexdigest()==h
summary=dict(head=head,parent='31c0f958c843cb60279a74aff2b55427ba39abec',branch='codex/csv-normalized-empty-fallback',selection='Retain the normalized-empty shortcut locally; no universal speedup or production linker flag change.',panels=decisions,audits=audits,known_failures=load('failure-inventory.json'),native_tests={m:d['summary'] for m,d in tests.items()})
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
def change(d,storage,metric):
 a=d['medians']['parent_'+storage][metric];b=d['medians']['candidate_'+storage][metric];return (b/a-1)*100
rows=[]
for storage in ['optional','compact']:
 d=decisions['target-workflows']
 for case,a in d['per_case_operation_cpu_ns']['parent_'+storage].items():
  b=d['per_case_operation_cpu_ns']['candidate_'+storage][case];rows.append(f'| {case.removesuffix("/read")} | {storage} | {a/1e6:.3f} | {b/1e6:.3f} | {(b/a-1)*100:+.2f}% |')
controls=[]
for storage in ['optional','compact']:
 for case in decisions['safe-control-workflows']['per_case_operation_cpu_ns']['parent_'+storage]:
  values=[]
  for name in ['safe-control-workflows','safe-control-reversed','layout-controls']:
   d=decisions[name];a=d['per_case_operation_cpu_ns']['parent_'+storage][case];b=d['per_case_operation_cpu_ns']['candidate_'+storage][case];values.append(f'{(b/a-1)*100:+.2f}%')
  controls.append(f'| {case.removesuffix("/read")} | {storage} | '+ ' | '.join(values)+' |')
reference=[]
for storage in ['optional','compact']:
 d=decisions['reference-workflows'];a=d['medians']['parent_'+storage];b=d['medians']['candidate_'+storage]
 reference.append(f'| {storage} | {change(d,storage,"charged_cpu_ns"):+.2f}% | {change(d,storage,"completed_per_minute"):+.2f}% | {a["sampled_peak_rss_bytes"]/2**20:.1f} → {b["sampled_peak_rss_bytes"]/2**20:.1f} |')
total=dict(queues=sum(d['queues'] for d in audits.values()),jobs=sum(d['jobs'] for d in audits.values()),checks=sum(d['full_output_checks'] for d in audits.values()))
text=f'''# Normalized empty CSV fields skip numeric conversion

Retain `{head}` locally on `codex/csv-normalized-empty-fallback`, based on [the raw-empty optimization](../2026-10-24-csv-empty-numeric-fallback/README.md) at `31c0f958c843cb60279a74aff2b55427ba39abec`. Nothing is pushed and no PR is opened. Engineering records remain on `codex/engineering-notes`.

The change adds an empty check to the existing private numeric fallback after CSV String normalization. Quoted-empty and ASCII space/tab-only fields with custom null tokens use about 94–95% less operation CPU in the targeted panel. Ordinary reference workflows are effectively neutral. Nonempty control timings depend on the tested link layout, so this is not a universal efficiency claim.

## Remove numeric conversion of an already empty String

The raw-empty shortcut stays first. For a nonzero-length field, the existing parser strips outer quotes and ASCII whitespace. If the resulting String is empty, the new guard returns nil before invoking numeric conversion and its whitespace trimming. Nonempty text still uses the original conversion. Unicode whitespace handling and numeric grammar are unchanged.

Null matching still precedes fallback. An explicit numeric schema maps both missing and invalid values to nil. Inference must keep an undeclared normalized empty invalid, then retain a text column. The patch adds no policy, public API, storage change, parallelism change, or new normalization rule.

## Targeted resource result

Four fixed inputs use 1,003 rows and eight numeric columns: quoted-empty and ASCII space/tab-only Int64 and Double fields. Both builds receive the same full schema and custom null set containing only `?`. Eight rotated rounds include a twin for every binary/storage condition, with four callers and 256 reads per queue. The panel completes 16,384 reads and 32 full-output checks.

| Input | Storage | Parent operation CPU ms/read | Candidate operation CPU ms/read | Change |
| --- | --- | ---: | ---: | ---: |
{chr(10).join(rows)}

A separate mixed panel rotates normalized empties, valid numbers, quoted values and recognized custom nulls. It completes 8,192 reads and 16 full-output checks. Charged queue CPU falls {abs(change(decisions['mixed-workflows'],'optional','charged_cpu_ns')):.2f}% with optional storage and {abs(change(decisions['mixed-workflows'],'compact','charged_cpu_ns')):.2f}% with compact storage. These queue figures include controller work; the table measures worker operation CPU.

## Nonempty controls expose a layout dependency

The five correctly completing controls cover the retained raw-empty path, ordinary Doubles and Int64 values, long decimals, and Unicode-padded numeric text. Each control panel completes 20,480 reads and 40 full-output checks. A reversed-order repeat investigates increases in the first panel instead of discarding them.

| Input | Storage | Original operation CPU change | Reversed order | Equal stub alignment |
| --- | --- | ---: | ---: | ---: |
{chr(10).join(controls)}

The long-decimal conversion returns before reaching the changed guard. Disassembly shows the same 131 instructions in its specialization, apart from two runtime-call displacements. Their destination stubs move by 60 bytes in the ordinary links.

A diagnostic reuses the exact library objects and links both binaries with the runtime-stub section aligned to the measured 16 KiB host page size. Both stub sections begin at the same address. The linked long-decimal instruction bytes and call addresses then match exactly. The earlier consistent long-decimal/Unicode penalty does not persist in that link configuration.

The observed penalty is not stable across these two link configurations. Its exact internal cause remains unproven, and the result does not guarantee behavior in other applications. The alignment flags are diagnostic only. No production linker option is changed, and the unfavorable ordinary-link measurements remain in the record.

## Complete reference workflows

The full reference panel completes 8,192 jobs in 64 queues with 32 full-output checks. It reads 35,064 Aotizhongxin observations and 2,075,259 household electricity records, alone or followed by stable sorting and numeric matrix construction. Each queue has 128 jobs and four native CPU callers.

| Storage | Charged CPU change | Throughput change | Peak RSS MiB, parent → candidate |
| --- | ---: | ---: | ---: |
{chr(10).join(reference)}

These inputs recognize empty strings as null, so their empty fields already exit before this private fallback. The panel checks ordinary-operation regressions. It does not establish that the targeted shortcut accelerates those datasets. No new memory reduction is demonstrated.

## Existing integer crash remains failed conformance

The original sixth control, an out-of-range Int64 token, crashes during the unchanged parent's preflight. It never enters timing. Independent replay confirms the same crash on both builds. A one-cell public CSV reproduction also crashes on valid `Int64.min` and on values just above or below the representable range. `Int64.max` passes.

The fault is in the unchanged `VectorizedByteParsers.parseInt`, which accumulates positive magnitude with checked arithmetic before applying the sign. The magnitude of `Int64.min` cannot fit. Crash traces identify that function. The [defect record](integer-overflow.md) and red-capable process-isolated reproducer preserve the expected results and failures. The case is excluded only from timing, not accepted as passing. Repair belongs in a separate branch and regression commit.

## Validation and reproducibility

All {tests['debug']['summary']['passedTests']} dataframe tests pass in Debug and all {tests['release']['summary']['passedTests']} pass in Release, with no failures or skips. Existing tests now parameterize raw-empty, quoted-empty and ASCII whitespace forms for missing-versus-invalid classification and late inference fallback. No failing-before semantic claim is made; the original values were correct. The integer boundary reproducer still fails. No full MLX suite, hosted coverage or CI result is claimed.

The first short identical-binary screen fails the unchanged 10% CPU twin limit. A budgeted longer baseline passes. All subsequent completed panels pass the recorded 10% twin CPU/wall and 5% plus 8 MiB-per-caller RSS controls. Every conservative sum of worker kernel peaks stays below 4 GiB. The separate failed integer-control preflight is retained alongside completed panels.

Audits recompute {total['queues']} completed queues, {total['jobs']:,} timed jobs and {total['checks']} full-output checks. Independent native-bit hashes include dtypes, values, null counts and matrices. Fixtures and expected fingerprints regenerate exactly. Workers always use full schemas; inference performance is not measured. Both binaries share dependency hashes and worker source, and only `CSVColumnConversion.swift` differs among measured library sources. Build receipts retain their original heads and exact dirty-source hashes, mapped to the later commit.

Panels, diagnostic link builds and native tests run sequentially. AC and recorded power settings remain unchanged within panels. CPU parallelism is native; callers are not pinned cores. Charged CPU is worker user/system time plus measured controller CPU and cleanup, not FLOPs or energy. Sampled RSS can miss brief peaks or count shared pages repeatedly. No GPU or Neural Engine result is implied.

[Summary](summary.json), [hash inventory](artifact-sha256.json), and [experiment archive](experiment.tar.gz) contain source snapshots, normal and diagnostic link receipts, all completed/unqualified/failed outcomes, raw accounting, independent fingerprints, expanded tests, disassembly and the integer reproducer. Binaries, objects, caches, raw CSVs and xcresult bundles are excluded. Restore the recorded source/dependencies/reference-file hashes, remap paths, regenerate fixtures, and run the preserved panel/audit tools in fresh directories. Run native validation separately from timing. The crash reproducer should exit nonzero until its separate repair lands.
'''
(r/'README.md').write_text(text)
fault='''# CSV integer conversion traps at signed boundaries

Status: unresolved existing defect. The normalized-empty change does not edit the integer parser or fix these failures.

With an explicit Int64 schema, a CSV containing one numeric cell has these results on both parent and candidate:

| Cell | Expected | Actual |
| --- | --- | --- |
| `9223372036854775807` | `Int64.max` | Pass |
| `-9223372036854775808` | `Int64.min` | SIGTRAP |
| `9223372036854775808` | nil under the documented invalid-value coercion | SIGTRAP |
| `-9223372036854775809` | nil under the documented invalid-value coercion | SIGTRAP |

The reproduction uses a full Int64 override and the null token `?`. It runs each input in its own process, checks the complete native-bit result where execution completes, preserves crash status, and exits nonzero if any case fails. The parent is `31c0f958c843cb60279a74aff2b55427ba39abec`. The candidate has the same integer-parser source hash.

Crash frames identify `VectorizedByteParsers.parseInt(buffer:offset:)`. It accumulates a positive `Int` with checked multiply/add, then applies the sign. A positive accumulator cannot hold the magnitude of `Int64.min`, and out-of-range magnitudes trap before the optional fallback can reject them.

The archived `crash-reproducer/reproduce.py` accepts `--binary` and a fresh `--out` directory. Its parent and candidate records each retain three failures and one passing upper-bound case. The original failed control preflight and original nil expectation are preserved. No tolerance, expectation or production code is changed to waive the fault. The repair should have its own branch, regression tests and commit, including valid signed limits, out-of-range values, signs and surrounding whitespace.
'''
(r/'integer-overflow.md').write_text(fault)
print('Report generated for',head)
