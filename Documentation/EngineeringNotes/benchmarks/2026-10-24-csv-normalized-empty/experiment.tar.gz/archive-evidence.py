"""Archive the reviewable record; omit binaries, caches, raw CSVs and xcresult bundles."""
from pathlib import Path
import os,json,hashlib,tarfile,sys
r=Path(__file__).parent;d=Path(sys.argv[1]);d.mkdir(parents=True,exist_ok=False)
for name in ['README.md','summary.json','integer-overflow.md']:(d/name).write_bytes((r/name).read_bytes())
allowed={'.py','.json','.log','.txt','.swift','.md','.patch','.asm'}
files=[]
for root,dirs,names in os.walk(r):
 dirs[:]=[x for x in dirs if x not in ['module-cache','__pycache__'] and not x.endswith('.xcresult')]
 root=Path(root)
 for name in names:
  p=root/name;rel=p.relative_to(r)
  if p.suffix not in allowed or name.endswith('.abi.json'):continue
  if rel.parts[0] in ['candidate-build','fallback-build'] and (len(rel.parts)!=2 or name not in ['build.json','build-0.log','build-1.log']):continue
  files.append(p)
files.sort();inventory={str(p.relative_to(r)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
with tarfile.open(d/'experiment.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(r)),recursive=False)
 content=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(content)
 import io
 archive.addfile(info,io.BytesIO(content))
with tarfile.open(d/'experiment.tar.gz','r:gz') as archive:
 actual=json.load(archive.extractfile('inventory.json'));assert actual==inventory
 for member in archive.getmembers():
  if member.name=='inventory.json':continue
  payload=archive.extractfile(member).read();record=inventory[member.name]
  assert len(payload)==record['bytes'] and hashlib.sha256(payload).hexdigest()==record['sha256']
hashes={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in d.iterdir() if p.is_file()}
(d/'artifact-sha256.json').write_text(json.dumps(dict(files=hashes,archive_members_verified=len(inventory)),indent=2)+'\n')
print(json.dumps(dict(archive_members_verified=len(inventory),archive_bytes=(d/'experiment.tar.gz').stat().st_size),indent=2))
