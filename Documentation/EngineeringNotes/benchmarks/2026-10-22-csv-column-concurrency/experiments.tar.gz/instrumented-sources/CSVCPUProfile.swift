import Foundation
import Darwin

// [CSV-CPU-20261022] Diagnostic overlay only; one joined coordinator writes.
internal enum CSVCPUProfile {
    nonisolated(unsafe) static var elapsed = [String: Int64]()
    nonisolated(unsafe) static var calls = [String: Int]()
    static func cpu() -> Int64 {
        var t = timespec()
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &t)
        return Int64(t.tv_sec) * 1_000_000_000 + Int64(t.tv_nsec)
    }
    static func add(_ key: String, since start: Int64) {
        elapsed[key, default: 0] += cpu() - start
        calls[key, default: 0] += 1
    }
    static func measure<T>(_ key: String, _ body: () throws -> T) rethrows -> T {
        let start = cpu()
        defer { add(key, since: start) }
        return try body()
    }
    static func emit() {
        let record: [String: Any] = ["tag": "CSV-CPU-20261022", "cpu_ns": elapsed, "calls": calls]
        let bytes = try! JSONSerialization.data(withJSONObject: record, options: [.sortedKeys])
        FileHandle.standardError.write(bytes + Data([10]))
        elapsed = [:]
        calls = [:]
    }
}
