from pathlib import Path
import os,subprocess,json,time,hashlib,sys
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');configuration=sys.argv[1];assert configuration in ['Release','Debug']
build=json.loads((R/(configuration.lower()+'-build.json')).read_text());assert build['exit_code']==0
for name,digest in build['sources'].items():assert hashlib.sha256((S/name).read_bytes()).hexdigest()==digest
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==build['head']
tokenizer=Path('/Users/crabel/Library/Caches/SwiftSci/models/Llama-3.2-1B-Instruct-bf16-863c846a/tokenizer.json');assert hashlib.sha256(tokenizer.read_bytes()).hexdigest()=='79e3e522635f3171300913bb421464a87de6222182a0570b9b2ccba2a964b2b4'
xctestrun=Path('/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/SwiftSci-Package_SwiftSci-Package_macosx27.0-arm64.xctestrun');assert xctestrun.exists()
cmd=['xcodebuild','test-without-building','-xctestrun',str(xctestrun),'-destination','platform=macOS,arch=arm64','-parallel-testing-enabled','NO','-resultBundlePath',str(R/(configuration.lower()+'.xcresult'))]
env=dict(os.environ);env['TEST_RUNNER_SWIFTSCI_LLAMA_TOKENIZER_JSON']=str(tokenizer);env['TEST_RUNNER_PATH']=str(R/'onnx-env/bin')+':'+env['PATH'];env['TEST_RUNNER_STRICT_ONNX_CI']='1'
start=time.time()
with (R/(configuration.lower()+'-tests.log')).open('w') as out:result=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=900)
record={'head':build['head'],'command':cmd,'exit_code':result.returncode,'seconds':time.time()-start,'strict_onnx_ci':True,'tokenizer_sha256':hashlib.sha256(tokenizer.read_bytes()).hexdigest()}
if (R/(configuration.lower()+'.xcresult')).exists():record['summary']=json.loads(subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(R/(configuration.lower()+'.xcresult')),'--format','json'],text=True))
(R/(configuration.lower()+'-tests.json')).write_text(json.dumps(record,indent=2)+'\n');summary=record.get('summary',{});print(configuration,'exit',result.returncode,{k:summary.get(k) for k in ['totalTestCount','passedTests','failedTests','skippedTests']},flush=True)
raise SystemExit(result.returncode or (1 if summary.get('failedTests',1) or summary.get('skippedTests',1) else 0))
