from pathlib import Path
import subprocess,json,time,hashlib
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
record=json.loads((R/'build-command.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==record['head']
record['sources']={str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['Sources','Tests','Benchmarks/Worker','Benchmarks/Support'] for p in (S/folder).rglob('*.swift')}
start=time.time()
with (R/'release-build.log').open('w') as out:result=subprocess.run(record['command'],cwd=S,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
record.update(exit_code=result.returncode,seconds=time.time()-start)
(R/'release-build.json').write_text(json.dumps(record,indent=2)+'\n')
print('Release build-for-testing exit',result.returncode,'seconds',record['seconds'],flush=True)
raise SystemExit(result.returncode)
