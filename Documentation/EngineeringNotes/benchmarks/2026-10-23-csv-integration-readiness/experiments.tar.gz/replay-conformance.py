from pathlib import Path
import copy,json,sys
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');sys.path.insert(0,str(S/'Benchmarks/Tools'))
from acceptance import inspect_run,load_policy
from contracts import load_profile,identity
from regression_policy import expected_cases,coverage_identity,evaluate
original=json.loads((R/'cpu-conformance-verified/acceptance.json').read_text());report=copy.deepcopy(original);report['profiles']=[]
for entry in load_policy(S)['profiles']:
 if entry['tier']!='cpu':continue
 name=entry['profile'];record=inspect_run(R/'cpu-conformance-verified'/name,load_profile(S,name),original['source'],['swiftsci','pandas'],S);report['profiles'].append(dict(profile=name,tier='cpu',**record));print('Replayed',name,record['status'],flush=True)
report['coverage_complete']=all(x['coverage_complete'] for x in report['profiles']);report['status']='failed' if any(x['status']!='passed' for x in report['profiles']) else 'passed'
expected=expected_cases(S,load_policy(S));baseline=json.loads((S/'Benchmarks/Specs/known-failures.json').read_text());old_entries=identity(baseline['entries']);baseline['coverage_sha256']=coverage_identity(expected);decision=evaluate(report,baseline,expected)
assert report['coverage_complete'] and decision['status']=='passed' and decision['blocking']==[] and len(decision['known_failures'])==4
assert identity(baseline['entries'])==old_entries
(R/'replayed-conformance.json').write_text(json.dumps(report,indent=2)+'\n');(R/'baseline-review.json').write_text(json.dumps({'replay_of_immutable_capture':True,'proposed_coverage_sha256':baseline['coverage_sha256'],'failure_entries_sha256_unchanged':old_entries,'decision':decision,'case_executions':sum(x['engine_cases'] for x in report['profiles'])},indent=2)+'\n');print('Replay complete. Policy passes with the four unchanged known failures; no new numerical failures.')
