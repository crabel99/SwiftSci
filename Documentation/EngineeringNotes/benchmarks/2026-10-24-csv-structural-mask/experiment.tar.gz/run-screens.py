from pathlib import Path
import subprocess
R=Path(__file__).parent
for i,command in enumerate([['python3',str(R/'prepare-screens.py')],['python3',str(R/'screen-formats.py')],['python3',str(R/'screen-density.py'),'nibble'],['python3',str(R/'screen-stress.py')]]):
 with (R/f'screens-stage-{i}.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('completed',i,flush=True)
