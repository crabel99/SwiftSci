from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,statistics
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-24-csv-structural-mask';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commit=json.loads((R/'local-commit.json').read_text());build=json.loads((R/'nibble-build/build.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==commit['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
for name,digest in build['sources'].items():assert sha(S/name)==digest,name
for mode in ['debug','release']:
 t=json.loads((R/'nibble-validation'/('compact-'+mode+'-tests.json')).read_text());assert t['exit_code']==0 and t['summary']['passedTests']==437 and t['summary']['failedTests']==t['summary']['skippedTests']==0
for name in ['parent','nibble']:
 assert json.loads((R/(name+'-check.json')).read_text())['results_sha256']=='9ef88e34ce971b6dd5855327cd32a387dcbc8828aa080585ded2b5278c3ea504'
for name in ['nibble-workflows','nibble-workflows-reversed']:
 a=json.loads((R/name/'audit.json').read_text());assert a['qualified'] and a['jobs']==8192 and a['full_output_checks']==32
summary=dict(decision='Retain the tested scanner change locally; no push or PR',commit=commit,source_diff=dict(file='Sources/SwiftDataFrame/IO/SystemsCSVParser.swift',added_lines=9,removed_lines=10),native_tests=dict(Debug=437,Release=437,failures=0,skips=0),scanner_corpus=dict(cases=75583,independent_coordinate_oracle_subset=65536,output_sha256='9ef88e34ce971b6dd5855327cd32a387dcbc8828aa080585ded2b5278c3ea504'),analysis=json.loads((R/'analysis.json').read_text()),screen_audit=json.loads((R/'screen-audit.json').read_text()),default_null_control=json.loads((R/'default-null-result/screen/decision.json').read_text()),interrupted_diagnostic=json.loads((R/'dense-empty-interruption.json').read_text()),assembly=json.loads((R/'assembly-summary.json').read_text()),schema_mode='full_explicit',inference_performance_claim=False,profiled_timings_excluded=True,remote_actions=False)
summary['default_null_control']['cpu_change_percent']=100*(summary['default_null_control']['trial_to_compact_cpu_ratio']-1)
summary['screen_audit']['all_screen_qualified']=True
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
P=R/'provenance';P.mkdir(exist_ok=True)
for p in (S/'Sources/SwiftDataFrame').rglob('*.swift'):
 dest=P/p.relative_to(S);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
for p in [*list((S/'Tests/SwiftDataFrameTests').rglob('*.swift')),*list((S/'Benchmarks/CPUThroughput').rglob('*.py')),*list((S/'Benchmarks/Tools').glob('*.py')),S/'Benchmarks/CPUThroughput/Worker.swift',S/'Package.swift',S/'Package.resolved']:
 dest=P/p.relative_to(S);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
subprocess.run(['git','diff',commit['parent'],commit['head'],'--output='+str(P/'source.patch')],cwd=S,check=True)
# Keep the original fixture generators. Their absolute paths are recorded and must be remapped on replay.
for name,p in [('density-generator.py',Path('/private/tmp/swiftsci-compact-builder-20261024/density.py')),('format-generator.py',Path('/private/tmp/swiftsci-number-parser-20261024/prepare-formats.py'))]:shutil.copyfile(p,P/name)
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='archive-files.json':continue
 parts=p.relative_to(R).parts
 if any(x in {'module-cache','__pycache__'} or x.endswith('.xcresult') for x in parts):continue
 if p.suffix not in {'.py','.swift','.json','.txt','.log','.s','.patch'}:continue
 if p.name in {'compact-debug-build.log','compact-release-build.log'}:continue
 files.append(p)
files.append(R/'parent-results.bin')
manifest={str(p.relative_to(R)):sha(p) for p in files};(R/'archive-files.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(R/'archive-files.json')
with tarfile.open(D/'experiment.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
print('Preserved',len(files),'files;',round((D/'experiment.tar.gz').stat().st_size/2**20,2),'MiB')
