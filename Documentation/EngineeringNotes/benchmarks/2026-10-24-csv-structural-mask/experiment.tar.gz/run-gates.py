from pathlib import Path
import subprocess,json,sys
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
parent=Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker');trial=R/'nibble-build/worker'
a=json.loads(parent.with_name('build.json').read_text());b=json.loads(trial.with_name('build.json').read_text())
assert a['dependencies']==b['dependencies'] and set(a['sources'])==set(b['sources'])
assert [k for k in a['sources'] if a['sources'][k]!=b['sources'][k]]==['Sources/SwiftDataFrame/IO/SystemsCSVParser.swift']
for name,binary in [('parent',parent),('nibble',trial)]:subprocess.run(['python3',str(R/'check.py'),str(binary.parent),name],check=True)
assert (R/'parent-results.bin').read_bytes()==(R/'nibble-results.bin').read_bytes()
plan=json.loads(Path('/private/tmp/swiftsci-number-parser-20261024/pair-workflows/plan.json').read_text());expected=json.loads(Path('/private/tmp/swiftsci-number-parser-20261024/pair-workflows/expected.json').read_text())
D=R/'preflight';D.mkdir();run.preflight(trial,plan['cases'],expected,D)
subprocess.run(['python3',str(R/'measure.py'),'--worker',str(parent),'--trial',str(trial),'--rounds','8','--out',str(R/'household-screen')],check=True)
