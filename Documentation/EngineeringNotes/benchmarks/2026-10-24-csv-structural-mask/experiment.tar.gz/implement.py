from pathlib import Path
import json
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent
p=S/'Sources/SwiftDataFrame/IO/SystemsCSVParser.swift';s=p.read_text();(R/'parent-parser.swift').write_text(s)
s=s.replace('    var matches: UInt16 = 0','    var matches: UInt64 = 0')
a=s.index('                // Each disjoint byte-weight sum');b=s.index('\n                cursor += 16',a)
s=s[:a]+'''                // Two byte flags become two nibbles in each narrowed lane.
                // Keep one bit per nibble so a trailing-zero count locates a byte.
                let flags = SIMD16<UInt8>.zero.replacing(with: SIMD16(repeating: 255), where: structural)
                let words = unsafeBitCast(flags, to: SIMD8<UInt16>.self)
                let nibbles = SIMD8<UInt8>(truncatingIfNeeded: words &>> 4)
                matches = unsafeBitCast(nibbles, to: UInt64.self) & 0x1111_1111_1111_1111'''+s[b:]
s=s.replace('matches |= UInt16(1) << (cursor - blockStart)','matches |= UInt64(1) << ((cursor - blockStart) * 4)')
s=s.replace('let position = matches.trailingZeroBitCount','let position = matches.trailingZeroBitCount / 4')
p.write_text(s)
(R/'hypotheses.json').write_text(json.dumps(dict(parent='5b9c90297723cf53dcba17299c57778688e282e2',ranked=[dict(rank=1,cause='Two horizontal sums in each SIMD structural block',prediction='Replacing only match packing with a verified shift/narrow representation lowers complete-operation CPU across numeric formats without changing parser state or memory.'),dict(rank=2,cause='Repeated row-bound and field-coordinate access during column conversion',prediction='A direct coordinate traversal lowers conversion CPU even if mask packing has no useful effect.',tested=False),dict(rank=3,cause='String creation and ownership work around explicit string columns',prediction='A string-heavy input improves more than numeric-only formats after removing materialization work.',tested=False)],feedback='Existing immutable public CSV throughput worker; fresh identical-binary controls and exhaustive parser coordinate tests',change='Only SystemsCSVParser.swift structural-match representation; existing DFA, SIMD load width, byte comparisons, cancellation windows and numeric conversion preserved.',promotion='Require exact coordinates and full outputs, semantic suites, varied formats and matched full workflow CPU/RSS evidence.'),indent=2)+'\n')
