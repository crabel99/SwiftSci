from pathlib import Path
import json,hashlib,struct,sys,subprocess,argparse
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
p=argparse.ArgumentParser();p.add_argument('variant');a=p.parse_args()
D=R/(a.variant+'-densities');D.mkdir()
for pattern in ['present','sparse','alternating','missing']:
 contract=R/'densities'/(pattern+'.json');manifest=json.loads(contract.read_text());h=hashlib.sha256();nulls=0
 with Path(manifest['path']).open() as f:
  next(f)
  for line in f:
   token=line.strip()
   if token=='?':h.update(b'\0');nulls+=1
   else:h.update(b'\1'+struct.pack('<d',float(token)))
 expected=dict(frame=dict(rows=manifest['rows'],columns=[dict(name='x',type='Double',nulls=nulls,sha256=h.hexdigest())]),matrix_sha256='absent')
 run.save(D/(pattern+'-expected.json'),expected)
 binary=R/(a.variant+'-build/worker')
 for storage in ['optional','compact']:
  worker=run.Worker(binary,storage,D/(pattern+'-'+storage+'.log'))
  try:assert worker.ask(dict(id=0,contract=str(contract),workflow='read',key='x',verify=True))['check']==expected
  finally:worker.close()
 subprocess.run(['python3',str(R/'measure.py'),'--worker','/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker','--trial',str(binary),'--contract',str(contract),'--rounds','6','--out',str(D/(pattern+'-screen'))],cwd=S,check=True)
 print(pattern,'complete',flush=True)
