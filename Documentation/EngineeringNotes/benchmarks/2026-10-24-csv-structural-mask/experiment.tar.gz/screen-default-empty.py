from pathlib import Path
import sys,json,ast,hashlib,subprocess,re
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
assert (R/'dense-empty-interruption.json').exists() or (R/'dense-empty-confirm/decision.json').exists()
D=R/'default-null-result';D.mkdir()
m=json.loads((R/'stress/dense-empty.json').read_text())
text=(S/'Sources/SwiftDataFrame/IO/CSVReadOptions.swift').read_text()
line=next(line for line in text.splitlines() if 'public var nullValues:' in line)
nulls=ast.literal_eval(line.split('=',1)[1].strip())
assert '' in nulls and len(nulls)==10
m['id']='dense-empty-default-nulls';m['null_tokens']=nulls
contract=D/'contract.json';run.save(contract,m)
run.save(D/'null-policy.json',dict(derivation='Public CSVReadOptions default nullValues declaration',source_sha256=run.digest(S/'Sources/SwiftDataFrame/IO/CSVReadOptions.swift'),null_tokens=nulls,inference=False))
empty_hash=hashlib.sha256(b'\0'*m['rows']).hexdigest()
expected=dict(frame=dict(rows=m['rows'],columns=[dict(name=name,type='Double',nulls=m['rows'],sha256=empty_hash) for name in m['names']]),matrix_sha256='absent')
run.save(D/'expected.json',expected)
parent=Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker');candidate=R/'nibble-build/worker';checks=[]
for label,binary in [('parent',parent),('candidate',candidate)]:
 for storage in ['optional','compact']:
  worker=run.Worker(binary,storage,D/(label+'-'+storage+'.log'))
  try:
   actual=worker.ask(dict(id=0,contract=str(contract),workflow='read',key='x',verify=True))['check'];assert actual==expected
   checks.append(dict(build=label,storage=storage,check=actual))
  finally:worker.close()
run.save(D/'checks.json',checks)
subprocess.run(['python3',str(R/'measure.py'),'--worker',str(parent),'--trial',str(candidate),'--contract',str(contract),'--rounds','8','--out',str(D/'screen')],check=True)
