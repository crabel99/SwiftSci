from pathlib import Path
import sys,subprocess,json,time
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
D=R/'empty-fallback-profile';D.mkdir()
worker=run.Worker(Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker'),'compact',D/'worker.log')
rows=[];start=time.monotonic()
try:
 with (D/'sample.log').open('w') as log:
  sampler=subprocess.Popen(['sample',str(worker.process.pid),'4','1','-file',str(D/'sample.txt')],stdout=log,stderr=subprocess.STDOUT)
  while sampler.poll() is None and time.monotonic()-start<8:
   rows.append(worker.ask(dict(id=len(rows),contract=str(R/'stress/dense-empty.json'),workflow='read',key='x',verify=False)))
  code=sampler.wait(timeout=10)
 run.save(D/'receipt.json',dict(sample_exit=code,requests=len(rows),profiled_timings_excluded_from_performance_evidence=True,worker_sha256=run.digest(worker.binary) if hasattr(worker,'binary') else run.digest(Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker')),elapsed_seconds=time.monotonic()-start))
finally:worker.close()
text=(D/'sample.txt').read_text();marker='Sort by top of stack, same collapsed'
section=text[text.index(marker):] if marker in text else text
(D/'leaves.txt').write_text(section.split('Binary Images:')[0]);print((D/'leaves.txt').read_text()[:3500])
