from pathlib import Path
import json,subprocess,hashlib,sys
R=Path(__file__).parent;build=Path(sys.argv[1]);name=sys.argv[2]
receipt=json.loads((build/'build.json').read_text());cmd=receipt['commands'][1].copy()
old=next(x for x in cmd if x.endswith('/CPUThroughput/Worker.swift'));cmd[cmd.index(old)]=str(R/'ScanCheck.swift');cmd[cmd.index('-o')+1]=str(R/(name+'-check'))
with (R/(name+'-check-build.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
output=subprocess.check_output([str(R/(name+'-check')),str(R/(name+'-results.bin'))],text=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(command=cmd,worker_build_sha256=receipt['binary_sha256'],checker_source_sha256=sha(R/'ScanCheck.swift'),checker_sha256=sha(R/(name+'-check')),results_sha256=sha(R/(name+'-results.bin')),output=output)
(R/(name+'-check.json')).write_text(json.dumps(record,indent=2)+'\n');print(output,record['results_sha256'])
