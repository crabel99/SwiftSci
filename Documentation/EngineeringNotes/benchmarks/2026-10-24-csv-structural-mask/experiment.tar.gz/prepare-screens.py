from pathlib import Path
import shutil,json,hashlib
R=Path(__file__).parent;OLD=Path('/private/tmp/swiftsci-number-parser-20261024')
for name in ['formats','densities']:
 (R/name).mkdir()
 for p in (OLD/name).glob('*.json'):shutil.copyfile(p,R/name/p.name)
s=(OLD/'screen-formats.py').read_text().replace("R/'pair-formats'","R/'nibble-formats'").replace("R/'pair-build/worker'","R/'nibble-build/worker'")
(R/'screen-formats.py').write_text(s)
shutil.copyfile(OLD/'screen-density.py',R/'screen-density.py')
D=R/'stress';D.mkdir()
for name,token in [('dense-empty',''),('dense-quoted','"1"')]:
 rows=100_003;names=['x']+['x'+str(i) for i in range(1,16)];p=D/(name+'.csv')
 with p.open('w') as f:
  f.write(','.join(names)+'\n');line=','.join([token]*16)+'\n'
  for i in range(rows):f.write(line)
 manifest=dict(id=name,path=str(p),rows=rows,names=names,types=['Double']*16,null_tokens=['?'],delimiter=',',sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (D/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared unchanged reference formats and explicit dense-row stress contracts')
