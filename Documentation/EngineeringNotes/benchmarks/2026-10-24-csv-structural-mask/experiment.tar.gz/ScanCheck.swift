import Foundation
import SwiftDataFrame

@main struct ScanCheck {
    static func main() throws {
        var output = Data()
        var cases = 0
        var oracleChecks = 0
        func integer(_ value: Int) {
            var bits = UInt64(value).littleEndian
            withUnsafeBytes(of: &bits) { output.append(contentsOf: $0) }
        }
        func emit(_ bytes: [UInt8], delimiter: UInt8 = 44, quote: UInt8 = 34, boundaries: [Int]? = nil) {
            let padding = cases & 31
            let padded = [UInt8](repeating: 65, count: padding) + bytes
            let rows = padded.withUnsafeBufferPointer { whole in
                SystemsCSVParser(delimiterByte: delimiter, quoteByte: quote)
                    .parse(buffer: UnsafeBufferPointer(rebasing: whole[padding...]))
            }
            if let boundaries {
                precondition(rows.count == 1 && rows[0].count == boundaries.count - 1)
                for index in rows[0].indices {
                    let field = rows[0][index]
                    precondition(field.startOffset == boundaries[index] + 1)
                    precondition(field.length == boundaries[index + 1] - boundaries[index] - 1)
                    precondition(!field.escapedQuotesPresent)
                }
                oracleChecks += 1
            }
            integer(rows.count)
            for row in rows {
                integer(row.count)
                for field in row {
                    integer(field.startOffset); integer(field.length)
                    output.append(field.escapedQuotesPresent ? 1 : 0)
                }
            }
            cases += 1
        }
        for mask in 0..<65_536 {
            var bytes = [UInt8](repeating: 120, count: 17)
            bytes[16] = 10
            var boundaries = [-1]
            for lane in 0..<16 where mask & (1 << lane) != 0 {
                bytes[lane] = 44; boundaries.append(lane)
            }
            boundaries.append(16)
            emit(bytes, boundaries: boundaries)
        }
        var state: UInt64 = 0x243f6a8885a308d3
        let alphabet: [UInt8] = [0, 9, 10, 13, 34, 39, 44, 59, 65, 120, 128, 255]
        let delimiters: [UInt8] = [44, 59, 9, 0, 13, 255]
        let quotes: [UInt8] = [34, 39, 0, 255]
        for count in 0..<10_000 {
            var bytes = [UInt8]()
            for _ in 0..<(count % 257) {
                state = state &* 6364136223846793005 &+ 1442695040888963407
                bytes.append(alphabet[Int((state >> 32) % UInt64(alphabet.count))])
            }
            emit(bytes, delimiter: delimiters[count % delimiters.count], quote: quotes[count % quotes.count])
        }
        for length in [15, 16, 17, 31, 32, 33, 65_535, 65_536, 65_537] {
            let prefix = Array(String(repeating: "x", count: length).utf8)
            for tail in [",\n", "\r\n", ",\"x,y\n\"\"z\"\n", ",last", ","] {
                emit(prefix + Array(tail.utf8))
            }
        }
        for quote in [false, true] {
            let row = quote ? "\"a\"\"b\",c\r\n" : "a,b,c\r\n"
            emit(Array(String(repeating: row, count: 150_001).utf8))
        }
        try output.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
        print("cases=\(cases) oracle_checks=\(oracleChecks) bytes=\(output.count)")
    }
}
