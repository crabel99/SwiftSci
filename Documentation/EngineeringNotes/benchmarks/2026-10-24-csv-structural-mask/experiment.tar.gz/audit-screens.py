from pathlib import Path
import json,statistics,sys
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent;sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
from Benchmarks.CPUThroughput.budget import jobs_for
paths=[R/'baseline-controls',R/'household-screen',R/'default-null-result/screen']
for name in ['nibble-formats','nibble-densities','stress-results']:paths.extend(sorted((R/name).glob('*-screen')))
queues=jobs=0
for D in paths:
 plan=json.loads((D/'plan.json').read_text());records=json.loads((D/'records.json').read_text());decision=json.loads((D/'decision.json').read_text())
 required={(i,label) for i,order in enumerate(plan['orders']) for label in order}
 assert len(records)==len(required) and {(r['round'],r['label']) for r in records}==required
 assert decision['qualified'] and not decision['flags']
 for r in records:
  raw=json.loads((D/f"r{r['round']}-{r['label']}"/'result.json').read_text());summary=raw['summary'];assert summary==r['summary']
  expected=jobs_for([plan['case']],plan['jobs_per_queue'],0)
  recomputed=run.summarize(raw['jobs'],summary['elapsed_ns'],raw['memory_samples'],expected)
  assert all(summary[k]==v for k,v in recomputed.items())
  assert summary['worker_cpu_ns']==sum(b['cpu_ns']-a['cpu_ns'] for a,b in zip(raw['before'],raw['after']))
  assert summary['charged_cpu_ns']==summary['worker_cpu_ns']+summary['controller_cpu_ns']
  assert all(x['storage']==('optional' if r['label'].startswith('optional') else 'compact') for x in raw['jobs'])
  jobs+=len(raw['jobs']);queues+=1
 labels=[x for x in decision['medians']]
 for label in labels:
  for key,value in decision['medians'][label].items():assert value==statistics.median(r['summary'][key] for r in records if r['label'].removesuffix('_twin')==label)
result=dict(screens=len(paths),queues=queues,reads=jobs,CPU_and_RSS_recomputed=True,interrupted_long_diagnostic_excluded=True)
run.save(R/'screen-audit.json',result);print(json.dumps(result,indent=2))
