"""Forecast a diagnostic from its existing matched screen before scheduling more reads."""
from pathlib import Path
import argparse,json,statistics,sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--screen',type=Path,required=True)
p.add_argument('--reads-per-queue',type=int,default=32)
p.add_argument('--rounds',type=int,default=8)
p.add_argument('--max-wall-seconds',type=float,default=120)
p.add_argument('--max-cpu-seconds',type=float,default=600)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();plan=json.loads((a.screen/'plan.json').read_text());rows=json.loads((a.screen/'records.json').read_text())
assert a.reads_per_queue>0 and a.rounds>0
labels=plan['orders'][0];jobs=a.reads_per_queue*a.rounds*len(labels)
per_read={label:{key:statistics.median(r['summary'][key] for r in rows if r['label']==label)/plan['jobs_per_queue']/1e9 for key in ['elapsed_ns','charged_cpu_ns']} for label in labels}
wall=max(v['elapsed_ns'] for v in per_read.values())*jobs;cpu=max(v['charged_cpu_ns'] for v in per_read.values())*jobs
result=dict(reference_screen=str(a.screen),planned_reads=jobs,projected_wall_seconds=wall,projected_cpu_seconds=cpu,wall_budget_seconds=a.max_wall_seconds,cpu_budget_seconds=a.max_cpu_seconds,allowed=wall<=a.max_wall_seconds and cpu<=a.max_cpu_seconds,method='Conservative maximum of label median per-read costs, scaled linearly; estimate, not a guaranteed runtime bound',worker_sha256=plan['worker_sha256'],trial_sha256=plan.get('trial_sha256'))
a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
sys.exit(0 if result['allowed'] else 2)
