from pathlib import Path
import sys,json,hashlib,struct,subprocess
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
D=R/'stress-results';D.mkdir()
parent=Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker');trial=R/'nibble-build/worker'
for p in sorted((R/'stress').glob('*.json')):
 m=json.loads(p.read_text());missing=m['id']=='dense-empty';token=b'\0' if missing else b'\1'+struct.pack('<d',1.0)
 digest=hashlib.sha256(token*m['rows']).hexdigest()
 expected=dict(frame=dict(rows=m['rows'],columns=[dict(name=name,type='Double',nulls=m['rows'] if missing else 0,sha256=digest) for name in m['names']]),matrix_sha256='absent')
 run.save(D/(m['id']+'-expected.json'),expected)
 checks=[]
 for label,binary in [('parent',parent),('trial',trial)]:
  for storage in ['optional','compact']:
   worker=run.Worker(binary,storage,D/(m['id']+'-'+label+'-'+storage+'.log'))
   try:
    actual=worker.ask(dict(id=0,contract=str(p),workflow='read',key='x',verify=True))['check'];assert actual==expected
    checks.append(dict(build=label,storage=storage,check=actual))
   finally:worker.close()
 run.save(D/(m['id']+'-checks.json'),checks)
 subprocess.run(['python3',str(R/'measure.py'),'--worker',str(parent),'--trial',str(trial),'--contract',str(p),'--rounds','8','--out',str(D/(m['id']+'-screen'))],check=True)
