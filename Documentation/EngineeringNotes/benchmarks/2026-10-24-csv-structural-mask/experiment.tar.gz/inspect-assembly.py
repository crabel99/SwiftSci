from pathlib import Path
import subprocess,re,json
R=Path(__file__).parent;counts={}
for name,binary in [('parent',Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker')),('nibble',R/'nibble-build/worker')]:
 symbols=[line.split()[-1] for line in subprocess.check_output(['xcrun','nm','-n',str(binary)],text=True).splitlines() if '11scanRecords' in line]
 text='\n'.join(subprocess.check_output(['xcrun','llvm-objdump','--no-show-raw-insn','--disassemble-symbols='+symbol,str(binary)],text=True) for symbol in symbols)
 (R/(name+'-scanner-assembly.txt')).write_text(text)
 counts[name]=dict(symbols=len(symbols),horizontal_reductions=len(re.findall(r'\t(?:uaddlv|addv)\b',text)),shift_narrow=len(re.findall(r'\tshrn\b',text)))
(R/'assembly-summary.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts,indent=2))
