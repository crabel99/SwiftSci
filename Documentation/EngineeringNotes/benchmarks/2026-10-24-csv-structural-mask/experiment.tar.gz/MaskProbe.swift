import Foundation

@inline(never)
func pack(_ flags: SIMD16<UInt8>) -> UInt64 {
    let words = unsafeBitCast(flags, to: SIMD8<UInt16>.self)
    let nibbles = SIMD8<UInt8>(truncatingIfNeeded: words &>> 4)
    return unsafeBitCast(nibbles, to: UInt64.self) & 0x1111_1111_1111_1111
}

@main struct Probe {
    static func main() {
        for mask in 0..<65_536 {
            var flags = SIMD16<UInt8>.zero
            var expected: UInt64 = 0
            for lane in 0..<16 where mask & (1 << lane) != 0 {
                flags[lane] = 255
                expected |= UInt64(1) << (lane * 4)
            }
            precondition(pack(flags) == expected)
        }
        print("All 65536 SIMD mask patterns match their scalar oracle")
    }
}
