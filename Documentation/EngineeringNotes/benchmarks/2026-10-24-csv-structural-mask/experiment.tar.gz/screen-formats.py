from pathlib import Path
import sys,json,subprocess
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
D=R/'nibble-formats';D.mkdir()
binaries={'parent':Path('/private/tmp/swiftsci-compact-conversion-20261024/baseline-build/worker'),'candidate':R/'nibble-build/worker'}
for contract in sorted((R/'formats').glob('*.json')):
 if contract.name.endswith('-expected.json'):continue
 name=contract.stem;expected=json.loads(contract.with_name(name+'-expected.json').read_text());checks=[]
 for label,binary in binaries.items():
  for storage in ['optional','compact']:
   worker=run.Worker(binary,storage,D/(name+'-'+label+'-'+storage+'.log'))
   try:
    check=worker.ask(dict(id=0,contract=str(contract),workflow='read',key='x',verify=True))['check'];assert check==expected
    checks.append(dict(binary=label,storage=storage,check=check))
   finally:worker.close()
 run.save(D/(name+'-checks.json'),checks)
 subprocess.run(['python3',str(R/'measure.py'),'--worker',str(binaries['parent']),'--trial',str(binaries['candidate']),'--contract',str(contract),'--rounds','6','--out',str(D/(name+'-screen'))],cwd=S,check=True)
 print(name,'complete',flush=True)
