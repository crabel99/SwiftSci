	.build_version macos, 14, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_$s9MaskProbe4packys6UInt64Vs6SIMD16Vys5UInt8VGF ; -- Begin function $s9MaskProbe4packys6UInt64Vs6SIMD16Vys5UInt8VGF
	.globl	_$s9MaskProbe4packys6UInt64Vs6SIMD16Vys5UInt8VGF
	.p2align	2
_$s9MaskProbe4packys6UInt64Vs6SIMD16Vys5UInt8VGF: ; @"$s9MaskProbe4packys6UInt64Vs6SIMD16Vys5UInt8VGF"
; %bb.0:
	shrn.8b	v0, v0, #4
	fmov	x8, d0
	and	x0, x8, #0x1111111111111111
	ret
                                        ; -- End function
	.private_extern	_$s9MaskProbe0B0V4mainyyFZ ; -- Begin function $s9MaskProbe0B0V4mainyyFZ
	.globl	_$s9MaskProbe0B0V4mainyyFZ
	.p2align	2
_$s9MaskProbe0B0V4mainyyFZ:             ; @"$s9MaskProbe0B0V4mainyyFZ"
	.cfi_startproc
; %bb.0:
	b	_$s9MaskProbe0B0V4mainyyFZTf4d_n
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9MaskProbe0B0V5$mainyyFZ ; -- Begin function $s9MaskProbe0B0V5$mainyyFZ
	.globl	_$s9MaskProbe0B0V5$mainyyFZ
	.p2align	2
_$s9MaskProbe0B0V5$mainyyFZ:            ; @"$s9MaskProbe0B0V5$mainyyFZ"
	.cfi_startproc
; %bb.0:
	b	_$s9MaskProbe0B0V4mainyyFZTf4d_n
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9MaskProbe0B0VACycfC ; -- Begin function $s9MaskProbe0B0VACycfC
	.globl	_$s9MaskProbe0B0VACycfC
	.p2align	2
_$s9MaskProbe0B0VACycfC:                ; @"$s9MaskProbe0B0VACycfC"
; %bb.0:
	ret
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_$s9MaskProbe0B0V4mainyyFZTf4d_n
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function $s9MaskProbe0B0V4mainyyFZTf4d_n
lCPI5_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_$s9MaskProbe0B0V4mainyyFZTf4d_n
	.globl	_$s9MaskProbe0B0V4mainyyFZTf4d_n
	.weak_def_can_be_hidden	_$s9MaskProbe0B0V4mainyyFZTf4d_n
	.p2align	2
_$s9MaskProbe0B0V4mainyyFZTf4d_n:       ; @"$s9MaskProbe0B0V4mainyyFZTf4d_n"
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, #0                         ; =0x0
	mov	w20, #255                       ; =0xff
	mov	w21, #1                         ; =0x1
LBB5_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_3 Depth 2
	mov	x8, #0                          ; =0x0
	mov	x22, #0                         ; =0x0
	mov	x9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	b	LBB5_3
LBB5_2:                                 ;   in Loop: Header=BB5_3 Depth=2
	add	x8, x8, #4
	add	x9, x9, #1
	cmp	x8, #64
	b.eq	LBB5_5
LBB5_3:                                 ;   Parent Loop BB5_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x10, x19, x9
	tbz	w10, #0, LBB5_2
; %bb.4:                                ;   in Loop: Header=BB5_3 Depth=2
	str	q0, [sp]
	mov	x10, sp
	bfxil	x10, x9, #0, #4
	strb	w20, [x10]
	ldr	q0, [sp]
	lsl	x10, x21, x8
	orr	x22, x10, x22
	b	LBB5_2
LBB5_5:                                 ;   in Loop: Header=BB5_1 Depth=1
	bl	_$s9MaskProbe4packys6UInt64Vs6SIMD16Vys5UInt8VGF
	cmp	x0, x22
	b.ne	LBB5_8
; %bb.6:                                ;   in Loop: Header=BB5_1 Depth=1
	add	x19, x19, #1
	cmp	x19, #16, lsl #12               ; =65536
	b.ne	LBB5_1
; %bb.7:
Lloh0:
	adrp	x0, _$ss23_ContiguousArrayStorageCyypGMd@PAGE
Lloh1:
	add	x0, x0, _$ss23_ContiguousArrayStorageCyypGMd@PAGEOFF
Lloh2:
	adrp	x1, _$ss23_ContiguousArrayStorageCyypGMR@PAGE
Lloh3:
	add	x1, x1, _$ss23_ContiguousArrayStorageCyypGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameV2
	mov	w1, #64                         ; =0x40
	mov	w2, #7                          ; =0x7
	bl	_swift_allocObject
	mov	x19, x0
Lloh4:
	adrp	x8, lCPI5_0@PAGE
Lloh5:
	ldr	q0, [x8, lCPI5_0@PAGEOFF]
	str	q0, [x0, #16]
Lloh6:
	adrp	x8, "l_.str.54.All 65536 SIMD mask patterns match their scalar oracle"@PAGE
Lloh7:
	add	x8, x8, "l_.str.54.All 65536 SIMD mask patterns match their scalar oracle"@PAGEOFF
	sub	x8, x8, #32
	orr	x8, x8, #0x8000000000000000
Lloh8:
	adrp	x9, _$sSSN@GOTPAGE
Lloh9:
	ldr	x9, [x9, _$sSSN@GOTPAGEOFF]
	str	x9, [x0, #56]
	mov	x9, #54                         ; =0x36
	movk	x9, #53248, lsl #48
	stp	x9, x8, [x0, #32]
	mov	w1, #32                         ; =0x20
	mov	x2, #-2233785415175766016       ; =0xe100000000000000
	mov	w3, #10                         ; =0xa
	mov	x4, #-2233785415175766016       ; =0xe100000000000000
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	b	_swift_release
LBB5_8:
	brk	#0x1
	.loh AdrpLdrGot	Lloh8, Lloh9
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9MaskProbe0B0VMa     ; -- Begin function $s9MaskProbe0B0VMa
	.globl	_$s9MaskProbe0B0VMa
	.p2align	2
_$s9MaskProbe0B0VMa:                    ; @"$s9MaskProbe0B0VMa"
; %bb.0:
Lloh10:
	adrp	x0, _$s9MaskProbe0B0VMf@PAGE+16
Lloh11:
	add	x0, x0, _$s9MaskProbe0B0VMf@PAGEOFF+16
	mov	x1, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh10, Lloh11
                                        ; -- End function
	.private_extern	___swift_instantiateConcreteTypeFromMangledNameV2 ; -- Begin function __swift_instantiateConcreteTypeFromMangledNameV2
	.globl	___swift_instantiateConcreteTypeFromMangledNameV2
	.weak_def_can_be_hidden	___swift_instantiateConcreteTypeFromMangledNameV2
	.p2align	2
___swift_instantiateConcreteTypeFromMangledNameV2: ; @__swift_instantiateConcreteTypeFromMangledNameV2
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	x19, x0
	ldr	x0, [x0]
	and	x8, x0, #0x1
	cmp	x0, #0
	ccmp	x8, #0, #0, ne
	b.eq	LBB7_2
; %bb.1:
	ldr	x9, [x1]
	asr	x8, x9, #32
	add	x0, x1, w9, sxtw
	mov	x1, x8
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_swift_getTypeByMangledNameInContext2
	str	x0, [x19]
LBB7_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__swift5_entry,regular,no_dead_strip
	.p2align	2, 0x0                          ; @"\01l_entry_point"
l_entry_point:
	.long	_main-l_entry_point
	.long	1                               ; 0x1

	.section	__TEXT,__const
l_.str.9.MaskProbe:                     ; @.str.9.MaskProbe
	.asciz	"MaskProbe"

	.private_extern	_$s9MaskProbeMXM        ; @"$s9MaskProbeMXM"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9MaskProbeMXM
	.weak_definition	_$s9MaskProbeMXM
	.p2align	2, 0x0
_$s9MaskProbeMXM:
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	l_.str.9.MaskProbe-_$s9MaskProbeMXM-8

	.section	__TEXT,__const
l_.str.5.Probe:                         ; @.str.5.Probe
	.asciz	"Probe"

	.private_extern	_$s9MaskProbe0B0VMn     ; @"$s9MaskProbe0B0VMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9MaskProbe0B0VMn
	.p2align	2, 0x0
_$s9MaskProbe0B0VMn:
	.long	81                              ; 0x51
	.long	_$s9MaskProbeMXM-_$s9MaskProbe0B0VMn-4
	.long	l_.str.5.Probe-_$s9MaskProbe0B0VMn-8
	.long	_$s9MaskProbe0B0VMa-_$s9MaskProbe0B0VMn-12
	.long	_$s9MaskProbe0B0VMF-_$s9MaskProbe0B0VMn-16
	.long	0                               ; 0x0
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9MaskProbe0B0VMf"
_$s9MaskProbe0B0VMf:
	.quad	0
	.quad	_$sytWV
	.quad	512                             ; 0x200
	.quad	_$s9MaskProbe0B0VMn

	.private_extern	"_symbolic _____ 9MaskProbe0B0V" ; @"symbolic _____ 9MaskProbe0B0V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 9MaskProbe0B0V"
	.weak_definition	"_symbolic _____ 9MaskProbe0B0V"
	.p2align	1, 0x0
"_symbolic _____ 9MaskProbe0B0V":
	.byte	1                               ; 0x1
	.long	_$s9MaskProbe0B0VMn-"_symbolic _____ 9MaskProbe0B0V"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s9MaskProbe0B0VMF"
_$s9MaskProbe0B0VMF:
	.long	"_symbolic _____ 9MaskProbe0B0V"-_$s9MaskProbe0B0VMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	0                               ; 0x0

	.private_extern	__swift_FORCE_LOAD_$_swiftFoundation_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swiftFoundation_$_MaskProbe"
	.section	__DATA,__const
	.globl	__swift_FORCE_LOAD_$_swiftFoundation_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swiftFoundation_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftFoundation_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swiftFoundation

	.private_extern	__swift_FORCE_LOAD_$_swift_Builtin_float_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swift_Builtin_float_$_MaskProbe"
	.globl	__swift_FORCE_LOAD_$_swift_Builtin_float_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swift_Builtin_float_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swift_Builtin_float_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swift_Builtin_float

	.private_extern	__swift_FORCE_LOAD_$_swiftObjectiveC_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swiftObjectiveC_$_MaskProbe"
	.globl	__swift_FORCE_LOAD_$_swiftObjectiveC_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swiftObjectiveC_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftObjectiveC_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swiftObjectiveC

	.private_extern	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swiftCoreFoundation_$_MaskProbe"
	.globl	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftCoreFoundation_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swiftCoreFoundation

	.private_extern	__swift_FORCE_LOAD_$_swiftDispatch_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swiftDispatch_$_MaskProbe"
	.globl	__swift_FORCE_LOAD_$_swiftDispatch_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swiftDispatch_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftDispatch_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swiftDispatch

	.private_extern	__swift_FORCE_LOAD_$_swiftXPC_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swiftXPC_$_MaskProbe"
	.globl	__swift_FORCE_LOAD_$_swiftXPC_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swiftXPC_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftXPC_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swiftXPC

	.private_extern	__swift_FORCE_LOAD_$_swiftIOKit_$_MaskProbe ; @"_swift_FORCE_LOAD_$_swiftIOKit_$_MaskProbe"
	.globl	__swift_FORCE_LOAD_$_swiftIOKit_$_MaskProbe
	.weak_definition	__swift_FORCE_LOAD_$_swiftIOKit_$_MaskProbe
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftIOKit_$_MaskProbe:
	.quad	__swift_FORCE_LOAD_$_swiftIOKit

	.private_extern	"_symbolic _____yypG s23_ContiguousArrayStorageC" ; @"symbolic _____yypG s23_ContiguousArrayStorageC"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____yypG s23_ContiguousArrayStorageC"
	.weak_definition	"_symbolic _____yypG s23_ContiguousArrayStorageC"
	.p2align	1, 0x0
"_symbolic _____yypG s23_ContiguousArrayStorageC":
	.byte	2                               ; 0x2
Ltmp0:
	.long	_$ss23_ContiguousArrayStorageCMn@GOT-Ltmp0
	.ascii	"yypG"
	.byte	0                               ; 0x0

	.private_extern	_$ss23_ContiguousArrayStorageCyypGMd ; @"$ss23_ContiguousArrayStorageCyypGMd"
	.section	__DATA,__data
	.globl	_$ss23_ContiguousArrayStorageCyypGMd
	.weak_definition	_$ss23_ContiguousArrayStorageCyypGMd
	.p2align	3, 0x0
_$ss23_ContiguousArrayStorageCyypGMd:
	.space	8

	.private_extern	_$ss23_ContiguousArrayStorageCyypGMR ; @"$ss23_ContiguousArrayStorageCyypGMR"
	.section	__TEXT,__const
	.globl	_$ss23_ContiguousArrayStorageCyypGMR
	.weak_definition	_$ss23_ContiguousArrayStorageCyypGMR
	.p2align	3, 0x0
_$ss23_ContiguousArrayStorageCyypGMR:
	.long	"_symbolic _____yypG s23_ContiguousArrayStorageC"-_$ss23_ContiguousArrayStorageCyypGMR
	.long	9                               ; 0x9

	.section	__TEXT,__cstring,cstring_literals
	.p2align	4, 0x0                          ; @".str.54.All 65536 SIMD mask patterns match their scalar oracle"
"l_.str.54.All 65536 SIMD mask patterns match their scalar oracle":
	.asciz	"All 65536 SIMD mask patterns match their scalar oracle"

	.section	__TEXT,__swift5_types
	.p2align	2, 0x0                          ; @"$s9MaskProbe0B0VHn"
l_$s9MaskProbe0B0VHn:
	.long	_$s9MaskProbe0B0VMn-l_$s9MaskProbe0B0VHn

	.private_extern	___swift_reflection_version ; @__swift_reflection_version
	.section	__TEXT,__const
	.globl	___swift_reflection_version
	.weak_definition	___swift_reflection_version
	.p2align	1, 0x0
___swift_reflection_version:
	.short	3                               ; 0x3

	.no_dead_strip	l_entry_point
	.no_dead_strip	l_$s9MaskProbe0B0VHn
	.no_dead_strip	_$s9MaskProbe0B0VMF
	.no_dead_strip	___swift_reflection_version
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_MaskProbe
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftDispatch_$_MaskProbe
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftFoundation_$_MaskProbe
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftIOKit_$_MaskProbe
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftObjectiveC_$_MaskProbe
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftXPC_$_MaskProbe
	.no_dead_strip	__swift_FORCE_LOAD_$_swift_Builtin_float_$_MaskProbe
	.no_dead_strip	_main
	.linker_option "-lswiftFoundation"
	.linker_option "-framework", "Foundation"
	.linker_option "-lswiftCore"
	.linker_option "-lswift_DarwinFoundation3"
	.linker_option "-lswift_DarwinFoundation1"
	.linker_option "-lswift_Builtin_float"
	.linker_option "-lswift_DarwinFoundation2"
	.linker_option "-lswift_StringProcessing"
	.linker_option "-lswift_Concurrency"
	.linker_option "-lswiftSystem"
	.linker_option "-lswiftDarwin"
	.linker_option "-lswiftObservation"
	.linker_option "-lswiftObjectiveC"
	.linker_option "-lswiftCoreFoundation"
	.linker_option "-framework", "CoreFoundation"
	.linker_option "-lswiftDispatch"
	.linker_option "-framework", "Combine"
	.linker_option "-framework", "CoreServices"
	.linker_option "-framework", "Security"
	.linker_option "-lswiftXPC"
	.linker_option "-framework", "CFNetwork"
	.linker_option "-framework", "DiskArbitration"
	.linker_option "-lswiftIOKit"
	.linker_option "-framework", "IOKit"
	.linker_option "-lobjc"
	.section	__DATA,__objc_imageinfo,regular,no_dead_strip
L_OBJC_IMAGE_INFO:
	.long	0
	.long	100927296

	.globl	_$s9MaskProbe0B0VN
	.private_extern	_$s9MaskProbe0B0VN
	.alt_entry	_$s9MaskProbe0B0VN
_$s9MaskProbe0B0VN = _$s9MaskProbe0B0VMf+16
	.weak_reference __swift_FORCE_LOAD_$_swiftFoundation
	.weak_reference __swift_FORCE_LOAD_$_swift_Builtin_float
	.weak_reference __swift_FORCE_LOAD_$_swiftObjectiveC
	.weak_reference __swift_FORCE_LOAD_$_swiftCoreFoundation
	.weak_reference __swift_FORCE_LOAD_$_swiftDispatch
	.weak_reference __swift_FORCE_LOAD_$_swiftXPC
	.weak_reference __swift_FORCE_LOAD_$_swiftIOKit
.subsections_via_symbols
