from pathlib import Path
import json,hashlib,csv,struct
R=Path(__file__).parent;D=R/'formats';D.mkdir(exist_ok=True)
patterns={
 'one-digit':lambda i:str((-1 if i%2 else 1)*(i%10)),
 'six-fraction':lambda i:f'{(-1 if i%2 else 1)*(i%100000)}.{i%1000000:06d}',
 'short-limit':lambda i:f'{(-1 if i%2 else 1)*(100000000+i%100000)}.{i%100000:05d}',
 'scientific':lambda i:f'{(-1 if i%2 else 1)*(i%10000)}.{i%1000:03d}e{(i%41)-20:+d}',
 'long-fallback':lambda i:f'{(-1 if i%2 else 1)*(1000000000+i%100000)}.{i%1000000000:09d}',
 'quoted-padded':lambda i:' \t'+f'{(-1 if i%2 else 1)*(i%10000)}.{i%100000:05d}'+' '
}
for name,token in patterns.items():
 p=D/(name+'.csv');rows=250003
 with p.open('w',newline='') as f:
  writer=csv.writer(f,lineterminator='\n',quoting=csv.QUOTE_ALL if name=='quoted-padded' else csv.QUOTE_MINIMAL);writer.writerow(['x'])
  for i in range(rows):writer.writerow(['?' if i%97==96 else token(i)])
 h=hashlib.sha256();nulls=0
 with p.open(newline='') as f:
  reader=csv.reader(f);assert next(reader)==['x']
  for row in reader:
   text=row[0]
   if text=='?':nulls+=1;h.update(b'\0')
   else:h.update(b'\1'+struct.pack('<d',float(text)))
 manifest=dict(id=name,path=str(p),rows=rows,names=['x'],types=['Double'],null_tokens=['?'],delimiter=',',sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 expected=dict(frame=dict(rows=rows,columns=[dict(name='x',type='Double',nulls=nulls,sha256=h.hexdigest())]),matrix_sha256='absent')
 (D/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
 (D/(name+'-expected.json')).write_text(json.dumps(expected,indent=2)+'\n')
print('Prepared six reproducible number-format contracts')
