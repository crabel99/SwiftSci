from pathlib import Path
import hashlib,struct,json,subprocess,sys
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
D=R/'densities';D.mkdir()
for pattern in ['present','sparse','alternating','missing']:
 csv=D/(pattern+'.csv');h=hashlib.sha256();rows=1000003;nulls=0
 with csv.open('w') as out:
  out.write('x\n')
  for i in range(rows):
   missing=pattern=='missing' or (pattern=='sparse' and i%97==0) or (pattern=='alternating' and i%2==0)
   if missing:out.write('?\n');h.update(b'\0');nulls+=1
   else:
    value=(i%10000)/4;out.write(str(value)+'\n');h.update(b'\1'+struct.pack('<d',value))
 contract=D/(pattern+'.json')
 run.save(contract,dict(id=pattern,path=str(csv),rows=rows,names=['x'],types=['Double'],null_tokens=['?'],delimiter=',',sha256=run.digest(csv)))
 expected=dict(frame=dict(rows=rows,columns=[dict(name='x',type='Double',nulls=nulls,sha256=h.hexdigest())]),matrix_sha256='absent')
 for name,binary in [('parent',Path('/private/tmp/swiftsci-cpu-throughput-final-build-20261024/worker')),('candidate',R/'cold-build/worker')]:
  worker=run.Worker(binary,'compact',D/(pattern+'-'+name+'.log'))
  try:
   result=worker.ask(dict(id=0,contract=str(contract),workflow='read',key='x',verify=True));assert result['check']==expected
  finally:worker.close()
 subprocess.run(['python3',str(R/'measure.py'),'--worker','/private/tmp/swiftsci-cpu-throughput-final-build-20261024/worker','--trial',str(R/'cold-build/worker'),'--contract',str(contract),'--rounds','6','--out',str(D/(pattern+'-screen'))],cwd=S,check=True)
 print(pattern,'complete',flush=True)
