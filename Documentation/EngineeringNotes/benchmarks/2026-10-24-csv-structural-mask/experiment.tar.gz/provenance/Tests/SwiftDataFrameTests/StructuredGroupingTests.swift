import Foundation
import Testing
import SwiftDataFrame

@Suite("Structured group key equality")
struct StructuredGroupingTests {
    private func frame(_ keys: [any AnyColumn]) throws -> DataFrame {
        let count = keys.first?.count ?? 0
        return try DataFrame(columns: keys + [TypedColumn<Double>(
            name: "value", values: (1...max(count, 1)).prefix(count).map(Double.init))])
    }

    @Test func stringSentinelsAreValues() throws {
        let data = try frame([TypedColumn<String>(
            name: "key", values: [nil, "__null__", "null", "", nil, "__null__"])])
        let result = data.groupBy("key").sum()
        #expect(result[column: "key", as: String.self]?.values == [nil, "__null__", "null", ""])
        #expect(result[column: "value", as: Double.self]?.values == [6, 8, 3, 4])
    }

    @Test func tupleBoundariesAndNullsCannotCollide() throws {
        let data = try frame([
            TypedColumn<String>(name: "a", values: ["a||b", "a", nil, "null", "a||b", "a"]),
            TypedColumn<String>(name: "b", values: ["c", "b||c", "x", "x", "c", "b||c"])])
        #expect(data.groupBy("a", "b").sum()[column: "value", as: Double.self]?.values == [6, 8, 3, 4])
        #expect(data.groupBy("b", "a").sum()[column: "value", as: Double.self]?.values == [6, 8, 3, 4])
        #expect(data.groupBy("a", "b").transform(["value": .sum])[column: "value_group_sum", as: Double.self]?.values == [6, 8, 3, 4, 6, 8])
    }

    @Test func threeKeysPreserveExactIntegersAndOrder() throws {
        let high = Int64(9_007_199_254_740_992)
        let data = try frame([
            TypedColumn<Int64>(name: "a", values: [high, high + 1, high, high, high + 1]),
            TypedColumn<Int32>(name: "b", values: [1, 1, 1, 2, 1]),
            TypedColumn<String>(name: "c", values: ["x", "x", "x", "x", "x"])])
        let result = data.groupBy("a", "b", "c").sum()
        #expect(result[column: "a", as: String.self]?.values == [String(high), String(high + 1), String(high)])
        #expect(result[column: "value", as: Double.self]?.values == [4, 7, 4])
    }

    @Test func floatingKeysHaveExplicitEquality() throws {
        let values: [Double?] = [-0.0, 0.0, .nan, Double(bitPattern: 0x7ff8000000000001), nil, .infinity, -.infinity, nil]
        for key in [
            TypedColumn<Double>(name: "key", values: values) as any AnyColumn,
            TypedColumn<Float>(name: "key", values: values.map { $0.map(Float.init) })
        ] {
            let data = try frame([key, TypedColumn<Bool>(name: "kind", values: Array(repeating: true, count: values.count))])
            for result in [data.groupBy("key").sum(), data.groupBy("key", "kind").sum()] {
                #expect(result[column: "value", as: Double.self]?.values == [3, 7, 13, 6, 7])
                #expect(result[column: "key", as: String.self]?.values.first == "-0.0")
            }
        }
    }

    @Test func datesKeepSubsecondIdentityAndBoolsKeepNull() throws {
        let date = Date(timeIntervalSince1970: 1_000)
        let later = date.addingTimeInterval(0.001)
        let data = try frame([
            TypedColumn<Date>(name: "date", values: [date, later, date, date, date]),
            TypedColumn<Bool>(name: "flag", values: [true, true, true, false, nil])])
        #expect(data.groupBy("date", "flag").sum()[column: "value", as: Double.self]?.values == [4, 2, 4, 5])
        #expect(data.groupBy("date").sum()[column: "value", as: Double.self]?.values == [13, 2])
    }

    @Test func generatedTuplesMatchIndependentRowEquality() throws {
        let keys: [Int64?] = (0..<257).map { (index: Int) -> Int64? in
            if index % 13 == 0 { return nil }
            let offset = Int64(index % 17)
            return 9_007_199_254_740_992 + offset
        }
        let labels: [String?] = (0..<257).map { [nil, "null", "__null__", "a||b", ""][($0 * 7) % 5] }
        var representatives: [Int] = []
        var sums: [Double] = []
        var expectedRows: [Int] = []
        for row in keys.indices {
            let found = representatives.firstIndex { keys[$0] == keys[row] && labels[$0] == labels[row] }
            let group = found ?? representatives.count
            if found == nil { representatives.append(row); sums.append(0) }
            sums[group] += Double(row + 1)
            expectedRows.append(group)
        }
        let data = try frame([TypedColumn<Int64>(name: "key", values: keys), TypedColumn<String>(name: "label", values: labels)])
        let result = data.groupBy("key", "label").sum()
        #expect(result[column: "key", as: String.self]?.values == representatives.map { keys[$0].map(String.init) })
        #expect(result[column: "label", as: String.self]?.values == representatives.map { labels[$0] })
        #expect(result[column: "value", as: Double.self]?.values == sums.map(Optional.init))
        #expect(data.groupBy("key", "label").transform(["value": .sum])[column: "value_group_sum", as: Double.self]?.values == expectedRows.map { Optional(sums[$0]) })
    }

    private struct CollisionKey: Hashable, CustomStringConvertible {
        let value: Int
        var description: String { "same text" }
        func hash(into hasher: inout Hasher) { hasher.combine(0) }
    }

    private struct TextKey: CustomStringConvertible {
        let value: Int
        var description: String { "text\(value)" }
    }

    @Test func erasedHashableKeysUseEqualityAfterHashCollision() throws {
        let key = DataFrameRelease35CoverageTests.CustomGenericColumn(
            name: "key", dtype: .utf8,
            rawValues: [CollisionKey(value: 2), CollisionKey(value: 1), CollisionKey(value: 2), nil])
        let data = try frame([key])
        #expect(data.groupBy("key").sum()[column: "value", as: Double.self]?.values == [4, 2, 4])
    }

    @Test func erasedKeysKeepRuntimeTypesDistinct() throws {
        let key = DataFrameRelease35CoverageTests.CustomGenericColumn(
            name: "key", dtype: .utf8,
            rawValues: [Int(1), Int64(1), Double(1), "1", true, Int(1)])
        #expect(try frame([key]).groupBy("key").sum()[column: "value", as: Double.self]?.values == [7, 2, 3, 4, 5])
    }

    @Test func erasedFloatingKeysMatchTypedRules() throws {
        let key = DataFrameRelease35CoverageTests.CustomGenericColumn(
            name: "key", dtype: .float64,
            rawValues: [-0.0, 0.0, Double.nan, Double(bitPattern: 0x7ff8000000000001), nil])
        #expect(try frame([key]).groupBy("key").sum()[column: "value", as: Double.self]?.values == [3, 7, 5])
    }

    @Test func erasedFloatKeysNormalizeZerosAndNaNs() throws {
        let key = DataFrameRelease35CoverageTests.CustomGenericColumn(
            name: "key", dtype: .float32,
            rawValues: [Float(-0.0), Float(0.0), Float.nan,
                Float(bitPattern: 0x7fc0_0001), nil, Float.infinity,
                -Float.infinity, nil, Float(1), Float(1)])
        let result = try frame([key]).groupBy("key").sum()
        #expect(result.shape.rows == 6)
        #expect(result[column: "value", as: Double.self]?.values == [3, 7, 13, 6, 7, 19])
        let keys = try #require(result[column: "key", as: String.self])
        #expect(keys.values.first == "-0.0")
        #expect(keys.values[2] == nil)
        #expect(keys.nullCount == 1)
    }

    @Test(arguments: [false, true])
    func countsWithoutNumericValuesPreserveOrderAndNullGroups(includeTextColumn: Bool) throws {
        var columns: [any AnyColumn] = [TypedColumn<String>(
            name: "key", values: ["beta", "alpha", "beta", nil, nil, "alpha", "beta"])]
        if includeTextColumn {
            columns.append(TypedColumn<String>(
                name: "note", values: ["x", nil, "y", nil, "x", "y", nil]))
        }
        let data = try DataFrame(columns: columns)
        let result = data.groupBy("key").count()
        #expect(result.columnNames == ["key", "count"])
        #expect(result.shape.rows == 3)
        #expect(result[column: "key", as: String.self]?.values == ["beta", "alpha", nil])
        let counts = try #require(result[column: "count", as: Int64.self])
        #expect(counts.values == [3, 2, 2])
        #expect(counts.nullCount == 0)
    }

    @Test func nonHashableFallbackRemainsPerComponent() throws {
        let key = DataFrameRelease35CoverageTests.CustomGenericColumn(
            name: "key", dtype: .utf8,
            rawValues: [TextKey(value: 1), TextKey(value: 2), TextKey(value: 1), nil])
        let data = try frame([key, TypedColumn<String>(name: "kind", values: ["x", "x", "x", "text1"])])
        #expect(data.groupBy("key", "kind").sum()[column: "value", as: Double.self]?.values == [4, 2, 4])
    }
}
