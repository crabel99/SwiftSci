from pathlib import Path
import json,statistics
R=Path(__file__).parent
out={}
for name in ['nibble-workflows','nibble-workflows-reversed']:
 p=R/name/'decision.json'
 if not p.exists():continue
 d=json.loads(p.read_text());result=dict(qualified=d['qualified'],flags=d['flags'],jobs=d['jobs'],storage={})
 for storage in ['optional','compact']:
  a=d['medians']['parent_'+storage];b=d['medians']['candidate_'+storage]
  cases={key:dict(parent_ms=v/1e6,candidate_ms=d['per_case_operation_cpu_ns']['candidate_'+storage][key]/1e6,change_percent=100*(d['per_case_operation_cpu_ns']['candidate_'+storage][key]/v-1)) for key,v in d['per_case_operation_cpu_ns']['parent_'+storage].items()}
  result['storage'][storage]=dict(parent_cpu_ms_per_job=a['charged_cpu_ns']/128/1e6,candidate_cpu_ms_per_job=b['charged_cpu_ns']/128/1e6,cpu_change_percent=100*(b['charged_cpu_ns']/a['charged_cpu_ns']-1),parent_peak_MiB=a['sampled_peak_rss_bytes']/2**20,candidate_peak_MiB=b['sampled_peak_rss_bytes']/2**20,parent_throughput=a['completed_per_minute'],candidate_throughput=b['completed_per_minute'],throughput_change_percent=100*(b['completed_per_minute']/a['completed_per_minute']-1),paired=d['paired'][storage],cases=cases)
 out[name]=result
for directory in ['nibble-formats','nibble-densities','stress-results']:
 out[directory]={}
 for p in sorted((R/directory).glob('*-screen/decision.json')):
  d=json.loads(p.read_text());a=d['medians']['compact'];b=d['medians']['trial']
  out[directory][p.parent.name]=dict(qualified=d['qualified'],flags=d['flags'],parent_cpu_ms=a['charged_cpu_ns']/4/1e6,candidate_cpu_ms=b['charged_cpu_ns']/4/1e6,cpu_change_percent=100*(b['charged_cpu_ns']/a['charged_cpu_ns']-1),parent_peak_MiB=a['sampled_peak_rss_bytes']/2**20,candidate_peak_MiB=b['sampled_peak_rss_bytes']/2**20)
(R/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
