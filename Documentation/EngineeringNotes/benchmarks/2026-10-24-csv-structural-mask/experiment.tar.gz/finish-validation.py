from pathlib import Path
import subprocess,json
R=Path(__file__).parent
for category,count in [('nibble-formats',6),('nibble-densities',4),('stress-results',2)]:
 results=list((R/category).glob('*-screen/decision.json'));assert len(results)==count
 for p in results:
  d=json.loads(p.read_text());assert d['qualified'] and not d['flags'],p
steps=[['python3',str(R/'nibble-validation/validate.py')],['python3',str(R/'compare-workflows.py')],['python3',str(R/'audit-workflows.py'),'nibble-workflows'],['python3',str(R/'compare-workflows-reversed.py')],['python3',str(R/'audit-workflows.py'),'nibble-workflows-reversed'],['python3',str(R/'analyze.py')]]
for i,command in enumerate(steps):
 with (R/f'validation-stage-{i}.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('completed',i,flush=True)
(R/'completed.json').write_text(json.dumps(dict(steps=steps,complete=True),indent=2)+'\n')
