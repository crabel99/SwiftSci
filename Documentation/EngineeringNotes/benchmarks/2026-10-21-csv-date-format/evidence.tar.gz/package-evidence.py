from pathlib import Path
import hashlib,json,subprocess,tarfile
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-date-format-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-21-csv-date-format')
assert json.loads((R/'verification.json').read_text())['passed']
N.mkdir(parents=True,exist_ok=True)
source=R/'source';source.mkdir(exist_ok=True)
(source/'feature.patch').write_bytes(subprocess.check_output(['git','diff','548a783f02678c95c027a733e3cbd51df363dc47','HEAD'],cwd=S))
(source/'commit.txt').write_bytes(subprocess.check_output(['git','show','--no-patch','--format=fuller','HEAD'],cwd=S))
files=[]
for p in R.rglob('*'):
 if not p.is_file():continue
 relative=p.relative_to(R)
 if any(x.endswith('.xcresult') or x in ['module-cache'] for x in relative.parts):continue
 if p.suffix not in ['.json','.jsonl','.py','.swift','.patch','.txt','.log','.stderr']:continue
 files.append(p)
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(N/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=N/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(R)),recursive=False)
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(manifest)
 for member in t:
  assert hashlib.sha256(t.extractfile(member).read()).hexdigest()==manifest[member.name]
(N/'verification.json').write_bytes((R/'verification.json').read_bytes())
print(dict(files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
