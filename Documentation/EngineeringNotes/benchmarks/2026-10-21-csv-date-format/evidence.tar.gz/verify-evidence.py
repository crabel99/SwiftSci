from pathlib import Path
import hashlib,json,subprocess
V=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-date-format-20261021')
base='548a783f02678c95c027a733e3cbd51df363dc47'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head!=base and not subprocess.check_output(['git','status','--porcelain'],cwd=S)
red=json.loads((V/'red-behavior-summary.json').read_text());cmd=json.loads((V/'red-behavior-command.json').read_text())
assert red['failedTests']==1 and red['passedTests']==343 and cmd['exit_code']!=0
f='Sources/SwiftDataFrame/IO/CSVReader.swift'
assert cmd['source_sha256'][f]==hashlib.sha256(subprocess.check_output(['git','show',base+':'+f],cwd=S)).hexdigest()
f='Tests/SwiftDataFrameTests/CSVDateFormatTests.swift';assert cmd['source_sha256'][f]==h(S/f)
for label in ['green','release']:
 c=json.loads((V/(label+'-command.json')).read_text());r=json.loads((V/(label+'-summary.json')).read_text())
 assert c['exit_code']==0 and r['passedTests']==344 and r['failedTests']==r['skippedTests']==0
 for f,d in c['source_sha256'].items():assert h(S/f)==d
cov=json.loads((V/'patch-coverage.json').read_text());assert sum(x['covered'] for x in cov['results'])==15
for r in cov['results']:
 assert not r['uncovered'] and r['covered']==r['added_executable']
 assert h(S/'Sources/SwiftDataFrame/IO'/r['file'])==r['source_sha256']
 assert h(V/(r['file']+'.coverage.txt'))==r['coverage_sha256']
R=V/'reference';build=json.loads((R/'build/explicit/build.json').read_text())
for f,d in build['sources'].items():assert h(S/f)==d
assert h(R/'ResourceProbe.swift')==build['harness_sha256']
assert h(R/'build/explicit/ResourceProbe')==build['binary_sha256']
for label in ['prefix','full']:
 data=json.loads((R/(label+'-known.json')).read_text());oracle=json.loads((R/(label+'.json')).read_text())
 assert data['validated'] and data['checks']['passed']
 assert [c['sha256'] for c in data['checks']['columns']]==oracle['hashes']
 assert [c['nulls'] for c in data['checks']['columns']]==oracle['null_counts']
 assert h(Path(oracle['path']))==oracle['sha256']
data=json.loads((R/'prefix-infer.json').read_text());assert not data['validated'] and data['checks']['failures']==['values/nulls: Date']
old=json.loads(Path('/private/tmp/swiftsci-csv-inference-checks-20261021/reference/date-audit.json').read_text())
assert data['checks']==old['checks']
cert=json.loads((V/'tabular-smoke/certificate.json').read_text());run=json.loads((V/'tabular-smoke/run.json').read_text())
assert cert['status']==run['status']=='passed' and cert['validated_samples']==len(run['events'])==190
assert cert['source']['commit']==head and h(V/'tabular-smoke/run.json')==cert['run_sha256']
result=dict(passed=True,head=head,parent=base,red_failed_test=1,debug_passed=344,release_passed=344,added_executable_lines_covered=15,standard_validated_samples=190,explicit_date_reference_rows=2075259,default_date_diagnostic_unchanged=True)
(V/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
