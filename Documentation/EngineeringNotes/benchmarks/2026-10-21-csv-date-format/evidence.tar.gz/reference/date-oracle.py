from pathlib import Path
import csv,datetime,hashlib,json,struct
R=Path(__file__).resolve().parent
original=Path('/private/tmp/swiftsci-csv-reference-20261021')
source=json.loads((original/'cases.json').read_text())[0]
p=Path(source['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256']
hashes=[hashlib.sha256() for _ in source['names']]
prefix=[hashlib.sha256() for _ in hashes]
nulls=[0]*len(hashes);prefix_nulls=[0]*len(hashes);date_cache={}
with p.open(newline='',encoding='utf-8') as f:
 reader=csv.reader(f,delimiter=';');assert next(reader)==source['names']
 for count,row in enumerate(reader,1):
  assert len(row)==len(hashes)
  for j,v in enumerate(row):
   if v in source['null_tokens']:
    b=b'\0';nulls[j]+=1
    if count<=25000:prefix_nulls[j]+=1
   elif j==0:
    if v not in date_cache:
     d,m,y=map(int,v.split('/'))
     date_cache[v]=datetime.datetime(y,m,d,tzinfo=datetime.timezone.utc).timestamp()
    b=b'\1'+struct.pack('<d',date_cache[v])
   elif j==1:
    vb=v.encode();b=b'\1'+struct.pack('<I',len(vb))+vb
   else:b=b'\1'+struct.pack('<d',float(v))
   hashes[j].update(b)
   if count<=25000:prefix[j].update(b)
assert count==source['rows']
assert [h.hexdigest() for h in hashes[1:]]==source['hashes'][1:]
for label,n,hs,ns in [('full',count,hashes,nulls),('prefix',25000,prefix,prefix_nulls)]:
 data={k:source[k] for k in ['path','names','delimiter','null_tokens','integral','sha256','bytes']}
 data.update(id='energy-date-'+label,rows=n,max_rows=None if label=='full' else n,types=['Date','String']+['Double']*7,hashes=[h.hexdigest() for h in hs],null_counts=ns,date_format='d/M/yyyy',time_zone='UTC')
 (R/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
print(dict(rows=count,unique_dates=len(date_cache),date_hash=hashes[0].hexdigest()))
