from pathlib import Path
import json,subprocess,hashlib
R=Path(__file__).resolve().parent
binary=R/'build/explicit/ResourceProbe'
records=[]
for label,mode,expected in [('prefix','infer',False),('prefix','known',True),('full','known',True)]:
 args=[str(binary),str(R/(label+'.json')),mode,'audit','1']
 result=subprocess.run(args,capture_output=True,text=True,check=True,timeout=600)
 name=label+'-'+mode
 (R/(name+'.stderr')).write_text(result.stderr)
 data=json.loads(result.stdout);(R/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
 assert data['validated']==expected,(name,data['checks'])
 if expected:
  oracle=json.loads((R/(label+'.json')).read_text())
  assert [c['nulls'] for c in data['checks']['columns']]==oracle['null_counts']
 else:
  assert data['checks']['failures']==['values/nulls: Date']
 records.append(dict(case=name,command=args,expected_validated=expected,validated=data['validated'],failures=data['checks']['failures'],binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
 print(name,data['validated'],data['checks']['failures'],flush=True)
(R/'audit-summary.json').write_text(json.dumps(records,indent=2)+'\n')
