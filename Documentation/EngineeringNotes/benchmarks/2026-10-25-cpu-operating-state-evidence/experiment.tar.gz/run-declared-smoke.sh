#!/bin/sh
set -eu
cd /private/tmp/swiftsci-e-core-observer-isolation-20261025/source
exec /Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python Benchmarks/CPUThroughput/operating_state.py \
  --collect \
  --swift-worker /private/tmp/swiftsci-csv-integer-overflow-20261024/sequential-build/worker \
  --python /Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python \
  --air-contract /private/tmp/swiftsci-csv-external-20261023/inputs/Aotizhongxin-default.json \
  --energy-contract /private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json \
  --expected /private/tmp/swiftsci-sort-closeout-20261023/comparison-initialized/expected.json \
  --pandas-arrow --smoke \
  --output /private/tmp/swiftsci-cpu-operating-state-evidence-20261025/declared-smoke
