"""Preserve the diagnostic collection and verify its extracted file bytes."""
import hashlib,json,pathlib,tarfile,tempfile
q=pathlib.Path(__file__).resolve().parent
names=['README.md','REPLAY.md','review.md','final-review.md','review-disposition.md','decisions.tsv',
    'final-test-provenance.json','final-controller-tests.log','final-focused-tests.log',
    'declared-smoke-verification.json','integrity-verification.json','run-bound-tests.py',
    'verify-declared-smoke.py','verify-integrity.py','run-declared-smoke.sh','package-evidence.py',
    'implementation.patch','source-snapshot-verification.json','source-head.txt','source-status.txt','source-commits.txt',
    'declared-report.md','comparison-report.md','audit.json','method.json','retrospective-report.md','tests-before.log']
paths=[q/name for name in names]
paths += sorted(p for folder in ['source','declared-smoke','retrospective-final'] for p in (q/folder).rglob('*') if p.is_file())
if any(not p.is_file() for p in paths):raise ValueError([str(p) for p in paths if not p.is_file()])
manifest={str(p.relative_to(q)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(q/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(q/'experiment.tar.gz','w:gz') as archive:
    for p in paths+[q/'manifest.json']:archive.add(p,arcname=str(p.relative_to(q)),recursive=False)
with tempfile.TemporaryDirectory(prefix='swiftsci-counter-archive-') as directory:
    out=pathlib.Path(directory)
    with tarfile.open(q/'experiment.tar.gz','r:gz') as archive:archive.extractall(out,filter='data')
    for name,sha in manifest.items():
        assert hashlib.sha256((out/name).read_bytes()).hexdigest()==sha,name
    receipt=dict(archive_sha256=hashlib.sha256((q/'experiment.tar.gz').read_bytes()).hexdigest(),
        manifest_sha256=hashlib.sha256((q/'manifest.json').read_bytes()).hexdigest(),verified_files=len(manifest),
        scope='Extracted file hashes only. Live source-dependent diagnostic replay is recorded separately in declared-smoke-verification.json.')
(q/'archive-integrity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
