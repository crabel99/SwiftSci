#!/usr/bin/env python3
"""Describe counter work and execution rates without adjusting timing or controls."""
import argparse
import json
from pathlib import Path
import statistics
import subprocess
import sys
import tempfile
import datetime

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput import compare,run
from Benchmarks.CPUThroughput.core_usage import audit_receipt,WORKER_POLICY

PROTOCOL='cpu-counter-evidence-v1'


def account(processes):
    result={}
    for kind in ['e','p']:
        cpu=sum(p['time_ns']['user_'+kind]+p['time_ns']['kernel_'+kind] for p in processes)
        counts={key:sum(p['deltas']['p_'+key] if kind=='p' else
            p['deltas'][key]-p['deltas']['p_'+key] for p in processes)
            for key in ['instructions','cycles']}
        result[kind]=dict(cpu_ns=cpu,**counts,
            cycles_per_cpu_ns=counts['cycles']/cpu if cpu else None,
            instructions_per_cycle=counts['instructions']/counts['cycles'] if counts['cycles'] else None)
    return result


def method_sources():
    return [*Path(__file__).parent.glob('*.py'),*Path(__file__).parent.glob('*.c'),
        Path(__file__).with_name('COUNTER_EVIDENCE.md'),ROOT/'Benchmarks/Tools/execution_policy.py',
        ROOT/'Benchmarks/Tools/runner.py']


def method_manifest(panel,command):
    return dict(protocol=PROTOCOL,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        panel=str(panel.resolve()),command=command,core_policy=WORKER_POLICY,
        quality_policy=compare.LIMITS.copy(),
        source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        source_hashes={str(p.relative_to(ROOT)):run.digest(p) for p in method_sources()})


def validate_method(method,plan,root):
    if (method['protocol']!=PROTOCOL or method['panel']!=str(root.resolve())
            or method['quality_policy']!=plan['quality_policy']
            or method['source_head']!=plan['source_head']
            or method['core_policy']!=plan['core_policy']['policy']):
        raise ValueError('Capture differs from its predeclared method')
    if set(method['source_hashes'])!={str(p.relative_to(ROOT)) for p in method_sources()}:
        raise ValueError('Predeclared method source inventory differs')
    for name,sha in method['source_hashes'].items():
        if run.digest(ROOT/name)!=sha:
            raise ValueError('Predeclared method source changed: '+name)
    if any(method['source_hashes'].get(name)!=sha for name,sha in plan['source_hashes'].items()):
        raise ValueError('Controller plan differs from its predeclared method')


def summarize(records,decision):
    labels={r['label'] for r in records}
    primary=sorted(label for label in labels if not label.endswith('_twin'))
    if not primary or labels != set(primary)|{label+'_twin' for label in primary}:
        raise ValueError('Complete primary and twin conditions are required')
    conditions={}
    for label in primary:
        conditions[label]={}
        for role in ['worker','controller']:
            conditions[label][role]={}
            for kind in ['e','p']:
                groups={}
                for name,suffix in [('primary',''),('twin','_twin')]:
                    selected=[r for r in records if r['label']==label+suffix]
                    metrics={key+'_per_job':[r[role][kind][key]/r['jobs'] for r in selected]
                             for key in ['cpu_ns','instructions','cycles']}
                    metrics.update({key:[r[role][kind][key] for r in selected]
                                    for key in ['cycles_per_cpu_ns','instructions_per_cycle']})
                    groups[name]={key:statistics.median(values) if all(v is not None for v in values) else None
                                  for key,values in metrics.items()}
                groups['twin_to_primary']={key:groups['twin'][key]/value
                    if value not in (None,0) and groups['twin'][key] is not None else None
                    for key,value in groups['primary'].items()}
                conditions[label][role][kind]=groups
    resources={}
    for label in primary:
        resources[label]={}
        for name,suffix in [('primary',''),('twin','_twin')]:
            selected=[r for r in records if r['label']==label+suffix]
            resources[label][name]={key:statistics.median(r['measurements'][key] for r in selected)
                for key in selected[0]['measurements']}
    return dict(protocol=PROTOCOL,original_audit=decision,conditions=conditions,resources=resources,queues=records,
        interpretation='Descriptive counters only. Cycles per CPU ns is an accounted execution rate, not direct hardware frequency or energy. Rates and CPU time share a denominator. No causal classification, timing normalization, exclusion, or qualification change.')


def analyze(root,method=None):
    root=root.resolve()
    # Reuse the complete audit while keeping all generated files outside the capture.
    with tempfile.TemporaryDirectory(prefix='swiftsci-counter-audit-') as directory:
        overlay=Path(directory)
        for entry in root.iterdir():
            if entry.name not in ('audit.json','report.md'):
                (overlay/entry.name).symlink_to(entry,target_is_directory=entry.is_dir())
        decision=compare.audit(overlay)
    if decision!=json.loads((root/'audit.json').read_text()):
        raise ValueError('Saved audit differs from the revalidated capture')
    plan=json.loads((root/'plan.json').read_text())
    if plan.get('core_policy') is None:
        raise ValueError('Counter evidence requires a recorded core policy')
    if method is not None:validate_method(method,plan,root)
    records=json.loads((root/'records.json').read_text())
    rows=[]
    inputs=[root/name for name in ['plan.json','records.json','audit.json','expected.json','end.json',
                                  'preflight/checks.json','postflight/checks.json']]
    for row in records:
        path=root/f"r{row['round']}-{row['label']}"/'result.json';inputs.append(path)
        raw=json.loads(path.read_text())
        core=audit_receipt(raw['core_usage'],[r['pid'] for r in raw['runtime']],policy=plan['core_policy']['policy'])
        jobs=len(raw['jobs']);summary=raw['summary']
        measurements=dict(cpu_ms_per_job=summary['charged_cpu_ns']/jobs/1e6,
            wall_ms_per_job=summary['elapsed_ns']/jobs/1e6,jobs_per_minute=summary['completed_per_minute'],
            sampled_peak_mib=summary['sampled_peak_rss_bytes']/2**20,
            sampled_mib_seconds=summary['sampled_resident_byte_seconds']/2**20)
        rows.append(dict(round=row['round'],label=row['label'],jobs=jobs,measurements=measurements,
            worker=account(core['workers']),controller=account([core['controller']])))
    result=summarize(rows,decision)
    sources=[Path(__file__),*(ROOT/name for name in plan['source_hashes'])]
    result['provenance']=dict(input_directory=str(root),measurement_head=plan['source_head'],
        analysis_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        python=sys.version,core_policy=plan['core_policy']['policy'],
        source_hashes={str(path.relative_to(ROOT)):run.digest(path) for path in sources},
        input_hashes={str(path.relative_to(root)):run.digest(path) for path in inputs},
        method_predeclared=method is not None,method=method)
    return result


def report(value):
    lines=['# CPU counter evidence','',f"Protocol: {value['protocol']}.",
        '',f"Original controls passed: {value['original_audit']['controls_passed']}. Performance qualified: {value['original_audit']['performance_qualified']}.",
        '',value['interpretation'],'',
        'Method predeclared: '+str(value['provenance']['method_predeclared'])+'.',
        '',f"[Original comparison report](<{value['provenance']['input_directory']}/report.md>)",'',
        '| Condition | Variant | Jobs/min | CPU ms/job | Wall ms/job | Sampled peak MiB | Resident MiB-seconds |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    def number(value):return 'unavailable' if value is None else f'{value:.5g}'
    for label,variants in value['resources'].items():
        for variant,metrics in variants.items():
            values=[metrics[key] for key in ['jobs_per_minute','cpu_ms_per_job','wall_ms_per_job',
                'sampled_peak_mib','sampled_mib_seconds']]
            lines.append('| '+label+' | '+variant+' | '+' | '.join(map(number,values))+' |')
    lines+=['','## Work and accounted execution rates','',
        'Medians keep primary and twin queues separate. Every ratio is twin divided by primary. Worker values sum processes before dividing; controller work remains separate. Instructions and cycles include user and kernel work on the named core class. Worker P values are permitted kernel work because P-user time must be zero. Ratios against near-zero P work are unstable. None of these columns measures energy.', '',
        '| Condition | Role | Core | Instructions/job | Twin instruction ratio | Cycles/job | Twin cycle ratio | Cycles/CPU ns | Twin rate ratio |',
        '| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for label,roles in value['conditions'].items():
        for role,kinds in roles.items():
            for kind,group in kinds.items():
                left,ratio=group['primary'],group['twin_to_primary']
                cells=[left['instructions_per_job'],ratio['instructions_per_job'],left['cycles_per_job'],
                       ratio['cycles_per_job'],left['cycles_per_cpu_ns'],ratio['cycles_per_cpu_ns']]
                lines.append('| '+label+' | '+role+' | '+kind.upper()+' | '+' | '.join(map(number,cells))+' |')
    lines+=['','## Original control failures','']
    for flag in value['original_audit']['flags']:
        lines.append('- '+json.dumps(flag,sort_keys=True))
    if not value['original_audit']['flags']:lines.append('None. A smoke panel still cannot qualify performance.')
    lines+=['','Direct hardware frequency was not measured in these queue receipts. A separate fixed-loop trace cannot identify the clock state of an earlier queue. Ratios from different libraries can also reflect instruction mix and memory stalls. Do not attribute them solely to frequency.']
    return '\n'.join(lines)+'\n'


def write_report(output,value):
    output.mkdir(parents=True,exist_ok=False)
    run.save(output/'counter-evidence.json',value)
    (output/'report.md').write_text(report(value))
    print(json.dumps(dict(queues=len(value['queues']),original_controls_passed=value['original_audit']['controls_passed'],
        original_performance_qualified=value['original_audit']['performance_qualified'],output=str(output))))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collect',action='store_true',help='Freeze the method before a new observer-isolated comparison')
    parser.add_argument('--output',type=Path,required=True)
    args,rest=parser.parse_known_args()
    if args.collect:
        if any(a.split('=')[0] in ['--audit','--core-calibration'] for a in rest):
            parser.error('Collection accepts comparison arguments, not a capture, audit, or calibration override')
        output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
        panel=output/'comparison/panel'
        command=[sys.executable,str(Path(__file__).with_name('compare_e_cores.py')),
            '--observer-isolation',*rest,'--output',str(output/'comparison')]
        method=method_manifest(panel,command);run.save(output/'method.json',method)
        method_sha=run.digest(output/'method.json')
        try:
            subprocess.run(command,check=True)
            if run.digest(output/'method.json')!=method_sha:raise ValueError('Pre-run method manifest changed')
            value=analyze(panel,method)
            value['provenance']['method_file_sha256']=method_sha
            write_report(output/'diagnostics',value)
        except BaseException as error:
            run.save(output/'failure.json',dict(type=type(error).__name__,error=str(error)))
            raise
    else:
        if len(rest)!=1 or rest[0].startswith('-'):parser.error('Supply one capture and no comparison arguments for replay')
        capture=Path(rest[0])
        if args.output.resolve().is_relative_to(capture.resolve()):
            parser.error('Write diagnostics outside the unchanged capture directory')
        write_report(args.output,analyze(capture))


if __name__=='__main__':main()
