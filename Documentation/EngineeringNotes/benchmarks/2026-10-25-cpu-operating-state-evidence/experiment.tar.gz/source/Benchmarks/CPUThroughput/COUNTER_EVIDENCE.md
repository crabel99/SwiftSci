# CPU counter evidence protocol

`cpu-counter-evidence-v1` describes the CPU work and execution rates in completed external-engine queue comparisons. It reuses recorded counters and the full existing audit. It adds no work to timed queues and changes no acceptance limit.

## Comparison boundary

The comparison retains the complete input schemas, native-bit output checks, stable missing-last sorting, writable C-order matrices, and timed output release. Each library uses its native CPU pools. Four worker processes serve the same queue under the same memory ceiling. Pinned executable, interpreter, source, and input hashes identify the measured programs.

The full panel rotates every primary condition and its identical-binary twin through every order position. The Arrow-to-pandas extension retains both pandas readers. No condition, round, failed control, or partial result is dropped because its timing is inconvenient.

For E-core comparisons, `e-core-workers-observer-v2` requires zero P-core user time in every compute worker. Kernel P/E time and the ordinary controller's P/E time remain separate. The requested observation cadence and its coverage checks remain unchanged. This verifies application core type, not an exact hardware clock rate.

AC power and the recorded power policy remain required. The controller records the surrounding system state. No artificial workload forces a clock rate, and no operator waits for a favorable temperature before selecting a run. Balanced order and identical-condition controls address repeatability under the declared conditions.

## Unchanged acceptance

The original structural and accounting audit must succeed before the diagnostic report is written. A successful audit can still return failed quality controls. The report copies that verdict and every failure without modification.

The existing twin allowances remain 10% for charged CPU and elapsed time, and 5% plus 8 MiB per caller for sampled peak RSS. Coverage and full-output checks remain mandatory. A smoke panel never qualifies comparative performance. A failed full panel remains unqualified, even when the new counters suggest a possible explanation.

Freeze source hashes, work totals, order, core profile, and these limits before collecting a new panel. Keep every completed attempt. Define any later protocol change as a new experiment rather than adjusting recorded measurements or retrying until a panel passes.

## Counter definitions

Apple's Recount accounting reports total counters and P-only counters. Subtracting P-only from total gives E-core work. Instructions and cycles include user and kernel execution; the exposed counts do not partition those two privilege levels. [Apple Recount documentation](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/doc/observability/recount.md)

Each queue keeps worker totals separate from controller totals. Worker counters are summed before division.

| Quantity | Definition | Limit |
| --- | --- | --- |
| Instructions per job | Counted instructions divided by completed jobs | Different instructions can do different work |
| Cycles per job | Counted cycles divided by completed jobs | Includes stalls and user and kernel work |
| Core-class CPU time | User plus kernel time on that class | Wider interval than the queue wall timer |
| Cycles per CPU ns | Class cycles divided by class CPU nanoseconds | Accounted rate, not direct hardware frequency |
| Instructions per cycle | Class instructions divided by class cycles | Depends on instruction mix and memory behavior |
| Twin ratio | Twin median divided by primary median | Descriptive, no new acceptance threshold |

Worker P-class counters describe permitted kernel work because P-core user time must be zero. Ratios against very small P counts can be large and unstable. A zero denominator yields an unavailable ratio, not a zero rate. Medians keep primary and twin labels separate. CPU milliseconds and cycles per CPU nanosecond share a denominator, so their association is not independent evidence of frequency scaling.

A separately instrumented fixed-loop experiment can test whether hardware frequency varies under a scheduling policy. It cannot assign frequencies to earlier queue receipts. Queue-level claims about actual hardware frequencies require concurrent direct telemetry with documented clock domains, sample windows, and alignment uncertainty. Neither nominal thermal pressure nor zero sampled forced-idle endpoints rules out every thermal influence or brief scheduling event.

These counters support no energy estimate. They do not normalize timing, automatically classify a control failure, or rank libraries by instructions alone. Report throughput, CPU work, and memory together. More throughput with higher resource consumption remains a tradeoff.

## Evidence files

`counter-evidence.json` records every queue's worker and controller counts, separate E and P values, condition medians, twin ratios, the unchanged audit, and analysis provenance. Input and analysis-source hashes bind the report to its receipts. `report.md` presents the same evidence for review.

The analyzer reruns the full comparison audit in a temporary directory. Original queue receipts and generated comparison reports remain untouched. A mismatched source, executable, interpreter, raw receipt, or saved audit prevents analysis rather than silently accepting inconsistent evidence.

## Predeclared collection

The analyzer's `--collect` launcher creates `method.json` before starting `compare_e_cores.py`. The manifest records the exact command, source head, analyzer and protocol definitions, controller source hashes, core profile, quality limits, and capture location. No environment override is added by this wrapper. The existing controller records its environment and clears inherited library thread caps.

After collection, the analyzer checks the manifest's unchanged bytes, all recorded source hashes, and its agreement with the measured plan. The report retains the manifest and its hash. Original comparison files remain in `comparison/panel`; diagnostics are written separately. A mismatch writes a failure receipt instead of a diagnostic report.

A replay without this wrapper is retrospective. Its hashes bind the report to the current input files, not to a trusted historical baseline. The complete audit still checks internal consistency. The report records whether the method was predeclared.
