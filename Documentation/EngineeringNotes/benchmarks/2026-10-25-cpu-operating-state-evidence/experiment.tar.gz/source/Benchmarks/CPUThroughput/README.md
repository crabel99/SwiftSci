# CPU queue throughput experiment

This controller compares optional and compact Double storage on the same SwiftDataFrame build. Each finite queue mixes CSV reads with complete CSV, stable sort, and matrix workflows. It measures resource use and completion under increasing caller concurrency. It adds no production scheduling policy.

The [existing mixed-workload trial](../MixedWorkloads/README.md) covers CPU, GPU, and Core ML admission. This experiment isolates CPU dataframe callers. It reuses the [production-default execution policy](../Tools/execution_policy.py), which clears inherited thread caps. One, two, four, or eight persistent worker processes compete with their native internal parallelism.

## Work and correctness

Two input contracts describe the air-quality and household-energy reference CSVs. Contracts contain input paths and SHA-256 hashes, row counts, ordered column names and types, delimiters, and null tokens. Every engine or storage choice receives a complete schema. This experiment uses `PM2.5` and `Global_active_power` as sort keys.

Each full queue contains four copies of each dataset and workflow combination, for 16 jobs. Every concurrency processes the same queue. The controller rotates task order across eight rounds. Four labels, including an identical-binary twin of each storage mode, rotate through each position and its reverse. Caller-count order rotates too.

Both workflows read and materialize the complete frame. Sort-and-matrix jobs sort the complete frame stably with missing keys last, then construct an owned, contiguous, row-major Double matrix of numeric columns. Outputs are released before each job responds. No result crosses process boundaries.

Before and after the panel, both storage modes must match externally supplied native-bit fingerprints for every column and matrix. Use fingerprints independently checked against reference libraries, not hashes generated from this run. Each timed output receives row-count, column-order, type, and matrix-size checks. Full hashes are outside queue timing. The panel does not fully hash every timed result.

## Measurement boundaries

All jobs enter the queue at the same initial submission time. Response time includes time waiting for a worker, dispatch, the public operations, output release, and receipt. Separate queue and service times identify whether callers wait longer under contention. A finite burst does not model a sustained arrival distribution.

The controller starts fresh worker processes for every batch. Worker startup completes before timing. The first public API call in each worker remains inside timing. Process startup, full-hash preflight, and postflight are excluded. Repeated fixture reads follow preflight, so this is not a cold-disk test.

Metrics have distinct meanings:

- Jobs per minute is the fixed work total divided by whole-queue elapsed time. Jobs have different sizes, so this rate is comparable only with the same queue composition.
- Charged CPU is summed worker user and system time plus controller CPU during the queue. It includes dispatch and sampling. It is neither FLOPs nor energy.
- Operation CPU excludes request decoding and controller work. It includes frame construction, requested operations, shape checks, memory bookkeeping, and release.
- Peak worker RSS is the maximum sampled sum of concurrent process residency. It is not the sum of separate lifetime peaks. Shared pages can be counted more than once, so RSS does not measure unique physical memory.
- Retained RSS describes live workers after the queue and after output release. It includes runtime and allocator caches. It does not by itself establish a leak.
- Resident byte-seconds integrates sampled residency across queue time. This approximate memory occupancy accounts for how long workers retain memory.

Sampling targets 10 ms and records the largest observed gap. Short-lived peaks may be missed. An 8 GiB aggregate worker-RSS ceiling stops only this experiment's process groups. It is an experiment bound, not a recommended application memory limit. Cleanup closes every worker on completion and failure.

AC power is required at the start, before each batch, and at the end. System paging counters, swap use, and process activity are recorded at panel boundaries. These are system-wide observations and cannot identify the owner of paging. Background applications remain running.

The plan records source and dependency hashes, compiler commands, executable hash, toolchain, hardware, input contracts, independent fingerprint hash, and controller hash before measurements. Coverage-instrumented workers are rejected. The audit requires every planned job and batch and retains control failures. Identical-binary limits are 10% for CPU and elapsed time, and 5% plus 8 MiB per caller for sampled peak RSS. A small difference inside those limits is not automatically significant.

## Run the experiment

Build the worker against the existing uninstrumented Release dependency objects. Supply their directory and the ArrowC and Atomics module-map paths from the local package build.

```sh
python3 Benchmarks/CPUThroughput/build.py \
  --products /absolute/path/Release \
  --arrow-module-map /absolute/path/ArrowC.modulemap \
  --atomics-module-map /absolute/path/module.modulemap \
  --output /absolute/path/new-worker-directory
```

Run the short smoke panel first. All output directories must be new.

```sh
python3 Benchmarks/CPUThroughput/run.py \
  --worker /absolute/path/new-worker-directory/worker \
  --air-contract /absolute/path/air.json \
  --energy-contract /absolute/path/energy.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-results-directory \
  --smoke
```

Remove `--smoke` for eight rounds at all four caller counts. Audit the completed full panel separately.

```sh
python3 Benchmarks/CPUThroughput/audit.py /absolute/path/new-results-directory
python3 -m unittest discover -s Benchmarks/Tests -p test_cpu_throughput.py
```

Read `report.md` for medians, `audit.json` for control qualification, and each batch's `result.json` for task latency and raw memory samples. Full-hash receipts are under `preflight` and `postflight`. Keep engineering conclusions and measured artifacts on the engineering-notes branch.

## Compare longer queues within fixed memory budgets

The budget experiment reuses the worker and queue controller. Its reference plan is a completed `run.py` plan. That plan fixes the input contracts, independent output fingerprints, execution policy, label orders, and quality limits.

```sh
python3 Benchmarks/CPUThroughput/budget.py \
  --worker /absolute/path/new-worker-directory/worker \
  --reference-plan /absolute/path/completed-queue-panel/plan.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-budget-results-directory \
  --smoke
```

Remove `--smoke` for the full experiment. Each queue has 32 copies of all four cases, for 128 jobs. All jobs enter together and remain available until callers drain the queue. This is a longer finite burst, not a service with a constant arrival rate.

A separate calibration runs two single-caller queues per storage mode in opposite orders. Each calibration queue has the same length and case mix as the measured queues. Calibration uses the larger of sampled RSS and the kernel-recorded lifetime peak for each single caller. The reservation is the largest calibration peak, plus 5% and 8 MiB. This reuses the existing RSS-control allowance. It is an experimental estimate, not a proven allocation bound.

Before any timed comparisons, the controller freezes caller counts for budgets of 2, 4, and 8 GiB. Both modes use the same rule: divide the budget by the caller reservation, round down, and admit at most eight callers. Native parallelism inside each caller remains enabled. If a declared budget cannot admit one caller, the experiment fails rather than changing the budget.

The sampler checks each queue against its declared budget. A sampled overrun terminates only the benchmark workers and fails the panel. The limit covers aggregate sampled worker RSS. It excludes controller RSS and is not an OS-enforced physical-memory limit. Sampling can miss short peaks, and shared pages can be counted repeatedly.

Caller startup, calibration, and full-output checks are outside queue timing. Calibration cost and memory are preserved in separate receipts. The same frozen admissions apply to primary and twin labels in every measured round. Budgets and label order rotate. No admission value is retuned after seeing measured results.

The report places throughput beside CPU per job, memory occupancy, and recorded response times. More callers can increase throughput while using more CPU per result. Such a result is a tradeoff, not an unconditional efficiency improvement. System paging remains a separate observation.

Audit the completed budget panel and run its controller tests with:

```sh
python3 Benchmarks/CPUThroughput/budget.py \
  --output /absolute/path/completed-budget-results-directory --audit
python3 -m unittest discover -s Benchmarks/Tests -p 'test_cpu*.py'
```

The budget audit requires preflight and postflight full-output checks, every planned queue and job, unchanged caller counts, matching raw job receipts, and the original identical-binary quality limits. Retain an unqualified panel as evidence. Do not raise its limits to make it pass.

## Separate storage savings from extra caller concurrency

Use `--matched-control` to compare three configurations under one 4 GiB worker-RSS budget:

- Optional Double storage with four callers.
- Compact Double storage with four callers.
- Compact Double storage with five callers.

```sh
python3 Benchmarks/CPUThroughput/budget.py \
  --worker /absolute/path/new-worker-directory/worker \
  --reference-plan /absolute/path/completed-queue-panel/plan.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-matched-control-results-directory \
  --matched-control
```

Calibration checks that every declared configuration fits its envelope before timing starts. An unsuitable configuration fails instead of reducing its caller count. The caller counts remain fixed throughout the panel.

All three configurations and their identical-binary twins run in 12 rotated rounds. Each queue has the same 128 jobs as the full budget experiment. Each label occupies each position twice. Add `--smoke` for two rounds with eight jobs per queue.

The optional/four versus compact/four comparison isolates storage at matched caller concurrency. Compact/four versus compact/five measures the effect of the extra caller in the same panel. Four callers means four worker processes. Every process retains native internal parallelism, so this does not enforce four CPU threads or core affinity.

Audits keep each configuration and its twin separate. The earlier capacity-panel format remains readable, and its existing audits must remain unchanged. Full-output validation, CPU accounting, failure cleanup, and memory guard behavior use the same controller as the capacity experiment. No production concurrency policy changes.

## Compare equivalent queues across libraries

`compare.py` adds persistent pandas, Polars, and DuckDB workers to the same queue protocol. It compares five conditions: SwiftSci optional, SwiftSci compact, pandas, Polars, and DuckDB. Every condition has its own identical-binary twin. All conditions use four callers with native internal parallelism and the same 8 GiB sampled worker-RSS ceiling.

Use the comparison environment installed from `Benchmarks/Python/requirements-comparison.txt`. Supply the same complete input contracts and independent native-bit fingerprints used by the Swift queues.

```sh
python3 Benchmarks/CPUThroughput/compare.py \
  --swift-worker /absolute/path/worker \
  --python /absolute/path/comparison-environment/bin/python \
  --air-contract /absolute/path/air.json \
  --energy-contract /absolute/path/energy.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-comparison-directory \
  --smoke
```

Remove `--smoke` for ten rotated rounds. Full queues contain 16 copies of each of the four cases, for 64 jobs. Every primary and twin condition occupies every order position. The two-round smoke uses eight jobs per queue and cannot qualify comparative performance. Queue rates are comparable only within the same declared work total and case mix. Do not compare these rates directly with the earlier 128-job study.

Add `--pandas-arrow` to retain these five conditions and add a sixth, `pandas_arrow`. This condition calls `pyarrow.csv.read_csv` with every column type declared, then converts the table to pandas. Parsing and conversion both remain inside timing. Sorting and matrix construction use the same pandas operations as the C-reader condition. The extended full panel uses 12 rotated rounds and 144 queues. Each condition and its twin occupies every position once; work per queue and qualification limits stay unchanged. Existing five-condition plans remain readable.

This is an explicit-schema Arrow-to-pandas pipeline, not `pandas.read_csv(engine="pyarrow")`. The installed pandas wrapper can infer parser types before applying `dtype`. Arrow's `column_types` disables inference for declared columns. The adapter requests null recognition in strings, preserves textual values, and records the native Arrow CPU pool size without changing it. See [pandas CSV options](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html) and [Arrow conversion options](https://arrow.apache.org/docs/python/generated/pyarrow.csv.ConvertOptions.html).

Full-output checks run on every condition before and after timing. All engines must preserve the same column order, native Int64 and Float64 values, declared nulls, stable missing-last sorting, and independent writable C-order Float64 matrix. Pandas uses its C reader with round-trip float conversion. Polars receives a complete schema and requests stable sorting and writable C-order output. DuckDB uses a persistent connection, materializes Arrow output, computes a stable row permutation, and gathers original rows through Arrow. That final gather preserves signed-zero bits that direct ordered projection can canonicalize. Its CPU and memory costs remain inside timing.

These adapters implement the controlled reference contracts, not a general CSV compatibility layer. In particular, pandas' ordinary Int64 reader does not support missing integer fields, and its ordinary Float64 null model cannot distinguish a valid NaN from a missing value. Such inputs must not be added to this comparison without a matching representation and new conformance checks. Full native-bit preflight rejects a mismatch before timing starts.

Engine imports, DuckDB connection setup, and readiness complete before queue timing. The first public CSV call in each fresh worker remains timed. Persistent workers serve repeated requests and release each output before responding. Runtime versions, configured pool sizes, CPU accounting, and worker residency are recorded. Pool size is not measured active core use. The existing execution policy clears inherited thread caps in every worker.

The controller records all four raw worker runtime identities per queue. Its independent audit checks the frozen modes, caller counts, work totals, unchanged limits, raw CPU and memory accounting, interpreter and binary hashes, controller-source hashes, and every full-output fingerprint. Audit the completed directory separately:

```sh
python3 Benchmarks/CPUThroughput/compare.py \
  --output /absolute/path/completed-comparison-directory --audit
python3 -m unittest discover -s Benchmarks/Tests -p 'test_*cpu*.py'
```

Read `report.md`, `audit.json`, and the raw queue receipts together. A failed control remains unqualified. All performance and engineering conclusions belong on the engineering-notes branch.

## Compare with verified E-core application execution

Use `compare_e_cores.py` for the common application-core rule. Pass the same comparison arguments, including `--pandas-arrow` when comparing both pandas readers:

```sh
python3 Benchmarks/CPUThroughput/compare_e_cores.py \
  --swift-worker /absolute/path/worker \
  --python /absolute/path/comparison-environment/bin/python \
  --air-contract /absolute/path/air.json \
  --energy-contract /absolute/path/energy.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-core-comparison-directory \
  --pandas-arrow --smoke
```

The launcher builds a small C reader against the installed macOS SDK, which defines the versioned `rusage_info_v6` layout. It demonstrates working P-core counters with a one-second probe before starting the comparison under a background QoS clamp. The controller and its worker processes inherit the same clamp. Libraries retain their native thread pools. QoS is a scheduling preference, so every timed queue must independently verify its actual placement.

Run the launcher under normal scheduling. Preclamping the launcher can prevent its positive-P calibration. Missing SDK support, failed calibration, a different boot session, invalid counters, or any nonzero P-core user time fails the run. Unsupported zero counters cannot stand in for proof of E-core execution.

Acceptance requires zero P-core user time for every worker and the controller. Kernel execution may use either core type. Each queue records raw per-process user, kernel, P-only, instruction, and cycle counters. The audit binds them to the actual worker and controller process IDs, recomputes all deltas, and reports E-user, P-user, E-kernel, and P-kernel time separately. Nonzero P-kernel time is visible and allowed.

Core snapshots bracket the queue plus boundary bookkeeping, while the existing wall timer covers queue execution. The four core-time components therefore are not an exact partition of `charged_cpu_ns`. They are additional accounting with explicit interval boundaries, not an energy estimate. The worker snapshots require zero running threads before and after each read, with a bounded wait; the controller snapshot includes its active accounting call. No scheduler trace or enforced affinity is claimed.

The original work totals, caller counts, native CPU parallelism, memory ceiling, output contracts, and twin limits stay unchanged. Core-class acceptance does not waive a failed CPU, elapsed-time, memory, or output check. A smoke run still cannot qualify performance. Compare results within the same core policy; unrestricted runs do not establish E-core results.

Read `<output>/panel/report.md` and its raw queue receipts. `<output>/core-controls/calibration.json` records the host boot session, source and compiled-reader fingerprints, build commands, and positive-P probe. Audit separately with:

```sh
python3 Benchmarks/CPUThroughput/compare.py \
  --output /absolute/path/completed-core-comparison-directory/panel --audit
```

Apple documents P-only counters in [Recount](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/doc/observability/recount.md). The [Apple Silicon scheduling guidance](https://developer.apple.com/news/?id=vk3m204o) explains how QoS influences placement. These controls do not expose a public P/E affinity mask.

## Separate compute placement from observation scheduling

Add `--observer-isolation` to `compare_e_cores.py` to select `e-core-workers-observer-v2`. Without the flag, the launcher retains `e-core-application-v1` and its whole-tree clamp.

The new profile backgrounds each compute worker, including preflight and postflight workers. The controller runs without that clamp. Queue dispatch, response collection, memory sampling, and bookkeeping can therefore use either core type. Every timed worker must still record zero P-core user time. Controller P/E time appears separately, and all measured controller CPU remains charged. Raw controller QoS counters reject execution under a background, maintenance, or utility policy.

The new controller charge interval starts before initial worker stats and observations. It ends after the final memory scan, worker stats, counter reads, and receipt validation. Final receipt serialization and disk writes are outside that interval. Queue wall timing retains its original boundaries. Receipts preserve both intervals. The two profiles measure different controller scheduling and charging scopes, so their performance results are not interchangeable.

The sampler uses absolute monotonic deadlines with a requested 10 ms interval. It skips missed deadlines instead of issuing catch-up bursts. Each scan records its start, end, worker identities, RSS, and physical footprint. The independent audit requires boundary scans around the queue, unchanged process start identities, and an exact match between scan RSS and the existing RSS sample list.

Coverage requires every queue to have an effective gap no greater than 50 ms and every scan to take no longer than 50 ms. A coverage failure prevents qualification and remains visible in the raw receipts and audit. This is a measurement-quality limit, not a scheduling guarantee or proof of the instantaneous memory peak.

Physical footprint supplements RSS. It does not replace sampled peak RSS or its repeatability control. Reusable memory is not available through this unprivileged cross-process probe. The work totals, native pools, engine panel, twins, output checks, memory ceiling, and CPU, elapsed-time, and RSS allowances are unchanged. A smoke run cannot qualify comparative performance.

## Explain counter work without adjusting timings

Use the [CPU counter evidence protocol](COUNTER_EVIDENCE.md) to inspect completed comparisons with recorded core counters. The analyzer reruns the original audit and writes into a new directory outside the capture.

```sh
python3 Benchmarks/CPUThroughput/operating_state.py \
  /absolute/path/completed-core-comparison-directory/panel \
  --output /absolute/path/new-counter-evidence-directory
```

Read the new `report.md` alongside the original comparison report. Worker and controller counts remain separate, as do E and P execution. The diagnostic report preserves all failed controls. Cycles per CPU nanosecond is an accounted rate, not direct hardware frequency or an energy estimate. No workload is rerun.

For a new panel, use `--collect` with the same comparison arguments. This writes `method.json` before starting the existing observer-isolated launcher and checks the frozen method against the completed plan.

```sh
python3 Benchmarks/CPUThroughput/operating_state.py --collect \
  --swift-worker /absolute/path/worker \
  --python /absolute/path/comparison-environment/bin/python \
  --air-contract /absolute/path/air.json \
  --energy-contract /absolute/path/energy.json \
  --expected /absolute/path/independent-expected.json \
  --pandas-arrow --smoke \
  --output /absolute/path/new-declared-comparison
```

The original capture is under `comparison/panel`, and the additional report is under `diagnostics`. A failed collection writes `failure.json` and retains its partial evidence. Remove `--smoke` for the full panel. A separately replayed older capture is labeled retrospective and does not acquire a predeclared method.
