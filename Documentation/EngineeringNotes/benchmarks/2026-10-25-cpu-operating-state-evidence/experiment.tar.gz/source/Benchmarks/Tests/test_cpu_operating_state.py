"""Keep counter work, execution rate, and timing qualification distinct."""
import copy
from pathlib import Path
import sys
import unittest
import tempfile
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput.operating_state import account, summarize, report, method_manifest, validate_method


def process(pid=1):
    return dict(pid=pid,deltas=dict(instructions=1000,p_instructions=100,cycles=2000,p_cycles=400),
        time_ns=dict(user_e=800,user_p=0,kernel_e=200,kernel_p=100))


class OperatingStateTests(unittest.TestCase):
    def test_p_kernel_counts_do_not_become_e_work(self):
        value=account([process()])
        self.assertEqual(value['e'],dict(cpu_ns=1000,instructions=900,cycles=1600,
            cycles_per_cpu_ns=1.6,instructions_per_cycle=900/1600))
        self.assertEqual(value['p'],dict(cpu_ns=100,instructions=100,cycles=400,
            cycles_per_cpu_ns=4,instructions_per_cycle=.25))

    def test_role_totals_use_sum_then_ratio_not_mean_of_process_rates(self):
        slow=process(2);slow['time_ns']['user_e']=1800
        value=account([process(),slow])
        self.assertAlmostEqual(value['e']['cycles_per_cpu_ns'],3200/3000)
        self.assertEqual(value['e']['cpu_ns'],3000)

    def test_no_p_work_has_no_invented_rate(self):
        value=process()
        value['time_ns']['kernel_p']=0
        value['deltas'].update(p_cycles=0,p_instructions=0)
        self.assertIsNone(account([value])['p']['cycles_per_cpu_ns'])
        self.assertIsNone(account([value])['p']['instructions_per_cycle'])

    def test_identical_work_can_have_different_rate_without_changing_verdict(self):
        primary=account([process()])
        changed=process();changed['time_ns'].update(user_e=1600,kernel_e=400)
        twin=account([changed])
        measurements=dict(cpu_ms_per_job=3,wall_ms_per_job=2,jobs_per_minute=30000,
            sampled_peak_mib=128,sampled_mib_seconds=256)
        records=[dict(round=0,label='engine',jobs=2,measurements=measurements,worker=primary,controller=account([process(2)])),
                 dict(round=0,label='engine_twin',jobs=2,measurements=measurements,worker=twin,controller=account([process(3)]))]
        decision=dict(controls_passed=False,performance_qualified=False,flags=[dict(label='engine',metric='charged_cpu_ns',ratio=2)])
        original=copy.deepcopy(decision)
        value=summarize(records,decision)
        self.assertEqual(decision,original)
        self.assertEqual(value['original_audit'],original)
        worker=value['conditions']['engine']['worker']['e']
        self.assertEqual(worker['primary']['instructions_per_job'],worker['twin']['instructions_per_job'])
        self.assertEqual(worker['twin_to_primary']['cycles_per_cpu_ns'],.5)
        self.assertEqual(worker['twin_to_primary']['cpu_ns_per_job'],2)
        self.assertNotIn('normalized_cpu_ns',str(value))
        value['provenance']=dict(input_directory='/captured/panel',method_predeclared=False)
        text=report(value)
        self.assertIn('CPU ms/job',text)
        self.assertIn('Sampled peak MiB',text)
        self.assertIn('Resident MiB-seconds',text)
        self.assertIn('Original comparison report',text)
        self.assertIn('Original controls passed: False',text)

    def test_predeclared_method_rejects_mismatched_capture_and_definition(self):
        from Benchmarks.CPUThroughput.compare import LIMITS
        from Benchmarks.CPUThroughput.core_usage import WORKER_POLICY
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            method=method_manifest(root,['python','comparison'])
            plan=dict(source_head=method['source_head'],quality_policy=LIMITS.copy(),
                core_policy=dict(policy=WORKER_POLICY),source_hashes=method['source_hashes'].copy())
            validate_method(method,plan,root)
            for key,value in [('protocol','different'),('panel','/different'),('source_head','different'),
                              ('core_policy','e-core-application-v1'),('quality_policy',{})]:
                with self.subTest(key=key):
                    changed=copy.deepcopy(method);changed[key]=value
                    with self.assertRaises(ValueError):validate_method(changed,plan,root)
            changed=copy.deepcopy(method)
            changed['source_hashes']['Benchmarks/CPUThroughput/operating_state.py']='0'*64
            with self.assertRaises(ValueError):validate_method(changed,plan,root)
            missing=copy.deepcopy(method);missing['source_hashes'].pop('Benchmarks/CPUThroughput/operating_state.py')
            with self.assertRaises(ValueError):validate_method(missing,plan,root)
            changed=copy.deepcopy(plan);changed['source_hashes']['missing.py']='0'*64
            with self.assertRaises(ValueError):validate_method(method,changed,root)

    def test_partial_panel_does_not_become_a_diagnostic_comparison(self):
        with self.assertRaises(ValueError):summarize([],dict(controls_passed=True))
        with self.assertRaises(ValueError):summarize([dict(label='engine')],dict(controls_passed=True))


if __name__=='__main__':unittest.main()
