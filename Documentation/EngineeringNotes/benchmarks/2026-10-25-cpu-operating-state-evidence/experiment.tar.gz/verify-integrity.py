"""Exercise the real analyzer and reject altered placement without changing saved data."""
import hashlib,json,pathlib,subprocess,sys,tempfile
q=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source')
panel=pathlib.Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/smoke-final/panel')
program=source/'Benchmarks/CPUThroughput/operating_state.py'
def hashes(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
before=hashes(panel)
with tempfile.TemporaryDirectory(prefix='swiftsci-counter-integrity-') as directory:
    tmp=pathlib.Path(directory)
    good=subprocess.run([sys.executable,str(program),str(panel),'--output',str(tmp/'good')],capture_output=True,text=True)
    assert good.returncode==0,good.stderr
    result=json.loads((tmp/'good/counter-evidence.json').read_text())
    original=json.loads((panel/'audit.json').read_text())
    assert result['original_audit']==original and len(original['flags'])==8
    assert len(result['queues'])==24 and original['performance_qualified'] is False
    bad=tmp/'altered';bad.mkdir()
    records=json.loads((panel/'records.json').read_text())
    first=records[0];queue=f"r{first['round']}-{first['label']}"
    for entry in panel.iterdir():
        if entry.name!=queue:(bad/entry.name).symlink_to(entry,target_is_directory=entry.is_dir())
    (bad/queue).mkdir()
    raw=json.loads((panel/queue/'result.json').read_text())
    raw['core_usage']['after'][0]['p_user_ticks']+=1
    (bad/queue/'result.json').write_text(json.dumps(raw))
    rejected=subprocess.run([sys.executable,str(program),str(bad),'--output',str(tmp/'bad-output')],capture_output=True,text=True)
    assert rejected.returncode!=0 and 'Application CPU time ran on P cores' in rejected.stderr,rejected.stderr
    assert not (tmp/'bad-output').exists()
    inside=subprocess.run([sys.executable,str(program),str(panel),'--output',str(panel/'must-not-exist')],capture_output=True,text=True)
    assert inside.returncode!=0 and 'outside the unchanged capture' in inside.stderr
    assert not (panel/'must-not-exist').exists()
    assert hashes(panel)==before
    receipt=dict(python=sys.version,command=[sys.executable,str(program)],verified_input_files=len(before),input_hashes=before,
        original_audit_unchanged=True,all_capture_file_bytes_unchanged=True,retained_control_failures=len(original['flags']),
        valid_replay_stdout=good.stdout,altered_placement_rejected=True,in_capture_output_rejected=True,
        analysis_source_sha256=hashlib.sha256(program.read_bytes()).hexdigest())
    (q/'integrity-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['python','command','input_hashes','analysis_source_sha256']}))
