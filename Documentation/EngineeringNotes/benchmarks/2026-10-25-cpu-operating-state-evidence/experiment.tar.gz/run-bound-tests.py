import datetime,hashlib,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source')
def command(argv):return subprocess.check_output(argv,cwd=source,text=True).strip()
paths=sorted((source/'Benchmarks/Tests').glob('*.py'))+sorted((source/'Benchmarks/CPUThroughput').glob('*.py'))+[source/'Benchmarks/CPUThroughput/COUNTER_EVIDENCE.md']
receipt=dict(command=[sys.executable,'-m','unittest','discover','-s','Benchmarks/Tests'],cwd=str(source),python=sys.version,
    start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_before=command(['git','rev-parse','HEAD']),
    status_before=command(['git','status','--porcelain']),environment_override=dict(SWIFTSCI_MLX_TEST_GPU='1'),
    source_hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
with (q/'final-controller-tests.log').open('w') as log:
    result=subprocess.run(receipt['command'],cwd=source,env=dict(os.environ,SWIFTSCI_MLX_TEST_GPU='1'),stdout=log,stderr=log)
receipt.update(returncode=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    head_after=command(['git','rev-parse','HEAD']),status_after=command(['git','status','--porcelain']),
    log_sha256=hashlib.sha256((q/'final-controller-tests.log').read_bytes()).hexdigest())
(q/'final-test-provenance.json').write_text(json.dumps(receipt,indent=2)+'\n')
print((q/'final-controller-tests.log').read_text()[-500:])
assert receipt['returncode']==0 and receipt['head_before']==receipt['head_after'] and not receipt['status_before'] and not receipt['status_after']
