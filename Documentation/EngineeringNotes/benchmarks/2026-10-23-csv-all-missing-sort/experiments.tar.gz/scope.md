# All-missing sort identity trial

The source change is one metadata-based early return in TypedColumn.sortedIndices. A fully missing key has identity stable row order in either direction. TypedColumn computes or maintains its immutable null count, so no key reads are needed to establish the condition. Empty columns are included. Valid NaNs are not missing values.

Source and small public-behavior tests stay on codex/csv-all-missing-sort, based on 940353d441. Scripts, data contracts, decisions, and results belong only on codex/engineering-notes. No push or PR is authorized.

The semantic behavior is already correct. The two added test functions pass before implementation and protect the identity rule, all supported native types, compact Double validity, valid NaNs, both directions, original row identities, and bitmap boundaries. They are not presented as failing-before correctness regressions.

The primary resource comparison is against the preserved direct parent in the same measurement session. An earlier shared-key checkpoint supplies context. All clients use matching module interfaces and objects and identical flags. Native-type controls use one and eight million all-missing values. Constructor work is outside timing, the caller retains the input, complete identity output checks are outside timing, and output release CPU is included. Peak RSS can include the earlier constructor peak.

The existing 80 ordered, nearly ordered, sparse, and random Double controls check common paths. Four household observation workflows cover serial optional and compact CSV conversion, index sorting, and sorting followed by matrix preparation. This focused reference panel does not replace the earlier complete 24-case panel. Exact eager and streamed reference reads retain their full native schemas, null tokens, values, and row order.

CPU means process user plus system time. Memory metrics distinguish live heap, process peak RSS, and constructor peaks. No energy, cache, or FLOP claim follows from them. No worker limits, affinity flags, crossover thresholds, numerical tolerances, or precision policies change.

Eight balanced orders retain the frozen identical-binary quality policy: median CPU deviation above 10%, or peak RSS above 5% plus 8 MiB, flags a case. Flagged comparisons remain unqualified. Tests, builds, and fixtures finish before accepted measurements. AC power is checked at both ends.

A benefit on all-missing keys does not establish that such keys are frequent in production or that normal CSV workflows become faster. Acceptance must record costs on unaffected inputs as well as the invariant-based saving.
