from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parent
for script,args in [('strict-check.py',[]),('run-panel.py',['preflight']),('run-shape-panel.py',['preflight']),('run-native.py',['preflight']),('run-native.py',['measurement']),('run-shape-panel.py',['measurement']),('run-panel.py',['measurement']),('audit-shapes.py',[]),('audit.py',[]),('audit-native.py',[])]:
 print('START',script,*args,flush=True)
 subprocess.run([sys.executable,str(R/script),*args],check=True)
