from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parent
for configuration,label,extra in [('Debug','final-debug',[]),('Release','final-asan',['--address-sanitizer'])]:
 print('START',label,flush=True)
 subprocess.run([sys.executable,str(R/'verify.py'),configuration,'--label',label,*extra],check=True)
subprocess.run([sys.executable,str(R/'build.py')],check=True)
subprocess.run([sys.executable,str(R/'prepare-panel.py')],check=True)
subprocess.run([sys.executable,str(R/'prepare-shapes.py')],check=True)
print('VALIDATION AND BUILDS COMPLETE',flush=True)

subprocess.run([sys.executable,str(R/'prepare-native.py')],check=True)
