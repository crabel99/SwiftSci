from pathlib import Path
import hashlib,itertools,json,statistics,subprocess,sys,time
R=Path(__file__).resolve().parent;mode=sys.argv[1];assert mode in ['preflight','measurement'];D=R/('native-'+mode);D.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();labels=['original','prior','current','twin'];base=[0,1,3,2]
first=[[labels[(x+shift)%4] for x in base] for shift in range(4)];orders=first+[list(reversed(x)) for x in reversed(first)]
binary=lambda label:R/(('current' if label=='twin' else label)+'-native')
contracts=json.loads((R/'native-contracts.json').read_text())
plan={'controller_sha256':h(Path(__file__)),'contracts':contracts,'orders':orders,'binaries':{k:h(binary(k)) for k in labels},'quality_policy':{'cpu_twin_deviation':.10,'peak_twin_relative':1.05,'peak_twin_slack_bytes':8*2**20}}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
if mode=='measurement':
 assert json.loads((R/'native-preflight/plan.json').read_text())==plan
 assert json.loads((R/'native-preflight/decision.json').read_text())['all_outputs_match']
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power.txt').open('w'),check=True);assert 'AC Power' in (D/'power.txt').read_text()
rows=[]
with (D/'workers.jsonl').open('w') as out:
 for case in contracts:
  key=f"{case['kind']}/{case['count']}"
  for turn,order in enumerate(orders if mode=='measurement' else [labels]):
   for position,label in enumerate(order):
    start=time.time();x=json.loads(subprocess.check_output([str(binary(label)),case['kind'],str(case['count']),case['path']],text=True,timeout=60))
    assert x['validated_identity'] and x['kind']==case['kind'] and x['rows']==x['nulls']==case['count'] and x['dtype']==case['dtype'] and x['indices_sha256']==case['indices_sha256'],(case,x)
    x.update(case=key,engine=label,round=turn,position=position,worker_seconds=time.time()-start);out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();rows.append(x)
  print(mode,key,flush=True)
summary=[];flags=[]
for case in contracts:
 key=f"{case['kind']}/{case['count']}";g={}
 for label in labels:
  xs=[x for x in rows if x['case']==key and x['engine']==label]
  med={k:statistics.median(x[k] for x in xs) for k in ['operations_cpu_ns','total_cpu_ns','heap_before_bytes','held_heap_bytes','heap_after_release_bytes','process_peak_before_bytes','process_peak_held_bytes']};g[label]=med
  summary.append({'case':key,'engine':label,'workers':len(xs),'medians':med})
 if mode=='measurement':
  a,b=g['current'],g['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
  if abs(ratio-1)>.10:flags.append({'case':key,'reason':'identical-binary CPU','ratio':ratio})
  for x,y in [(a,b),(b,a)]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':key,'reason':'identical-binary peak'})
if mode=='measurement':
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power-end.txt').open('w'),check=True);assert 'AC Power' in (D/'power-end.txt').read_text()
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');decision={'all_outputs_match':True,'workers':len(rows),'quality_flags':flags,'quality_passed':not flags};(D/'decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps(decision),flush=True)
