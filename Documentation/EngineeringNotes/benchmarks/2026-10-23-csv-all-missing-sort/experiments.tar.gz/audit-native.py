from pathlib import Path
from collections import Counter
import hashlib,itertools,json,statistics
R=Path(__file__).resolve().parent;D=R/'native-measurement';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((D/'plan.json').read_text());assert plan==json.loads((R/'native-preflight/plan.json').read_text());assert plan['controller_sha256']==h(R/'run-native.py')
labels=['original','prior','current','twin']
for label in labels:
 assert Counter(order.index(label) for order in plan['orders'])==Counter({n:2 for n in range(4)})
 assert plan['binaries'][label]==h(R/(('current' if label=='twin' else label)+'-native'))
assert Counter((a,b) for order in plan['orders'] for a,b in zip(order,order[1:]))==Counter({x:2 for x in itertools.permutations(labels,2)})
for label in labels[:-1]:
 receipt=json.loads((R/(label+'-native-build.json')).read_text());assert receipt['binary_sha256']==plan['binaries'][label] and receipt['source_sha256']==h(R/'AllMissingProbe.swift');assert receipt['verified_module']==json.loads((R/(label+'-workflow-build.json')).read_text())['verified_module']
contracts={f"{x['kind']}/{x['count']}":x for x in plan['contracts']};assert len(contracts)==json.loads((R/'study.json').read_text())['all_missing_case_count']
for c in contracts.values():assert h(Path(c['path']))==c['csv_sha256']
rows=[json.loads(x) for x in (D/'workers.jsonl').read_text().splitlines()];pre=[json.loads(x) for x in (R/'native-preflight/workers.jsonl').read_text().splitlines()]
assert len(rows)==len(contracts)*32 and len(pre)==len(contracts)*4
for x in rows+pre:
 c=contracts[x['case']];assert x['validated_identity'] and x['kind']==c['kind'] and x['dtype']==c['dtype'] and x['nulls']==x['rows']==c['count'] and x['indices_sha256']==c['indices_sha256']
for p in ['power.txt','power-end.txt']:assert 'AC Power' in (D/p).read_text()
summary=[];flags=[];comparisons=[]
for key in contracts:
 group={}
 for label in labels:
  xs=[x for x in rows if x['case']==key and x['engine']==label];assert len(xs)==8 and {x['round'] for x in xs}==set(range(8))
  for x in xs:assert plan['orders'][x['round']][x['position']]==label
  med={k:statistics.median(x[k] for x in xs) for k in ['operations_cpu_ns','total_cpu_ns','heap_before_bytes','held_heap_bytes','heap_after_release_bytes','process_peak_before_bytes','process_peak_held_bytes']};group[label]=med;summary.append({'case':key,'engine':label,'workers':8,'medians':med})
 a,b=group['current'],group['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append({'case':key,'reason':'identical-binary CPU','ratio':ratio})
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':key,'reason':'identical-binary peak'})
 p,c=group['prior'],group['current'];comparisons.append({'case':key,'parent_cpu_ms':p['total_cpu_ns']/1e6,'current_cpu_ms':c['total_cpu_ns']/1e6,'cpu_ratio':c['total_cpu_ns']/p['total_cpu_ns'],'parent_peak_mib':p['process_peak_held_bytes']/2**20,'current_peak_mib':c['process_peak_held_bytes']/2**20,'parent_held_mib':p['held_heap_bytes']/2**20,'current_held_mib':c['held_heap_bytes']/2**20})
assert summary==json.loads((D/'summary.json').read_text());assert flags==json.loads((D/'decision.json').read_text())['quality_flags']
result={'cases':len(contracts),'preflights':len(pre),'measured_processes':len(rows),'exact_identity_outputs':True,'quality_passed':not flags,'quality_flags':flags,'comparisons':comparisons}
(R/'native-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
