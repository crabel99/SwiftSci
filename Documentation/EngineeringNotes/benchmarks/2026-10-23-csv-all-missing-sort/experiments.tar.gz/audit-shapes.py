from pathlib import Path
from collections import Counter
import hashlib,itertools,json,statistics
R=Path(__file__).resolve().parent;D=R/'shape-measurement'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((D/'plan.json').read_text());assert plan==json.loads((R/'shape-preflight/plan.json').read_text())
assert plan['controller_sha256']==h(R/'run-shape-panel.py')
labels=['original','prior','current','twin'];orders=plan['orders']
for label in labels:
 assert Counter(order.index(label) for order in orders)==Counter({x:2 for x in range(4)})
 assert plan['binaries'][label]==h(R/(('current' if label=='twin' else label)+'-shape'))
assert Counter((a,b) for order in orders for a,b in zip(order,order[1:]))==Counter({x:2 for x in itertools.permutations(labels,2)})
for label in labels[:-1]:
 x=json.loads((R/(label+'-shape-build.json')).read_text())
 assert x['source_sha256']==h(R/'ShapeProbe.swift') and x['binary_sha256']==plan['binaries'][label]
 assert x['verified_module']==json.loads((R/(label+'-workflow-build.json')).read_text())['verified_module']
for c in plan['contracts'].values():assert h(Path(c['path']))==c['file_sha256']
rows=[json.loads(x) for x in (D/'workers.jsonl').read_text().splitlines()]
pre=[json.loads(x) for x in (R/'shape-preflight/workers.jsonl').read_text().splitlines()]
assert len(rows)==len(plan['cases'])*32 and len(pre)==len(plan['cases'])*4
for x in rows+pre:
 c=plan['contracts'][x['case'].split('/')[0]]
 assert x['selection_sha256']==c['expected_index_sha256']
 assert x['frame']=={'rows':c['rows'],'columns':[{'name':'x','type':'Double','nulls':c['null_count'],'sha256':c['hashes'][0]}]}
 assert x['effective_double_storage']==x['case'].split('/')[2]
for name in ['power.txt','power-end.txt']:assert 'AC Power' in (D/name).read_text()
summary=[];flags=[]
for case in plan['cases']:
 key='/'.join(case.values());group={}
 for label in labels:
  xs=[x for x in rows if x['case']==key and x['engine']==label];assert len(xs)==8
  assert {x['round'] for x in xs}==set(range(8))
  for x in xs:assert x['engine']==orders[x['round']][x['position']]
  values=[x['samples'][0] for x in xs]
  m={k:statistics.median(x[k] for x in values) for k in values[0]}
  m['peak_above_baseline_bytes']=statistics.median(x['process_peak_held_bytes']-x['process_peak_before_bytes'] for x in values)
  summary.append(dict(case=key,engine=label,workers=8,medians=m));group[label]=m
 a,b=group['current'],group['twin'];ratio=b['total_cpu_ns']/a['total_cpu_ns']
 if abs(ratio-1)>.10:flags.append(dict(case=key,reason='identical-binary CPU',ratio=ratio))
 for x,y in [(a,b),(b,a)]:
  if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append(dict(case=key,reason='identical-binary memory'))
assert summary==json.loads((D/'summary.json').read_text())
assert flags==json.loads((D/'decision.json').read_text())['quality_flags']
result={'all_outputs_match':True,'preflights':len(pre),'measured_processes':len(rows),'cases':len(plan['cases']),'quality_passed':not flags,'quality_flags':flags,'scope':'Sorting and index release, input creation excluded and input retained through timing'}
(R/'shape-audit.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Ordered and disordered sort controls','','Eight fresh processes per label. CPU covers public sorting and index release with the input frame retained. CSV construction and exact validation are excluded. Original is checkpoint b982028c59; prior is 940353d441. All labels honor the requested storage choice.','','| Shape / count / storage | CPU original / prior / current, ms | Held heap original / prior / current, MiB | Peak RSS original / prior / current, MiB |','|---|---:|---:|---:|']
for case in plan['cases']:
 key='/'.join(case.values());g={x['engine']:x['medians'] for x in summary if x['case']==key}
 pair=lambda k,d:' / '.join(f'{g[e][k]/d:.3f}' for e in ['original','prior','current'])
 lines.append(f"| {case['input']} / {case['storage']} | {pair('total_cpu_ns',1e6)} | {pair('held_heap_bytes',2**20)} | {pair('process_peak_held_bytes',2**20)} |")
lines+=['','Quality flags: '+json.dumps(flags)+'. Flagged cases remain unqualified. Process peak RSS can include the earlier CSV construction peak.','']
(R/'shape-results.md').write_text('\n'.join(lines));print(json.dumps(result,indent=2))
