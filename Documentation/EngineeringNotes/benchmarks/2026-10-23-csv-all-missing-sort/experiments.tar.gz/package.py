from pathlib import Path
import ast,gzip,hashlib,json,re,shutil,subprocess,tarfile
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
assert subprocess.check_output(['git','branch','--show-current'],cwd=N,text=True).strip()=='codex/engineering-notes'
T=N/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-all-missing-sort';T.mkdir(parents=True,exist_ok=True)
a=json.loads((R/'audit.json').read_text());native=json.loads((R/'native-audit.json').read_text());shape=json.loads((R/'shape-audit.json').read_text());study=json.loads((R/'study.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==a['current_head']
flags={x['case'] for x in native['quality_flags']}
nt=['| Native key and row count | CPU parent / candidate, ms | Peak RSS parent / candidate, MiB | Qualified |','|---|---:|---:|---|']
for x in native['comparisons']:
 nt.append(f"| {x['case']} | {x['parent_cpu_ms']:.3f} / {x['current_cpu_ms']:.3f} | {x['parent_peak_mib']:.3f} / {x['current_peak_mib']:.3f} | {x['case'] not in flags} |")
real=json.loads((R/'measurement/summary.json').read_text());rt=['| Household serial storage and workflow | Total CPU parent / candidate, ms | Operation CPU parent / candidate, ms | Held heap parent / candidate, MiB | Peak RSS parent / candidate, MiB |','|---|---:|---:|---:|---:|']
for case in sorted({x['case'] for x in real}):
 g={x['engine']:x['medians'] for x in real if x['case']==case};pair=lambda k,d:' / '.join(f'{g[label][k]/d:.3f}' for label in ['prior','current'])
 rt.append(f"| {case.removeprefix('energy-common/serial/')} | {pair('total_cpu_ns',1e6)} | {pair('operations_cpu_ns',1e6)} | {pair('held_heap_bytes',2**20)} | {pair('process_peak_held_bytes',2**20)} |")
qualified=[x for x in native['comparisons'] if x['case'] not in flags]
allflags={'native':native['quality_flags'],'shape':shape['quality_flags'],'reference':a['quality_flags']}
overall={'source_head':a['current_head'],'parent_head':a['base'],'all_outputs_match':True,'test_functions_each_configuration':431,'test_configurations':['Release','Debug','Address Sanitizer'],'preflights':native['preflights']+shape['preflights']+a['workflow_preflights'],'measured_processes':native['measured_processes']+shape['measured_processes']+a['measured_processes'],'timing_cases':native['cases']+shape['cases']+a['case_combinations'],'qualified_timing_cases':native['cases']+shape['cases']+a['case_combinations']-len(flags)-len({x['case'] for x in shape['quality_flags']})-len({x['case'] for x in a['quality_flags']}),'quality_flags':allflags,'all_timing_cases_qualified':not any(allflags.values()),'source_promotion':False,'decision':'Retain isolated local candidate. All-missing invariant saves resources in qualified cases; five unqualified timings and common-path cost observations remain explicit.'}
(R/'overall-audit.json').write_text(json.dumps(overall,indent=2)+'\n')
text=f'''# Stable identity sorting for fully missing keys

The candidate adds one early return to `TypedColumn.sortedIndices`. When `nullCount == count`, every key is missing and the stable permutation is the original row order in either direction. Returning that permutation avoids key scans and sort preparation.

Source is `{a['current_head']}` on `{a['branch']}`, based on `{a['base']}`. This remains a local candidate. No push or PR is included. The [previous sparse-admission study](../2026-10-23-csv-sparse-key-admission/README.md) and [common-path diagnosis](../2026-10-23-csv-common-path-diagnosis/README.md) retain the earlier decisions and results.

## Use an existing invariant without another policy

`TypedColumn` is immutable and maintains its null count. The shortcut needs no additional metadata, cache, public option, size threshold, worker limit, or precision conversion. It runs before type-specific sorting dispatch and therefore applies to all supported native types, including Bool, String, and Date. Empty columns satisfy the same invariant.

Valid NaNs do not contribute to the null count and still use the existing comparison fallback. Finite values, numeric ties, signed zero, mixed missing values, native integer identities, and public dataframe sorting retain their existing contracts. The implementation adds one source line. The two new test functions occupy a 60-line type.

The semantic result was already correct. Both new tests pass before implementation. Their purpose is to protect the invariant and nearby behavior, not to manufacture a failing-before correctness claim. Resource measurements test the optimization separately.

## Measure the all-missing case across types and sizes

Eighteen cases cover Double, Float, Int64, Int32, Int, String, Date, Bool, and compact Double at one and eight million rows. Input construction is outside timing, and the caller retains the input through index sorting and result release. Optional native columns use their public initializer. Compact Double uses the public CSV reader with a complete Double schema and quoted empty fields. Constructor methods and storage choices match across source versions.

Every worker checks every returned index against identity and verifies its complete byte hash against an independently generated permutation. Timings use ascending order. Correctness tests cover both directions. Process peak RSS can include the earlier constructor peak.

{chr(10).join(nt)}

Fourteen of the 18 cases qualify under the frozen identical-binary controls. Their observed CPU reductions range from {(1-max(x['cpu_ratio'] for x in qualified))*100:.1f}% to {(1-min(x['cpu_ratio'] for x in qualified))*100:.1f}%. These are exceptional-case results for entirely missing keys. They do not establish the prevalence of that condition in production.

The qualified eight-million-row compact Double case falls from 18.867 to 6.076 ms CPU. Peak RSS falls from 191.828 to 130.797 MiB, about 61 MiB. The qualified String case falls from 383.430 to 6.147 ms CPU, with peak RSS 311.672 to 189.500 MiB, about 122 MiB less. Bool falls from 536.513 to 5.475 ms, with peak RSS 197.234 to 75.062 MiB.

The retained input and required index result are the same size. Held heap is essentially unchanged. The memory benefit comes from lower process peak, consistent with avoiding temporary sorting storage. These measurements do not establish physical memory traffic, cache effects, energy, or FLOPs.

The Double one-million-row, Float one-million-row, Date one-million-row, and Double eight-million-row comparisons are unqualified. Their identical-binary median CPU ratios exceed the existing 10% limit. Their outputs remain correct, and their observations remain in the table and raw records. No performance conclusion is drawn from those four cases. No rerun or quality waiver replaces them.

## Keep common-path costs visible

The existing 80 shape cases cover 32,768 and one million rows with both storage choices. They include monotonic order, early/middle/late disorder, random values, sparse values, clustered and distributed missing rows, and the earlier admission boundary. They check the added branch when a key contains values.

All 2,560 measured outputs match their full fingerprints. Seventy-nine timing comparisons qualify. The compact 32,768-row distributed case just below half occupancy is unqualified because the identical-binary CPU ratio is 1.1311.

The largest qualified common-control CPU increase is the optional 32,768-row half-minus-one case, 0.068 to 0.076 ms, about 11.8%. The compact million-row half-plus-one case rises from 2.353 to 2.589 ms, about 10.0%. The optional million-row ascending control rises from 1.270 to 1.354 ms, about 6.6%. These observations are retained. A single metadata branch does not by itself explain their physical cause, and the panel does not establish that every increase is a persistent algorithmic cost. It would also be wrong to discard them because the all-missing case improves.

[All shape results](shape-results.md) include the earlier shared-key checkpoint and the immediate parent. No new threshold or source workaround was fitted to these results.

## Check complete reference workflows separately

Four serial household workflows cover optional and compact storage, index sorting, and sorting followed by matrix preparation over 2,075,259 observations. These keys contain values and do not take the new early return. The same complete schema, null tokens, input bytes, native types, and row order apply to every source version.

Total CPU includes CSV construction, the requested operations, consumer preparation, and release. Operation CPU excludes CSV construction and release. Full verification is outside timing.

{chr(10).join(rt)}

Total CPU changes range from 2.4% lower to 1.1% higher. Retained heap and peak RSS are essentially unchanged. Optional index-sort operation CPU rises from 46.694 to 49.629 ms, about 6.3%, although its full-path increase is 1.1%. Matrix-operation CPU also changes slightly. These observations do not show a general CSV or ordinary-sort improvement.

All four reference cases qualify and match exactly. This selected panel is a common-path check, not a replacement for the earlier 24-case reference panel or a new formal performance baseline. The same input contracts also pass 28 eager and 28 streamed exact reads across the existing reference policies and storage choices.

## Verification, qualification, and decision

Release, Debug, and Address Sanitizer each pass all 431 dataframe test functions with zero failures or skips. The two new functions check all supported native types, both directions, empty and bitmap-boundary sizes, public sort output, unchanged column names and types, Int64 row identities above 2^53, compact null validity, and valid NaNs among missing values. This validates the dataframe module, not the complete MLX-dependent package. Address Sanitizer does not prove universal leak freedom.

The panels contain {overall['preflights']} preflights and {overall['measured_processes']} measured fresh processes. Every complete output matches. There are 102 timing comparisons, of which {overall['qualified_timing_cases']} qualify. Four all-missing cases and one common-shape case remain unqualified.

Eight balanced orders put each label in each position twice and each ordered adjacent pair twice. The original label is `b982028c59c89f615688882ee71be19a0eccd8f2`. The parent label is `940353d441c5b2b1bcec69344629452b4ac65b7c`. Current and twin run the identical new executable. Median CPU drift above 10%, or peak RSS above 5% plus 8 MiB, flags the affected comparison. No quality rule, numerical tolerance, worker budget, affinity setting, or precision policy changed.

Tests, builds, and input preparation finish before timing. AC power is checked at both ends. Native parallelism is unchanged. CPU is process user plus system time. Independent audits verify source and input hashes, matching object and module provenance, complete output equality, balanced orders, and recomputed medians.

The decision is to retain the one-line shortcut as an isolated local candidate. Its invariant is general and its qualified exceptional-case resource savings are substantial. Five unqualified comparisons and the common-control CPU increases prevent an unconditional performance or production recommendation. The source checkpoint is preserved without changing other sorting policies.

## Evidence and reproduction

[Overall audit](overall-audit.json), [source and reference audit](audit.json), [all-missing audit](native-audit.json), [shape audit](shape-audit.json), [full reference results](results.md), [all shape results](shape-results.md), and [comparator provenance](comparator-provenance.json) retain the results and their limits.

The [experiment archive](experiments.tar.gz) contains the clients, fixture generators, controllers, raw measurements, build and test receipts, source snapshots, and validation logs. The [source patch](changes.patch.gz) applies to the recorded direct parent. [Artifact hashes](artifact-sha256.json) identify these files.

The archived `verify.py`, `validate.py`, `measure.py`, `audit.py`, `audit-native.py`, and `package.py` reproduce the stages. Restore the recorded dependency paths and external dataset contracts before rebuilding. Match each client to its own module interface and object. Preserve unqualified records when repeating any later study.
'''
assert '—' not in text
(T/'README.md').write_text(text)
for name in ['overall-audit.json','audit.json','native-audit.json','shape-audit.json','results.md','shape-results.md','comparator-provenance.json','study.json']:shutil.copy2(R/name,T/name)
patch=subprocess.check_output(['git','diff',a['base'],'--binary'],cwd=S);(R/'changes.patch').write_bytes(patch);subprocess.run(['git','apply','--reverse','--check','-'],cwd=S,input=patch,check=True)
with gzip.GzipFile(filename=str(T/'changes.patch.gz'),mode='wb',mtime=0) as f:f.write(patch)
assert gzip.decompress((T/'changes.patch.gz').read_bytes())==patch
with tarfile.open(T/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.swift','.json','.jsonl','.log','.txt','.md','.patch'] and not any(x.endswith('.xcresult') for x in p.relative_to(R).parts):tar.add(p,arcname=str(p.relative_to(R)))
 for folder in ['Sources/SwiftDataFrame','Tests/SwiftDataFrameTests']:
  for p in sorted((S/folder).rglob('*.swift')):tar.add(p,arcname='final-source/'+str(p.relative_to(S)))
 for label,root in [('original','/private/tmp/swiftsci-csv-lazy-sort-cache-20261023'),('prior','/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023')]:tar.add(Path(root)/'module-build.json',arcname=label+'-module-receipt.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='inputs/'+p.name)
with tarfile.open(T/'experiments.tar.gz') as tar:assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
for p in R.glob('*.py'):ast.parse(p.read_text())
for link in re.findall(r'\]\(([^)]+)\)',text):
 if '://' not in link and link!='artifact-sha256.json':assert (T/link).exists(),link
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={p.name:h(p) for p in sorted(T.iterdir()) if p.name!='artifact-sha256.json'};(T/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n');assert all(h(T/k)==v for k,v in manifest.items())
print(T);print(json.dumps(overall,indent=2));print('Verified patch, archive, links, scripts and evidence hashes')
