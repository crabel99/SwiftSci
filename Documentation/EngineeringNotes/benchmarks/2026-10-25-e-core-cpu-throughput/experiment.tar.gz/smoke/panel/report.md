# Equivalent external-engine CPU queues

Smoke validation only.

Controls passed: False. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 109.5 | 578.05 | 1987.3 | 4991.8 |
| swiftsci_compact | 121.2 | 551.46 | 1413.6 | 3803.3 |
| pandas | 48.3 | 1716.41 | 2216.9 | 10619.7 |
| polars | 123.3 | 678.48 | 1764.1 | 5153.5 |
| duckdb | 86.5 | 1019.70 | 2247.5 | 8780.5 |
| pandas_arrow | 136.0 | 615.09 | 2227.0 | 5047.6 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.

## Verified application core class

Every worker and the controller must record zero P-core user time. Kernel P/E time is reported separately and does not fail that rule. A supported-counter calibration precedes the common background QoS clamp. QoS is not treated as affinity.

| Condition | E user ms/job | P user ms/job | E kernel ms/job | P kernel ms/job |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 499.197 | 0.000 | 79.142 | 0.038 |
| swiftsci_compact | 496.821 | 0.000 | 60.969 | 0.037 |
| pandas | 1602.833 | 0.000 | 113.817 | 0.040 |
| polars | 587.359 | 0.000 | 90.666 | 0.627 |
| duckdb | 917.881 | 0.000 | 101.499 | 0.028 |
| pandas_arrow | 526.638 | 0.000 | 90.358 | 0.067 |

Core counters bracket the queue plus boundary bookkeeping. They cover a wider interval than the wall timer and are not an exact partition of the existing charged_cpu_ns metric. Raw worker and controller snapshots remain in each receipt.
