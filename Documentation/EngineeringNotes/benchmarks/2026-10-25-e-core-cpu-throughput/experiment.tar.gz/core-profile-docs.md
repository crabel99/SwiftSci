
## Compare with verified E-core application execution

Use `compare_e_cores.py` for the common application-core rule. Pass the same comparison arguments, including `--pandas-arrow` when comparing both pandas readers:

```sh
python3 Benchmarks/CPUThroughput/compare_e_cores.py \
  --swift-worker /absolute/path/worker \
  --python /absolute/path/comparison-environment/bin/python \
  --air-contract /absolute/path/air.json \
  --energy-contract /absolute/path/energy.json \
  --expected /absolute/path/independent-expected.json \
  --output /absolute/path/new-core-comparison-directory \
  --pandas-arrow --smoke
```

The launcher builds a small C reader against the installed macOS SDK, which defines the versioned `rusage_info_v6` layout. It demonstrates working P-core counters with a one-second probe before starting the comparison under a background QoS clamp. The controller and its worker processes inherit the same clamp. Libraries retain their native thread pools. QoS is a scheduling preference, so every timed queue must independently verify its actual placement.

Run the launcher under normal scheduling. Preclamping the launcher can prevent its positive-P calibration. Missing SDK support, failed calibration, a different boot session, invalid counters, or any nonzero P-core user time fails the run. Unsupported zero counters cannot stand in for proof of E-core execution.

Acceptance requires zero P-core user time for every worker and the controller. Kernel execution may use either core type. Each queue records raw per-process user, kernel, P-only, instruction, and cycle counters. The audit binds them to the actual worker and controller process IDs, recomputes all deltas, and reports E-user, P-user, E-kernel, and P-kernel time separately. Nonzero P-kernel time is visible and allowed.

Core snapshots bracket the queue plus boundary bookkeeping, while the existing wall timer covers queue execution. The four core-time components therefore are not an exact partition of `charged_cpu_ns`. They are additional accounting with explicit interval boundaries, not an energy estimate. The worker snapshots occur while workers are waiting at the request boundary; the controller snapshot includes its active accounting call. No scheduler trace or enforced affinity is claimed.

The original work totals, caller counts, native CPU parallelism, memory ceiling, output contracts, and twin limits stay unchanged. Core-class acceptance does not waive a failed CPU, elapsed-time, memory, or output check. A smoke run still cannot qualify performance. Compare results within the same core policy; unrestricted runs do not establish E-core results.

Read `<output>/panel/report.md` and its raw queue receipts. `<output>/core-controls/calibration.json` records the host boot session, source and compiled-reader fingerprints, build commands, and positive-P probe. Audit separately with:

```sh
python3 Benchmarks/CPUThroughput/compare.py \
  --output /absolute/path/completed-core-comparison-directory/panel --audit
```

Apple documents P-only counters in [Recount](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/doc/observability/recount.md). The [Apple Silicon scheduling guidance](https://developer.apple.com/news/?id=vk3m204o) explains how QoS influences placement. These controls do not expose a public P/E affinity mask.
