from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
p=S/'Benchmarks/CPUThroughput/core_usage.py';s=p.read_text().replace('import os\n','').replace('import time\n','');p.write_text(s)
p=S/'Benchmarks/CPUThroughput/run.py';s=p.read_text()
s=s.replace('directory, rss_limit_bytes=8 * 2**30):','directory, rss_limit_bytes=8 * 2**30, core_reader=None):',1)
s=s.replace("        before = [worker.ask('stats') for worker in workers]\n", "        before = [worker.ask('stats') for worker in workers]\n        core_before = None if core_reader is None else [core_reader.snapshot(w.process.pid) for w in workers]\n        controller_before = None if core_reader is None else core_reader.snapshot(os.getpid())\n",1)
s=s.replace("        summary = summarize(results, end-start, sampler.samples, jobs)\n", "        core_after = None if core_reader is None else [core_reader.snapshot(w.process.pid) for w in workers]\n        controller_after = None if core_reader is None else core_reader.snapshot(os.getpid())\n        summary = summarize(results, end-start, sampler.samples, jobs)\n",1)
a=s.index("        save(directory / 'result.json', dict(summary=summary,");b=s.index('        return summary',a)
s=s[:a]+'''        record = dict(summary=summary, jobs=results, memory_samples=sampler.samples,
                      before=before, after=after, runtime=[worker.ready for worker in workers])
        if core_reader is not None:
            from Benchmarks.CPUThroughput.core_usage import audit_receipt
            record['core_usage'] = dict(before=core_before,after=core_after,
                controller_before=controller_before,controller_after=controller_after)
            save(directory / 'result.json',record)
            summary['core_time_ns'] = audit_receipt(record['core_usage'],concurrency)['time_ns']
        save(directory / 'result.json',record)
'''+s[b:];p.write_text(s)
p=S/'Benchmarks/CPUThroughput/compare.py';s=p.read_text()
s=s.replace('from runner import power_state','from runner import power_state\nfrom Benchmarks.CPUThroughput.core_usage import CoreReader, audit_receipt, validate_calibration')
s=s.replace("    modes = {name:c['mode']", "    if plan.get('core_policy') is not None:\n        validate_calibration(plan['core_policy'])\n    modes = {name:c['mode']",1)
s=s.replace("        jobs+=len(raw['jobs'])", "        if plan.get('core_policy') is not None:\n            core = audit_receipt(raw['core_usage'],plan['callers'])\n            if summary['core_time_ns'] != core['time_ns']:\n                raise ValueError('Core time summary differs from raw counters')\n        elif 'core_usage' in raw:\n            raise ValueError('Unplanned core accounting')\n        jobs+=len(raw['jobs'])")
s=s.replace("performance_qualified=not flags and not plan['smoke'],flags=flags)", "performance_qualified=not flags and not plan['smoke'],flags=flags,\n                  application_core_class='efficiency' if plan.get('core_policy') else 'unverified')")
s=s.replace("    return '\\n'.join(lines)+'\\n'", '''    if plan.get('core_policy') is not None:
        lines += ['', '## Verified application core class', '',
            'Every worker and the controller must record zero P-core user time. Kernel P/E time is reported separately and does not fail that rule. A supported-counter calibration precedes the common background QoS clamp. QoS is not treated as affinity.', '',
            '| Condition | E user ms/job | P user ms/job | E kernel ms/job | P kernel ms/job |',
            '| --- | ---: | ---: | ---: | ---: |']
        for name in plan['conditions']:
            rows=[r['summary']['core_time_ns'] for r in records if r['label'].removesuffix('_twin')==name]
            lines.append('| '+name+' | '+' | '.join(f"{statistics.median(x[k] for x in rows)/decision['jobs_per_queue']/1e6:.3f}" for k in ['user_e','user_p','kernel_e','kernel_p'])+' |')
        lines += ['', 'Core counters bracket the queue plus boundary bookkeeping. They cover a wider interval than the wall timer and are not an exact partition of the existing charged_cpu_ns metric. Raw worker and controller snapshots remain in each receipt.']
    else:
        lines += ['', 'P/E placement was not verified for this unrestricted native-CPU profile. Its controls do not establish the same application core type.']
    return '\\n'.join(lines)+'\\n' '''.rstrip(),1)
s=s.replace("p.add_argument('--pandas-arrow',", "p.add_argument('--core-calibration',type=Path,help=argparse.SUPPRESS)\n    p.add_argument('--pandas-arrow',")
s=s.replace('    configs=conditions(args.swift_worker,', '    core_reader = CoreReader(args.core_calibration) if args.core_calibration else None\n    configs=conditions(args.swift_worker,',1)
s=s.replace("ROOT/'Benchmarks/Tools/runner.py']", "ROOT/'Benchmarks/Tools/runner.py',Path(__file__).with_name('core_usage.py'),\n             Path(__file__).with_name('core_counters.c'),Path(__file__).with_name('compare_e_cores.py')]")
s=s.replace('plan=dict(include_pandas_arrow=', 'plan=dict(core_policy=None if core_reader is None else core_reader.policy,include_pandas_arrow=')
s=s.replace("rss_limit_bytes=plan['rss_limit_bytes'])", "rss_limit_bytes=plan['rss_limit_bytes'],core_reader=core_reader)")
p.write_text(s)
