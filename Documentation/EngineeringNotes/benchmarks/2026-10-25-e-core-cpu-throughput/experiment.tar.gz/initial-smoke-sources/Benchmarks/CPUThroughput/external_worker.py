#!/usr/bin/env python3
"""Persistent external-engine endpoint for the CPU queue protocol."""
from pathlib import Path
import json
import os
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"Tools"))
from execution_policy import PRODUCTION_MODE, runtime_record, validate_runtime
from external_workflows import ExternalWorkflow, cpu, rss, peak


def emit(value):
    print(json.dumps(value,allow_nan=False),flush=True)


def main():
    engine = sys.argv[1]
    work = ExternalWorkflow(engine)
    try:
        execution = runtime_record(work.pools)
        validate_runtime(execution,PRODUCTION_MODE,engine)
        emit(dict(ready=True,pid=os.getpid(),engine=engine,versions=work.versions,execution=execution))
        for line in sys.stdin:
            if line.strip() == "stats":
                emit(dict(cpu_ns=cpu(),rss_bytes=rss(),peak_bytes=peak()))
            else:
                emit(work.execute(json.loads(line)))
    finally:
        work.close()


if __name__ == "__main__":
    main()
