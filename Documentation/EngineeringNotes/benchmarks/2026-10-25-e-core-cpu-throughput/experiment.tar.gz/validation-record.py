"""Verify the executed test counts before recording validation evidence."""
from pathlib import Path
import json,re
R=Path(__file__).parent
results={}
for filename,expected,skips in [('focused-tests.log',29,0),('controller-tests.log',255,4),('optional-metal-tests.log',4,0)]:
 text=(R/filename).read_text();match=re.search(r'Ran (\d+) tests? in ',text)
 assert match and int(match[1])==expected,(filename,text[-2000:])
 ending=text.strip().splitlines()[-1]
 assert ending==('OK (skipped=4)' if skips else 'OK'),(filename,ending)
 results[filename]=dict(tests=expected,passed=expected-skips,skipped=skips,status='passed')
results.update(unique_tests_executed=255,new_native_swift_tests=False,
 unchanged_swift_source_head='58db37c4b3c97b287186c377f76f89abcbbb0b0d',
 prior_dataframe_tests=dict(debug=447,release=447),
 test_commands='validate.sh',hosted_ci_run=False)
(R/'validation.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
