# Equivalent external-engine CPU queues

Smoke validation only.

Controls passed: False. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 114.0 | 781.93 | 2122.8 | 5190.8 |
| swiftsci_compact | 128.9 | 733.35 | 1417.8 | 3280.3 |
| pandas | 40.3 | 2463.55 | 2720.8 | 11740.6 |
| polars | 141.1 | 953.69 | 1745.5 | 4017.3 |
| duckdb | 67.2 | 1896.09 | 2220.7 | 10725.3 |
| pandas_arrow | 119.8 | 1057.98 | 3140.5 | 5945.1 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.

## Verified application core class

Every worker and the controller must record zero P-core user time. Kernel P/E time is reported separately and does not fail that rule. A supported-counter calibration precedes the common background QoS clamp. QoS is not treated as affinity.

| Condition | E user ms/job | P user ms/job | E kernel ms/job | P kernel ms/job |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 691.051 | 0.000 | 92.807 | 0.021 |
| swiftsci_compact | 668.199 | 0.000 | 65.340 | 0.018 |
| pandas | 2329.136 | 0.000 | 134.601 | 0.072 |
| polars | 854.162 | 0.000 | 99.565 | 0.048 |
| duckdb | 1733.618 | 0.000 | 161.725 | 0.105 |
| pandas_arrow | 929.104 | 0.000 | 129.216 | 0.000 |

Core counters bracket the queue plus boundary bookkeeping. They cover a wider interval than the wall timer and are not an exact partition of the existing charged_cpu_ns metric. Raw worker and controller snapshots remain in each receipt.
