"""Audit core-class qualification separately from comparative performance."""
from pathlib import Path
import hashlib,json,subprocess,sys
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent;D=R/'committed-smoke/panel'
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput.compare import audit
from Benchmarks.CPUThroughput.core_usage import audit_receipt
from Benchmarks.CPUThroughput.run import save,digest
plan=json.loads((D/'plan.json').read_text());decision=audit(D)
assert decision['application_core_class']=='efficiency'
assert (decision['queues'],decision['jobs'],decision['full_output_checks'])==(24,192,48)
assert not decision['performance_qualified']
records=json.loads((D/'records.json').read_text());ready=json.loads((D/'preflight/ready.json').read_text());post=json.loads((D/'postflight/ready.json').read_text())
intervals=[]
for row in records:
 raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
 value=audit_receipt(raw['core_usage'],[w['pid'] for w in raw['runtime']])
 assert value['time_ns']==row['summary']['core_time_ns']
 assert value['controller']['pid']==plan['controller_pid']
 name=row['label'].removesuffix('_twin')
 for meta in raw['runtime']:
  for key in ['engine','versions','execution']:assert meta.get(key)==ready[name].get(key)==post[name].get(key)
 intervals.append(dict(round=row['round'],label=row['label'],**value))
for path,contract in plan['contracts'].items():
 assert digest(Path(contract['path']))==contract['sha256'];assert json.loads(Path(path).read_text())==contract
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert head==plan['source_head']
sources=plan['source_hashes'] | plan['swift_build']['sources']
for path in [*S.glob('Benchmarks/Tests/test_*cpu*.py'),S/'Benchmarks/CPUThroughput/README.md']:
 name=str(path.relative_to(S));sources[name]=digest(path)
for name,sha in sources.items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=S);assert hashlib.sha256(data).hexdigest()==sha
 dest=R/'measured-sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
workers=sum(len(x['workers']) for x in intervals)
assert workers==96 and all(x['time_ns']['user_p']==0 for x in intervals)
summary=dict(source_commit=head,policy=plan['core_policy']['policy'],user_selected_rule='Require E-core application execution; report kernel P/E time separately',
 qualification=decision,worker_intervals=workers,controller_intervals=len(intervals),application_p_time_ns=0,
 kernel_p_ns=sum(x['time_ns']['kernel_p'] for x in intervals),validation=json.loads((R/'validation.json').read_text()),runtime=ready)
save(R/'summary.json',summary);save(R/'core-intervals.json',intervals)
save(R/'provenance.json',dict(source_commit=head,controller_source_hashes=plan['source_hashes'],swift_build=plan['swift_build'],core_policy=plan['core_policy'],all_hashes_match_commit=True,all_contracts_unchanged=True,all_runtime_identities_match=True))
lines=['# Verified E-core application benchmark profile','',
 f'Implementation commit `{head}` on local branch `codex/e-core-cpu-throughput` builds on `624fc7e08638b0a80647753d8f8dbe44eb37ef80`. The user selected this rule on 2026-10-25: require E-core application execution and report kernel P/E time separately. Nothing is pushed.','',
'## Qualification result','',
'The committed controller completes 24 smoke queues, 192 jobs, and 48 full native-output checks across SwiftSci optional, SwiftSci compact, pandas C, pandas via explicit-schema Arrow, Polars, and DuckDB plus Arrow. All 96 worker intervals and 24 controller intervals record zero P-core application time. All worker counter boundaries pass the idle-thread checks. Kernel P-core execution remains recorded and allowed.','',
'This validates the selected placement rule and the reusable controller path. It does not qualify performance. Smoke never establishes a ranking, and its CPU/elapsed repeatability controls also fail. These failures stay visible; no limits, case counts, memory ceiling, caller counts, or schemas change.','',
'## Implementation','',
'The launcher builds a small C reader against the installed SDK, using rusage_info_v6 and proc_taskinfo instead of guessed structure offsets. It demonstrates positive P-core counters before starting the comparison under one inherited background QoS clamp. The calibration is bound to the OS boot session and records source, compiled-reader, and probe fingerprints.','',
'Each worker must have zero running threads before and after its resource snapshot. A bounded wait fails if the worker does not become idle. The controller uses its own snapshots after all queue work and controller threads have completed. The independent audit binds counters to actual worker/controller PIDs, checks positive work and monotonic/consistent counters, rejects any P-core user time, and recomputes the four time components from raw Mach ticks.','',
'QoS is a scheduling preference, not affinity. Acceptance depends on observed counters. Kernel time is classified separately into P and E time; it does not fail the application-only rule. Core counters bracket queue work plus boundary bookkeeping and are not an exact partition of the older charged_cpu_ns interval. Raw values and the Mach timebase remain preserved. CPU time is not measured energy.','',
'The source README documents the new compare_e_cores.py entry point and separate audit. Existing unrestricted plans remain identifiable as unverified for core class. Neither historical results nor the earlier failed Arrow panel gains placement evidence retroactively.','',
'## Test evidence','',
'The 29 focused CPU tests pass. The complete controller discovery executes 255 tests: 251 pass and four require Metal opt-in. Those four pass separately with SWIFTSCI_MLX_TEST_GPU=1. All 255 execute successfully across the two configurations. Tests run after CPU timing. The C reader and positive-P probe compile with -Wall -Wextra -Werror.','',
'New tests cover E-only application time with allowed P-kernel time, P-user rejection, unsupported zero P calibration, invalid/negative counters, wrong PIDs, incomplete/duplicate worker receipts, idle-boundary rejection, and timeout. A live negative-path test confirms a rejected queue preserves its raw counters and closes its worker.','',
'All 51 measured Swift source hashes are unchanged from library head 58db37c4b3c97b287186c377f76f89abcbbb0b0d, which previously passed 447 Debug and 447 Release dataframe tests. No new native Swift or hosted CI run is claimed.','',
'## Remaining performance work','',
'The formal six-condition E-core panel remains to run. Its fixed protocol has 12 rotated rounds, 144 queues, 64 jobs per queue, four callers, the same 8 GiB sampled worker-RSS ceiling, independent output hashes, and unchanged twin limits. The first smoke gives a rough two-hour runtime forecast for that work on four E cores. This is planning, not a scaling result or permission to retune the work.','',
'The short committed smoke has the following control failures:','',
'| Condition | Metric | Twin ratio |','| --- | --- | ---: |']
for flag in decision['flags']:lines.append(f'| {flag["label"]} | {flag["metric"]} | {flag.get("ratio",0):.3f} |')
lines+=['',
'The initial pre-commit smoke is retained separately with its 11 exact controller-source snapshots. It predates the idle-boundary guard; the committed smoke above is the validation of that stronger guard. The earlier Arrow panel and its RSS failure remain in the prior engineering-notes record.','',
'## Evidence and reproduction','',
'[Summary](summary.json), [source provenance](provenance.json), [validation](validation.json), [accepted process intervals](core-intervals.json), and the [experiment archive](experiment.tar.gz) preserve exact measured sources, raw before/after counters, calibrations, output checks, runtime metadata, controls, and test logs. The archive excludes binaries, raw datasets, and caches.','',
'Restore the recorded worker and input contracts by SHA256. Run compare_e_cores.py under normal scheduling with the documented comparison arguments and --pandas-arrow --smoke. It compiles and calibrates before applying the clamp to the child controller. Audit the panel subdirectory with compare.py --audit. Remove --smoke only for the full fixed panel.','',
'Primary API context: [Apple Recount](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/doc/observability/recount.md), [SDK process task fields](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/sys/proc_info.h), and [Apple scheduling guidance](https://developer.apple.com/news/?id=vk3m204o). Engineering conclusions remain on codex/engineering-notes.']
(R/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(summary,indent=2))
