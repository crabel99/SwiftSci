"""Keep unlike workloads and changed qualification rules out of engine comparisons."""
import copy
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput.compare import conditions, validate_plan, LIMITS


class ExternalCPUPlanTests(unittest.TestCase):
    def setUp(self):
        self.plan=dict(conditions=conditions(Path('/swift'),Path('/python')),smoke=False,
            callers=4,copies_per_case=16,rss_limit_bytes=8*2**30,quality_policy=LIMITS.copy(),
            cases=[dict(input=kind,workflow=flow) for kind in ['air','energy'] for flow in ['read','sort-matrix']])
        labels=list(self.plan['conditions']);labels += [name+'_twin' for name in labels]
        self.plan['orders']=[labels[i:]+labels[:i] for i in range(10)]

    def test_accepts_frozen_full_and_smoke_work(self):
        validate_plan(self.plan)
        self.plan.update(smoke=True,copies_per_case=2,orders=self.plan['orders'][:2])
        validate_plan(self.plan)

    def test_arrow_extension_retains_original_panel_and_full_rotation(self):
        self.plan.update(include_pandas_arrow=True,
            conditions=conditions(Path('/swift'),Path('/python'),True))
        labels=list(self.plan['conditions']);labels += [name+'_twin' for name in labels]
        self.plan['orders']=[labels[i:]+labels[:i] for i in range(len(labels))]
        validate_plan(self.plan)
        self.plan['conditions'].pop('pandas_arrow')
        with self.assertRaises(ValueError):validate_plan(self.plan)

    def test_rejects_unlike_engines_work_budgets_and_relaxed_limits(self):
        mutations=[lambda p:p['conditions'].pop('duckdb'),
            lambda p:p['conditions']['pandas'].update(mode='compact'),
            lambda p:p.update(callers=5),lambda p:p.update(copies_per_case=1),
            lambda p:p.update(rss_limit_bytes=16*2**30),
            lambda p:p['quality_policy'].update(twin_cpu_deviation=.20),
            lambda p:p['orders'].pop(),lambda p:p['cases'].pop(),
            lambda p:p['cases'][0].update(workflow='partial-read')]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                changed=copy.deepcopy(self.plan);mutate(changed)
                with self.assertRaises(ValueError):validate_plan(changed)


if __name__=='__main__':unittest.main()
