"""Reject unverified or mixed application placement without hiding kernel work."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput.core_usage import CoreReader, FIELDS, POLICY, SOURCE, audit_receipt, digest, interval, validate_calibration


def snapshot(pid=1):
    return dict.fromkeys(FIELDS,0) | dict(pid=pid,timebase_numer=125,timebase_denom=3,running_before=0,running_after=0)


def completed(pid=1):
    return snapshot(pid) | dict(user_ticks=24,system_ticks=12,p_system_ticks=3,
                                instructions=100,p_instructions=10,cycles=200,p_cycles=20)


class CoreUsageTests(unittest.TestCase):
    def test_e_application_accepts_and_splits_p_kernel_work(self):
        value=interval(snapshot(),completed())
        self.assertEqual(value['deltas']['p_system_ticks'],3)
        self.assertEqual(value['time_ns'],dict(user_e=1000,user_p=0,kernel_e=375,kernel_p=125))

    def test_rejects_p_user_time_missing_work_and_invalid_accounting(self):
        for key,value in [('p_user_ticks',1),('instructions',0),('cycles',0),
                          ('system_ticks',-1),('p_system_ticks',13),('p_instructions',101),
                          ('pid',2),('timebase_numer',0),('timebase_denom',4)]:
            with self.subTest(key=key):
                after=completed();after[key]=value
                with self.assertRaises(ValueError):interval(snapshot(),after)

    def test_receipt_checks_every_worker_and_controller(self):
        value=dict(before=[snapshot(1),snapshot(2)],after=[completed(1),completed(2)],
                   controller_before=snapshot(3),controller_after=completed(3))
        self.assertEqual(audit_receipt(value,[1,2])['time_ns']['kernel_p'],375)
        for who in ['after','controller_after']:
            invalid=copy.deepcopy(value)
            target=invalid[who][1] if who=='after' else invalid[who]
            target['p_user_ticks']=1
            with self.assertRaises(ValueError):audit_receipt(invalid,[1,2])
        invalid=copy.deepcopy(value);invalid['before'][1]=snapshot(1);invalid['after'][1]=completed(1)
        with self.assertRaises(ValueError):audit_receipt(invalid,[1,2])
        with self.assertRaises(ValueError):audit_receipt(value,[1,2,3])

    def test_worker_snapshot_requires_idle_threads(self):
        reader=CoreReader.__new__(CoreReader)
        reader.lib=SimpleNamespace(running_threads=Mock(side_effect=[0,1,0,0]))
        reader.snapshot=Mock(return_value=completed(12))
        with patch('Benchmarks.CPUThroughput.core_usage.time.sleep'):
            value=reader.worker_snapshot(12)
        self.assertEqual((value['running_before'],value['running_after']),(0,0))
        self.assertEqual(reader.snapshot.call_count,2)
        reader.lib.running_threads=Mock(return_value=1)
        with patch('Benchmarks.CPUThroughput.core_usage.time.monotonic',side_effect=[0,0,2]), \
             patch('Benchmarks.CPUThroughput.core_usage.time.sleep'):
            with self.assertRaises(TimeoutError):reader.worker_snapshot(12)
        bad=dict(before=[completed(1)],after=[completed(1)],
                 controller_before=snapshot(3),controller_after=completed(3))
        bad['before'][0]['running_before']=1
        with self.assertRaises(ValueError):audit_receipt(bad,[1])

    def test_zero_p_calibration_is_not_e_core_proof(self):
        with tempfile.TemporaryDirectory() as root:
            library=Path(root)/'library';library.write_bytes(b'calibration fixture')
            calibration=dict(policy=POLICY,source_sha256=digest(SOURCE),library=str(library),
                library_sha256=digest(library),probe=completed() | dict(p_user_ticks=1))
            validate_calibration(calibration)
            for key in ['p_user_ticks','p_instructions','p_cycles']:
                invalid=copy.deepcopy(calibration);invalid['probe'][key]=0
                with self.assertRaises(ValueError):validate_calibration(invalid)
            library.write_bytes(b'changed')
            with self.assertRaises(ValueError):validate_calibration(calibration)


if __name__=='__main__':unittest.main()
