/* Compile against the installed SDK to read the versioned resource structure. */
#include <libproc.h>
#include <sys/resource.h>
#include <stdint.h>
#include <mach/mach_time.h>
#include <sys/proc_info.h>
#include <errno.h>

int read_core_usage(int pid, uint64_t *out) {
    struct rusage_info_v6 r = {0};
    int status = proc_pid_rusage(pid, RUSAGE_INFO_V6, (rusage_info_t *)&r);
    if (status) return status;
    out[0] = r.ri_user_time; out[1] = r.ri_system_time;
    out[2] = r.ri_user_ptime; out[3] = r.ri_system_ptime;
    out[4] = r.ri_instructions; out[5] = r.ri_pinstructions;
    out[6] = r.ri_cycles; out[7] = r.ri_pcycles; out[8] = r.ri_flags;
    mach_timebase_info_data_t scale;
    mach_timebase_info(&scale);
    out[9] = scale.numer; out[10] = scale.denom;
    return 0;
}

int running_threads(int pid) {
    struct proc_taskinfo task;
    int size = proc_pidinfo(pid, PROC_PIDTASKINFO, 0, &task, sizeof(task));
    if (size != (int)sizeof(task)) {
        if (size >= 0) errno = EIO;
        return -1;
    }
    return task.pti_numrunning;
}

#ifdef CORE_COUNTER_PROBE
#include <stdio.h>
#include <time.h>
#include <unistd.h>
static uint64_t now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000000000ULL + t.tv_nsec;
}
int main(void) {
    uint64_t a[11], b[11];
    if (read_core_usage(getpid(), a)) return 1;
    volatile uint64_t value = 1;
    uint64_t start = now();
    while (now() - start < 1000000000ULL)
        for (int i = 0; i < 10000; i++) value = value * 6364136223846793005ULL + 1;
    if (read_core_usage(getpid(), b)) return 1;
    printf("{\"user_ticks\":%llu,\"system_ticks\":%llu,\"p_user_ticks\":%llu,"
           "\"p_system_ticks\":%llu,\"instructions\":%llu,\"p_instructions\":%llu,"
           "\"cycles\":%llu,\"p_cycles\":%llu,\"timebase_numer\":%llu,\"timebase_denom\":%llu}\n",
           b[0]-a[0], b[1]-a[1], b[2]-a[2], b[3]-a[3], b[4]-a[4],
           b[5]-a[5], b[6]-a[6], b[7]-a[7], b[9], b[10]);
    return 0;
}
#endif
