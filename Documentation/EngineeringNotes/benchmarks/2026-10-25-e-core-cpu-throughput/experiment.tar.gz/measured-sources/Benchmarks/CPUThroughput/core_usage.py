"""Account application and kernel P/E time without treating QoS as affinity."""
import ctypes
import hashlib
import json
import platform
from pathlib import Path
import subprocess
import time

POLICY = 'e-core-application-v1'
FIELDS = ('user_ticks','system_ticks','p_user_ticks','p_system_ticks','instructions',
          'p_instructions','cycles','p_cycles','flags','timebase_numer','timebase_denom')
SOURCE = Path(__file__).with_name('core_counters.c')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_calibration(value):
    if value['policy'] != POLICY or value['source_sha256'] != digest(SOURCE):
        raise ValueError('Unknown core policy or counter source')
    probe = value['probe']
    for key in ('p_user_ticks','p_instructions','p_cycles','timebase_numer','timebase_denom'):
        if type(probe.get(key)) is not int or probe[key] <= 0:
            raise ValueError('P-core counter support was not demonstrated')
    if digest(value['library']) != value['library_sha256']:
        raise ValueError('Core reader binary changed')


def host_identity():
    return dict(os_version=platform.mac_ver()[0],boot_session=subprocess.check_output(
        ['sysctl','-n','kern.bootsessionuuid'],text=True).strip())


def build(directory):
    directory.mkdir()
    library = directory/'core-counters.dylib'
    probe = directory/'core-counter-probe'
    commands = [
        ['xcrun','clang','-O2','-Wall','-Wextra','-Werror','-dynamiclib',str(SOURCE),'-o',str(library)],
        ['xcrun','clang','-O2','-Wall','-Wextra','-Werror','-DCORE_COUNTER_PROBE',str(SOURCE),'-o',str(probe)],
    ]
    with (directory/'build.log').open('w') as log:
        for command in commands:
            subprocess.run(command,stdout=log,stderr=log,check=True)
    value = dict(host=host_identity(),policy=POLICY,library=str(library.resolve()),library_sha256=digest(library),
        source_sha256=digest(SOURCE),probe_binary_sha256=digest(probe),build_commands=commands,
        probe=json.loads(subprocess.check_output([str(probe)],text=True)))
    validate_calibration(value)
    path = directory/'calibration.json'
    path.write_text(json.dumps(value,indent=2)+'\n')
    return path


class CoreReader:
    def __init__(self, calibration):
        self.policy = json.loads(Path(calibration).read_text())
        validate_calibration(self.policy)
        if self.policy['host'] != host_identity():
            raise ValueError('Core calibration belongs to another OS or boot session')
        self.lib = ctypes.CDLL(self.policy['library'],use_errno=True)
        self.lib.read_core_usage.argtypes = [ctypes.c_int,ctypes.POINTER(ctypes.c_uint64)]
        self.lib.read_core_usage.restype = ctypes.c_int
        self.lib.running_threads.argtypes = [ctypes.c_int]
        self.lib.running_threads.restype = ctypes.c_int

    def snapshot(self, pid):
        data = (ctypes.c_uint64*len(FIELDS))()
        if self.lib.read_core_usage(pid,data):
            raise OSError(ctypes.get_errno(),'Cannot read core counters for '+str(pid))
        return dict(pid=pid,**dict(zip(FIELDS,map(int,data))))

    def worker_snapshot(self, pid):
        deadline = time.monotonic()+1
        while time.monotonic() < deadline:
            before = self.lib.running_threads(pid)
            if before < 0:
                raise OSError(ctypes.get_errno(),'Cannot inspect worker threads')
            if before == 0:
                value = self.snapshot(pid)
                after = self.lib.running_threads(pid)
                if after < 0:
                    raise OSError(ctypes.get_errno(),'Cannot inspect worker threads')
                if after == 0:
                    return value | dict(running_before=before,running_after=after)
            time.sleep(.001)
        raise TimeoutError('Worker threads did not quiesce for core accounting')


def interval(before, after):
    if before['pid'] != after['pid']:
        raise ValueError('Core snapshot PID mismatch')
    scale = (before['timebase_numer'],before['timebase_denom'])
    if (any(type(n) is not int or n <= 0 for n in scale)
            or scale != (after['timebase_numer'],after['timebase_denom'])):
        raise ValueError('Invalid Mach timebase')
    counts = {}
    for key in FIELDS[:8]:
        a,b = before[key],after[key]
        if type(a) is not int or type(b) is not int or a < 0 or b < a:
            raise ValueError('Invalid or backward core counter: '+key)
        counts[key] = b-a
    for total,p in [('user_ticks','p_user_ticks'),('system_ticks','p_system_ticks'),
                    ('instructions','p_instructions'),('cycles','p_cycles')]:
        if counts[p] > counts[total]:
            raise ValueError('P counter exceeds total: '+p)
    if counts['user_ticks'] <= 0 or counts['instructions'] <= 0 or counts['cycles'] <= 0:
        raise ValueError('Missing positive core-accounting work')
    if counts['p_user_ticks']:
        raise ValueError('Application CPU time ran on P cores')
    ticks = dict(user_e=counts['user_ticks'],user_p=counts['p_user_ticks'],
                 kernel_e=counts['system_ticks']-counts['p_system_ticks'],kernel_p=counts['p_system_ticks'])
    return dict(pid=before['pid'],deltas=counts,
        time_ns={key:value*scale[0]/scale[1] for key,value in ticks.items()})


def audit_receipt(value, worker_pids):
    worker_pids = list(worker_pids)
    if (len(worker_pids) != len(set(worker_pids))
            or [w['pid'] for w in value['before']] != worker_pids
            or [w['pid'] for w in value['after']] != worker_pids):
        raise ValueError('Missing or mismatched worker core snapshot')
    for snapshot in value['before']+value['after']:
        if any(type(snapshot.get(k)) is not int or snapshot[k] != 0
               for k in ['running_before','running_after']):
            raise ValueError('Worker was not quiescent at the counter boundary')
    workers = [interval(a,b) for a,b in zip(value['before'],value['after'])]
    controller = interval(value['controller_before'],value['controller_after'])
    if controller['pid'] in {w['pid'] for w in workers}:
        raise ValueError('Controller is also recorded as a worker')
    return dict(policy=POLICY,workers=workers,controller=controller,
        time_ns={key:sum(w['time_ns'][key] for w in workers)+controller['time_ns'][key]
                 for key in controller['time_ns']})
