#!/usr/bin/env python3
"""Compare fixed mixed CSV queues at increasing CPU caller concurrency."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import select
import signal
import statistics
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'Benchmarks/Tools'))
from execution_policy import PRODUCTION_MODE, policy, worker_environment
from runner import environment, verify_uninstrumented


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def power():
    value = subprocess.check_output(['pmset', '-g', 'batt'], text=True)
    if 'AC Power' not in value:
        raise RuntimeError('AC power is required')
    return value


def system_state():
    return {name: subprocess.check_output(command, text=True) for name, command in {
        'vm_stat': ['vm_stat'], 'swap': ['sysctl', 'vm.swapusage'],
        'processes': ['ps', '-Ao', 'pid,rss,pcpu,comm', '-r'],
    }.items()}


class Worker:
    def __init__(self, binary, storage, log):
        self.log = log.open('w')
        command = [str(binary)] if isinstance(binary, (str, os.PathLike)) else list(map(str, binary))
        self.process = subprocess.Popen([*command, storage], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=self.log, text=True, bufsize=1,
            env=worker_environment(PRODUCTION_MODE), start_new_session=True)
        try:
            self.ready = self.receive()
        except BaseException:
            self.close()
            raise

    def receive(self):
        if not select.select([self.process.stdout], [], [], 120)[0]:
            raise TimeoutError(f'Worker {self.process.pid} timed out')
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError(f'Worker {self.process.pid} exited: {self.process.poll()}')
        return json.loads(line)

    def ask(self, request):
        self.process.stdin.write((request if isinstance(request, str) else json.dumps(request)) + '\n')
        self.process.stdin.flush()
        return self.receive()

    def close(self):
        try:
            try:
                self.process.stdin.close()
            except BrokenPipeError:
                pass
            if self.process.poll() is None:
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(self.process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    self.process.wait()
        finally:
            self.process.stdout.close()
            self.log.close()


class MemorySampler:
    """Sample concurrent resident bytes, rather than adding unrelated process peaks."""
    def __init__(self, workers, limit_bytes, interval=.01):
        self.workers, self.limit_bytes, self.interval = workers, limit_bytes, interval
        self.samples, self.error = [], None
        self.stop = threading.Event()
        self.lib = ctypes.CDLL('/usr/lib/libproc.dylib')
        self.lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64,
                                         ctypes.c_void_p, ctypes.c_int]
        self.thread = threading.Thread(target=self.run)

    def sample(self):
        total = 0
        for worker in self.workers:
            data = ctypes.create_string_buffer(256)
            size = self.lib.proc_pidinfo(worker.process.pid, 4, 0, data, len(data))
            if size < 16:
                raise RuntimeError('Cannot sample benchmark worker residency')
            # proc_taskinfo starts with virtual_size and resident_size, both UInt64.
            total += ctypes.c_uint64.from_buffer(data, 8).value
        self.samples.append((time.monotonic_ns(), total))
        if total > self.limit_bytes:
            raise MemoryError('Benchmark workers exceeded the experiment RSS ceiling')

    def run(self):
        try:
            while not self.stop.is_set():
                self.sample()
                self.stop.wait(self.interval)
        except BaseException as e:
            self.error = str(e)
            for worker in self.workers:
                try:
                    os.killpg(worker.process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass


def percentile(values, fraction):
    return sorted(values)[max(0, math.ceil(len(values) * fraction) - 1)]


def summarize(jobs, elapsed_ns, samples, queued_jobs):
    if len(jobs) != len(queued_jobs) or {x['id'] for x in jobs} != {x['id'] for x in queued_jobs}:
        raise ValueError('Incomplete or duplicate work set')
    expected = {x['id']: x for x in queued_jobs}
    for job in jobs:
        task = expected[job['id']]
        if job['workflow'] != task['workflow'] or job['input'] != task['input']:
            raise ValueError('Worker completed the wrong task')
        for key in ('cpu_ns', 'wall_ns', 'response_ns', 'queue_ns'):
            if not math.isfinite(job[key]) or job[key] < 0:
                raise ValueError('Invalid timing')
        if job['response_ns'] < job['queue_ns'] or job['response_ns'] > elapsed_ns:
            raise ValueError('Response falls outside the batch')
    result = dict(completed=len(jobs), elapsed_ns=elapsed_ns,
                  completed_per_minute=len(jobs) * 60e9 / elapsed_ns,
                  operation_cpu_ns=sum(x['cpu_ns'] for x in jobs),
                  sampled_peak_rss_bytes=max(x[1] for x in samples),
                  sample_count=len(samples), per_case={})
    for case in sorted({x['input'] + '/' + x['workflow'] for x in jobs}):
        group = [x for x in jobs if x['input'] + '/' + x['workflow'] == case]
        result['per_case'][case] = dict(count=len(group),
            p50_response_ns=percentile([x['response_ns'] for x in group], .5),
            p95_response_ns=percentile([x['response_ns'] for x in group], .95),
            p95_queue_ns=percentile([x['queue_ns'] for x in group], .95),
            p95_service_ns=percentile([x['response_ns']-x['queue_ns'] for x in group], .95))
    return result


def batch(binary, storage, jobs, concurrency, directory, rss_limit_bytes=8 * 2**30, core_reader=None):
    directory.mkdir()
    workers = []
    sampler = None
    try:
        for slot in range(concurrency):
            workers.append(Worker(binary, storage, directory / f'worker-{slot}.log'))
        before = [worker.ask('stats') for worker in workers]
        core_before = None if core_reader is None else [core_reader.worker_snapshot(w.process.pid) for w in workers]
        controller_before = None if core_reader is None else core_reader.snapshot(os.getpid())
        pending = queue.Queue()
        for task in jobs:
            pending.put(task)
        barrier = threading.Barrier(concurrency + 1)
        sampler = MemorySampler(workers, rss_limit_bytes)
        sampler.sample()
        def lane(worker):
            done = []
            barrier.wait()
            while True:
                try:
                    task = pending.get_nowait()
                except queue.Empty:
                    return done
                dispatch = time.monotonic_ns()
                result = worker.ask({k: v for k, v in task.items() if k != 'input'})
                completed = time.monotonic_ns()
                result.update(queue_ns=dispatch-start, response_ns=completed-start, worker_pid=worker.process.pid)
                done.append(result)
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futures = [pool.submit(lane, worker) for worker in workers]
            sampler.thread.start()
            controller_cpu = time.process_time_ns()
            start = time.monotonic_ns()
            barrier.wait()
            try:
                results = [job for f in futures for job in f.result()]
                end = time.monotonic_ns()
            finally:
                sampler.stop.set()
                sampler.thread.join()
            controller_cpu = time.process_time_ns() - controller_cpu
        if sampler.error:
            raise RuntimeError(sampler.error)
        sampler.sample()
        after = [worker.ask('stats') for worker in workers]
        core_after = None if core_reader is None else [core_reader.worker_snapshot(w.process.pid) for w in workers]
        controller_after = None if core_reader is None else core_reader.snapshot(os.getpid())
        summary = summarize(results, end-start, sampler.samples, jobs)
        summary.update(worker_cpu_ns=sum(b['cpu_ns']-a['cpu_ns'] for a,b in zip(before,after)),
                       controller_cpu_ns=controller_cpu,
                       initial_rss_bytes=sum(x['rss_bytes'] for x in before),
                       retained_rss_bytes=sum(x['rss_bytes'] for x in after),
                       max_sample_gap_ns=max(b[0]-a[0] for a,b in zip(sampler.samples,sampler.samples[1:])))
        summary['charged_cpu_ns'] = summary['worker_cpu_ns'] + controller_cpu
        summary['sampled_resident_byte_seconds'] = sum(
            max(0, min(end,b[0])-max(start,a[0])) * a[1] / 1e9
            for a,b in zip(sampler.samples,sampler.samples[1:]))
        record = dict(summary=summary, jobs=results, memory_samples=sampler.samples,
                      before=before, after=after, runtime=[worker.ready for worker in workers])
        if core_reader is not None:
            from Benchmarks.CPUThroughput.core_usage import audit_receipt
            record['core_usage'] = dict(before=core_before,after=core_after,
                controller_before=controller_before,controller_after=controller_after)
            save(directory / 'result.json',record)
            summary['core_time_ns'] = audit_receipt(record['core_usage'],[w.process.pid for w in workers])['time_ns']
        save(directory / 'result.json',record)
        return summary
    except BaseException as e:
        save(directory / 'failure.json', dict(error=str(e),
            memory_samples=[] if sampler is None else sampler.samples))
        raise
    finally:
        for worker in workers:
            worker.close()


def preflight(binary, cases, expected, directory):
    checks = []
    for storage in ('optional', 'compact'):
        worker = Worker(binary, storage, directory / f'{storage}.log')
        try:
            for task in cases:
                request = {k: v for k,v in task.items() if k != 'input'} | {'verify': True}
                result = worker.ask(request)
                if result['check'] != expected[task['input'] + '/' + task['workflow']]:
                    raise ValueError('Full native-bit output differs from the independent reference')
                checks.append(result)
        finally:
            worker.close()
    save(directory / 'checks.json', checks)


def report(records):
    lines = ['# Mixed CSV queue pilot', '',
        'The fixed queue contains the same jobs at each concurrency. Workers use native CPU parallelism. '
        'Throughput includes queue dispatch, public CSV reading, stable sorting, matrix construction, and output release. '
        'Process startup and preflight validation are outside the queue. Full native-bit hashes match before and after the panel; '
        'timed outputs receive shape and type checks, not full hashes.', '',
        '| Callers | Storage | Jobs/min | Charged CPU ms/job | Peak worker RSS MiB | Retained RSS MiB |',
        '| ---: | --- | ---: | ---: | ---: | ---: |']
    for callers in sorted({x['concurrency'] for x in records}):
        for storage in ('optional', 'compact'):
            group = [x for x in records if x['concurrency']==callers and x['storage']==storage]
            med = lambda f: statistics.median(f(x['summary']) for x in group)
            lines.append(f"| {callers} | {storage} | {med(lambda s:s['completed_per_minute']):.1f} | "
                f"{med(lambda s:s['charged_cpu_ns']/s['completed']/1e6):.2f} | "
                f"{med(lambda s:s['sampled_peak_rss_bytes']/2**20):.1f} | "
                f"{med(lambda s:s['retained_rss_bytes']/2**20):.1f} |")
    lines += ['', 'CPU includes benchmark workers and the measured controller. RSS is the sampled sum of live worker residency; '
        'it is not private memory and may double-count shared pages. Ten-millisecond sampling can miss short peaks. '
        'Retained RSS includes allocator caches after all outputs are released. System paging and unrelated processes are '
        'recorded separately and cannot be attributed to this experiment.', '',
        'Responses run from initial queue submission to result receipt, so they include queue waiting. '
        'Per-case p50 and p95 queue, service, and response times are in each result. '
        'These are finite CPU queue experiments, not energy, GPU, Neural Engine, or memory-exhaustion measurements.']
    return '\n'.join(lines) + '\n'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--worker', type=Path, required=True)
    p.add_argument('--air-contract', type=Path, required=True)
    p.add_argument('--energy-contract', type=Path, required=True)
    p.add_argument('--expected', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--smoke', action='store_true')
    a = p.parse_args()
    build = json.loads(a.worker.with_name('build.json').read_text())
    verify_uninstrumented(a.worker)
    if digest(a.worker) != build['binary_sha256']:
        raise ValueError('Worker differs from its build receipt')
    if any(digest(ROOT/name) != sha for name,sha in build['sources'].items()):
        raise ValueError('Source differs from the built worker')
    cases = []
    for contract, key in ((a.air_contract, 'PM2.5'), (a.energy_contract, 'Global_active_power')):
        value = json.loads(contract.read_text())
        if digest(Path(value['path'])) != value['sha256']:
            raise ValueError('Input bytes differ from their contract')
        for workflow in ('read', 'sort-matrix'):
            cases.append(dict(id=len(cases), contract=str(contract.resolve()), workflow=workflow,
                              input=value['id'], key=key, verify=False))
    a.output.mkdir(parents=True, exist_ok=False)
    expected = json.loads(a.expected.read_text())
    labels = ['optional', 'compact', 'optional_twin', 'compact_twin']
    orders = [labels[i:]+labels[:i] for i in range(4)]
    orders += [list(reversed(order)) for order in orders]
    if a.smoke:
        orders = orders[:2]
    concurrencies = [1,2] if a.smoke else [1,2,4,8]
    repeats = 1 if a.smoke else 4
    save(a.output / 'plan.json', dict(build=build, environment=environment(), cases=cases, orders=orders,
        concurrency=concurrencies, copies_per_case=repeats, execution=policy(PRODUCTION_MODE),
        expected_sha256=digest(a.expected), controller_sha256=digest(Path(__file__)),
        contracts={str(p.resolve()): json.loads(p.read_text()) for p in (a.air_contract,a.energy_contract)},
        quality_policy=dict(twin_cpu_deviation=.10, twin_wall_deviation=.10,
                            twin_peak_relative=1.05, twin_peak_slack_per_caller_bytes=8*2**20),
        power_start=power(), system_start=system_state(),
        measurement_scope='Fixed finite queue; process startup and full-hash checks excluded; cold first public call per worker'))
    for name in ('preflight', 'postflight'):
        (a.output/name).mkdir()
    preflight(a.worker, cases, expected, a.output/'preflight')
    records = []
    try:
        for iteration, order in enumerate(orders):
            counts = concurrencies[iteration%len(concurrencies):]+concurrencies[:iteration%len(concurrencies)]
            tasks = [dict(task, id=copy*len(cases)+task['id']) for copy in range(repeats) for task in cases]
            offset = iteration % len(tasks)
            tasks = tasks[offset:] + tasks[:offset]
            for callers in counts:
                for label in order:
                    storage = label.split('_')[0]
                    directory = a.output/f'r{iteration}-c{callers}-{label}'
                    power()
                    summary = batch(a.worker, storage, tasks, callers, directory)
                    record = dict(round=iteration, label=label, storage=storage, concurrency=callers, summary=summary)
                    records.append(record)
                    save(a.output/'records.json', records)
                    print(f'round {iteration+1}/{len(orders)} callers={callers} {label}: '
                          f"{summary['completed_per_minute']:.1f} jobs/min", flush=True)
        preflight(a.worker, cases, expected, a.output/'postflight')
        if digest(a.worker) != build['binary_sha256']:
            raise ValueError('Worker changed during the panel')
        save(a.output/'end.json', dict(power_end=power(), system_end=system_state()))
        (a.output/'report.md').write_text(report(records))
    except BaseException as e:
        save(a.output/'failure.json', dict(error=str(e), completed_batches=len(records), system=system_state()))
        raise

if __name__ == '__main__':
    main()
