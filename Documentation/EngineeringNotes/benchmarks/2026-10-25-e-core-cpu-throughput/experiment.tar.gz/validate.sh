#!/bin/zsh
set -eu
cd /private/tmp/swiftsci-csv-compact-construction-20261024
py=/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python
out=/private/tmp/swiftsci-e-core-cpu-throughput-20261025
POLARS_MAX_THREADS=1 "$py" -m unittest discover -s Benchmarks/Tests > "$out/controller-tests.log" 2>&1
SWIFTSCI_MLX_TEST_GPU=1 POLARS_MAX_THREADS=1 PYTHONPATH=Benchmarks/Tests "$py" -m unittest -v \
 test_llama_precision.MixedPrecisionAdapterTests.test_shared_storage_preserves_inputs_and_projection_without_duplicate_matrix \
 test_llama_precision.MixedPrecisionAdapterTests.test_wider_projection_preserves_close_score_without_changing_body_weights \
 test_mlx_workers.MLXWorkersTests.test_explicit_metal_decoder_and_boundary \
 test_neural_shapes.ShapedDecoderTests.test_mlx_explicit_gpu_all_shapes > "$out/optional-metal-tests.log" 2>&1
