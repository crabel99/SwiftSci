# Fixed-memory mixed CPU queues

Caller counts follow a frozen calibration model. The same queue runs under each worker-RSS budget. Actual sampled residency is checked throughout each queue. Process startup, calibration, and full-hash validation are outside timing. These are longer finite bursts, not a constant-rate request service.

| Budget GiB | Storage | Callers | Jobs/min | CPU ms/job | Peak RSS MiB | Resident MiB-seconds |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 4 | optional | 4 | 1538.8 | 219.13 | 2137.6 | 425.3 |
| 4 | compact | 4 | 1574.9 | 209.35 | 1429.2 | 290.8 |
| 4 | compact | 5 | 1538.1 | 211.01 | 1451.4 | 308.3 |

Audit qualified: True. See audit.json for every retained control failure.

The budget covers sampled worker RSS. It excludes controller RSS and is not an OS-enforced physical-memory cap. Sampling can miss short peaks; shared pages may be counted repeatedly. Worker native parallelism is unchanged. CPU and response costs must be considered beside any throughput gain.
