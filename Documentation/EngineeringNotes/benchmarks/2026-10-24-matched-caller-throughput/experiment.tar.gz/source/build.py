#!/usr/bin/env python3
"""Build an uninstrumented dataframe module and the persistent CPU worker."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--products', type=Path, required=True)
    p.add_argument('--arrow-module-map', type=Path, required=True)
    p.add_argument('--atomics-module-map', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    sdk = subprocess.check_output(['xcrun', '--show-sdk-path'], text=True).strip()
    base = ['xcrun', 'swiftc', '-package-name', 'SwiftSci', '-O', '-whole-module-optimization',
            '-swift-version', '6', '-enable-upcoming-feature', 'ExistentialAny',
            '-target', 'arm64-apple-macos14.0', '-sdk', sdk, '-I', str(a.products.resolve()),
            '-Xcc', f'-fmodule-map-file={a.arrow_module_map.resolve()}',
            '-Xcc', f'-fmodule-map-file={a.atomics_module_map.resolve()}',
            '-module-cache-path', str(out / 'module-cache'), '-parse-as-library']
    sources = sorted((ROOT / 'Sources/SwiftDataFrame').rglob('*.swift'))
    objects = [a.products.resolve() / f'{name}.o'
               for name in ('Arrow', 'ArrowC', 'FlatBuffers', 'Atomics', '_AtomicsShims')]
    worker = Path(__file__).with_name('Worker.swift')
    identity = {str(f.relative_to(ROOT)): digest(f) for f in sources + [worker]}
    commands = [base + ['-module-name', 'SwiftDataFrame', '-emit-module', '-emit-module-path',
                       str(out / 'SwiftDataFrame.swiftmodule'), '-emit-object', '-o',
                       str(out / 'SwiftDataFrame.o')] + list(map(str, sources)),
                base[:2] + ['-I', str(out)] + base[2:] + [str(worker), str(out / 'SwiftDataFrame.o')]
                + list(map(str, objects)) + ['-framework', 'Accelerate', '-lcompression',
                                           '-o', str(out / 'worker'), '-Rmodule-loading']]
    for index, command in enumerate(commands):
        with (out / f'build-{index}.log').open('w') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    loaded = dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",
                             (out / 'build-1.log').read_text()))
    assert loaded['SwiftDataFrame'] == str(out / 'SwiftDataFrame.swiftmodule')
    assert all(digest(ROOT / name) == sha for name, sha in identity.items())
    record = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                  sources=identity, dependencies={str(f): digest(f) for f in objects}, commands=commands,
                  binary_sha256=digest(out / 'worker'), module_sha256=digest(out / 'SwiftDataFrame.swiftmodule'),
                  object_sha256=digest(out / 'SwiftDataFrame.o'),
                  toolchain=subprocess.check_output(['xcrun', 'swiftc', '--version'], text=True))
    (out / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
    print(out / 'worker')

if __name__ == '__main__':
    main()
