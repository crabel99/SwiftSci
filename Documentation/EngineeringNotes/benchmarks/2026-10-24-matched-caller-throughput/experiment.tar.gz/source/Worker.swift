import Foundation
import SwiftDataFrame
import Darwin
import CryptoKit

struct Input: Decodable {
    let id: String, path: String, delimiter: String
    let rows: Int
    let names: [String], types: [String]
    let null_tokens: [String]
}
func cpu() -> Int64 {
    var r = rusage(); getrusage(RUSAGE_SELF, &r)
    return Int64(r.ru_utime.tv_sec + r.ru_stime.tv_sec) * 1_000_000_000 + Int64(r.ru_utime.tv_usec + r.ru_stime.tv_usec) * 1_000
}
func resident() -> Int64 {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<integer_t>.size)
    let result = withUnsafeMutablePointer(to: &info) { pointer in
        pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    precondition(result == KERN_SUCCESS)
    return Int64(info.resident_size)
}
func heap() -> Int64 {
    var s = malloc_statistics_t(); malloc_zone_statistics(nil, &s)
    return Int64(s.size_in_use)
}
func peak() -> Int64 { var r = rusage(); getrusage(RUSAGE_SELF, &r); return Int64(r.ru_maxrss) }
struct Digest {
    var hash = SHA256(), buffer = Data(), nulls = 0
    mutating func integer<T: FixedWidthInteger>(_ value: T) {
        var value = value.littleEndian
        withUnsafeBytes(of: &value) { buffer.append(contentsOf: $0) }
    }
    mutating func append<T>(_ value: T?, encode: (inout Digest, T) -> Void) {
        if let value { buffer.append(1); encode(&self, value) }
        else { buffer.append(0); nulls += 1 }
        if buffer.count >= 65536 { hash.update(data: buffer); buffer.removeAll(keepingCapacity: true) }
    }
    mutating func finish() -> String {
        hash.update(data: buffer)
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
func fingerprint(_ df: DataFrame) -> [String: Any] {
    var columns = [[String: Any]]()
    for name in df.columnNames {
        var d = Digest()
        let type = df.dtypes[name]!.description
        switch type {
        case "Double":
            let c = df[column: name, as: Double.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1.bitPattern) } }
        case "Int64":
            let c = df[column: name, as: Int64.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1) } }
        case "String":
            let c = df[column: name, as: String.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { digest, value in
                digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
            } }
        default: preconditionFailure("Unsupported fixture type")
        }
        columns.append(["name": name, "type": type, "nulls": d.nulls, "sha256": d.finish()])
    }
    return ["rows": df.rowCount, "columns": columns]
}
struct Request: Decodable {
    let id: Int
    let contract: String
    let workflow: String
    let key: String
    let verify: Bool
}
func emit(_ value: [String: Any]) throws {
    let data = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    FileHandle.standardOutput.write(data + Data([10]))
}
@MainActor @main struct ThroughputWorker {
    static func main() async throws {
        let storage = CommandLine.arguments[1]
        precondition(storage == "optional" || storage == "compact")
        try emit(["ready": true, "pid": ProcessInfo.processInfo.processIdentifier])
        while let line = readLine() {
            if line == "stats" {
                try emit(["cpu_ns": cpu(), "rss_bytes": resident(), "peak_bytes": peak()])
                continue
            }
            let request = try JSONDecoder().decode(Request.self, from: Data(line.utf8))
            precondition(request.workflow == "read" || request.workflow == "sort-matrix")
            let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: request.contract)))
            var options = CSVReadOptions()
            options.doubleStorage = storage == "compact" ? .compact : .optional
            options.delimiter = Character(input.delimiter)
            options.nullValues = Set(input.null_tokens)
            options.columnConversionMode = .parallel
            let mapping: [String: ColumnDType] = ["String": .utf8, "Double": .float64, "Int64": .int64]
            options.columnTypeOverrides = Dictionary(uniqueKeysWithValues:
                zip(input.names, input.types).map { ($0.0, mapping[$0.1]!) })
            let numeric = zip(input.names, input.types).filter { $0.1 != "String" }.map { $0.0 }
            let c0 = cpu(), t0 = DispatchTime.now().uptimeNanoseconds
            var frame: DataFrame? = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)
            var matrix: PreparedNumericMatrix?
            if request.workflow == "sort-matrix" {
                frame = try frame!.sortBy(request.key)
                matrix = try frame!.prepareNumericMatrix(numeric)
            }
            precondition(frame!.rowCount == input.rows && frame!.columnNames == input.names)
            for (name, kind) in zip(input.names, input.types) {
                precondition(frame!.dtypes[name]!.description == kind)
            }
            if let matrix {
                precondition(matrix.values.count == input.rows * numeric.count)
            }
            let held = resident(), heldHeap = heap(), heldPeak = peak()
            let t1 = DispatchTime.now().uptimeNanoseconds, c1 = cpu()
            var check: [String: Any] = [:]
            if request.verify {
                check["frame"] = fingerprint(frame!)
                var matrixCheck = "absent"
                if let matrix {
                    var digest = Digest()
                    for value in matrix.values { digest.append(Optional(value)) { $0.integer($1.bitPattern) } }
                    matrixCheck = digest.finish()
                }
                check["matrix_sha256"] = matrixCheck
            }
            let c2 = cpu(), t2 = DispatchTime.now().uptimeNanoseconds
            frame = nil
            matrix = nil
            let t3 = DispatchTime.now().uptimeNanoseconds, c3 = cpu()
            try emit(["id": request.id, "input": input.id, "workflow": request.workflow,
                      "storage": storage, "cpu_ns": c1-c0+c3-c2,
                      "wall_ns": t1-t0+t3-t2, "held_rss_bytes": held,
                      "held_heap_bytes": heldHeap, "process_peak_bytes": heldPeak,
                      "released_rss_bytes": resident(), "check": check])
        }
    }
}
