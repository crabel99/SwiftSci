"""Check fair admission and reject incomplete memory-budget evidence."""
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from Benchmarks.CPUThroughput import budget
from Benchmarks.CPUThroughput import run as throughput


class AdmissionTests(unittest.TestCase):
    def test_same_rule_can_admit_more_compact_callers(self):
        gib = 2**30
        optional = budget.admission([600*2**20], 2*gib)
        compact = budget.admission([400*2**20], 2*gib)
        self.assertEqual(optional['callers'], 3)
        self.assertEqual(compact['callers'], 4)
        for result in (optional,compact):
            self.assertLessEqual(result['callers']*result['reservation_bytes'], 2*gib)
            self.assertGreater((result['callers']+1)*result['reservation_bytes'], 2*gib)

    def test_worst_calibration_and_caller_cap_apply(self):
        result = budget.admission([100,1000], 10000000)
        self.assertGreater(result['reservation_bytes'], 1000)
        self.assertEqual(result['callers'], 1)
        self.assertEqual(budget.admission([1000], 2**40)['callers'], 8)
        self.assertEqual(budget.admission([2**30], 2**30)['callers'], 0)


    def test_matched_control_keeps_storage_and_caller_effects_separate(self):
        b = 4 * 2**30
        admissions = {str(b): {'optional': budget.admission([900*2**20],b),
                              'compact': budget.admission([650*2**20],b)}}
        conditions = budget.conditions_for(admissions,matched_control=True)[str(b)]
        self.assertEqual(conditions['optional_4'],dict(storage='optional',callers=4))
        self.assertEqual(conditions['compact_4'],dict(storage='compact',callers=4))
        self.assertEqual(conditions['compact_5'],dict(storage='compact',callers=5))
        self.assertEqual(conditions['compact_5'],conditions['compact_5_twin'])

    def test_control_refuses_to_retune_a_configuration_that_cannot_fit(self):
        b = 4 * 2**30
        admissions = {str(b): {'optional': budget.admission([1100*2**20],b),
                              'compact': budget.admission([650*2**20],b)}}
        with self.assertRaisesRegex(ValueError,'does not fit'):
            budget.conditions_for(admissions,matched_control=True)


    def test_drift_controls_do_not_pool_different_compact_caller_counts(self):
        labels=['optional_4','compact_4','compact_5']
        medians={name:dict(charged_cpu_ns=100,elapsed_ns=100,sampled_peak_rss_bytes=100)
                 for label in labels for name in (label,label+'_twin')}
        medians['compact_4_twin']['charged_cpu_ns']=125
        limits=dict(twin_cpu_deviation=.1,twin_wall_deviation=.1,
                    twin_peak_relative=1.05,twin_peak_slack_per_caller_bytes=0)
        flags=budget.control_flags(medians,limits,dict(optional_4=4,compact_4=4,compact_5=5))
        self.assertEqual(len(flags),1)
        self.assertEqual(flags[0]['label'],'compact_4')


class BudgetAuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.cases = [dict(id=0,input='air',workflow='read')]
        expected = {'air/read': {'frame': []}}
        throughput.save(self.root/'expected.json', expected)
        plan = dict(cases=self.cases, orders=[['optional','compact','optional_twin','compact_twin']],
            budgets_bytes=[1024], copies_per_case=1,
            expected_sha256=throughput.digest(self.root/'expected.json'),
            admissions={'1024':{s:dict(callers=1,reservation_bytes=300) for s in ('optional','compact')}},
            quality_policy=dict(twin_cpu_deviation=.1,twin_wall_deviation=.1,
                                twin_peak_relative=1.05,twin_peak_slack_per_caller_bytes=0))
        throughput.save(self.root/'plan.json',plan)
        throughput.save(self.root/'end.json',{})
        checks = [dict(storage=s,input='air',workflow='read',check=expected['air/read']) for s in ('optional','compact')]
        for phase in ('preflight','postflight'):
            (self.root/phase).mkdir()
            throughput.save(self.root/phase/'checks.json',checks)
        self.records = []
        jobs = [dict(self.cases[0],cpu_ns=20,wall_ns=30,response_ns=40,queue_ns=0)]
        samples = [(0,100),(50,200),(100,100)]
        for label in plan['orders'][0]:
            summary = throughput.summarize(jobs,100,samples,self.cases) | {'charged_cpu_ns': 30}
            directory = self.root/label
            directory.mkdir()
            throughput.save(directory/'result.json',dict(summary=summary,jobs=jobs,memory_samples=samples))
            self.records.append(dict(round=0,budget_bytes=1024,label=label,storage=label.split('_')[0],
                                     concurrency=1,directory=label,summary=summary))
        self.save_records()

    def save_records(self):
        throughput.save(self.root/'records.json',self.records)

    def test_complete_matched_work_passes(self):
        result = budget.audit(self.root)
        self.assertTrue(result['qualified'])
        self.assertEqual(result['completed_jobs'], 4)

    def test_missing_full_hash_check_cannot_pass(self):
        throughput.save(self.root/'postflight'/'checks.json', [])
        with self.assertRaisesRegex(ValueError, 'validation'):
            budget.audit(self.root)

    def test_caller_count_cannot_change_after_calibration(self):
        self.records[0]['concurrency'] = 2
        self.save_records()
        with self.assertRaisesRegex(ValueError, 'Admission changed'):
            budget.audit(self.root)

    def test_raw_queue_mismatch_cannot_pass(self):
        self.records[0]['summary']['completed'] = 2
        self.save_records()
        with self.assertRaisesRegex(ValueError, 'Raw queue'):
            budget.audit(self.root)

if __name__=='__main__':
    unittest.main()
