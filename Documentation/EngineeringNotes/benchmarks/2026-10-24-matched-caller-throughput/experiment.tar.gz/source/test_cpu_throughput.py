"""Reject incomplete queues and misleading response-time records."""
import copy
import importlib.util
from pathlib import Path
import unittest
import sys
import json
import tempfile

spec = importlib.util.spec_from_file_location('cpu_throughput',
    Path(__file__).resolve().parents[1] / 'CPUThroughput/run.py')
controller = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controller)

class ThroughputTests(unittest.TestCase):
    def setUp(self):
        self.tasks = [dict(id=i, input='air', workflow=flow)
                      for i,flow in enumerate(('read', 'sort-matrix'))]
        self.jobs = [dict(task, cpu_ns=20, wall_ns=30, queue_ns=i*10, response_ns=40+i*10)
                     for i,task in enumerate(self.tasks)]
        self.samples = [(0,100), (50,140), (100,90)]

    def test_reports_same_fixed_work_and_includes_queue_latency(self):
        result = controller.summarize(self.jobs, 100, self.samples, self.tasks)
        self.assertEqual(result['completed'], 2)
        self.assertEqual(result['operation_cpu_ns'], 40)
        self.assertEqual(result['sampled_peak_rss_bytes'], 140)
        self.assertEqual(result['per_case']['air/sort-matrix']['p95_response_ns'], 50)
        self.assertEqual(result['per_case']['air/sort-matrix']['p95_service_ns'], 40)

    def test_rejects_missing_duplicate_wrong_or_impossible_results(self):
        mutations = [lambda rows: rows.pop(),
                     lambda rows: rows[1].update(id=0),
                     lambda rows: rows[0].update(workflow='wrong'),
                     lambda rows: rows[0].update(input='wrong'),
                     lambda rows: rows[0].update(cpu_ns=float('nan')),
                     lambda rows: rows[0].update(response_ns=101),
                     lambda rows: rows[0].update(queue_ns=50)]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                rows = copy.deepcopy(self.jobs)
                mutate(rows)
                with self.assertRaises(ValueError):
                    controller.summarize(rows, 100, self.samples, self.tasks)

    def test_percentile_does_not_interpolate_away_tail(self):
        self.assertEqual(controller.percentile([10,30,20,100], .95), 100)

    @unittest.skipUnless(sys.platform == 'darwin', 'Native sampler requires macOS')
    def test_sampler_matches_worker_residency(self):
        import os
        from types import SimpleNamespace
        sampler = controller.MemorySampler([SimpleNamespace(process=SimpleNamespace(pid=os.getpid()))], 2**40)
        sampler.sample()
        self.assertGreater(sampler.samples[0][1], 0)

audit_spec = importlib.util.spec_from_file_location('cpu_audit',
    Path(__file__).resolve().parents[1] / 'CPUThroughput/audit.py')
audit_module = importlib.util.module_from_spec(audit_spec)
audit_spec.loader.exec_module(audit_module)

class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.plan = dict(orders=[['optional','compact','optional_twin','compact_twin']],
            concurrency=[1], cases=[1], copies_per_case=1,
            quality_policy=dict(twin_cpu_deviation=.10, twin_wall_deviation=.10,
                twin_peak_relative=1.05, twin_peak_slack_per_caller_bytes=0))
        (self.root/'plan.json').write_text(json.dumps(self.plan))
        (self.root/'end.json').write_text('{}')
        self.records = [dict(round=0,concurrency=1,label=label,
            summary=dict(completed=1,charged_cpu_ns=100,elapsed_ns=100,sampled_peak_rss_bytes=100))
            for label in self.plan['orders'][0]]

    def run_audit(self):
        (self.root/'records.json').write_text(json.dumps(self.records))
        return audit_module.audit(self.root)

    def test_keeps_control_failure_visible(self):
        self.assertTrue(self.run_audit()['qualified'])
        self.records[2]['summary']['charged_cpu_ns'] = 125
        result = self.run_audit()
        self.assertFalse(result['qualified'])
        self.assertEqual(result['quality_flags'][0]['metric'], 'charged_cpu_ns')

    def test_incomplete_and_failed_panels_cannot_pass(self):
        self.records.pop()
        with self.assertRaises(ValueError):
            self.run_audit()

    def test_changed_work_total_cannot_pass(self):
        self.records[0]['summary']['completed'] = 2
        with self.assertRaises(ValueError):
            self.run_audit()

if __name__ == '__main__':
    unittest.main()
