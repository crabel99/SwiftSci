from pathlib import Path
import json,hashlib,statistics,subprocess,tarfile,re,shutil
S=Path('/private/tmp/swiftsci-mixed-throughput-20261024')
R=Path('/private/tmp/swiftsci-cpu-matched-panel-20261024')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-24-matched-caller-throughput'
plan=json.loads((R/'plan.json').read_text());records=json.loads((R/'records.json').read_text());audit=json.loads((R/'audit.json').read_text())
assert audit['batches']==72 and audit['completed_jobs']==9216
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected in plan['controller_sha256'].items():assert sha(R/('measured-'+name))==expected
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
labels=['optional_4','compact_4','compact_5'];summary=[];paired=[];bounds=[]
for row in records:
 raw=json.loads((R/row['directory']/'result.json').read_text())
 upper=sum(w['peak_bytes'] for w in raw['after'])
 bounds.append(dict(directory=row['directory'],conservative_kernel_peak_sum_bytes=upper,
                    budget_bytes=row['budget_bytes'],within_budget=upper<=row['budget_bytes']))
assert all(x['within_budget'] for x in bounds)
metrics=['completed_per_minute','charged_cpu_ns','sampled_peak_rss_bytes','retained_rss_bytes','sampled_resident_byte_seconds']
for label in labels:
 group=[r for r in records if r['label'].removesuffix('_twin')==label]
 row=dict(condition=label,storage=group[0]['storage'],callers=group[0]['concurrency'],samples=len(group),
          cpu_ms_per_job=statistics.median(x['summary']['charged_cpu_ns']/128/1e6 for x in group),
          **{key:statistics.median(x['summary'][key] for x in group) for key in metrics})
 row['responses']={case:statistics.median(x['summary']['per_case'][case]['p95_response_ns']/1e6 for x in group) for case in group[0]['summary']['per_case']}
 case_cpu={}
 for case in row['responses']:
  values=[]
  for record in group:
   raw=json.loads((R/record['directory']/'result.json').read_text())
   jobs=[j for j in raw['jobs'] if j['input']+'/'+j['workflow']==case]
   values.append(sum(j['cpu_ns'] for j in jobs)/len(jobs)/1e6)
  case_cpu[case]=statistics.median(values)
 row['operation_cpu_ms_by_case']=case_cpu
 summary.append(row)
by={x['condition']:x for x in summary}
comparisons=[]
for name,left,right in [('storage at four callers','optional_4','compact_4'),('fifth compact caller','compact_4','compact_5'),('combined choice','optional_4','compact_5')]:
 delta={key:(by[right][key]/by[left][key]-1)*100 for key in metrics}
 ratios=[]
 for i in range(12):
  source={label:{key:statistics.median(x['summary'][key] for x in records if x['round']==i and x['label'].removesuffix('_twin')==label) for key in metrics} for label in (left,right)}
  ratios.append({key:source[right][key]/source[left][key] for key in metrics})
 comparisons.append(dict(comparison=name,left=left,right=right,median_changes_percent=delta,
     paired_rounds=ratios,positive_throughput_rounds=sum(x['completed_per_minute']>1 for x in ratios),
     lower_cpu_rounds=sum(x['charged_cpu_ns']<1 for x in ratios)))
D.mkdir(parents=True,exist_ok=False)
for name,value in [('summary.json',summary),('comparisons.json',comparisons),('kernel-bounds.json',bounds)]:
 (D/name).write_text(json.dumps(value,indent=2)+'\n')
shutil.copy2(R/'audit.json',D/'audit.json')
lines=['# Separate compact storage from caller concurrency','',
 f'The local experiment is `codex/dataframe-mixed-throughput`, commit `{head}`. Production code and existing PR branches are unchanged. No source branch was pushed.', '',
 'This panel interleaves optional storage with four callers, compact storage with four callers, and compact storage with five callers. Every configuration has its own identical-binary twin. It completes 72 queues and 9,216 timed jobs. Four separate calibration queues complete another 512 jobs.', '',
 f'Full-output checks match the independent reference before and after the panel. Audit qualification is `{audit["qualified"]}`. [Quality flags remain visible](audit.json).', '',
 '## Compare matched callers before considering more concurrency','',
 '| Storage | Callers | Jobs/min | CPU ms/job | Peak RSS MiB | Retained RSS MiB | Resident MiB-seconds |',
 '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for x in summary:lines.append(f"| {x['storage']} | {x['callers']} | {x['completed_per_minute']:.1f} | {x['cpu_ms_per_job']:.2f} | {x['sampled_peak_rss_bytes']/2**20:.1f} | {x['retained_rss_bytes']/2**20:.1f} | {x['sampled_resident_byte_seconds']/2**20:.1f} |")
lines += ['', 'Each row pools its primary and twin labels, for 24 queues per configuration. Values are medians. Each queue contains 128 jobs with the same case mix. CPU is worker user and system time plus controller CPU. Shared pages can be counted repeatedly in RSS.', '',
 '| Comparison | Throughput change | CPU/job change | Peak RSS change | Resident byte-seconds change |',
 '| --- | ---: | ---: | ---: | ---: |']
for x in comparisons:
 d=x['median_changes_percent'];lines.append(f"| {x['comparison']} | {d['completed_per_minute']:+.1f}% | {d['charged_cpu_ns']:+.1f}% | {d['sampled_peak_rss_bytes']:+.1f}% | {d['sampled_resident_byte_seconds']:+.1f}% |")
storage_delta=comparisons[0]['median_changes_percent'];caller_delta=comparisons[1]['median_changes_percent']
lines += ['', f'At matched four callers, compact storage reduces peak RSS by {-storage_delta["sampled_peak_rss_bytes"]:.1f}%. CPU/job changes by {storage_delta["charged_cpu_ns"]:+.1f}% and throughput by {storage_delta["completed_per_minute"]:+.1f}%. This panel establishes a substantial memory benefit; it does not establish a CPU-time reduction.', '',
 f'Within compact storage, adding the fifth caller raises throughput by {caller_delta["completed_per_minute"]:.1f}%, CPU/job by {caller_delta["charged_cpu_ns"]:.1f}%, and peak RSS by {caller_delta["sampled_peak_rss_bytes"]:.1f}%. Both configurations fit 4 GiB. This is a selectable capacity and latency tradeoff.', '',
 'The earlier capacity study remains unchanged. All ratios here come from the interleaved configurations in this new panel, rather than comparisons across different measurement sessions.']
lines += ['', 'The first comparison holds caller count at four and changes storage. The second holds compact storage fixed and adds one caller. The combined comparison includes both changes. These are distinct engineering choices.', '',
 '## Keep variation visible','',
 '| Comparison | Rounds with higher throughput | Rounds with lower CPU/job |',
 '| --- | ---: | ---: |']
for x in comparisons:lines.append(f"| {x['comparison']} | {x['positive_throughput_rounds']}/12 | {x['lower_cpu_rounds']}/12 |")
lines += ['', 'Round comparisons use the median of each condition and its twin within that round. The [comparison record](comparisons.json) preserves every ratio. Counts describe consistency; they are not confidence intervals or proof of independent observations. Passing a 10% drift control does not certify small differences.', '',
 '## Examine CPU costs by operation','',
 '| Case | Optional/four operation CPU ms | Compact/four operation CPU ms | Compact/five operation CPU ms |',
 '| --- | ---: | ---: | ---: |']
for case in summary[0]['operation_cpu_ms_by_case']:
 lines.append('| '+case+' | '+' | '.join(f"{x['operation_cpu_ms_by_case'][case]:.3f}" for x in summary)+' |')
lines += ['', 'Each value is the median per-queue mean operation CPU for that case. Operation CPU includes public CSV reading, any requested sort and matrix construction, shape checks, memory bookkeeping, and output release. It excludes controller work and request decoding. It therefore differs from whole-queue charged CPU. This is a CPU-time breakdown, not a hardware-counter profile.', '',
 '## Queue responses include waiting','',
 '| Storage | Callers | Air read p95 ms | Air sort-matrix p95 ms | Energy read p95 ms | Energy sort-matrix p95 ms |',
 '| --- | ---: | ---: | ---: | ---: | ---: |']
for x in summary:lines.append(f"| {x['storage']} | {x['callers']} | "+' | '.join(f"{x['responses'][case]:.1f}" for case in ['Aotizhongxin-default/read','Aotizhongxin-default/sort-matrix','energy-common/read','energy-common/sort-matrix'])+' |')
lines += ['', 'All jobs enter the queue at once. Response includes waiting for a caller, execution, release, and receipt. Values are medians of per-queue p95 responses. This is a longer finite burst, not a steady arrival stream.', '',
 '## Protocol and memory boundaries','',
 'Two reference datasets supply 35,064 air-quality rows and 2,075,259 household-energy rows. Every queue has 32 copies of each read and read/sort/matrix case. Schemas, native types, null tokens, CSV bytes, stable missing-last ordering, and matrix contracts remain unchanged. Full-output hashes run before and after the panel. Timed outputs receive shape and type checks rather than full hashes.', '',
 'All callers use the same uninstrumented Release worker with native CPU parallelism. Four callers means four worker processes, not four CPU threads. No core affinity or internal thread cap changes. Startup and readiness finish before queue timing; the first public call in each worker remains timed. Calibration and full-hash checks are outside timing.', '',
 'Separate calibration checks that optional/four, compact/four, and compact/five fit the 4 GiB envelope before timing. Reservations use the maximum kernel-recorded or sampled single-caller peak plus 5% and 8 MiB. The declared caller counts are not retuned. Twelve rotated rounds put every primary and twin label in every position twice.', '',
 'The audit keeps each condition and twin separate. Limits remain 10% for CPU and elapsed-time drift, and 5% plus 8 MiB per caller for RSS drift. Earlier capacity-panel audits remain unchanged after the controller extension. No default admission or production storage policy changes.', '',
 f'All 72 conservative sums of per-worker kernel lifetime peaks are within 4 GiB. The largest bound is {max(x["conservative_kernel_peak_sum_bytes"] for x in bounds)/2**20:.1f} MiB. Such a sum is an upper bound, not a simultaneous observed peak. See [kernel bounds](kernel-bounds.json).', '',
 'Sampled RSS remains an application-level metric and may count shared pages repeatedly. This does not emulate global memory pressure on a 4 GiB machine. System paging counters and unrelated process snapshots are preserved, without attributing activity to the benchmark. AC power is required before each queue and at panel boundaries.', '',
 '## Validation and reproduction','',
 'The smoke panel and all 242 benchmark-controller tests pass with the established Metal opt-in and no skips. Normal completion leaves no orphan workers. The queue and cleanup controller is byte-identical to the preceding study, so its real guard-failure check remains applicable; that reused evidence is explicitly labelled in the archive. No production Swift sources changed, so this adds no new full-package test claim. The same exact-source worker and reference hashes are reused from the earlier studies.', '',
 '[Summary](summary.json), [comparisons](comparisons.json), [audit](audit.json), [kernel bounds](kernel-bounds.json), [artifact hashes](artifact-sha256.json), and the [experiment archive](experiment.tar.gz) preserve the evidence. The archive contains exact measured controllers, all raw queues and calibrations, input contracts, source code, and test receipts. CSV bytes, compiled executables, objects, and caches are excluded.', '',
 'Rebuild with `Benchmarks/CPUThroughput/build.py`, then run `budget.py --matched-control` with the recorded reference plan, independent expected fingerprints, and a new output directory. Audit with `budget.py --audit`. Absolute dependency and input paths must be present or remapped. The source README defines the command parameters.']
(D/'README.md').write_text('\n'.join(lines)+'\n')
subprocess.run(['git','bundle','create','/private/tmp/swiftsci-cpu-matched-delivery-20261024/source.bundle','d205cb71c07bb5a94772393571371632cdd00e9e..HEAD'],cwd=S,check=True)
with tarfile.open(D/'experiment.tar.gz','w:gz') as tar:
 for root,prefix in [(R,'panel'),(Path('/private/tmp/swiftsci-cpu-matched-smoke-20261024'),'smoke')]:
  for f in root.rglob('*'):
   if f.is_file():tar.add(f,arcname=prefix+'/'+str(f.relative_to(root)))
 for f in (S/'Benchmarks/CPUThroughput').iterdir():
  if f.is_file():tar.add(f,arcname='source/'+f.name)
 for name in ['test_cpu_budget.py','test_cpu_throughput.py']:
  tar.add(S/'Benchmarks/Tests'/name,arcname='source/'+name)
 tar.add('/private/tmp/swiftsci-cpu-throughput-panel-20261024/plan.json',arcname='reference/plan.json')
 for f in Path('/private/tmp/swiftsci-cpu-matched-delivery-20261024').rglob('*'):
  if f.is_file():tar.add(f,arcname='delivery/'+str(f.relative_to('/private/tmp/swiftsci-cpu-matched-delivery-20261024')))
(D/'artifact-sha256.json').write_text(json.dumps({p.name:sha(p) for p in sorted(D.iterdir()) if p.is_file()},indent=2)+'\n')
print(D)
