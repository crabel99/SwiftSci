# Single-pass CSV block trial

The index construction and field lookups are included in CPU and elapsed time. Values include result release. CPU percentages use median paired ratios, while displayed times are medians of worker medians. Memory workers are separate and capture peak RSS before validation.

| Input | CPU ms before → trial | Paired CPU change and ratio range | Elapsed ms before → trial | Peak RSS MiB before → trial | Held heap MiB before → trial |
| --- | ---: | ---: | ---: | ---: | ---: |
| csv, 1,000 × 4 | 0.32 → 0.33 | +3.5%; 0.970–1.176 | 0.17 → 0.19 | 7.14 → 7.08 | 0.08 → 0.08 |
| csv-quoted, 1,000 × 4 | 0.32 → 0.32 | -0.3%; 0.922–1.040 | 0.18 → 0.17 | 7.05 → 7.00 | 0.08 → 0.08 |
| csv-quoted, 10,000 × 4 | 0.75 → 0.77 | +2.8%; 0.995–1.118 | 0.46 → 0.46 | 8.69 → 8.25 | 0.64 → 0.64 |
| csv-quoted, 131,071 × 7 | 11.70 → 12.96 | +10.7%; 0.894–1.134 | 5.83 → 6.53 | 63.95 → 37.12 | 15.17 → 14.13 |
| csv-quoted, 75,001 × 13 | 19.78 → 15.21 | -18.5%; 0.697–0.863 | 6.73 → 6.55 | 66.97 → 38.61 | 15.05 → 15.05 |
