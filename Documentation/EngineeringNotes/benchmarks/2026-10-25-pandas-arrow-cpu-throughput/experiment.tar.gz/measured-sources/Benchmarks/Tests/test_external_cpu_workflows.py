"""Prove complete outputs and persistent-worker ownership before comparing timings."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT / 'Benchmarks/CPUThroughput'))
AVAILABLE = sys.platform == "darwin" and all(importlib.util.find_spec(name) for name in ("numpy","pandas","polars","duckdb","pyarrow"))
if AVAILABLE:
    from external_workflows import ExternalWorkflow, fingerprint
from run import Worker

ENGINES = ('pandas','polars','duckdb','pandas_arrow')
ROWS = [(0,2.0,'alpha'),(1,-1.0,None),(2,2.0,'quoted, "text"'),
        (3,None,'tail'),(2**63-1,-0.0,'max'),(-(2**63),0.10000000000000002,'min')]


def golden(rows, matrix=False):
    columns=[]
    for index,(name,kind) in enumerate(zip(['id','x','label'],['Int64','Double','String'])):
        data=bytearray();nulls=0
        for row in rows:
            value=row[index]
            if value is None:
                data.append(0);nulls+=1
            elif kind == 'String':
                encoded=value.encode();data.extend(b'\1'+struct.pack('<I',len(encoded))+encoded)
            else:
                data.extend(b'\1'+struct.pack('<q' if kind == 'Int64' else '<d',value))
        columns.append(dict(name=name,type=kind,nulls=nulls,sha256=hashlib.sha256(data).hexdigest()))
    matrix_hash='absent'
    if matrix:
        data=b''.join(b'\1'+struct.pack('<d',float(value) if value is not None else float('nan'))
                      for row in rows for value in row[:2])
        matrix_hash=hashlib.sha256(data).hexdigest()
    return dict(frame=dict(rows=len(rows),columns=columns),matrix_sha256=matrix_hash)


@unittest.skipUnless(AVAILABLE,"macOS and comparison dependencies are required")
class ExternalCPUWorkflowsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);path=self.root/'input.csv'
        with path.open('w',newline='') as out:
            writer=csv.writer(out);writer.writerow(['id','x','label'])
            writer.writerows(['?' if value is None else value for value in row] for row in ROWS)
        self.case=dict(id='fixture',path=str(path),rows=len(ROWS),names=['id','x','label'],
                       types=['Int64','Double','String'],null_tokens=['?'],null_counts=[0,1,1],delimiter=',')
        self.contract=self.root/'contract.json';self.contract.write_text(json.dumps(self.case))

    def request(self, workflow, ident=0):
        return dict(id=ident,contract=str(self.contract),workflow=workflow,key='x',verify=True)

    def test_native_bits_stable_missing_last_sort_and_persistent_reuse(self):
        ordered=[ROWS[index] for index in [1,4,5,0,2,3]]
        command=[sys.executable,str(ROOT/'Benchmarks/CPUThroughput/external_worker.py')]
        for engine in ENGINES:
            with self.subTest(engine=engine):
                worker=Worker(command,engine,self.root/(engine+'.log'))
                try:
                    self.assertTrue(worker.ready['ready'])
                    self.assertEqual(worker.ready['execution']['thread_environment'],{})
                    first=worker.ask('stats')
                    for ident,(flow,expected) in enumerate([('read',golden(ROWS)),
                            ('sort-matrix',golden(ordered,True)),('read',golden(ROWS))]):
                        result=worker.ask(self.request(flow,ident))
                        self.assertEqual(result['id'],ident)
                        self.assertEqual(result['check'],expected)
                        self.assertGreater(result['cpu_ns'],0)
                    self.assertGreater(worker.ask('stats')['cpu_ns'],first['cpu_ns'])
                finally:
                    worker.close()
                self.assertIsNotNone(worker.process.poll())

    def test_matrix_writes_do_not_mutate_the_materialized_frame(self):
        for engine in ENGINES:
            with self.subTest(engine=engine):
                work=ExternalWorkflow(engine)
                try:
                    frame=work.read(self.case);matrix=work.matrix(frame,self.case)
                    work.validate_shape(frame,matrix,self.case)
                    matrix[:,:]=42
                    self.assertEqual(fingerprint(frame,engine,self.case),golden(ROWS)['frame'])
                finally:
                    work.close()

    def test_arrow_parser_receives_full_schema_and_preserves_numeric_text(self):
        import pyarrow as pa
        import pyarrow.csv as pc
        rows=[(2**63-1,-0.0,'001'),(-(2**63),0.10000000000000002,'2026-10-25')]
        with Path(self.case['path']).open('w',newline='') as out:
            writer=csv.writer(out);writer.writerow(self.case['names']);writer.writerows(rows)
        self.case.update(rows=2,null_counts=[0,0,0])
        work=ExternalWorkflow('pandas_arrow')
        try:
            with patch.object(pc,'read_csv',wraps=pc.read_csv) as read:
                frame=work.read(self.case)
            self.assertEqual(read.call_args.kwargs['convert_options'].column_types,
                dict(id=pa.int64(),x=pa.float64(),label=pa.string()))
            self.assertTrue(read.call_args.kwargs['convert_options'].strings_can_be_null)
            self.assertEqual(fingerprint(frame,'pandas_arrow',self.case),golden(rows)['frame'])
            work.validate_shape(frame,work.matrix(frame,self.case),self.case)
            self.assertEqual(work.pools['pyarrow'],pa.cpu_count())
        finally:
            work.close()

    def test_bad_request_exits_and_is_closed(self):
        command=[sys.executable,str(ROOT/'Benchmarks/CPUThroughput/external_worker.py')]
        worker=Worker(command,'duckdb',self.root/'invalid.log')
        try:
            with self.assertRaises(RuntimeError):
                worker.ask(self.request('not-a-workflow'))
        finally:
            worker.close()
        self.assertNotEqual(worker.process.returncode,0)


if __name__ == '__main__':
    unittest.main()
