"""Diagnostic core-placement collection; neither acceptance nor comparative performance."""
import ctypes,json,os,sys,time
from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run,compare
from Benchmarks.CPUThroughput.budget import jobs_for
from Benchmarks.Tools.execution_policy import PRODUCTION_MODE,worker_environment
lib=ctypes.CDLL(str(R/'core-counter-reader.dylib'),use_errno=True)
lib.read_core_usage.argtypes=[ctypes.c_int,ctypes.POINTER(ctypes.c_uint64)];lib.read_core_usage.restype=ctypes.c_int
FIELDS=['user_ticks','system_ticks','p_user_ticks','p_system_ticks','instructions','p_instructions','cycles','p_cycles','flags','timebase_numer','timebase_denom']
def snapshot(pid):
 values=(ctypes.c_uint64*len(FIELDS))()
 if lib.read_core_usage(pid,values):raise OSError(ctypes.get_errno(),'proc_pid_rusage')
 return dict(zip(FIELDS,map(int,values)))
def delta(a,b):
 keys=FIELDS[:8]
 if any(b[k]<a[k] for k in keys):raise ValueError('Counter moved backward')
 d={k:b[k]-a[k] for k in keys}
 d['total_ticks']=d['user_ticks']+d['system_ticks'];d['p_ticks']=d['p_user_ticks']+d['p_system_ticks']
 if d['p_ticks']>d['total_ticks'] or d['p_instructions']>d['instructions'] or d['p_cycles']>d['cycles']:raise ValueError('Inconsistent P/total counters')
 d['e_ticks']=d['total_ticks']-d['p_ticks']
 d['e_only']=d['total_ticks']>0 and d['instructions']>0 and d['cycles']>0 and d['p_ticks']==0 and d['p_instructions']==0 and d['p_cycles']==0
 return d
base=json.loads((R/'core-counter-default.json').read_text())
assert base['user_ptime']>0 and base['pinstructions']>0 and base['pcycles']>0,'P counter support must be demonstrated before zero is evidence'
original=run.Worker;observations=[]
class ObservedWorker(original):
 def ask(self,request):
  result=super().ask(request)
  if request=='stats':
   result['core_usage']=snapshot(self.process.pid)
   observations.append(dict(pid=self.process.pid,usage=result['core_usage']))
  return result
run.Worker=ObservedWorker
swift=Path('/private/tmp/swiftsci-csv-integer-overflow-20261024/sequential-build/worker')
py=Path('/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python')
configs=compare.conditions(swift,py,True)
contracts=[('/private/tmp/swiftsci-csv-external-20261023/inputs/Aotizhongxin-default.json','PM2.5'),('/private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json','Global_active_power')]
cases=[]
for path,key in contracts:
 case=json.loads(Path(path).read_text())
 for flow in ['read','sort-matrix']:cases.append(dict(id=len(cases),contract=path,input=case['id'],key=key,workflow=flow,verify=False))
root=R/'core-placement-observation';root.mkdir(exist_ok=False)
receipts=[]
try:
 for name,config in configs.items():
  parent_before=snapshot(os.getpid())
  summary=run.batch(config['command'],config['mode'],jobs_for(cases,2,0),4,root/name,rss_limit_bytes=8*2**30)
  parent_after=snapshot(os.getpid())
  raw=json.loads((root/name/'result.json').read_text())
  workers=[delta(a['core_usage'],b['core_usage']) for a,b in zip(raw['before'],raw['after'])]
  parent=delta(parent_before,parent_after)
  receipt=dict(condition=name,workers=workers,controller=parent,all_e_only=all(w['e_only'] for w in workers) and parent['e_only'],runtime=raw['runtime'])
  receipts.append(receipt);run.save(root/'core-audit.json',dict(placement_qualification_only=True,performance_qualified=False,conditions=receipts))
  receipt['all_user_e_only']=all(w['p_user_ticks']==0 for w in workers) and parent['p_user_ticks']==0
  run.save(root/'core-audit.json',dict(diagnostic_only=True,performance_qualified=False,conditions=receipts))
  print(name+': user E-only='+str(receipt['all_user_e_only'])+', strict total E-only='+str(receipt['all_e_only']),flush=True)
except BaseException as error:
 run.save(root/'failure.json',dict(type=type(error).__name__,error=str(error)));raise
print(json.dumps(dict(conditions=len(receipts),worker_intervals=4*len(receipts),jobs=8*len(receipts),all_e_only=all(r['all_e_only'] for r in receipts),performance_qualified=False),indent=2))
