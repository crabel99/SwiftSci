"""Inspect the failed memory control using existing receipts only."""
from pathlib import Path
from collections import Counter
import json,statistics
R=Path(__file__).parent;D=R/'full';records=json.loads((D/'records.json').read_text())
rows=[];workers=[]
for row in records:
 if row['label'] not in ('pandas','pandas_twin'):continue
 raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
 by_pid={}
 for job in raw['jobs']:by_pid.setdefault(job['worker_pid'],[]).append(job)
 for pid,jobs in by_pid.items():
  last=max(jobs,key=lambda j:j['response_ns'])
  workers.append(dict(round=row['round'],label=row['label'],pid=pid,
   jobs=len(jobs),case_counts=dict(Counter(j['input']+'/'+j['workflow'] for j in jobs)),
   last_case=last['input']+'/'+last['workflow'],last_released_rss_bytes=last['released_rss_bytes'],
   max_job_peak_bytes=max(j['process_peak_bytes'] for j in jobs)))
 rows.append(dict(round=row['round'],label=row['label'],
  peak_rss_bytes=row['summary']['sampled_peak_rss_bytes'],retained_rss_bytes=row['summary']['retained_rss_bytes'],
  kernel_peaks=[s['peak_bytes'] for s in raw['after']],final_rss=[s['rss_bytes'] for s in raw['after']]))
med={label:{key:statistics.median(r[key] for r in rows if r['label']==label)
           for key in ['peak_rss_bytes','retained_rss_bytes']} for label in ['pandas','pandas_twin']}
low,high=sorted(x['peak_rss_bytes'] for x in med.values())
result=dict(medians=med,peak_twin_ratio=high/low,allowed_upper_bytes=low*1.05+4*8*2**20,
 observed_high_bytes=high,excess_bytes=high-(low*1.05+4*8*2**20),
 queues=rows,worker_histories=workers,
 interpretation='Both peak and retained residency vary. The queue uses dynamic job assignment, so per-worker case histories differ. These receipts do not prove an allocator mechanism or an owner leak. The full panel remains unqualified.')
(R/'memory-control.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['queues','worker_histories']},indent=2))
