import hashlib, inspect, json, sys
from pathlib import Path
from unittest.mock import patch
import pandas as pd
import pyarrow as pa
import pyarrow.csv as pc
import pandas.io.parsers.arrow_parser_wrapper as wrapper
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
sys.path.insert(0,str(S/'Benchmarks/CPUThroughput'))
from external_workflows import fingerprint
R=Path(__file__).parent
source=inspect.getsource(wrapper)
(R/'pandas-arrow-parser.py').write_text(source)
expected=json.loads(Path('/private/tmp/swiftsci-sort-closeout-20261023/comparison-initialized/expected.json').read_text())
rows=[]
for path in ['/private/tmp/swiftsci-csv-external-20261023/inputs/Aotizhongxin-default.json','/private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json']:
 case=json.loads(Path(path).read_text());dtype={n:{'String':'str','Double':'float64','Int64':'int64'}[t] for n,t in zip(case['names'],case['types'])}
 captured={};original=pc.read_csv
 def observe(*a,**kw):
  captured['column_types']={k:str(v) for k,v in kw['convert_options'].column_types.items()}
  return original(*a,**kw)
 with patch.object(pc,'read_csv',observe):
  frame=pd.read_csv(case['path'],sep=case['delimiter'],dtype=dtype,na_values=case['null_tokens'],keep_default_na=False,engine='pyarrow')
 actual=fingerprint(frame,'pandas',case);gold=expected[case['id']+'/read']['frame']
 rows.append(dict(input=case['id'],reader='pandas.read_csv(engine=pyarrow)',**captured,full_native_match=actual==gold,mismatched_columns=[a['name'] for a,b in zip(actual['columns'],gold['columns']) if a!=b]))
 del frame
 kinds={'String':pa.string(),'Double':pa.float64(),'Int64':pa.int64()}
 types={n:kinds[t] for n,t in zip(case['names'],case['types'])}
 table=pc.read_csv(case['path'],parse_options=pc.ParseOptions(delimiter=case['delimiter']),convert_options=pc.ConvertOptions(column_types=types,null_values=case['null_tokens'],strings_can_be_null=True))
 frame=table.to_pandas();actual=fingerprint(frame,'pandas',case)
 rows.append(dict(input=case['id'],reader='pyarrow.csv.read_csv(explicit schema).to_pandas()',column_types={k:str(v) for k,v in types.items()},full_native_match=actual==gold,mismatched_columns=[a['name'] for a,b in zip(actual['columns'],gold['columns']) if a!=b]))
 del table,frame
 result=dict(pandas=pd.__version__,pyarrow=pa.__version__,parser_source_sha256=hashlib.sha256(source.encode()).hexdigest(),results=rows)
 (R/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
