from pathlib import Path
p=Path('/private/tmp/swiftsci-csv-compact-construction-20261024/Benchmarks/CPUThroughput/README.md')
s=p.read_text();needle='Full-output checks run on every condition before and after timing.'
s=s.replace(needle,'''Add `--pandas-arrow` to retain these five conditions and add a sixth, `pandas_arrow`. This condition calls `pyarrow.csv.read_csv` with every column type declared, then converts the table to pandas. Parsing and conversion both remain inside timing. Sorting and matrix construction use the same pandas operations as the C-reader condition. The extended full panel uses 12 rotated rounds and 144 queues. Each condition and its twin occupies every position once; work per queue and qualification limits stay unchanged. Existing five-condition plans remain readable.

This is an explicit-schema Arrow-to-pandas pipeline, not `pandas.read_csv(engine="pyarrow")`. The installed pandas wrapper can infer parser types before applying `dtype`. Arrow's `column_types` disables inference for declared columns. The adapter requests null recognition in strings, preserves textual values, and records the native Arrow CPU pool size without changing it. See [pandas CSV options](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html) and [Arrow conversion options](https://arrow.apache.org/docs/python/generated/pyarrow.csv.ConvertOptions.html).

'''+needle)
p.write_text(s)
