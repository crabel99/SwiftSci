#include <libproc.h>
#include <sys/resource.h>
#include <stdint.h>
#include <mach/mach_time.h>
int read_core_usage(int pid, uint64_t *out) {
 struct rusage_info_v6 r={0};
 int status=proc_pid_rusage(pid,RUSAGE_INFO_V6,(rusage_info_t*)&r);
 if(status)return status;
 out[0]=r.ri_user_time;out[1]=r.ri_system_time;
 out[2]=r.ri_user_ptime;out[3]=r.ri_system_ptime;
 out[4]=r.ri_instructions;out[5]=r.ri_pinstructions;
 out[6]=r.ri_cycles;out[7]=r.ri_pcycles;out[8]=r.ri_flags;
 mach_timebase_info_data_t scale;mach_timebase_info(&scale);
 out[9]=scale.numer;out[10]=scale.denom;
 return 0;
}
