# Initial counter probe correction

The first probe incorrectly labels raw Mach ticks as user_ns and system_ns. Those original files remain preserved as core-counter-probe-v1.c and core-counter-default-v1.json. The corrected probe records user_mach_ticks, system_mach_ticks, and the Mach timebase, which is 125/3 nanoseconds per tick on this Mac. No timing conclusion uses the mislabeled fields.

The first background launch attempted /usr/bin/taskpolicy and failed before launching the child. The installed tool is /usr/sbin/taskpolicy. The corrected background record comes from that path. This failed command did not produce a benchmark measurement.
