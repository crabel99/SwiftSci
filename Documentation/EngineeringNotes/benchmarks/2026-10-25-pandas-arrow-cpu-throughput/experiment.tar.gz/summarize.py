"""Recompute the qualified six-condition panel and preserve its measured sources."""
from pathlib import Path
import hashlib, json, statistics, subprocess, sys
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
R=Path(__file__).parent;D=R/'full';sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput.compare import audit
from Benchmarks.CPUThroughput.run import digest,save
plan=json.loads((D/'plan.json').read_text());decision=audit(D)
smoke_plan=json.loads((R/'smoke/plan.json').read_text())
assert smoke_plan['source_hashes']==plan['source_hashes'], 'Smoke source must match the committed full-panel source'
assert decision['full_output_checks']==48, 'Incomplete correctness checks'
assert (decision['queues'],decision['jobs'],decision['full_output_checks'])==(144,9216,48)
records=json.loads((D/'records.json').read_text());ready=json.loads((D/'preflight/ready.json').read_text())
post=json.loads((D/'postflight/ready.json').read_text())
for path,contract in plan['contracts'].items():
 assert digest(Path(contract['path']))==contract['sha256']
 assert json.loads(Path(path).read_text())==contract
for name in plan['conditions']:
 for key in ['engine','versions','execution']:assert ready[name].get(key)==post[name].get(key)
for row in records:
 raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
 name=row['label'].removesuffix('_twin')
 for runtime in raw['runtime']:
  for key in ['engine','versions','execution']:assert runtime.get(key)==ready[name].get(key)
metrics=['completed_per_minute','charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes','retained_rss_bytes','sampled_resident_byte_seconds']
rows={};case_cpu={}
for name in plan['conditions']:
 group=[r for r in records if r['label'].removesuffix('_twin')==name]
 rows[name]={k:statistics.median(r['summary'][k] for r in group) for k in metrics}
 queues=[]
 for row in group:
  raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
  queues.append({case['input']+'/'+case['workflow']:statistics.mean(j['cpu_ns'] for j in raw['jobs'] if (j['input'],j['workflow'])==(case['input'],case['workflow'])) for case in plan['cases']})
 case_cpu[name]={k:statistics.median(q[k] for q in queues) for k in queues[0]}
pairs=[]
for left in ['swiftsci_optional','swiftsci_compact','pandas_arrow']:
 for right in (['pandas','polars','duckdb','pandas_arrow'] if left!='pandas_arrow' else ['pandas']):
  ratios={k:[] for k in metrics}
  for iteration in range(len(plan['orders'])):
   values={name:{k:statistics.median(r['summary'][k] for r in records if r['round']==iteration and r['label'].removesuffix('_twin')==name) for k in metrics} for name in [left,right]}
   for k in metrics:ratios[k].append(values[left][k]/values[right][k])
  pairs.append(dict(numerator=left,denominator=right,paired_ratios=ratios,paired_medians={k:statistics.median(v) for k,v in ratios.items()},rounds_lower_cpu=sum(x<1 for x in ratios['charged_cpu_ns'])))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert head==plan['source_head']
for name,sha in (plan['source_hashes'] | plan['swift_build']['sources']).items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=S);assert hashlib.sha256(data).hexdigest()==sha
 dest=R/'measured-sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
for name in ['Benchmarks/CPUThroughput/README.md','Benchmarks/Tests/test_external_cpu_plan.py','Benchmarks/Tests/test_external_cpu_workflows.py']:
 data=subprocess.check_output(['git','show',head+':'+name],cwd=S)
 dest=R/'measured-sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
summary=dict(source_commit=head,core_type_verified=False,required_core_match='P/E class matching requested after this uncontrolled panel; acceptance refinement pending',qualification=decision,conditions=rows,case_operation_cpu_ns=case_cpu,comparisons=pairs,runtime=ready,contracts_unchanged=True,runtime_versions_unchanged=True,validation=json.loads((R/'validation.json').read_text()))
save(R/'summary.json',summary);save(R/'comparisons.json',pairs)
save(R/'provenance.json',dict(source_commit=head,swift_build=plan['swift_build'],controller_sources=plan['source_hashes'],interpreter_sha256=plan['python_sha256'],all_source_hashes_match_commit=True,smoke_source_hashes_match_full=True,smoke_recorded_head=smoke_plan['source_head'],all_contracts_unchanged=True,runtime_versions_match_every_worker=True))
lines=['# Schema-explicit pandas via Arrow CPU comparison','',f'Benchmark commit `{head}` on local branch `codex/pandas-arrow-cpu-throughput` extends `6e101d1ce8020b3ac009767ac1789fa6b57b5606`. Swift production code is unchanged from `58db37c4b3c97b287186c377f76f89abcbbb0b0d`. Nothing is pushed.','',f"The full panel completes {decision['queues']} queues, {decision['jobs']:,} jobs, and {decision['full_output_checks']} complete native-output checks. Performance qualified: {decision['performance_qualified']}.",'',
'## Qualification decision','',
'The full panel is unqualified. Its identical pandas C-reader control has median peak RSS of 4,061.3 MiB versus 4,335.2 MiB, a 6.74% difference. The frozen allowance is 5% plus 32 MiB across four callers. The high value exceeds that allowance by 38.8 MiB. All CPU and elapsed twin controls pass; the other memory controls pass. Every output check passes.','',
'The following performance tables are provisional observations, not a validated ranking. No condition or failed round is discarded. The original limits and 64-job queue remain unchanged. A passing earlier panel does not validate this one.','',
'Both peak and retained pandas residency vary. Worker histories differ because the shared queue assigns jobs dynamically. The receipts do not identify an allocator mechanism or prove a leak. Before another performance claim, qualify a common processor class and isolate per-worker job history and retained allocations. The [memory-control analysis](memory-control.json) preserves every pandas queue and worker history.','',
'## Processor-class requirement','',
'This full panel records native CPU parallelism but does not measure or constrain P-core versus E-core placement. Matching backend and power settings does not prove matching core classes. It cannot establish efficiency under the subsequently clarified same-core-type requirement, independently of the failed RSS control. P/E scheduling has not been shown to cause the RSS difference.','',
'The [processor-class investigation](core-placement.md) and [local counter trials](core-placement-results.md) examine a supported way to measure placement. No replacement performance panel is accepted while the application-versus-kernel core rule is undecided.','',
'## Reader qualification','',
'Installed pandas 3.0.6 passes an empty column_types mapping to Arrow even when the caller supplies dtype. Its wrapper applies conversion after parsing. Both its ordinary Arrow entry point and an explicit-schema Arrow-to-pandas pipeline preserve every value in these two reference files. The latter also disables parser inference for every declared column, so that is the measured condition. This is not pandas.read_csv(engine="pyarrow").','',
'The archived qualification script captures actual parser options and complete native column hashes. A regression test checks that the adapter passes the full schema and preserves numeric-looking text, Int64 limits, and negative zero. Existing persistent-worker tests cover stable missing-last sorting, full Float64 matrix bits, and independent writable output for both pandas readers.','',
'Parsing and table.to_pandas conversion are timed. Subsequent sort_values and matrix construction use exactly the same pandas code as the C-reader condition. Arrow uses its default CPU pool; the benchmark does not set its size. Imports and process startup finish before queue timing. The first CSV read remains timed.','',
'API references: [pandas CSV options](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html) and [Arrow conversion options](https://arrow.apache.org/docs/python/generated/pyarrow.csv.ConvertOptions.html). Installed source and live parser calls establish the version-specific behavior above.','',
'## Provisional complete queue costs','',
'Four persistent callers serve 64 jobs per queue: 16 copies of each read or read-sort-matrix workflow on the air-quality and household-electricity datasets. All six conditions and their twins occupy every position across 12 rotated rounds. Every condition uses the same 8 GiB sampled worker-RSS ceiling and native internal CPU parallelism.','',
'| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Retained MiB | Resident MiB-seconds |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,m in rows.items():lines.append(f'| {name} | {m["completed_per_minute"]:.1f} | {m["charged_cpu_ns"]/64e6:.2f} | {m["sampled_peak_rss_bytes"]/2**20:.1f} | {m["retained_rss_bytes"]/2**20:.1f} | {m["sampled_resident_byte_seconds"]/2**20:.1f} |')
lines+=['','CPU sums worker user and system time plus measured controller CPU. It is not FLOPs or measured energy. RSS includes allocator residency and may count shared pages repeatedly. Resident MiB-seconds integrate sampled RSS over queue time; a lower peak does not imply lower occupancy.','',
'## Provisional comparisons within the same round','',
'Ratios divide the numerator by the denominator. Lower CPU, RSS, and resident byte-seconds mean less measured resource use. Higher jobs/min means higher throughput. Each ratio uses the median of a condition and its twin within a round, then the median of those 12 paired ratios.','',
'| Numerator | Denominator | CPU ratio | Throughput ratio | Peak RSS ratio | Resident byte-seconds ratio | Less CPU, rounds |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for c in pairs:
 m=c['paired_medians'];lines.append(f'| {c["numerator"]} | {c["denominator"]} | {m["charged_cpu_ns"]:.3f} | {m["completed_per_minute"]:.3f} | {m["sampled_peak_rss_bytes"]:.3f} | {m["sampled_resident_byte_seconds"]:.3f} | {c["rounds_lower_cpu"]}/12 |')
lines+=['','Rounds are not independent samples and do not establish confidence intervals. Results apply to these complete public paths and inputs. Historical C-reader results remain unchanged; this panel measures all readers together and does not divide timings from different days.','',
'## Provisional complete operation CPU','',
'| Dataset and workflow | Swift optional ms | Swift compact ms | pandas C ms | Polars ms | DuckDB plus Arrow ms | pandas via Arrow ms |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for case in case_cpu['pandas']:lines.append('| '+case+' | '+' | '.join(f'{case_cpu[name][case]/1e6:.2f}' for name in plan['conditions'])+' |')
lines+=['','These are complete path costs, not isolated sort measurements. Native fingerprints run outside timing. Output shape/type checks, materialization, owned writable row-major Float64 matrices, and output release remain inside. Every engine receives identical raw bytes, ordered schema, declared nulls, stable ascending missing-last sort, and independent expected output.','',
'DuckDB retains the earlier stable-index sort and Arrow gather, including their cost, to preserve signed-zero bits. No production algorithm changes. Ordinary pandas Int64 and Float64 null-representation limits remain; neither reference file requires missing integers or distinguishing valid NaN from null.','',
'## Controls, runtime, and validation','',
'The smoke ran before the source commit, and its recorded head remains unchanged. All eight measured controller hashes match the committed full-panel source. The smoke passes all controls but cannot qualify performance.','',
'Twin limits remain 10% CPU and elapsed drift, plus 5% and 8 MiB per caller for sampled peak RSS. Smoke cannot qualify performance and stays in the archive regardless of its control results. No limit, work count, schema, or caller count is tuned after the full panel starts. Runtime identity, contracts, all measured controller sources, Swift source hashes, interpreter, and binary are rechecked after timing.','']
for name,meta in ready.items():
 if 'versions' in meta:lines.append(f'- {name}: '+', '.join(f'{k} {v.splitlines()[0]}' for k,v in meta['versions'].items())+f'. Configured pools: {meta["execution"]["configured_pool_sizes"]}.')
lines+=['','Configured pool sizes are not active core measurements. Inherited thread overrides are cleared by the existing production-default worker policy.','','The 23 focused CPU tests pass without skips. The full controller discovery executes 249 tests: 245 pass and four require explicit Metal opt-in. Those four pass separately with SWIFTSCI_MLX_TEST_GPU=1. All 249 execute successfully across the two configurations; logs and exact commands are archived.','',
'The unchanged Swift source previously passed 447 Debug and 447 Release dataframe tests. No new native or hosted CI run is claimed for this Python-only feature. CPU timing does not overlap the controller tests or optional Metal tests.','',
'## Evidence','',
'[Memory-control analysis](memory-control.json), [summary](summary.json), [paired ratios](comparisons.json), [provenance](provenance.json), [validation](validation.json), and [archived experiment](experiment.tar.gz) preserve raw receipts, logs, exact measured source snapshots, the parser qualification, and reproduction scripts. Restore the recorded worker/interpreter and reference inputs by SHA256. Run compare.py with --pandas-arrow into a fresh directory, then --audit and the archived summarize.py. Binary files, raw CSVs, and caches are excluded.','',
'These finite queues repeat cached reference files. They do not establish cold-storage performance, sustained-service throughput, GPU/NPU performance, physical memory, energy, or a universal dataframe ranking. Engineering results stay on codex/engineering-notes.']
(R/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(qualification=decision,conditions=rows,compact=[x for x in pairs if x['numerator']=='swiftsci_compact']),indent=2))
