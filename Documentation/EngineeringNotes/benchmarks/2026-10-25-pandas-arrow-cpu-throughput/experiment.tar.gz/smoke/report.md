# Equivalent external-engine CPU queues

Smoke validation only.

Controls passed: True. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 1436.6 | 229.79 | 2135.3 | 454.8 |
| swiftsci_compact | 1412.7 | 217.40 | 1433.0 | 325.5 |
| pandas | 309.2 | 689.19 | 2724.7 | 1693.3 |
| polars | 2266.8 | 322.13 | 1649.1 | 241.2 |
| duckdb | 966.1 | 518.90 | 2262.6 | 787.8 |
| pandas_arrow | 1210.6 | 321.23 | 3100.5 | 741.4 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.
