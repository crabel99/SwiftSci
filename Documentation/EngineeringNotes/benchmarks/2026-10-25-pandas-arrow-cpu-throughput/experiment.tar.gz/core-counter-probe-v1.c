#include <libproc.h>
#include <sys/resource.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
static uint64_t now(void) {
 struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);
 return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;
}
int main(void) {
 struct rusage_info_v6 a={0},b={0};
 if (proc_pid_rusage(getpid(),RUSAGE_INFO_V6,(rusage_info_t*)&a)) {perror("rusage before");return 1;}
 volatile uint64_t x=1;uint64_t start=now();
 while(now()-start<1000000000ULL)for(int j=0;j<10000;j++)x=x*6364136223846793005ULL+1;
 if (proc_pid_rusage(getpid(),RUSAGE_INFO_V6,(rusage_info_t*)&b)) {perror("rusage after");return 1;}
 printf("{\"elapsed_ns\":%llu,\"user_ns\":%llu,\"system_ns\":%llu,\"user_ptime\":%llu,\"system_ptime\":%llu,\"instructions\":%llu,\"pinstructions\":%llu,\"cycles\":%llu,\"pcycles\":%llu,\"checksum\":%llu}\n",
 (unsigned long long)(now()-start),(unsigned long long)(b.ri_user_time-a.ri_user_time),(unsigned long long)(b.ri_system_time-a.ri_system_time),
 (unsigned long long)(b.ri_user_ptime-a.ri_user_ptime),(unsigned long long)(b.ri_system_ptime-a.ri_system_ptime),
 (unsigned long long)(b.ri_instructions-a.ri_instructions),(unsigned long long)(b.ri_pinstructions-a.ri_pinstructions),
 (unsigned long long)(b.ri_cycles-a.ri_cycles),(unsigned long long)(b.ri_pcycles-a.ri_pcycles),(unsigned long long)x);
 return 0;
}
