from pathlib import Path
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
p=S/'Benchmarks/CPUThroughput/external_workflows.py'
s=p.read_text().replace("lib=ctypes.CDLL", "PANDAS_ENGINES = ('pandas', 'pandas_arrow')\n\nlib=ctypes.CDLL")
s=s.replace(" names=list(frame.columns)", " engine = 'pandas' if engine in PANDAS_ENGINES else engine\n names=list(frame.columns)")
s=s.replace('if engine not in ("pandas", "polars", "duckdb"):', 'if engine not in (*PANDAS_ENGINES, "polars", "duckdb"):')
s=s.replace('self.modules = {engine: importlib.import_module(engine)}', '''self.family = "pandas" if engine in PANDAS_ENGINES else engine
        self.modules = {self.family: importlib.import_module(self.family)}''')
s=s.replace('        if engine == "duckdb":', '''        if engine == "pandas_arrow":
            self.modules["pyarrow"] = importlib.import_module("pyarrow")
            self.arrow_csv = importlib.import_module("pyarrow.csv")
            self.pools["pyarrow"] = self.modules["pyarrow"].cpu_count()
        if engine == "duckdb":''')
s=s.replace('    def read(self, case):\n', '''    def read(self, case):
        if self.engine == "pandas_arrow":
            pa = self.modules["pyarrow"]
            kinds = {"String": pa.string(), "Double": pa.float64(), "Int64": pa.int64()}
            table = self.arrow_csv.read_csv(case["path"],
                parse_options=self.arrow_csv.ParseOptions(delimiter=case["delimiter"]),
                convert_options=self.arrow_csv.ConvertOptions(
                    column_types={n: kinds[t] for n,t in zip(case["names"],case["types"])},
                    null_values=case["null_tokens"], strings_can_be_null=True))
            return table.to_pandas()
''')
s=s.replace('if self.engine == "pandas":','if self.family == "pandas":')
p.write_text(s)
p=S/'Benchmarks/CPUThroughput/compare.py';s=p.read_text()
s=s.replace('def conditions(swift, python):', 'def conditions(swift, python, include_pandas_arrow=False):')
s=s.replace("for engine in ('pandas','polars','duckdb')},", "for engine in ('pandas','polars','duckdb') + (('pandas_arrow',) if include_pandas_arrow else ())},")
a=s.index('    modes = ',s.index('def validate_plan'));b=s.index('    if plan[\'orders\']',a)
s=s[:a]+'''    modes = {name:c['mode'] for name,c in conditions('/swift','/python',
        plan.get('include_pandas_arrow',False)).items()}
    if {name:c['mode'] for name,c in plan['conditions'].items()} != modes:
        raise ValueError('Comparison must retain every declared reader condition')
    labels=list(modes)+[name+'_twin' for name in modes]
    orders=[labels[i:]+labels[:i] for i in range(2 if plan['smoke'] else len(labels))]
'''+s[b:]
s=s.replace("p.add_argument('--smoke',action='store_true');p.add_argument('--audit',action='store_true')", "p.add_argument('--smoke',action='store_true');p.add_argument('--audit',action='store_true')\n    p.add_argument('--pandas-arrow',action='store_true',help='Also compare explicit-schema Arrow CSV converted to pandas')")
s=s.replace('configs=conditions(args.swift_worker,args.python)', 'configs=conditions(args.swift_worker,args.python,args.pandas_arrow)')
s=s.replace('plan=dict(conditions=configs,', 'plan=dict(include_pandas_arrow=args.pandas_arrow,conditions=configs,')
s=s.replace("'', 'Every primary condition", "'', 'The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.',\n        '', 'Every primary condition")
p.write_text(s)
p=S/'Benchmarks/Tests/test_external_cpu_workflows.py';s=p.read_text().replace("ENGINES = ('pandas','polars','duckdb')", "ENGINES = ('pandas','polars','duckdb','pandas_arrow')")
s=s.replace('import unittest\n','import unittest\nfrom unittest.mock import patch\n')
where=s.index('    def test_bad_request_exits_and_is_closed')
s=s[:where]+'''    def test_arrow_parser_receives_full_schema_and_preserves_numeric_text(self):
        import pyarrow as pa
        import pyarrow.csv as pc
        rows=[(2**63-1,-0.0,'001'),(-(2**63),0.10000000000000002,'2026-10-25')]
        with Path(self.case['path']).open('w',newline='') as out:
            writer=csv.writer(out);writer.writerow(self.case['names']);writer.writerows(rows)
        self.case.update(rows=2,null_counts=[0,0,0])
        work=ExternalWorkflow('pandas_arrow')
        try:
            with patch.object(pc,'read_csv',wraps=pc.read_csv) as read:
                frame=work.read(self.case)
            self.assertEqual(read.call_args.kwargs['convert_options'].column_types,
                dict(id=pa.int64(),x=pa.float64(),label=pa.string()))
            self.assertTrue(read.call_args.kwargs['convert_options'].strings_can_be_null)
            self.assertEqual(fingerprint(frame,'pandas_arrow',self.case),golden(rows)['frame'])
            work.validate_shape(frame,work.matrix(frame,self.case),self.case)
            self.assertEqual(work.pools['pyarrow'],pa.cpu_count())
        finally:
            work.close()

'''+s[where:];p.write_text(s)
p=S/'Benchmarks/Tests/test_external_cpu_plan.py';s=p.read_text();idx=s.index('    def test_rejects_unlike')
s=s[:idx]+'''    def test_arrow_extension_retains_original_panel_and_full_rotation(self):
        self.plan.update(include_pandas_arrow=True,
            conditions=conditions(Path('/swift'),Path('/python'),True))
        labels=list(self.plan['conditions']);labels += [name+'_twin' for name in labels]
        self.plan['orders']=[labels[i:]+labels[:i] for i in range(len(labels))]
        validate_plan(self.plan)
        self.plan['conditions'].pop('pandas_arrow')
        with self.assertRaises(ValueError):validate_plan(self.plan)

'''+s[idx:];p.write_text(s)
