# Equivalent external-engine CPU queues

Fixed reference queues with native CPU parallelism.

Controls passed: False. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 2016.8 | 212.46 | 3461.3 | 5499.5 |
| swiftsci_compact | 1999.8 | 205.84 | 2480.4 | 3889.1 |
| pandas | 336.0 | 675.44 | 4107.7 | 38962.3 |
| polars | 2476.4 | 299.28 | 2840.0 | 3612.6 |
| duckdb | 1336.0 | 496.98 | 4205.9 | 9569.2 |
| pandas_arrow | 2009.5 | 296.11 | 5073.3 | 7974.7 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.
