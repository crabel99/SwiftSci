import Foundation

// Study-only entry points, never added to the production worktree.
public enum CSVPreparationDiagnostics {
    @inline(never)
    public static func makeAttempt(nullValues: Set<String>, selectedRows: Int) -> Any {
        var options = CSVReadOptions()
        options.nullValues = nullValues
        options.columnTypeOverrides = ["text": .utf8]
        let bytes = [UInt8]()
        return bytes.withUnsafeBufferPointer { buffer in
            let records = CSVRecordIndex(fields: [], rowStarts: [0])
            let plan = CSVColumnPlan(buffer: buffer, records: records, startRow: 0,
                rowCount: 0, column: 0, name: "text", options: options)
            return plan.conversion(type: .utf8, capacity: selectedRows)
        }
    }

    @inline(never)
    public static func makePrefix(nullValues: Set<String>, selectedRows: Int) -> Any? {
        return nil
    }

    @inline(never)
    public static func hashValues(_ values: [String], nullValues: Set<String>) -> [String?] {
        var result = [String?]()
        result.reserveCapacity(values.count)
        for value in values { result.append(nullValues.contains(value) ? nil : value) }
        return result
    }
}
