from pathlib import Path
import json,sys,subprocess
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
request=json.loads(Path('/private/tmp/swiftsci-cpu-throughput-panel-20261024/plan.json').read_text())['cases'][2]
request={k:v for k,v in request.items() if k!='input'}
for storage in ['optional','compact']:
 worker=run.Worker(Path('/private/tmp/swiftsci-cpu-throughput-final-build-20261024/worker'),storage,R/(storage+'-worker.log'))
 try:
  with (R/(storage+'-sample.log')).open('w') as log:
   sampler=subprocess.Popen(['sample',str(worker.process.pid),'4','1','-file',str(R/(storage+'-sample.txt'))],stdout=log,stderr=subprocess.STDOUT)
   rows=[worker.ask(dict(request,id=i)) for i in range(50)]
   code=sampler.wait(timeout=30)
  run.save(R/(storage+'-profile.json'),dict(profiled_timings_not_performance_evidence=True,iterations=len(rows),sample_exit=code,stats=worker.ask('stats')))
 finally:worker.close()
 print(storage,'profile complete',code,flush=True)
