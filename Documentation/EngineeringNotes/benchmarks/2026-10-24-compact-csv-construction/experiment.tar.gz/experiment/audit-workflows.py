from pathlib import Path
import json,sys
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent;D=R/(sys.argv[1] if len(sys.argv)>1 else 'word-state-workflows')
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput import run
from Benchmarks.CPUThroughput.budget import jobs_for
plan=json.loads((D/'plan.json').read_text());records=json.loads((D/'records.json').read_text());decision=json.loads((D/'decision.json').read_text());expected=json.loads((D/'expected.json').read_text())
assert (D/'end.json').exists() and not (D/'failure.json').exists()
assert run.digest(D/'expected.json')==plan['expected_sha256']
for name,binary in plan['binaries'].items():assert run.digest(Path(binary))==plan['receipts'][name]['binary_sha256']
for source,sha in plan['receipts']['candidate']['sources'].items():assert run.digest(S/source)==sha
required={(i,label) for i,order in enumerate(plan['orders']) for label in order}
assert len(records)==len(required)==64
assert {(r['round'],r['label']) for r in records}==required
jobs=0
for r in records:
 raw=json.loads((D/f"r{r['round']}-{r['label']}"/'result.json').read_text());summary=raw['summary'];queued=jobs_for(plan['cases'],plan['copies_per_case'],r['round'])
 assert summary==r['summary']
 recomputed=run.summarize(raw['jobs'],summary['elapsed_ns'],raw['memory_samples'],queued)
 assert all(summary[k]==v for k,v in recomputed.items())
 assert summary['worker_cpu_ns']==sum(b['cpu_ns']-a['cpu_ns'] for a,b in zip(raw['before'],raw['after']))
 assert summary['charged_cpu_ns']==summary['worker_cpu_ns']+summary['controller_cpu_ns']
 storage=r['label'].removesuffix('_twin').split('_')[1]
 assert all(x['storage']==storage for x in raw['jobs'])
 assert len(raw['before'])==len(raw['after'])==plan['callers']
 jobs+=len(raw['jobs'])
checks=0
for name in plan['binaries']:
 for phase in ['preflight','postflight']:
  raw=json.loads((D/(name+'-'+phase)/'checks.json').read_text())
  assert len(raw)==8
  assert {(x['storage'],x['input'],x['workflow']) for x in raw}=={(storage,c['input'],c['workflow']) for storage in ['optional','compact'] for c in plan['cases']}
  assert all(x['check']==expected[x['input']+'/'+x['workflow']] for x in raw)
  checks+=len(raw)
assert jobs==decision['jobs']==8192
assert decision['qualified'] and not decision['flags']
result=dict(queues=len(records),jobs=jobs,full_output_checks=checks,qualified=True,source_and_binary_receipts_match=True)
run.save(D/'audit.json',result);print(json.dumps(result,indent=2))
