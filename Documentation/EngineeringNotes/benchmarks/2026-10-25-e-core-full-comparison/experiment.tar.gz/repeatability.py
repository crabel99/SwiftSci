"""Describe identical-twin variability without changing frozen qualification."""
from pathlib import Path
import json
import statistics

r=Path(__file__).parent;d=r/'full/panel'
records=json.loads((d/'records.json').read_text());intervals=json.loads((r/'full-core-intervals.json').read_text())
core={(x['round'],x['label']):x for x in intervals}
conditions=json.loads((d/'plan.json').read_text())['conditions']
rows=[]
for name in conditions:
 values={}
 for label in [name,name+'_twin']:
  samples=[]
  for record in records:
   if record['label']!=label:continue
   c=core[(record['round'],label)];processes=c['workers']+[c['controller']]
   cycles=sum(x['deltas']['cycles']-x['deltas']['p_cycles'] for x in processes)
   instructions=sum(x['deltas']['instructions']-x['deltas']['p_instructions'] for x in processes)
   e_ns=c['time_ns']['user_e']+c['time_ns']['kernel_e']
   samples.append(dict(round=record['round'],charged_cpu_ns=record['summary']['charged_cpu_ns'],
    elapsed_ns=record['summary']['elapsed_ns'],peak_rss_bytes=record['summary']['sampled_peak_rss_bytes'],
    e_cpu_ns=e_ns,e_cycles=cycles,e_instructions=instructions,
    e_cycles_per_accounted_ns=cycles/e_ns,e_cycles_per_instruction=cycles/instructions))
  values[label]=dict(samples=samples,medians={k:statistics.median(x[k] for x in samples) for k in samples[0] if k!='round'})
 left=values[name]['medians'];right=values[name+'_twin']['medians']
 rows.append(dict(condition=name,values=values,twin_over_primary={k:right[k]/left[k] for k in left}))
(r/'full-repeatability.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
lines=['# Identical-twin diagnostics','',
'These diagnostics do not change the seven failed controls or qualify the panel. Every twin runs the same binary, schema, jobs, and output contract as its primary condition. Ratios divide the twin median by the primary median across twelve rotations.','',
'| Condition | Charged CPU | Elapsed | Peak RSS | E instructions | E cycles | E cycles per accounted ns |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for x in rows:
 m=x['twin_over_primary'];lines.append(f'| {x["condition"]} | {m["charged_cpu_ns"]:.4f} | {m["elapsed_ns"]:.4f} | {m["peak_rss_bytes"]:.4f} | {m["e_instructions"]:.4f} | {m["e_cycles"]:.4f} | {m["e_cycles_per_accounted_ns"]:.4f} |')
lines+=['',
'E cycles and instructions include E-user and E-kernel execution in the same recorded core intervals. P-kernel work remains separate. Cycles per accounted ns is a ratio of two process counters. It is not a direct measurement of core frequency, energy, temperature, or cache misses. A ratio change alone does not identify the hardware mechanism.','',
'Equal application core type therefore does not establish equal work rate or equal contention. Instruction and cycle variation may include runtime, allocator, scheduling, and data-access effects. This record does not isolate those causes. No new tolerance, workload, excluded engine, or accepted ranking follows from these diagnostics.']
(r/'full-repeatability.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
