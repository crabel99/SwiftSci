"""Validate the measured head after timing, preserving an explicit source binding."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

r=Path(__file__).parent;s=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
py='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
if not (r/'full-exit.json').is_file():raise RuntimeError('Do not overlap validation with benchmark timing')
if json.loads((r/'full-exit.json').read_text())['exit_code']!=0:raise RuntimeError('Benchmark did not complete successfully')
def snapshot():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()
 if subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip():raise RuntimeError('Measured source is dirty')
 names=subprocess.check_output(['git','ls-files','Benchmarks','Sources'],cwd=s,text=True).splitlines()
 hashes={n:hashlib.sha256((s/n).read_bytes()).hexdigest() for n in names if Path(n).suffix in {'.py','.c','.swift'}}
 return dict(commit=head,source_hashes=hashes)
before=snapshot();expected=json.loads((r/'full-launch.json').read_text())['source_commit']
if before['commit']!=expected:raise RuntimeError('Measured head changed')
base=dict(os.environ,POLARS_MAX_THREADS='1')
commands=[('full-controller-tests.log',[py,'-m','unittest','discover','-s','Benchmarks/Tests'],base),
 ('full-optional-metal-tests.log',[py,'-m','unittest','-v',
 'test_llama_precision.MixedPrecisionAdapterTests.test_shared_storage_preserves_inputs_and_projection_without_duplicate_matrix',
 'test_llama_precision.MixedPrecisionAdapterTests.test_wider_projection_preserves_close_score_without_changing_body_weights',
 'test_mlx_workers.MLXWorkersTests.test_explicit_metal_decoder_and_boundary',
 'test_neural_shapes.ShapedDecoderTests.test_mlx_explicit_gpu_all_shapes'],dict(base,SWIFTSCI_MLX_TEST_GPU='1',PYTHONPATH='Benchmarks/Tests'))]
result=dict(started_utc=datetime.now(timezone.utc).isoformat(),before=before,commands=[],overlaps_timing=False)
for name,command,env in commands:
 with (r/name).open('w') as log:completed=subprocess.run(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(r/name).read_text();match=re.search(r'Ran (\d+) tests?',text);skips=re.search(r'OK \(skipped=(\d+)\)',text)
 result['commands'].append(dict(command=command,log=name,exit_code=completed.returncode,tests=int(match.group(1)) if match else None,
  skipped=int(skips.group(1)) if skips else 0,environment={k:env[k] for k in ['POLARS_MAX_THREADS','SWIFTSCI_MLX_TEST_GPU','PYTHONPATH'] if k in env}))
 if completed.returncode:break
result['after']=snapshot();result['finished_utc']=datetime.now(timezone.utc).isoformat()
result['source_binding_passed']=result['before']==result['after']
result['passed']=result['source_binding_passed'] and len(result['commands'])==2 and all(c['exit_code']==0 for c in result['commands']) and [(c['tests'],c['skipped']) for c in result['commands']]==[(255,4),(4,0)]
(r/'full-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],commit=before['commit'],commands=result['commands']),indent=2))
if not result['passed']:raise SystemExit(1)
