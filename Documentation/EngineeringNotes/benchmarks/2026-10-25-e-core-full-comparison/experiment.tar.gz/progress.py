"""Read completed receipts without ranking an unfinished panel."""
from pathlib import Path
import json
R=Path(__file__).parent;D=R/'full/panel'
records=json.loads((D/'records.json').read_text()) if (D/'records.json').exists() else []
checks=len(json.loads((D/'preflight/checks.json').read_text())) if (D/'preflight/checks.json').exists() else 0
post=len(json.loads((D/'postflight/checks.json').read_text())) if (D/'postflight/checks.json').exists() else 0
print(json.dumps(dict(completed_queues=len(records),total_queues=144,completed_jobs=sum(x['summary']['completed'] for x in records),
 completed_rounds=len(records)//12,preflight_checks=checks,postflight_checks=post,
 latest=None if not records else dict(round=records[-1]['round'],condition=records[-1]['label']),
 failure=json.loads((D/'failure.json').read_text()) if (D/'failure.json').exists() else None,
 exit=json.loads((R/'full-exit.json').read_text()) if (R/'full-exit.json').exists() else None),indent=2))
