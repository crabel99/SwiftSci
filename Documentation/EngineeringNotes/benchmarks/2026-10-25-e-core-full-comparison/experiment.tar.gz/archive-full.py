"""Package the full study after timing and audits finish; verify every preserved byte."""
from pathlib import Path
import hashlib
import io
import json
import re
import shutil
import sys
import tarfile

def require(value,message):
 if not value:raise ValueError(message)

r=Path(__file__).parent;destination=Path(sys.argv[1])
require(json.loads((r/'full-exit.json').read_text())['exit_code']==0,'Full comparison failed')
require(json.loads((r/'full-summary.json').read_text())['qualification']['queues']==144,'Full comparison incomplete')
require((r/'full-input-metadata-final.json').is_file(),'Missing final input metadata')
require(json.loads((r/'full-validation.json').read_text())['passed'],'Post-run validation failed')
destination.mkdir(parents=True,exist_ok=False)
copies={'full-report.md':'README.md','full-summary.json':'summary.json','full-comparisons.json':'comparisons.json',
 'full-core-intervals.json':'core-intervals.json','full-provenance.json':'provenance.json','full-decisions.tsv':'decisions.tsv',
 'validation.json':'validation.json','full-validation.json':'current-head-validation.json','next-panel-plan.json':'next-panel-plan.json','verify-archive.py':'verify-archive.py',
 'full-review.md':'review.md','full-repeatability.md':'repeatability.md','full-repeatability.json':'repeatability.json','verify-isolated.py':'verify-isolated.py'}
for src,dst in copies.items():shutil.copyfile(r/src,destination/dst)
plan=json.loads((r/'full/panel/plan.json').read_text())
external=[]
for role,path,sha in [('Swift worker',plan['conditions']['swiftsci_optional']['command'][0],plan['swift_build']['binary_sha256']),
 ('Python interpreter',plan['conditions']['pandas']['command'][0],plan['python_sha256'])]:
 p=Path(path);data=p.read_bytes();require(hashlib.sha256(data).hexdigest()==sha,'Measured executable changed')
 external.append(dict(role=role,path=path,bytes=len(data),sha256=sha,status='recorded, bytes not archived'))
(r/'external-artifacts.json').write_text(json.dumps(external,indent=2)+'\n')
root_names={'full.log','full-exit.json','full-launch.json','full-awake.json','full-awake-first-attempt.json',
 'full-awake-live-proof.json','full-input-metadata-inflight.json','full-input-metadata-final.json',
 'full-summary.py','full-summary.json','full-comparisons.json','full-core-intervals.json','full-provenance.json',
 'full-report.md','full-decisions.tsv','full-review.md','next-panel-plan.json','launch-full.py','progress.py',
 'validation.json','validate.sh','validate-full-head.py','full-validation.json','full-controller-tests.log','full-optional-metal-tests.log','focused-tests.log','controller-tests.log','optional-metal-tests.log',
 'verify-archive.py','verify-isolated.py','archive-full.py','external-artifacts.json','repeatability.py','full-repeatability.md','full-repeatability.json','full-validation-driver.log','full-portable-trial.json','full-portable-trial-scoped.json','full-lifecycle.json'}
files=[p for p in r.iterdir() if p.is_file() and p.name in root_names]
for base in [r/'full',r/'full-measured-sources']:
 files += [p for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts and
           (p.suffix in {'.json','.log','.md','.py','.swift','.c','.dylib'} or p.name=='core-counter-probe')]
files.sort();payload={str(p.relative_to(r)):p.read_bytes() for p in files}
for name,data in payload.items():
 if name.endswith(('.dylib','core-counter-probe')):continue
 require_no_secret=not re.search(rb'(?:glpat-|glrt-|gh[pousr]_|github_pat_)[A-Za-z0-9_-]{16,}|https?://[^\s/:]+:[^\s/@]+@',data)
 require(require_no_secret,'Possible credential in '+name)
inventory={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in payload.items()}
with tarfile.open(destination/'experiment.tar.gz','w:gz') as archive:
 for name,data in payload.items():
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;archive.addfile(item,io.BytesIO(data))
 data=(json.dumps(inventory,indent=2)+'\n').encode();item=tarfile.TarInfo('inventory.json');item.size=len(data);archive.addfile(item,io.BytesIO(data))
with tarfile.open(destination/'experiment.tar.gz','r:gz') as archive:
 require(len(archive.getmembers())==len(inventory)+1,'Archive member count differs')
 for item in archive.getmembers():
  if item.name=='inventory.json':require(json.load(archive.extractfile(item))==inventory,'Inventory differs');continue
  data=archive.extractfile(item).read();require(inventory[item.name]==dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()),'Archived member differs')
hashes={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in destination.iterdir()}
(destination/'artifact-sha256.json').write_text(json.dumps(dict(files=hashes,archive_members_verified=len(inventory)),indent=2)+'\n')
print(json.dumps(dict(archive_members_verified=len(inventory),archive_bytes=(destination/'experiment.tar.gz').stat().st_size)))
