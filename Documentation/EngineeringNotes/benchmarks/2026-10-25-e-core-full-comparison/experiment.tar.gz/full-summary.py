"""Audit the fixed full E-core comparison and produce a readable results record."""
from pathlib import Path
import hashlib,json,statistics,subprocess,sys
from datetime import datetime,timezone
if not __debug__:raise RuntimeError('Closeout assertions require Python without optimization')
S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024');R=Path(__file__).parent;D=R/'full/panel'
sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput.compare import audit
from Benchmarks.CPUThroughput.core_usage import audit_receipt
from Benchmarks.CPUThroughput.run import digest,save
plan=json.loads((D/'plan.json').read_text());decision=audit(D)
assert (decision['queues'],decision['jobs'],decision['full_output_checks'])==(144,9216,48)
assert decision['application_core_class']=='efficiency'
records=json.loads((D/'records.json').read_text());ready=json.loads((D/'preflight/ready.json').read_text());post=json.loads((D/'postflight/ready.json').read_text())
for path,c in plan['contracts'].items():
 assert digest(Path(c['path']))==c['sha256'];assert json.loads(Path(path).read_text())==c
metadata=json.loads((R/'full-input-metadata-inflight.json').read_text())
for record in metadata['files']:
 stat=Path(record['path']).stat()
 assert (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns)==tuple(record[k] for k in ['device','inode','size','mtime_ns','ctime_ns'])
 assert record['ctime_before_launch']
save(R/'full-input-metadata-final.json',dict(metadata,captured_utc=datetime.now(timezone.utc).isoformat()))
calibration=plan['core_policy']
assert digest(Path(calibration['library']))==calibration['library_sha256']
assert digest(Path(calibration['library']).with_name('core-counter-probe'))==calibration['probe_binary_sha256']
intervals=[];expanded=[]
metrics=['completed_per_minute','charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes','retained_rss_bytes','sampled_resident_byte_seconds',
         'core_user_e_ns','core_kernel_e_ns','core_kernel_p_ns','accounted_e_cycles','accounted_e_instructions','accounted_p_cycles','accounted_p_instructions']
for row in records:
 raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
 name=row['label'].removesuffix('_twin')
 for runtime in raw['runtime']:
  for key in ['engine','versions','execution']:assert runtime.get(key)==ready[name].get(key)==post[name].get(key)
 core=audit_receipt(raw['core_usage'],[x['pid'] for x in raw['runtime']]);assert core['controller']['pid']==plan['controller_pid']
 assert row['summary']['core_time_ns']==core['time_ns']
 intervals.append(dict(round=row['round'],label=row['label'],**core))
 values=row['summary'].copy()
 values.update(core_user_e_ns=core['time_ns']['user_e'],core_kernel_e_ns=core['time_ns']['kernel_e'],core_kernel_p_ns=core['time_ns']['kernel_p'])
 processes=core['workers']+[core['controller']]
 values.update(accounted_e_cycles=sum(x['deltas']['cycles']-x['deltas']['p_cycles'] for x in processes),
  accounted_e_instructions=sum(x['deltas']['instructions']-x['deltas']['p_instructions'] for x in processes),
  accounted_p_cycles=sum(x['deltas']['p_cycles'] for x in processes),
  accounted_p_instructions=sum(x['deltas']['p_instructions'] for x in processes))
 expanded.append(dict(round=row['round'],label=row['label'],values=values))
rows={name:{k:statistics.median(x['values'][k] for x in expanded if x['label'].removesuffix('_twin')==name) for k in metrics} for name in plan['conditions']}
totals={}
for name in plan['conditions']:
 group=[x['values'] for x in expanded if x['label'].removesuffix('_twin')==name]
 count=sum(x['completed'] for x in group)
 totals[name]=dict(queues=len(group),jobs=count,charged_cpu_ns=sum(x['charged_cpu_ns'] for x in group),
  core_user_e_ns=sum(x['core_user_e_ns'] for x in group),elapsed_ns=sum(x['elapsed_ns'] for x in group),
  sampled_resident_byte_seconds=sum(x['sampled_resident_byte_seconds'] for x in group),
  maximum_sampled_peak_rss_bytes=max(x['sampled_peak_rss_bytes'] for x in group))
 assert totals[name]['queues']==24 and count==1536
pairs=[]
for left in ['swiftsci_optional','swiftsci_compact','pandas_arrow']:
 for right in (['pandas','polars','duckdb','pandas_arrow'] if left!='pandas_arrow' else ['pandas']):
  ratios={k:[] for k in metrics}
  for i in range(len(plan['orders'])):
   values={n:{k:statistics.median(x['values'][k] for x in expanded if x['round']==i and x['label'].removesuffix('_twin')==n) for k in metrics} for n in [left,right]}
   for k in metrics:
    if values[right][k]>0:ratios[k].append(values[left][k]/values[right][k])
  pairs.append(dict(numerator=left,denominator=right,paired_ratios=ratios,
   paired_medians={k:statistics.median(v) if v else None for k,v in ratios.items()},rounds_lower_charged_cpu=sum(x<1 for x in ratios['charged_cpu_ns'])))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert head==plan['source_head']
sources=plan['source_hashes'] | plan['swift_build']['sources']
for p in [*S.glob('Benchmarks/Tests/test_*cpu*.py'),S/'Benchmarks/CPUThroughput/README.md']:
 sources[str(p.relative_to(S))]=digest(p)
for name,sha in sources.items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=S);assert hashlib.sha256(data).hexdigest()==sha
 p=R/'full-measured-sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
workers=sum(len(x['workers']) for x in intervals);assert workers==576
assert all(x['time_ns']['user_p']==0 for x in intervals)
validation=json.loads((R/'validation.json').read_text())
current_validation=json.loads((R/'full-validation.json').read_text())
assert current_validation['passed'] and current_validation['source_binding_passed'] and current_validation['before']['commit']==head
summary=dict(source_commit=head,qualification=decision,worker_intervals=workers,controller_intervals=len(intervals),application_p_ns=0,
 conditions=rows,resource_totals=totals,comparisons=pairs,runtime=ready,current_head_validation=current_validation,prior_validation=validation,prior_test_commit_binding='Prior session reports this source; original test logs do not embed a commit hash')
save(R/'full-summary.json',summary);save(R/'full-comparisons.json',pairs);save(R/'full-core-intervals.json',intervals)
save(R/'full-provenance.json',dict(source_commit=head,controller_sources=plan['source_hashes'],swift_build=plan['swift_build'],
 core_policy=plan['core_policy'],all_source_hashes_match_commit=True,all_contracts_unchanged=True,all_runtime_identities_match=True,input_metadata_unchanged_since_inflight_capture=True,input_ctimes_precede_launch=True,calibration_probe_binary_hash_checked=True,
 prior_test_evidence_reused=True,post_run_tests_bound_to_commit=True,core_acceptance_scope='Recorded queue intervals only; excludes startup, preflight, postflight, and final audit'))
qualified=decision['performance_qualified']
lines=['# Full comparison with E-core application execution','',f'Source `{head}`, policy e-core-application-v1. Full panel performance qualified: {qualified}.','',
'## Qualification','',f'The panel completes 144 queues, 9,216 jobs, 48 full native-output checks, 576 worker intervals, and 144 controller intervals. Application P-core time is zero in every accepted queue interval. Startup, preflight, postflight, and the final audit are outside these receipts. Kernel P/E time remains measured separately. Controls passed: {decision["controls_passed"]}.','',
'The tables below support a qualified comparison.' if qualified else 'The tables below are provisional observations. The failed controls prevent a validated ranking. No failure or condition is discarded.', '',
'| Control condition | Failed control | Observed twin difference | Frozen allowance |','| --- | --- | --- | --- |']
for f in decision['flags']:
 if 'ratio' in f:
  metric={'elapsed_ns':'Elapsed time','charged_cpu_ns':'Charged CPU time'}[f['metric']]
  observed=f"{(f['ratio']-1)*100:+.1f}%";allowance='10%'
 else:
  metric='Sampled peak RSS';observed=f"{f['low']/2**20:.1f} to {f['high']/2**20:.1f} MiB";allowance='5% plus 32 MiB'
 lines.append(f'| {f["label"]} | {metric} | {observed} | {allowance} |')
if not decision['flags']:lines.append('| All | All controls pass | | |')
lines+=['','The [identical-twin diagnostics](repeatability.md) retain instruction and cycle counts. Pandas and DuckDB twins have nearly identical E-instruction counts, but charged CPU differs by 22% and 29%. The counted cycles per accounted ns also differ. These process-counter ratios do not establish core frequency, temperature, energy, or cache misses. Matching application core type was insufficient to qualify this run.','',
'## Complete queue costs','',
'Four persistent callers retain native internal parallelism under one inherited background QoS clamp. Every condition uses the same 64 jobs per queue, complete schemas, native-value contracts, stable missing-last sort, and owned writable row-major Float64 output. Twelve rotated rounds place every primary condition and its identical-binary twin in every position.','',
'| Condition | Jobs/min | Charged CPU ms/job | Peak RSS MiB | Retained RSS MiB | Resident MiB-seconds |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,m in rows.items():lines.append(f'| {name} | {m["completed_per_minute"]:.1f} | {m["charged_cpu_ns"]/64e6:.2f} | {m["sampled_peak_rss_bytes"]/2**20:.1f} | {m["retained_rss_bytes"]/2**20:.1f} | {m["sampled_resident_byte_seconds"]/2**20:.1f} |')
lines+=['','Medians pool each primary condition and its twin. Charged CPU sums worker user/system time and measured controller CPU. RSS may count shared pages more than once and includes allocator caches. It is not unique physical memory. Resident byte-seconds account for how long memory stays resident; lower peak alone does not establish lower occupancy.','',
'## Resource totals across every recorded queue','',
'Each condition completes 1,536 jobs across its 24 primary and twin queues. The figures below use sums across all those queues. They retain slow runs as well as fast ones and do not change qualification. CPU per job divides total charged CPU by total completed jobs. Aggregate throughput divides total jobs by total queue elapsed time.','',
'| Condition | All-run CPU ms/job | Aggregate jobs/min | Maximum sampled RSS MiB | Recorded resident MiB-seconds/job |','| --- | ---: | ---: | ---: | ---: |']
for name,m in totals.items():lines.append(f'| {name} | {m["charged_cpu_ns"]/m["jobs"]/1e6:.2f} | {m["jobs"]*60e9/m["elapsed_ns"]:.1f} | {m["maximum_sampled_peak_rss_bytes"]/2**20:.1f} | {m["sampled_resident_byte_seconds"]/m["jobs"]/2**20:.2f} |')
lines+=['',
'## Application and kernel core accounting','',
'| Condition | E user ms/job | E kernel ms/job | P kernel ms/job | E cycles/job, millions | E instructions/job, millions |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,m in rows.items():lines.append(f'| {name} | {m["core_user_e_ns"]/64e6:.3f} | {m["core_kernel_e_ns"]/64e6:.3f} | {m["core_kernel_p_ns"]/64e6:.3f} | {m["accounted_e_cycles"]/64e6:.2f} | {m["accounted_e_instructions"]/64e6:.2f} |')
lines+=['','P-core user time is zero. Accounted E cycles/instructions include both E-user and E-kernel execution. Accounted P cycles/instructions belong to kernel execution under this rule. Counters are not FLOPs or measured energy. A lower instruction count does not establish less equivalent mathematical work because instruction mixes differ.','',
'Core snapshots bracket queue work plus boundary bookkeeping, wider than the old wall and charged-CPU intervals. These components are not an exact partition of charged_cpu_ns. Every worker snapshot requires zero running threads before and after the read. The controller snapshot follows queue completion and thread teardown. Raw counters, process IDs, and Mach timebase remain in the receipts.','',
'## Paired ratios within each round','',
'Numerator divided by denominator, pooling a condition with its twin within each round before taking the median ratio over 12 rounds. Lower CPU/memory ratios mean less measured resource use; higher throughput ratios mean more completed jobs per minute.','',
'| Numerator | Denominator | Charged CPU | E-user CPU | Throughput | Peak RSS | Resident byte-seconds |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for p in pairs:
 m=p['paired_medians'];lines.append(f'| {p["numerator"]} | {p["denominator"]} | {m["charged_cpu_ns"]:.3f} | {m["core_user_e_ns"]:.3f} | {m["completed_per_minute"]:.3f} | {m["sampled_peak_rss_bytes"]:.3f} | {m["sampled_resident_byte_seconds"]:.3f} |')
lines+=['','Paired ratios can differ from ratios of pooled medians. Rounds are not independent samples and do not establish confidence intervals. P/E matching does not fix CPU frequency, cache state, or unrelated system activity. The recorded twin controls remain mandatory. These are finite repeated-data queues, not cold-storage or sustained-service measurements.','',
'## Adapters and scope','',
'Pandas C uses round-trip float conversion. The pandas_arrow condition uses pyarrow.csv.read_csv with an explicit full schema, then converts to pandas; it is not pandas.read_csv(engine="pyarrow"). Conversion is timed. Both pandas conditions share sorting and matrix code. Polars receives the complete schema. DuckDB materializes Arrow output and pays for stable-index sorting plus gathering original values to preserve signed-zero bits.','',
'The two source files contain 35,064 air-quality rows and 2,075,259 household-electricity rows. Every library receives identical bytes and declared nulls. Full output hashes match each native Int64/Float64/String column and matrix before and after timing. No representation mismatch is waived. Inputs needing missing Int64 or valid-NaN-versus-null distinction require additional equivalent adapters.','',
'QoS is a preference, not hard affinity. Acceptance depends on observed counters, positive-P calibration, consistent boot session, and zero application P-time for every participating PID. The 8 GiB sampled worker-RSS ceiling and original 10% CPU/wall and 5% plus 8 MiB-per-caller peak-RSS twin limits stay unchanged.','',
'After timing, 255 unique controller tests passed across normal and explicit Metal configurations. The new validation records before-and-after source hashes and this exact commit. Discovery executes 251 tests and explicitly skips four Metal cases, which the second command runs successfully. Earlier logs remain preserved, but do not independently embed a commit hash. No tests, compilation, or profiling overlap timing. All 51 Swift source hashes still match the previously tested library head. No new Swift production code or hosted CI result is claimed.','',
'## Evidence','',
'Live audit checks the original source, interpreter, worker, calibration binary hashes, current inputs, and every saved queue. The separate verify-archive.py audit uses only preserved files and Python standard-library code. It cannot authenticate stored calibration stdout, replace missing executable bytes, or prove continuous input immutability. Resident byte-seconds remain recorded values because the raw receipt omits the monotonic batch start/end anchors needed for exact integral recomputation. Peak RSS, boundary RSS, sample ordering, and integral bounds can be checked independently.','',
'[Source-bound validation](current-head-validation.json), [portable audit](verify-archive.py), [independent review](review.md), [summary](summary.json), [paired ratios](comparisons.json), [core intervals](core-intervals.json), [provenance](provenance.json), [decision trail](decisions.tsv), and [raw archive](experiment.tar.gz) preserve the reviewable record. A new timing run requires the recorded worker, reference inputs, and comparison environment. Restore inputs by SHA256, use the pinned source, and choose a fresh output directory. launch-full.py preserves the original absolute-path protocol and refuses to overwrite an existing full directory. It requires path adjustments for a relocated workspace. The raw receipt audit is separate from a new timing run. next-panel-plan.json preserves the pre-launch plan unchanged. full-launch.json and full-exit.json record actual execution. Engineering evidence stays on codex/engineering-notes.']
(R/'full-report.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(qualification=decision,conditions=rows),indent=2))
