"""Execute the frozen full protocol without changing its source or work totals."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path(__file__).parent;S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
path=R/'next-panel-plan.json';plan=json.loads(path.read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head==plan['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
assert not (R/'full').exists()
(R/'full-launch.json').write_text(json.dumps(dict(started_utc=datetime.now(timezone.utc).isoformat(),
 source_commit=head,protocol_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),command=plan['command']),indent=2)+'\n')
with (R/'full.log').open('w') as log:
 result=subprocess.run(plan['command'],cwd=S,stdout=log,stderr=subprocess.STDOUT)
(R/'full-exit.json').write_text(json.dumps(dict(exit_code=result.returncode,finished_utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n')
raise SystemExit(result.returncode)
