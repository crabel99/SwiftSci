# Equivalent external-engine CPU queues

Fixed reference queues with native CPU parallelism.

Controls passed: False. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 154.3 | 670.09 | 3428.5 | 66006.4 |
| swiftsci_compact | 156.4 | 544.39 | 2455.7 | 47368.0 |
| pandas | 41.8 | 2578.56 | 3513.7 | 237524.0 |
| polars | 111.0 | 716.30 | 2116.0 | 60942.4 |
| duckdb | 77.6 | 1250.75 | 3853.7 | 144448.1 |
| pandas_arrow | 133.0 | 748.41 | 3933.9 | 87819.5 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.

## Verified application core class

Every worker and the controller must record zero P-core user time. Kernel P/E time is reported separately and does not fail that rule. A supported-counter calibration precedes the common background QoS clamp. QoS is not treated as affinity.

| Condition | E user ms/job | P user ms/job | E kernel ms/job | P kernel ms/job |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 624.809 | 0.000 | 46.720 | 0.070 |
| swiftsci_compact | 515.586 | 0.000 | 30.993 | 0.026 |
| pandas | 2446.614 | 0.000 | 115.797 | 0.111 |
| polars | 631.067 | 0.000 | 79.719 | 0.085 |
| duckdb | 1146.026 | 0.000 | 108.356 | 0.681 |
| pandas_arrow | 651.626 | 0.000 | 98.928 | 0.198 |

Core counters bracket the queue plus boundary bookkeeping. They cover a wider interval than the wall timer and are not an exact partition of the existing charged_cpu_ns metric. Raw worker and controller snapshots remain in each receipt.
