# Equivalent external-engine CPU queues

Fixed reference queues with native CPU parallelism.

Controls passed: False. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 219.8 | 666.59 | 3447.7 | 50365.4 |
| swiftsci_compact | 200.8 | 592.77 | 2468.5 | 38672.3 |
| pandas | 58.5 | 2352.82 | 3683.7 | 185930.6 |
| polars | 148.8 | 842.14 | 2178.0 | 46681.4 |
| duckdb | 107.6 | 1194.41 | 4174.8 | 123686.7 |
| pandas_arrow | 175.2 | 698.98 | 5067.1 | 91338.8 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

The optional pandas_arrow condition parses a complete schema with pyarrow.csv.read_csv and converts to pandas. Conversion is timed; pandas.read_csv(engine=pyarrow) is not used because its wrapper infers parser types.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.

## Verified application core class

Only compute workers are background-clamped and must record zero P-core user time. The ordinary controller includes dispatch, observation, and bookkeeping. Its P/E work is reported separately and remains charged. Raw QoS counters reject inherited restricted controller execution. The profiles are not interchangeable.

| Condition | E user ms/job | P user ms/job | E kernel ms/job | P kernel ms/job |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 629.645 | 0.012 | 37.031 | 0.015 |
| swiftsci_compact | 561.548 | 0.013 | 31.946 | 0.018 |
| pandas | 2269.908 | 0.011 | 87.428 | 0.004 |
| polars | 765.509 | 0.002 | 76.450 | 0.002 |
| duckdb | 1107.746 | 0.004 | 86.651 | 0.005 |
| pandas_arrow | 632.189 | 0.002 | 60.488 | 0.003 |

| Condition and role | E user ms/job | P user ms/job | E kernel ms/job | P kernel ms/job |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional worker | 626.985 | 0.000 | 34.903 | 0.006 |
| swiftsci_optional controller | 3.108 | 0.012 | 2.173 | 0.010 |
| swiftsci_compact worker | 559.466 | 0.000 | 29.475 | 0.008 |
| swiftsci_compact controller | 3.381 | 0.013 | 2.322 | 0.010 |
| pandas worker | 2260.578 | 0.000 | 82.976 | 0.000 |
| pandas controller | 10.209 | 0.011 | 4.858 | 0.003 |
| polars worker | 762.408 | 0.000 | 72.481 | 0.000 |
| polars controller | 4.721 | 0.002 | 4.823 | 0.002 |
| duckdb worker | 1103.072 | 0.000 | 80.339 | 0.000 |
| duckdb controller | 6.393 | 0.004 | 8.072 | 0.003 |
| pandas_arrow worker | 629.874 | 0.000 | 58.251 | 0.000 |
| pandas_arrow controller | 4.072 | 0.002 | 3.289 | 0.001 |

Observation requests a 10 ms cadence. Every queue must meet the fixed 50 ms maximum coverage gap and scan duration. Missing boundary scans fail audit. These checks qualify sampling coverage, not an instantaneous memory peak.

| Condition | Sampled footprint MiB | Maximum coverage gap ms | Maximum scan ms | Controller CPU ms/job |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 3044.7 | 22.240 | 6.356 | 5.432 |
| swiftsci_compact | 2064.1 | 20.001 | 5.771 | 5.962 |
| pandas | 3135.0 | 50.526 | 37.394 | 16.087 |
| polars | 1858.3 | 27.455 | 4.228 | 9.756 |
| duckdb | 3217.9 | 32.893 | 9.581 | 14.908 |
| pandas_arrow | 4492.4 | 19.882 | 9.877 | 7.606 |

Physical footprint supplements RSS. It does not replace the unchanged RSS repeatability gate. Reusable bytes are not available from this unprivileged cross-process probe. Controller CPU charging includes initial/final scans, stats, core reads, and receipt validation. Its wider interval is recorded separately from queue wall timing. Final receipt serialization and disk writes are excluded.

Core counters bracket the queue plus boundary bookkeeping. They cover a wider interval than the wall timer and are not an exact partition of the existing charged_cpu_ns metric. Raw worker and controller snapshots remain in each receipt.
