"""Verify the completed collection, immutable replay, and owned-process cleanup."""
import hashlib,json,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/private/tmp/swiftsci-e-core-observer-isolation-20261025/source')
sys.path.insert(0,str(source))
from Benchmarks.CPUThroughput.operating_state import analyze
bundle=q/'study';panel=bundle/'comparison/panel'
method=json.loads((bundle/'method.json').read_text())
plan=json.loads((panel/'plan.json').read_text())
original=json.loads((panel/'audit.json').read_text())
saved=json.loads((bundle/'diagnostics/counter-evidence.json').read_text())
def hashes():return {str(p.relative_to(panel)):hashlib.sha256(p.read_bytes()).hexdigest() for p in panel.rglob('*') if p.is_file()}
before=hashes()
replayed=analyze(panel,method)
replayed['provenance']['method_file_sha256']=hashlib.sha256((bundle/'method.json').read_bytes()).hexdigest()
assert replayed==saved
assert saved['original_audit']==original
assert len(saved['queues'])==144 and original['jobs']==9216 and original['full_output_checks']==48
assert saved['provenance']['method_predeclared'] is True
assert (bundle/'method.json').stat().st_mtime_ns<(panel/'plan.json').stat().st_mtime_ns
assert not (bundle/'failure.json').exists()
assert hashes()==before
pids={plan['controller_pid']}
for row in json.loads((panel/'records.json').read_text()):
    raw=json.loads((panel/f"r{row['round']}-{row['label']}"/'result.json').read_text())
    pids.update(w['pid'] for w in raw['runtime'])
for stage in ['preflight','postflight']:
    pids.update(w['pid'] for w in json.loads((panel/stage/'ready.json').read_text()).values())
cleanup=[]
for pid in sorted(pids):
    result=subprocess.run(['ps','-p',str(pid),'-o','pid=,comm='],capture_output=True,text=True)
    cleanup.append(dict(pid=pid,absent=result.returncode==1 and not result.stdout.strip(),output=result.stdout.strip()))
assert all(r['absent'] for r in cleanup),cleanup
receipt=dict(source_head=plan['source_head'],python=sys.version,method_created_before_plan=True,
    method_file_sha256=saved['provenance']['method_file_sha256'],saved_and_replayed_diagnostics_equal=True,
    original_audit_unchanged=True,verified_capture_files=len(before),all_capture_bytes_unchanged=True,
    queues=144,jobs=9216,full_output_checks=48,control_failures=original['flags'],
    performance_qualified=original['performance_qualified'],owned_processes=cleanup)
(q/'full-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['python','owned_processes','control_failures']}|dict(control_failure_count=len(original['flags']),owned_pids_absent=len(cleanup))))
