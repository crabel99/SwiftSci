# Full E-core CPU queue comparison

This study is running under the predeclared `cpu-counter-evidence-v1` method. It uses the reviewed source at `06adea701994f8fbbe82481684dfdafd77958a09` and changes no measured source or acceptance limit.

The panel contains 12 rotated rounds, 144 queues, and 9,216 jobs. It retains SwiftSci optional and compact storage, pandas C, pandas with explicit-schema Arrow conversion, Polars, and DuckDB. Each condition has its own identical-binary twin. Four persistent workers retain native internal parallelism and must record zero P-core user time. The ordinary controller reports its own resource consumption separately.

Every queue contains 64 jobs from the same air-quality and household-energy workflows. The original full-output checks, observation-coverage limits, 8 GiB sampled worker-RSS ceiling, AC-power requirement, and twin quality limits remain frozen.

`study/method.json` records the method before launch. `study/comparison/panel/plan.json` records the full collection plan. After completion, the existing controller writes its report and audit, and the wrapper writes the counter and resource report under `study/diagnostics`.

No final comparison or qualification is available at launch. A failed control remains a failed control. The full study is one attempt, not repeated selection for a passing result.

`verify-full.py` is the prepared post-run check. It replays the completed diagnostics, checks capture immutability, and inspects recorded process IDs after completion. It has not been run against an incomplete panel.
