## Historical position at the CPU/GPU closeout

Implemented on the local trial: prepared column reuse through standard scaling, min-max scaling and imputation; ownership transfer through compatible preprocessing steps; admission and retained-storage accounting; scoped and retained GPU input ownership; and a complete training-only preprocessing / held-out GPU regression workflow.

The latest shared-device qualification recorded 874 selected Release tests passing, two optional skips, 32 controller tests passing, and 299,520 comparison requests with matching predictions and fitted parameters. These results apply to their recorded configurations. They do not establish full-repository validation, general leak freedom, or improved SRAM/SLC utilization. Device-handle reuse removed repeated software setup work; its memory measurements did not uniformly improve.

## 1. Close the current CPU/GPU contribution

- [x] Inventory production changes, experimental owners and benchmark-only paths against the intended contribution base. Identify what ships and what remains research.
- [x] Resolve the supported ownership boundary for `RetainedLinearRegressionTrial`, `RetainedGPUInputTrial`, and `RetainedPreparedGPUInputTrial`. Promotion requires caller and lifetime review, not just renaming.
- [x] Reconcile dependency and upstream changes; preserve existing public behavior, numerical policies, source snapshots and compatibility entry points.
- [x] Document supported dtypes, layouts, missing-value semantics, cancellation/completion behavior, and the limits of estimated admission budgets.
- [x] Run the applicable Debug/Release, numerical-policy, documentation and lifecycle checks on the final contribution revision. Keep skipped or unverified cases explicit.
- [x] Preserve benchmark fingerprints, rerun comparisons affected by consolidation, and record the reviewed local contribution and evidence.

Exit condition: a bounded, reviewable CPU/GPU contribution with an explicit supported contract and validation at its final head. Later accelerator experiments do not block this milestone.

Local closeout completed October 7, 2026 on `codex/cpu-gpu-optimization-closeout` at `22c6b8908b18c967295f08a5effa69265c7fa4ef`; implementation commit `e29002e7d0`. It is based on PR #62 and includes the merged #60 dependency update with no change to the tested tree. The trial head remains preserved. Retained-owner APIs and comparison controls stay experimental; in particular, the retained prediction adapter needs an explicit GPU/precision contract before promotion.

Validation: 1,208 Debug and 1,208 Release tests passed, with two optional skips in each configuration; 160 controller tests and 100 workflow validation controls passed. All 196 Swift numerical cases passed; the Python reference retains four reviewed Wampler failures out of 196 cases. Regression policy passed without changing tolerances. Across 48 comparison workers and 299,520 requests, predictions and fitted parameters matched; lifecycle checks passed. Median throughput changes against the preserved trial ranged from -1.44% to +1.03%, a bounded qualification rather than a statistical equivalence claim. Eight additional integrity workers checked retained-source preservation and consumed-buffer reuse.

Evidence is recorded locally on `codex/engineering-notes` at `5ce0758617b4a172b1aaed882f19d82c0e4048ff`, in `Documentation/EngineeringNotes/benchmarks/2026-10-07-cpu-gpu-closeout.md`. Neither new branch head has been pushed. Runtime qualification is on the current Apple silicon host, not every supported macOS version.

- [x] Publish the reviewed CPU/GPU contribution with its dependency on #62 clear, link its PR and published evidence, and complete hosted CI. Publication is separate from the completed local development/qualification above.

## 2. Add a Core ML execution interface on a separate branch

- [x] Audit and reuse existing `CoreMLExportable` / `CoreMLExporter` support and relevant Apple APIs before introducing new abstractions.
- [x] Connect prepared data to Core ML inputs and outputs with explicit dtype, shape, stride, conversion, and ownership contracts. Evaluate compatible shared backing and reusable output buffers; verify copies rather than assuming their absence.
- [x] Keep application admission and buffer lifetimes in our memory layer. Leave model partitioning, Neural Engine scheduling and internal memory placement with Core ML.
- [x] Expose allowed compute units and fallback behavior honestly. An allowed Neural Engine does not prove execution there.
- [x] Qualify asynchronous prediction, cancellation, errors, concurrent requests, model unload and repeated reuse. Account separately for application estimates and observed framework/process memory.
- [ ] Use a representative supported inference model with independently checked outputs. Compare CPU, GPU and Neural Engine configurations where available; record actual placement, conversion costs, cold/warm behavior, latency, throughput, memory and accuracy.

Status: the first verified workflow is delivered by #65 and #66, with end-to-end bounding in #67. Broader device-placement and compute-policy comparisons remain ongoing; allowed compute units do not establish actual placement.

Exit condition: one complete, verified workflow through the adapter, with documented fallback and ownership behavior. General dataframe operations and FP64 scientific computation do not become implicit NPU workloads.

## 3. Measure and optimize working sets

Each item starts as a hypothesis with a reference implementation. Retain an optimization only when representative measurements support its tradeoff.

- [ ] Characterize actively reused bytes, dtype, access order, strides and concurrency across realistic sizes. Separate software overhead, allocation, conversion, computation and synchronization. Use hardware counters where available and distinguish observations from inferred cache effects.
- [ ] Evaluate compact columns and validity storage through ingestion and numerical consumers. Include selection, missing values, retained snapshots, mutations and conversion costs.
- [x] Evaluate blocked matrix operations and packing with varied shapes and reuse counts. Compare established Accelerate/BLAS paths before adding custom kernels; avoid a universal hard-coded crossover from one fixture or chip.
- [x] Evaluate fusion of compatible preprocessing steps over chunks to reduce intermediate arrays and memory passes. Preserve training-only fitting, arithmetic/precision requirements, missing-value treatment and source ownership.
- [ ] Evaluate worker partitioning, task size and concurrent writes for false sharing and bandwidth contention. Measure whether padding or partition changes justify their extra memory cost.
- [ ] Compare Metal threadgroup staging with direct access for a suitable workload. Include occupancy, synchronization and staging costs; do not assume explicit scratch memory is faster.
- [ ] Test CPU/GPU/Core ML handoffs and overlapping work for shared-bandwidth contention, completion ordering and memory pressure. Unified addressing does not make accesses equally cheap or remove synchronization.

Exit condition per experiment: an adopted change with evidence, or a documented rejection/deferment explaining when to reconsider it. This milestone does not promise that every proposed optimization will ship.

## 4. Keep the roadmap and evidence usable

- [ ] Record each experiment's hypothesis, branch, baseline/candidate commits, workloads, numerical contract, result and decision in the engineering notes; link it here once published.
- [ ] Use child issues for substantial work, each with an acceptance condition and a bounded branch/PR. Reference this tracker in those issues and PRs without automatically closing it.
- [ ] Maintain a representative comparison across small/large/mixed inputs, retained/consumed ownership, cold/warm execution and bounded concurrency. Include end-to-end costs and relevant Python/framework references with equivalent contracts.
- [ ] Record supported-hardware and OS coverage, unavailable counters, untested failure paths, and performance regressions. Preserve historical results at their tested fingerprints.
- [ ] At each milestone, update this issue's completed work, next action, and deferred items so follow-up conversations do not become an undocumented backlog.

## Reference material

- [Apple CPU performance and false-sharing guidance](https://developer.apple.com/videos/play/tech-talks/110147/)
- [Apple Metal shader guidance](https://developer.apple.com/videos/play/tech-talks/111373/)
- [Metal shared storage](https://developer.apple.com/documentation/metal/mtlstoragemode/shared)
- [Apple Neural Engine transformer layout and memory guidance](https://machinelearning.apple.com/research/neural-engine-transformers), a documented implementation study rather than a universal layout rule for every chip generation.
- [Core ML input/output and performance integration](https://developer.apple.com/videos/play/wwdc2022/10027/)

The current decision and remaining production boundary are recorded in the October 12 status update above.






