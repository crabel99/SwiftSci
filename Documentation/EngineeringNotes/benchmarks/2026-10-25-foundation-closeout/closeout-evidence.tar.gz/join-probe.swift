import Foundation
import Darwin
@testable import SwiftDataFrame
let rows = Int(CommandLine.arguments[1])!
let compact = CommandLine.arguments[2] == "compact"
let values = (0..<rows).map(Double.init)
let key: TypedColumn<Double> = compact
    ? TypedColumn(name: "key", compactColumn: CompactNumericColumn(values))
    : TypedColumn(name: "key", values: values)
let frame = try DataFrame(columns: [key])
var before = rusage(); getrusage(RUSAGE_SELF, &before)
let start = DispatchTime.now().uptimeNanoseconds
let joined = try frame.join(frame, on: "key")
let wall = Double(DispatchTime.now().uptimeNanoseconds - start) / 1e6
var after = rusage(); getrusage(RUSAGE_SELF, &after)
func seconds(_ t: timeval) -> Double { Double(t.tv_sec) + Double(t.tv_usec) / 1e6 }
let cpu = 1000 * (seconds(after.ru_utime) + seconds(after.ru_stime) - seconds(before.ru_utime) - seconds(before.ru_stime))
precondition(joined.rowCount == rows && joined[column: "key", as: Double.self]![rows-1] == Double(rows-1))
print("{\"rows\":\(rows),\"compact\":\(compact),\"wall_ms\":\(wall),\"cpu_ms\":\(cpu),\"peak_rss_bytes\":\(after.ru_maxrss)}")
