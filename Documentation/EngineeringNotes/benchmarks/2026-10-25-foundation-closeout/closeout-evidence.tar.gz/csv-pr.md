## Problem and behavior

CSV integer overflow can trap while decoding values outside Int64, and compact validity construction updates its bitmap for every field. Empty numeric fallback also constructs and parses strings that cannot contain a number.

This patch accepts both signed Int64 limits and returns nil for overflow. It flushes compact validity a word at a time, narrows structural SIMD flags with the existing byte ordering, and skips empty raw or normalized numeric conversion. Schema inference still distinguishes missing fields from invalid tokens, and explicit-schema behavior remains unchanged. Optional Double storage stays the default.

## Validation

- All 1,647 native package tests pass in both Debug and Release, across all 15 test targets, with zero failures or skips. This includes MLX, strict ONNX prerequisites, and the pinned Llama tokenizer.
- All 226 benchmark-controller tests pass with Metal opt-in enabled and no skips.
- Complete CPU regression policy passes all 404 Swift/Python executions with no new failures. Swift passes 202/202; Python retains the four reviewed Wampler failures. Raw numerical conformance remains failed for those four cases.
- Changed Swift files emit no long-type-check warnings at the 100 ms expression and 200 ms function thresholds. New test files are 31, 75, and 80 lines. Documentation coverage is unchanged at 2431/2464 declarations.
- Independent standards and specification reviews report no actionable findings.

Validation head: `da03a630154843acee994c2e8b3af2924ee8b253`. Upstream base: `962fd9ff4d155e5116baf6f177abfa3e84fd8754`. Hosted checks are pending.

## Resource evidence and scope

The historical mixed-CSV comparison measures `36a93f7dfd54524fc7360fd52930366190db8d01` to `58db37c4b3`, not this new cherry-pick fingerprint. Two qualifying panels observed lower CPU work. The reversed panel failed its elapsed-time control and remains failed. The four changed CSV production files match the recorded `58db37c4b3` versions exactly. No new universal speed or energy claim is made.

Engineering notes, raw experiments, profiler code, and benchmark-control changes are excluded. Related roadmap: crabel99/SwiftSci#2. Review this CSV unit before the dependent foundation closeout.
