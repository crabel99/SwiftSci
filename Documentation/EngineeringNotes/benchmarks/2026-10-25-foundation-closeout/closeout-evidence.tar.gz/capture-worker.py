from pathlib import Path
import sys,json,shutil,hashlib
root=Path(__file__).resolve().parent;source=Path(sys.argv[1]);tag=sys.argv[2]
sys.path.insert(0,str(source/'Benchmarks/Tools'))
from runner import source_identity,verify_uninstrumented,metal_build_record,environment
from contracts import digest,write_json
build=json.loads((root/(tag+'-validation')/'release-build.json').read_text());assert build['exit_code']==0 and build['head']==source_identity(source)['commit']
for name,checksum in build['sources'].items():assert digest((source/name).read_bytes())==checksum
products=Path('/Users/crabel/Library/Caches/SwiftSci/mixed-workloads-derived/Build/Products/Release');out=root/(tag+'-worker');out.mkdir()
for p in products.iterdir():
 if p.name=='SwiftSciBenchmarkWorker' or p.suffix=='.metallib':shutil.copy2(p,out/p.name)
 elif p.suffix=='.bundle':shutil.copytree(p,out/p.name)
worker=out/'SwiftSciBenchmarkWorker';verify_uninstrumented(worker)
write_json(Path(str(worker)+'.build.json'),dict(schema_version=1,source=source_identity(source),command=build['command'],binary_sha256=digest(worker.read_bytes()),coverage_instrumentation='absent',metal=metal_build_record(worker),log=str(root/(tag+'-validation')/'release-build.log'),snapshot=str(source),environment=environment()))
print(worker)
