from pathlib import Path
import subprocess,hashlib,json,os,time,re
r=Path(__file__).resolve().parent;python='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
for name in ['csv','foundation']:
 s=r/(name+'-source');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();assert subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)==''
 names=subprocess.check_output(['git','ls-files','Benchmarks','Sources','Package.swift','Package.resolved'],cwd=s,text=True).splitlines()
 def fingerprint():return {n:hashlib.sha256((s/n).read_bytes()).hexdigest() for n in names if (s/n).is_file()}
 files=fingerprint();command=[python,'-m','unittest','discover','-s','Benchmarks/Tests'];env=dict(os.environ,SWIFTSCI_MLX_TEST_GPU='1');start=time.time();log=r/(name+'-controllers-final.log')
 with log.open('w') as out:p=subprocess.run(command,cwd=s,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=240)
 assert fingerprint()==files and subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==head and subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)==''
 text=log.read_text();assert p.returncode==0 and re.search(r'Ran 226 tests.*\n\nOK\s*$',text,re.S) and 'skipped=' not in text
 (r/(name+'-controllers-final.json')).write_text(json.dumps({'head':head,'command':command,'environment_overrides':{'SWIFTSCI_MLX_TEST_GPU':'1'},'source_files_sha256':files,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'exit_code':p.returncode,'tests':226,'skips':0,'seconds':time.time()-start},indent=2)+'\n');print(name,'226 controllers passed, head and source files unchanged',flush=True)
