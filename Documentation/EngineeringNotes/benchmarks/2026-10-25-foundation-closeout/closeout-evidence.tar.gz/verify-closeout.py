from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).resolve().parent
summary={}
for label,source,validation,policy in [('csv','csv-source','csv-validation','csv-conformance'),('foundation','foundation-source','final-validation','foundation-conformance')]:
 s=r/source;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();assert subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)==''
 checks={}
 for mode in ['debug','release']:
  build=json.loads((r/validation/(mode+'-build.json')).read_text());test=json.loads((r/validation/(mode+'-tests.json')).read_text());assert build['head']==test['head']==head and build['exit_code']==test['exit_code']==0
  for file,digest in build['sources'].items():assert hashlib.sha256((s/file).read_bytes()).hexdigest()==digest
  result=test['summary'];assert result['failedTests']==result['skippedTests']==0 and result['totalTestCount']==result['passedTests'] and len(test['targets'])==15 and test['strict_onnx_ci']
  checks[mode]={key:result[key] for key in ['totalTestCount','passedTests','failedTests','skippedTests']}
 accepted=json.loads((r/policy/'acceptance.json').read_text());decision=json.loads((r/policy/'regression-policy.json').read_text());assert accepted['source']['commit']==head and accepted['coverage_complete'] and accepted['status']=='failed'
 assert decision['status']=='passed' and not decision['blocking'] and len(decision['known_failures'])==4 and all(x['engine']=='pandas' and 'wampler' in x['case'] for x in decision['known_failures'])
 assert sum(x['engine_cases'] for x in accepted['profiles'])==404
 baseline=s/'Benchmarks/Specs/known-failures.json';assert baseline.read_bytes()==subprocess.check_output(['git','show','962fd9ff:Benchmarks/Specs/known-failures.json'],cwd=s)
 receipt=json.loads((r/(label+'-controllers-final.json')).read_text());log=r/(label+'-controllers-final.log')
 assert receipt['head']==head and receipt['tests']==226 and receipt['skips']==0 and receipt['exit_code']==0
 assert receipt['environment_overrides']=={'SWIFTSCI_MLX_TEST_GPU':'1'} and hashlib.sha256(log.read_bytes()).hexdigest()==receipt['log_sha256']
 for file,digest in receipt['source_files_sha256'].items():assert hashlib.sha256((s/file).read_bytes()).hexdigest()==digest
 controller=log.read_text();assert re.search(r'Ran 226 tests.*\n\nOK\s*$',controller,re.S) and 'skipped=' not in controller
 subprocess.run(['git','diff','--check','962fd9ff..HEAD'],cwd=s,check=True)
 changed=subprocess.check_output(['git','diff','--name-only','962fd9ff..HEAD'],cwd=s,text=True).splitlines();assert not any('EngineeringNotes' in f for f in changed)
 warnings={}
 for mode in ['debug','release']:
  warnings[mode]=[l for l in (r/validation/(mode+'-build.log')).read_text().splitlines() if 'warning:' in l and any(f in l for f in changed)]
 assert not any(warnings.values()),warnings
 summary[label]={'head':head,'native_tests':checks,'controller_tests':226,'numerical_policy':'passed','strict_conformance':'failed','executions':404,'known_python_wampler_failures':4,'unchanged_failure_inventory':True,'changed_file_warnings':warnings,'source_pr_excludes_engineering_notes':True}
# Preserve the exact historical CSV file-content relationship.
s=r/'csv-source';csvfiles=['CSVColumnBuilder.swift','CSVColumnConversion.swift','SystemsCSVParser.swift','VectorizedByteParsers.swift'];
for file in csvfiles:subprocess.run(['git','diff','--exit-code','58db37c4b3','HEAD','--','Sources/SwiftDataFrame/IO/'+file],cwd=s,check=True,stdout=subprocess.DEVNULL)
summary['historical_csv_production_files_match_58db37c4b3']=True
summary['final_base']='962fd9ff4d155e5116baf6f177abfa3e84fd8754';summary['timing_panel_qualified']=False;summary['hosted_ci']='pending';summary['old_or_interrupted_validation_receipts_excluded']=True
(r/'final-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
