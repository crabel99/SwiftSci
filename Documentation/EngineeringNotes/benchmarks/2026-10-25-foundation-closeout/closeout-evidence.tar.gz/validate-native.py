from pathlib import Path
import os,sys,json,subprocess,time,hashlib,plistlib
root=Path(__file__).resolve().parent
source=Path(sys.argv[1]); tag=sys.argv[2]; modes=sys.argv[3:] or ['Release','Debug']; out=root/tag;out.mkdir(exist_ok=True)
base=json.loads(Path('/private/tmp/swiftsci-csv-integration-20261023/build-command.json').read_text())['command']
derived=Path(base[base.index('-derivedDataPath')+1]);tokenizer=Path('/Users/crabel/Library/Caches/SwiftSci/models/Llama-3.2-1B-Instruct-bf16-863c846a/tokenizer.json')
assert hashlib.sha256(tokenizer.read_bytes()).hexdigest()=='79e3e522635f3171300913bb421464a87de6222182a0570b9b2ccba2a964b2b4'
env=dict(os.environ,TEST_RUNNER_SWIFTSCI_LLAMA_TOKENIZER_JSON=str(tokenizer),TEST_RUNNER_STRICT_ONNX_CI='1');env['TEST_RUNNER_PATH']='/private/tmp/swiftsci-csv-integration-20261023/onnx-env/bin:'+env['PATH']
for mode in modes:
 assert subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)==''
 cmd=base.copy();cmd[cmd.index('-configuration')+1]=mode
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
 fingerprint={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['Sources','Tests','Benchmarks/Worker','Benchmarks/Support'] for p in (source/folder).rglob('*.swift')}
 record={'head':head,'sources':fingerprint,'command':cmd};start=time.time()
 with (out/(mode.lower()+'-build.log')).open('w') as log:result=subprocess.run(cmd,cwd=source,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 record.update(exit_code=result.returncode,seconds=time.time()-start);(out/(mode.lower()+'-build.json')).write_text(json.dumps(record,indent=2)+'\n');print(tag,mode,'build',result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
 manifests=list((derived/'Build/Products').glob('*.xctestrun'));assert len(manifests)==1
 manifest=manifests[0]; data=plistlib.loads(manifest.read_bytes()); targets=data['TestConfigurations'][0]['TestTargets'];assert len(targets)==15,len(targets)
 assert not any(t.get('OnlyTestIdentifiers') or t.get('SkipTestIdentifiers') for t in targets)
 resultpath=out/(mode.lower()+'.xcresult')
 cmd=['xcodebuild','test-without-building','-xctestrun',str(manifest),'-destination','platform=macOS,arch=arm64','-parallel-testing-enabled','NO','-resultBundlePath',str(resultpath)]
 start=time.time()
 with (out/(mode.lower()+'-tests.log')).open('w') as log:result=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 summary=json.loads(subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(resultpath),'--format','json'],text=True)) if resultpath.exists() else {}
 record={'head':head,'command':cmd,'exit_code':result.returncode,'seconds':time.time()-start,'targets':[t['BlueprintName'] for t in targets],'strict_onnx_ci':True,'summary':summary}
 (out/(mode.lower()+'-tests.json')).write_text(json.dumps(record,indent=2)+'\n');print(tag,mode,'tests',result.returncode,{k:summary.get(k) for k in ['totalTestCount','passedTests','failedTests','skippedTests']},flush=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
 assert subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)==''
 assert fingerprint=={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['Sources','Tests','Benchmarks/Worker','Benchmarks/Support'] for p in (source/folder).rglob('*.swift')}
 if result.returncode or summary.get('failedTests',1) or summary.get('skippedTests',1):sys.exit(1)
