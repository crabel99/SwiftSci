# Foundation closeout plan

- [x] Read the Poteto principles and the required subtraction, evidence, and verification workflow.
- [x] Reconcile live upstream and preserve the earlier benchmark source and failed controls.
- [x] Extract the five pending CSV commits onto current upstream as a focused review unit.
- [x] Audit the supported data, schema, and ownership boundaries for avoidable materialization or missing lifetime coverage.
- [x] Correct demonstrated gaps in separate commits with focused regressions.
- [x] Run final Debug and Release package tests, numerical regression policy, benchmark controllers, documentation and compiler/type-size checks on the actual delivery heads.
- [x] Record supported foundation behavior and explicit limits; distinguish native paths from compatibility copies.
- [x] Preserve the completed resource study without modifying its failed timing controls or claiming a certified speed baseline.
- [x] Review and publish the bounded changes; update fork tracker #2 with completed, deferred, and unresolved work.

## Definition of done

The supported public foundation paths have documented representations, ownership and numerical contracts. The pending CSV correctness and resource changes are delivered in independently validated commits. Any demonstrated native-path copy or ownership defects are fixed and tested. Complete checks pass on the final heads, or concrete external limitations remain explicitly unresolved. Hosted delivery evidence and the roadmap identify the same heads. Engineering notes and raw experiments remain exclusively on codex/engineering-notes.

Timing repeatability is a separate measurement boundary. The full E-core panel remains recorded with ten timing-control failures and one 0.526 ms coverage overrun. Stable memory observations remain observations. No thresholds, failure inventories, or numerical tolerances change to achieve closeout.

## Scope

CSV ingestion and selectable compact Double storage; filtering, gathering, joins, grouping and sorting; prepared columns and matrices; supported preprocessing and CPU/GPU/Core ML handoffs; snapshots, mutation, cancellation and byte-budget lifetimes. Preserve legacy APIs and intentional compatibility conversions.

False-sharing experiments, custom Metal threadgroup kernels, general mutable foreign-array zero-copy, automatic hardware routing, broad new dtypes, and general Neural Engine placement guarantees are follow-on research. Their absence alone does not block this supported foundation.

## Verification strategy

Reuse existing tools before adding checks. Reproduce concrete gaps at their public API boundary, make the smallest correction, and rerun relevant cases. Run whole-library checks after source integration. Keep test expressions small and explicitly typed. Validate numerical and benchmark policies without rewriting recorded performance fingerprints. Use independent standards/spec and final evidence reviews.

## Final implementation state

Both source PRs are published as drafts, #87 then #88. Supported implementation and local validation are complete. Hosted checks and upstream review remain pending. Refresh #88 after #87 merges. The fork roadmap remains open for delivery and explicitly separate follow-on research; the timing panel remains unqualified.
