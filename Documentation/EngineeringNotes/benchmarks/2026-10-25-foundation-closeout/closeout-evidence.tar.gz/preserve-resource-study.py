from pathlib import Path
import hashlib,json,tarfile,shutil,subprocess
r=Path('/private/tmp/swiftsci-foundation-closeout-20261025'); q=Path('/private/tmp/swiftsci-cpu-operating-state-full-20261025');n=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-25-foundation-closeout');n.mkdir(exist_ok=True)
files=sorted(p for p in q.rglob('*') if p.is_file());manifest={str(p.relative_to(q)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(n/'full-e-core-study.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(q)),recursive=False)
with tarfile.open(n/'full-e-core-study.tar.gz','r:gz') as tar:
 assert {x.name:hashlib.sha256(tar.extractfile(x).read()).hexdigest() for x in tar.getmembers() if x.isfile()}==manifest
(n/'full-e-core-study-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
for a,b in [('full-verification.json','full-e-core-verification.json'),('study/diagnostics/report.md','full-e-core-counter-report.md'),('study/comparison/panel/audit.json','full-e-core-panel-audit.json')]:shutil.copy2(q/a,n/b)
(n/'roadmap-before-closeout.md').write_text(json.loads((r/'roadmap-before.json').read_text())['body']+'\n')
source=r/'csv-source';subprocess.run(['git','bundle','create',str(n/'measured-source.bundle'),'codex/cpu-operating-state-evidence','^962fd9ff4d155e5116baf6f177abfa3e84fd8754'],cwd=source,check=True);subprocess.run(['git','bundle','verify',str(n/'measured-source.bundle')],cwd=source,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print('Preserved and reverified',len(files),'files; archive bytes', (n/'full-e-core-study.tar.gz').stat().st_size)
