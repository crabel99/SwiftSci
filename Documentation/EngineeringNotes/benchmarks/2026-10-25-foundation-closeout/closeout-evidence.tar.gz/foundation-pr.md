## Problem and behavior

Compact floating-key grouping exports a complete optional column inside its row loop. Grouped numeric payloads and hash joins also export compact inputs unnecessarily. Separately, empty joins discard known column schema, and Core ML pipeline admission materializes identity row indices merely to inspect their capacity.

This change closes those supported data and ownership boundaries:

- Read compact grouping keys and numeric payloads by index while retaining grouping equality, first-seen order, and compensated reduction order.
- Probe compact Double join keys through the existing owning collection view. Preserve the direct optional-array specialization and all existing equality and traversal rules.
- Assemble typed columns for empty and disjoint joins, preserving payload suffixes and zero-row matrix preparation. Invalid-key checks still run first.
- Charge actual retained provenance capacity during pipeline admission. Implicit identity mappings have no retained row-index buffer. Selected indices still count against admission.
- Document native representations, compatibility copies, snapshots, precision conversion, asynchronous ownership, and estimated byte-budget limits in the foundation contract.

No public API, precision policy, scheduling layer, or numerical failure allowance is added or changed.

## Validation

Final validation head: `5cc699a7efe3f1d6a2697172eb62b94a35bc3a26`.

- All 1,656 native package tests pass in both Debug and Release across all 15 test targets, with zero failures or skips. MLX, strict ONNX prerequisites, and the pinned Llama tokenizer are included.
- All 226 benchmark-controller tests pass with Metal opt-in enabled and no skips.
- The complete CPU regression policy passes 404 Swift/Python executions with no new failures. Swift passes 202/202; Python passes 198/202. Its four reviewed Wampler failures remain failed conformance. Failure inventories and tolerances are unchanged.

Focused regressions fail on the prior empty-join implementation and pass after the change. Compact/optional grouping parity covers signed zeros, distinct NaN payloads, null groups, multiple keys, infinities, and cancellation-sensitive sums. Join tests cover both storage modes, all join kinds, empty inputs, NaNs, signed zeros, and missing keys. Pipeline accounting tests distinguish implicit identity provenance from retained selected indices and preserve rejection of insufficient allowances. Existing lifecycle tests cover cancellation, draining, and reservation release.

Independent standards and specification reviews report no actionable findings. New or changed test files are at most 105 lines. Changed files produce no long-type-check warnings under the 100 ms expression and 200 ms function diagnostic thresholds. Actual documentation coverage remains 2431/2464 declarations, unchanged from upstream. Hosted checks remain pending.

## Resource evidence and limits

The Release diagnostic reproduces repeated full-column expansion during compact grouping. The corrected path performs indexed reads. A million-row compact self-join no longer creates its two temporary optional input arrays. The recorded process peak RSS falls from about 95.1 MiB to 64.5 MiB in the focused diagnostic.

Those diagnostic timings were collected alongside correctness tests without P/E-core controls. They are not a qualified speed comparison. The separate full E-core panel retains its failed CPU and elapsed-time repeatability controls. Neither resource evidence nor a passing regression policy establishes full numerical conformance, universal leak freedom, an RSS cap, or guaranteed Neural Engine placement.

## Delivery order

Depends on #87. This branch includes its five CSV commits; review the additional foundation commits after `da03a630154843acee994c2e8b3af2924ee8b253`. Merge #87 first, then refresh this branch onto that merged base before final integration. Engineering notes, benchmark experiments, raw measurements, and decision records are excluded from this PR. Related roadmap: crabel99/SwiftSci#2.
