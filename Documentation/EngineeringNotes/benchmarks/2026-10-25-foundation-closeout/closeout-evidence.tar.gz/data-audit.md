# Foundation data audit

Audited `da03a63015` by tracing public dataframe callers into storage operations and reading their existing tests. Read-only review, no tests or benchmarks executed.

## Actionable findings

1. **Compact Double grouping reads an expanded column for every key.** `Sources/SwiftDataFrame/Core/GroupedDataFrame.swift:312-315` passes a callback that evaluates `typed.values[row]` for each input row. For dense storage, `TypedColumn.swift:27-35` constructs a complete optional array on each request. Public `frame.groupBy("key").count()`, `sum()`, and other aggregations reach this callback through `buildGroups`. This places full-column construction inside the row loop. Actual compiler elimination has not been measured. Replace the callback access with `typed[row]`, retaining `groupBits` normalization. Extend `StructuredGroupingTests.floatingKeysHaveExplicitEquality` with a compact fixture, a second grouping key, nil, distinct NaN payloads, signed zero, and first-seen order. A separate increasing-size allocation diagnostic should establish the resource correction without a timing threshold in unit tests.

2. **Compact numerical grouping and join inputs still expand once.** `GroupedDataFrame.swift:530-532` expands a compact Double payload before every `applyNumeric` call. `Sources/SwiftDataFrame/Core/DataFrame+SIMDJoin.swift:115-120` expands both compact key columns before hashing. These are internal native paths, not requests for the documented optional-array compatibility export. Reuse indexed column access or a collection-based internal kernel while preserving existing optional paths and hash/equality behavior. Existing join fixtures verify compact output but cannot detect these temporary inputs. Add compact/optional parity for grouped aggregation including all-null groups, valid NaN, infinities and cancellation-sensitive sums; retain existing join-kind tests and add signed-zero and NaN-key behavior. Inspect allocation behavior separately. Preserve current reduction order and compensation.

3. **Empty joins erase the known schema.** `DataFrame+SIMDJoin.swift:35-40` and `:52-53` return `DataFrame.empty`. Thus a disjoint public inner join discards its key and payload columns, and `prepareNumericMatrix` cannot consume the empty result because names disappear. `EmptySelectionSchemaTests` establishes schema preservation for selections but omits joins. Remove the schema-erasing early returns and assemble zero-length output columns through the normal path. Test disjoint inputs and both empty-input directions for every join kind, overlapping payload names, types, compact storage, null counts, and zero-row matrix preparation. Keep missing-key/type validation precedence.

## Already covered

- CSV optional/compact selection, explicit and inferred schema, serial/parallel conversion, eager/streaming consistency, native Int64 identity, nil versus valid NaN, signed-zero bits, and retry promotion have focused suites in `CSVDoubleStorageModeTests`, `CSVDoubleStorageInferenceTests`, and conversion tests.
- `CompactFilterTests` compares all six predicates with IEEE semantics and checks public compact output. `CompactSelectionTests` checks bitmap boundaries, duplicate/empty gathers, row association, sorting and shared numerical handoff.
- `CompactJoinTests` exercises every join kind, mixed storage, nullable payloads and key coalescing. It checks exact native integers and snapshot detachment after batch mutation.
- `CompactNumericConsumerTests`, `CompactMatrixPackingTests`, and prepared-matrix/provenance suites cover shared single-column storage, both layouts, repeated feature/row selections, selected-null rejection, valid NaNs, implicit row provenance and copy-on-write mutation.

## Intentional boundaries

`TypedColumn.values`, `PreparedNumericBatch.columnValues`, nested matrices, and generic map/fill/drop operations return legacy arrays. Their allocation is not itself a foundation defect. The direct public `TypedColumn.filtered(by:)` also returns optional storage, while dataframe predicate filters dispatch through compact-preserving gather. Document that distinction unless representation preservation is explicitly promised for the column mask API. No evidence here requires a new dtype system, general zero-copy API, or mathematical algorithm redesign.
