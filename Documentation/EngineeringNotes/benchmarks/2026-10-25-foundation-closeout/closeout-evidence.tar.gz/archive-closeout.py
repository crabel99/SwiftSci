from pathlib import Path
import hashlib,json,tarfile,re,shutil,subprocess
r=Path(__file__).resolve().parent;n=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-25-foundation-closeout')
skip={'csv-source','foundation-source','csv-worker','final-worker','foundation-worker','foundation-final-worker'};extensions={'.py','.sh','.swift','.md','.json','.jsonl','.tsv','.log','.txt'}
files=sorted(p for p in r.rglob('*') if p.is_file() and p.relative_to(r).parts[0] not in skip and not any(x.endswith('.xcresult') for x in p.relative_to(r).parts) and p.suffix in extensions)
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|glpat-[A-Za-z0-9_-]{16,}|-----BEGIN(?: [A-Z]+)? PRIVATE KEY-----)')
for p in files:assert not pattern.search(p.read_bytes()),'Potential credential in '+str(p.relative_to(r))
with tarfile.open(n/'full-e-core-study.tar.gz','r:gz') as tar:
 for member in tar.getmembers():
  if member.isfile():assert not pattern.search(tar.extractfile(member).read()),'Potential credential in study '+member.name
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(n/'closeout-evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(n/'closeout-evidence.tar.gz','r:gz') as tar:assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile()}==manifest
(n/'closeout-evidence-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['final-audit.json','diagnostic-summary.json','final-docs-and-size.json','final-evidence-review.md','decisions.tsv','foundation-standards-review.md','foundation-spec-review.md','csv-standards-review.md','csv-spec-review.md','roadmap-after.json']:
 shutil.copy2(r/name,n/name)
source=r/'foundation-source';bundle=n/'foundation-source.bundle';subprocess.run(['git','bundle','create',str(bundle),'codex/foundation-contract-closeout','^962fd9ff4d155e5116baf6f177abfa3e84fd8754'],cwd=source,check=True);subprocess.run(['git','bundle','verify',str(bundle)],cwd=source,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
(n/'sanitization.json').write_text(json.dumps({'potential_credentials_found':False,'patterns':'GitHub and GitLab token formats, PEM private-key headers','closeout_files':len(files),'full_study_files':757,'source_pr_engineering_notes_excluded':True},indent=2)+'\n')
checksums={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(n.iterdir()) if p.is_file() and p.name!='artifact-sha256.json'};(n/'artifact-sha256.json').write_text(json.dumps(checksums,indent=2)+'\n');print('Archived and rehashed',len(files),'closeout files. Compressed bytes:',(n/'closeout-evidence.tar.gz').stat().st_size)
