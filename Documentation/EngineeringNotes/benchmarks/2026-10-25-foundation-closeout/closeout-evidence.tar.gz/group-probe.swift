import Foundation
import Darwin
@testable import SwiftDataFrame

let rows = Int(CommandLine.arguments[1])!
let compact = CommandLine.arguments[2] == "compact"
let values: [Double] = (0..<rows).map { Double($0 % 17) }
let key: TypedColumn<Double> = compact
    ? TypedColumn(name: "key", compactColumn: CompactNumericColumn(values))
    : TypedColumn(name: "key", values: values)
let payload = TypedColumn<Double>(name: "value", values: Array(repeating: 1.0, count: rows))
let frame = try DataFrame(columns: [key, payload])
var before = rusage(); getrusage(RUSAGE_SELF, &before)
let start = DispatchTime.now().uptimeNanoseconds
let grouped = frame.groupBy("key").sum()
let wall = Double(DispatchTime.now().uptimeNanoseconds - start) / 1e6
var after = rusage(); getrusage(RUSAGE_SELF, &after)
func seconds(_ t: timeval) -> Double { Double(t.tv_sec) + Double(t.tv_usec) / 1e6 }
let cpu = 1000 * (seconds(after.ru_utime) + seconds(after.ru_stime) - seconds(before.ru_utime) - seconds(before.ru_stime))
let sum = grouped[column: "value", as: Double.self]!.values.compactMap { $0 }.reduce(0,+)
precondition(sum == Double(rows) && grouped.rowCount == 17)
print("{\"rows\":\(rows),\"compact\":\(compact),\"wall_ms\":\(wall),\"cpu_ms\":\(cpu),\"peak_rss_bytes\":\(after.ru_maxrss),\"sum\":\(sum)}")
