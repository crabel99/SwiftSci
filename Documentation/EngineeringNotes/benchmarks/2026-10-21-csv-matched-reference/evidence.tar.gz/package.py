from pathlib import Path
import hashlib,json,tarfile,re
R=Path(__file__).resolve().parent
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018/Documentation/EngineeringNotes/benchmarks/2026-10-21-csv-matched-reference')
assert json.loads((R/'verification.json').read_text())['passed']
files=[]
for p in R.rglob('*'):
 if not p.is_file() or 'module-cache' in p.relative_to(R).parts:continue
 if p.suffix not in ['.py','.swift','.json','.jsonl','.stderr','.txt','.log']:continue
 files.append(p)
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(N/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=N/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(R)),recursive=False)
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(manifest)
 for member in t:
  raw=t.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==manifest[member.name]
  content=raw.decode('utf-8',errors='replace')
  for pattern in [r'gh[pousr]_[A-Za-z0-9]{30,}',r'github_pat_[A-Za-z0-9_]{30,}',r'glpat-[A-Za-z0-9_-]{15,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']:
   assert not re.search(pattern,content),(member.name,'credential pattern')
for link in re.findall(r'\]\(([^)]+)\)',(N/'README.md').read_text()):
 if '://' not in link and not link.startswith('#'):assert (N/link.split('#')[0]).exists(),link
print(dict(files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),verified=True))
