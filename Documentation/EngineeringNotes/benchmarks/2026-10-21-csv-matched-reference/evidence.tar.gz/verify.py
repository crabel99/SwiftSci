from pathlib import Path
import hashlib,json,subprocess,statistics as st
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-date-format-20261021');D=R/'measurement'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((D/'plan.json').read_text());records=[json.loads(l) for l in (D/'workers.jsonl').read_text().splitlines()]
summary=json.loads((D/'summary.json').read_text())
assert plan['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
assert h(R/'python-probe.py')==plan['python_worker_sha256']==json.loads((R/'preflight-source.json').read_text())['python-probe.py']
assert h(R/'run.py')==plan['controller_sha256']
assert h(R/'ResourceProbe.swift')==plan['build']['harness_sha256']
assert h(R/'build/explicit/ResourceProbe')==plan['build']['binary_sha256']
for p,d in plan['build']['sources'].items():assert h(S/p)==d
for c in json.loads((R/'cases.json').read_text()):
 assert h(Path(c['path']))==c['sha256']
 for engine in plan['engines']:
  r=json.loads((R/'preflight'/(c['id']+'-'+engine+'.json')).read_text())
  assert r['validated'] and r['checks']['passed']
  assert [x['sha256'] for x in r['checks']['columns']]==c['hashes']
  assert [x['nulls'] for x in r['checks']['columns']]==c['null_counts']
expected={(c,e,r) for c in plan['cases'] for e in plan['engines'] for r in range(6)}
assert len(records)==len(expected)==96 and {(r['input'],r['engine'],r['round']) for r in records}==expected
assert plan['power_start']['source']==json.loads((D/'power-end.json').read_text())['source']=='AC'
for r in records:
 assert r['power']['source']=='AC'
 assert r['engine']==plan['orders'][r['round']][r['position']]
 assert r['validated'] and r['checks']['passed']
 c=plan['inputs'][r['input']]
 assert [x['sha256'] for x in r['checks']['columns']]==c['hashes']
 assert [x['nulls'] for x in r['checks']['columns']]==c['null_counts']
 assert len(r['samples'])==1
 s=r['samples'][0]
 assert s['total_ns']==s['call_ns']+s['release_ns']>0
 assert s['total_cpu_ns']==s['call_cpu_ns']+s['release_cpu_ns']>0
 assert s['rss_held_delta_bytes']==s['rss_held_bytes']-s['rss_before_bytes']
 assert s['process_peak_held_bytes']>=s['process_peak_before_bytes']>0
assert summary['records_sha256']==h(D/'workers.jsonl')
for row in summary['rows']:
 group=[r for r in records if r['input']==row['case'] and r['engine']==row['engine']]
 for key,values in row['metrics'].items():
  samples=[r['samples'][0][key] for r in group]
  assert values==dict(median=st.median(samples),minimum=min(samples),maximum=max(samples))
 for other,metrics in row['ratios'].items():
  for key,values in metrics.items():
   ratios=[next(r['samples'][0][key] for r in records if r['input']==row['case'] and r['engine']==row['engine'] and r['round']==i)/next(r['samples'][0][key] for r in records if r['input']==row['case'] and r['engine']==other and r['round']==i) for i in range(6)]
   assert values==dict(median=st.median(ratios),minimum=min(ratios),maximum=max(ratios),ratios=ratios)
result=dict(passed=True,head=plan['head'],preflight_workers=56,measurement_workers=96,all_values_and_nulls_verified=True,records_sha256=summary['records_sha256'],power='AC',scope='Matched-schema fresh-process first-read CSV comparison; native CPU parallelism')
(R/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
