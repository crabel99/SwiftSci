from pathlib import Path
import csv,json
R=Path(__file__).resolve().parent
c=json.loads((R/'inputs/energy-date-full.json').read_text());seen=set();runs=0;previous=None;count=0
with Path(c['path']).open(newline='',encoding='utf-8') as f:
 reader=csv.reader(f,delimiter=';');next(reader)
 for row in reader:
  count+=1;value=row[0];seen.add(value)
  if value!=previous:runs+=1;previous=value
assert count==c['rows']
data=dict(rows=count,distinct_date_strings=len(seen),consecutive_date_runs=runs,adjacent_repeats=count-runs,adjacent_repeat_fraction=(count-runs)/count,input_sha256=c['sha256'])
(R/'date-characteristics.json').write_text(json.dumps(data,indent=2)+'\n');print(data)
