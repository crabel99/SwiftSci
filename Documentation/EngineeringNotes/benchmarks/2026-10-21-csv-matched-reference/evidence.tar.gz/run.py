from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-date-format-20261021')
sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,PRODUCTION_MODE,policy
from runner import environment,power_state,verify_uninstrumented
P='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
preflight=json.loads((R/'preflight-summary.json').read_text());assert not preflight['failures'] and preflight['workers']==56
build=json.loads((R/'build/explicit/build.json').read_text());binary=R/'build/explicit/ResourceProbe'
assert h(binary)==build['binary_sha256'];verify_uninstrumented(binary)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='a5f6e78a751365ec360efdd4ae8f028db04b441b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
for f,d in build['sources'].items():assert h(S/f)==d
cases=['energy','Aotizhongxin','Wanliu','energy-date-full']
engines=['swiftsci','pandas','polars','duckdb']
# Three cyclic orders and their reverses balance each pair's relative position.
orders=[engines[i:]+engines[:i] for i in range(3)]
orders+= [list(reversed(order)) for order in orders.copy()]
for a in engines:
 for b in engines:
  if a!=b:assert sum(order.index(a)<order.index(b) for order in orders)==3
inputs={c:json.loads((R/'inputs'/(c+'.json')).read_text()) for c in cases}
for c in inputs.values():assert h(Path(c['path']))==c['sha256']
power=power_state();assert power['source']=='AC',power
out=R/'measurement';out.mkdir(exist_ok=False)
plan=dict(head=head,build=build,python_worker_sha256=h(R/'python-probe.py'),controller_sha256=h(Path(__file__)),inputs=inputs,cases=cases,engines=engines,orders=orders,power_start=power,environment=environment(),execution_policy=policy(PRODUCTION_MODE),rounds=6,reads_per_worker=1,process='fresh',io_cache='Explicit file read outside each round; normal OS file cache, not cold-storage I/O',scope='Prepared library runtime; one eager public CSV read plus output release. Exact canonical validation excluded. Memory captured before validation. DuckDB includes Arrow materialization; Polars includes explicit date conversion; pandas uses C round-trip float parser and date cache.')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'workers.jsonl').open('x') as f:
 for ci,name in enumerate(cases):
  for rnd,order in enumerate(orders):
   state=power_state();assert state['source']=='AC',state
   with Path(inputs[name]['path']).open('rb') as source:
    while source.read(1024*1024):pass
   for pos,engine in enumerate(order):
    args=[str(binary),str(R/'inputs'/(name+'.json')),'known','fresh','1'] if engine=='swiftsci' else [P,str(R/'python-probe.py'),engine,str(R/'inputs'/(name+'.json'))]
    start=time.time();p=subprocess.run(args,env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=300)
    (out/(name+'-'+str(rnd)+'-'+engine+'.stderr')).write_text(p.stderr)
    assert p.returncode==0,(name,engine,p.stderr[-1000:])
    data=json.loads(p.stdout)
    assert data['validated'] and data['checks']['passed'],(name,engine,data['checks'])
    oracle=inputs[name]
    assert [c['sha256'] for c in data['checks']['columns']]==oracle['hashes']
    assert [c['nulls'] for c in data['checks']['columns']]==oracle['null_counts']
    assert len(data['samples'])==1
    data.update(engine=engine,round=rnd,position=pos,process_seconds=time.time()-start,power=state)
    f.write(json.dumps(data)+'\n');f.flush()
    sample=data['samples'][0]
    print(name,rnd,engine,round(sample['total_ns']/1e6,2),'ms',round(sample['total_cpu_ns']/1e6,2),'CPUms',flush=True)
end=power_state();assert end['source']=='AC';(out/'power-end.json').write_text(json.dumps(end,indent=2)+'\n')
print('Complete: 96 validated fresh-process workers',flush=True)
