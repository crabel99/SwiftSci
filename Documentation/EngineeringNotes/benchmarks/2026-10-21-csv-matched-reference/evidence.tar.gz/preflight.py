from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/swiftsci-csv-date-format-20261021/Benchmarks/Tools')
from execution_policy import worker_environment,PRODUCTION_MODE
P='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
cases=json.loads((R/'cases.json').read_text());D=R/'preflight';D.mkdir(exist_ok=True)
failures=[]
for c in cases:
 for engine in ['pandas','polars','duckdb','swiftsci']:
  name=c['id']+'-'+engine
  if (D/(name+'.json')).exists():
   d=json.loads((D/(name+'.json')).read_text())
   if not d['validated']:failures.append(name)
   continue
  args=[str(R/'build/explicit/ResourceProbe'),str(R/'inputs'/(c['id']+'.json')),'known','audit','1'] if engine=='swiftsci' else [P,str(R/'python-probe.py'),engine,str(R/'inputs'/(c['id']+'.json'))]
  p=subprocess.run(args,env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=300)
  (D/(name+'.stderr')).write_text(p.stderr)
  if p.returncode:
   print(name,'ERROR',p.stderr[-1000:],flush=True);failures.append(name);continue
  d=json.loads(p.stdout);(D/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
  if not d['validated']:failures.append(name)
  print(name,'PASS' if d['validated'] else d['checks']['failures'],flush=True)
(R/'preflight-summary.json').write_text(json.dumps(dict(workers=len(cases)*4,failures=failures),indent=2)+'\n')
assert not failures,failures
