from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parent;D=Path('/private/tmp/swiftsci-csv-date-checks-20261021/reference');old=Path('/private/tmp/swiftsci-csv-reference-20261021')
(R/'inputs').mkdir(exist_ok=True)
cases=json.loads((old/'cases.json').read_text())+[json.loads((D/'full.json').read_text())]
for c in cases:(R/'inputs'/(c['id']+'.json')).write_text(json.dumps(c,indent=2)+'\n')
(R/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
shutil.copy(D/'build.py',R/'build.py');shutil.copy(D/'variants.json',R/'variants.json')
s=(D/'ResourceProbe.swift').read_text();s=s.replace('func heap() -> Int64 {','''func resident() -> Int64 {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<integer_t>.size)
    let result = withUnsafeMutablePointer(to: &info) { pointer in
        pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    precondition(result == KERN_SUCCESS)
    return Int64(info.resident_size)
}
func heap() -> Int64 {''')
s=s.replace('let h0 = heap(), p0 = peak(), c0 = cpu()', 'let h0 = heap(), p0 = peak(), r0 = resident(), c0 = cpu()')
s=s.replace('h1 = heap(), p1 = peak()', 'h1 = heap(), p1 = peak(), r1 = resident()')
s=s.replace('"heap_before_bytes":h0,', '"rss_before_bytes":r0,"rss_held_bytes":r1,"rss_held_delta_bytes":r1-r0,"rss_after_release_bytes":resident(),"heap_before_bytes":h0,')
(R/'ResourceProbe.swift').write_text(s)
