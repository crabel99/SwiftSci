from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
h=lambda x:hashlib.sha256(x.encode()).hexdigest()
def parse(path):
 out={};name=None;body=[]
 for line in path.read_text().splitlines():
  if line and not line[0].isspace() and line.endswith(':') and not re.match(r'^[0-9a-f]{16}\t',line):
   if name and body:out[name]=body
   name=line[:-1];body=[]
  elif re.match(r'^[0-9a-f]{16}\t',line):
   address,text=line.split('\t',1);body.append((int(address,16),text))
 if name and body:out[name]=body
 return out
all_bodies={label:parse(R/(label+'-disassembly.txt')) for label in ['parent','candidate']}
def normalized(body):
 start=body[0][0];end=body[-1][0]+4;lines=[]
 for address,text in body:
  op=text.split('\t',1)[0]
  if op=='adrp':text=re.sub(r' ; 0x[0-9a-f]+$','',text)
  if op in ['b','bl','cbz','cbnz','tbz','tbnz'] or op.startswith('b.'):
   text=re.sub(r'0x([0-9a-f]+)',lambda m:'@'+str(int(m[1],16)-start) if start<=int(m[1],16)<end else m[0],text)
  lines.append(text)
 return '\n'.join(lines)
rows=[]
for name in sorted(set(all_bodies['parent'])|set(all_bodies['candidate'])):
 if not any(x in name for x in ['CSV','sortedDoubleRows','prepareDoubleSortKeys','prepareNumericMatrix','gathered','sortIndicesDouble']):continue
 entry={'symbol':name}
 for label in ['parent','candidate']:
  body=all_bodies[label].get(name)
  entry[label]=None if body is None else {'instructions':len(body),'normalized_sha256':h(normalized(body))}
 entry['identical_after_normalizing_internal_branch_targets']=entry['parent']==entry['candidate']
 rows.append(entry)
result={'normalization':'Remove leading instruction addresses; convert numeric branch targets within the same symbol to function-relative offsets. Remove the disassembler-computed ADRP page-address comment, while retaining its actual operands. Keep all other opcodes, operands, and comments. This comparison does not measure cache, scheduling, or linked-address effects.','routines':rows}
(R/'code-inspection.json').write_text(json.dumps(result,indent=2)+'\n')
for term in ['sortedDoubleRows','prepareDoubleSortKeys','prepareNumericMatrix']:
 print(term)
 for x in rows:
  if term in x['symbol']:print(json.dumps(x))
csv=[x for x in rows if 'CSV' in x['symbol']];matched=[x for x in csv if x['parent'] and x['candidate']]
print('CSV matched symbols',len(matched),'identical normalized bodies',sum(x['identical_after_normalizing_internal_branch_targets'] for x in matched),'unmatched',len(csv)-len(matched))
changed=[x for x in matched if not x['identical_after_normalizing_internal_branch_targets']]
for x in changed[:5]:print('changed',json.dumps(x))
