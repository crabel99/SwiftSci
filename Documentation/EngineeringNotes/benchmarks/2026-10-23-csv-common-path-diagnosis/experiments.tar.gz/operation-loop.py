from pathlib import Path
import hashlib,itertools,json,statistics,subprocess,time
R=Path(__file__).resolve().parent;D=R/'operation-live';D.mkdir(exist_ok=False)
A=Path('/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023');I=Path('/private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=['parent','parent_twin','candidate','candidate_twin'];base=[0,1,3,2]
first=[[labels[(x+shift)%4] for x in base] for shift in range(4)];orders=first+[list(reversed(x)) for x in reversed(first)]
binaries={label:R/(('parent' if label.startswith('parent') else 'candidate')+'-operation') for label in labels}
cases=[('optional','sort-matrix'),('compact','sort-indices')]
plan={'controller_sha256':h(Path(__file__)),'binaries':{k:h(v) for k,v in binaries.items()},'input_contract_sha256':h(I),'orders':orders,'cases':cases,'iterations_per_worker':6,'quality_policy':{'cpu_twin_deviation':.10,'peak_twin_relative':1.05,'peak_twin_slack_bytes':8*2**20},'scope':'Diagnostic reuse of caller-retained input, not full CSV workflow or production baseline'}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');expected=json.loads((A/'preflight/expectations.json').read_text())
subprocess.run(['pmset','-g','batt'],stdout=(D/'power.txt').open('w'),check=True);assert 'AC Power' in (D/'power.txt').read_text()
rows=[]
with (D/'workers.jsonl').open('w') as out:
 for storage,workflow in cases:
  key=f'energy-common/serial/{storage}/{workflow}';reference=None
  for turn,order in enumerate(orders):
   for position,label in enumerate(order):
    start=time.time();x=json.loads(subprocess.check_output([str(binaries[label]),str(I),workflow,'serial',storage],text=True,timeout=60))
    assert x['input_validated'] and len(x['samples'])==6 and len(set(x['fingerprints']))==1
    for k in ['frame','matrix_sha256','selection_sha256']:assert x[k]==expected[key][k],(key,k)
    if reference is None:reference=x['fingerprints']
    assert x['fingerprints']==reference
    x.update(case=key,engine=label,round=turn,position=position,worker_seconds=time.time()-start)
    out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();rows.append(x)
   print(key,'round',turn+1,'/ 8',flush=True)
subprocess.run(['pmset','-g','batt'],stdout=(D/'power-end.txt').open('w'),check=True);assert 'AC Power' in (D/'power-end.txt').read_text()
summary=[];flags=[]
for case in sorted({x['case'] for x in rows}):
 group=[x for x in rows if x['case']==case]
 med={label:{metric:statistics.median(statistics.median(sample[metric] for sample in x['samples']) for x in group if x['engine']==label) for metric in ['total_cpu_ns','operations_cpu_ns','process_peak_held_bytes','heap_after_release_bytes']} for label in labels}
 for left,right in [('parent','parent_twin'),('candidate','candidate_twin')]:
  ratio=med[right]['total_cpu_ns']/med[left]['total_cpu_ns']
  if abs(ratio-1)>.10:flags.append({'case':case,'labels':[left,right],'reason':'identical-binary CPU','ratio':ratio})
  for x,y in [(med[left],med[right]),(med[right],med[left])]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':case,'labels':[left,right],'reason':'identical-binary peak'})
 phases={}
 for metric in ['total_cpu_ns','operations_cpu_ns']:
  role={name:[statistics.median(statistics.median(sample[metric] for sample in x['samples']) for x in group if x['engine'].startswith(name) and x['round']==turn) for turn in range(8)] for name in ['parent','candidate']}
  ratios=[c/p for p,c in zip(role['parent'],role['candidate'])]
  phases[metric]={'parent_median_ms':statistics.median(role['parent'])/1e6,'candidate_median_ms':statistics.median(role['candidate'])/1e6,'paired_median_ratio':statistics.median(ratios),'positive_pairs':sum(x>1 for x in ratios),'adverse_direction_7_of_8':sum(x>1 for x in ratios)>=7}
 summary.append({'case':case,'phases':phases,'per_label':med})
result={'workers':len(rows),'public_operations':len(rows)*6,'all_outputs_match_frozen_full_path_contracts':True,'quality_flags':flags,'cases':summary,'scope':plan['scope']}
(D/'decision.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
