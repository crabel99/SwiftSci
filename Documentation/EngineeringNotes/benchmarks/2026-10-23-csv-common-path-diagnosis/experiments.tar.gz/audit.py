from pathlib import Path
from collections import Counter
import hashlib,itertools,json,statistics,subprocess
R=Path(__file__).resolve().parent;A=Path('/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023');S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()=='940353d441c5b2b1bcec69344629452b4ac65b7c'
assert subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()==''
expect=json.loads((A/'preflight/expectations.json').read_text());labels=['parent','parent_twin','candidate','candidate_twin'];counts={};tables=[];heap_rows=[]
for name in ['live-1','live-2','operation-live']:
 D=R/name;plan=json.loads((D/'plan.json').read_text());controller=R/('operation-loop.py' if name=='operation-live' else 'loop.py');assert plan['controller_sha256']==h(controller)
 orders=plan['orders']
 for label in labels:assert Counter(order.index(label) for order in orders)==Counter({n:2 for n in range(4)})
 assert Counter((a,b) for order in orders for a,b in zip(order,order[1:]))==Counter({x:2 for x in itertools.permutations(labels,2)})
 for label in labels:
  binary=(R/(('parent' if label.startswith('parent') else 'candidate')+'-operation') if name=='operation-live' else A/('prior-workflow' if label.startswith('parent') else 'current-workflow'))
  assert plan['binaries'][label]==h(binary)
 rows=[json.loads(x) for x in (D/'workers.jsonl').read_text().splitlines()];assert len(rows)==64;counts[name]=len(rows)
 for x in rows:
  assert orders[x['round']][x['position']]==x['engine']
  keys=['frame','matrix_sha256','selection_sha256'] if name=='operation-live' else ['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']
  for key in keys:assert x[key]==expect[x['case']][key]
  if name=='operation-live':
   assert x['input_validated'] and len(set(x['fingerprints']))==1 and len(x['fingerprints'])==len(x['samples'])==6
   heap_rows.append({'case':x['case'],'engine':x['engine'],'round':x['round'],'post_release_bytes':[s['heap_after_release_bytes'] for s in x['samples']],'retained_measurement_metadata':True})
 for power in ['power.txt','power-end.txt']:assert 'AC Power' in (D/power).read_text()
 decision=json.loads((D/'decision.json').read_text());assert decision['quality_flags']==[]
 for case in sorted({x['case'] for x in rows}):
  group=[x for x in rows if x['case']==case];assert all(sum(x['engine']==label for x in group)==8 for label in labels)
  if name=='operation-live':assert len({tuple(x['fingerprints']) for x in group})==1
  for metric in ['total_cpu_ns','operations_cpu_ns']:
   values={role:[statistics.median((statistics.median(s[metric] for s in x['samples']) if name=='operation-live' else x['samples'][0][metric]) for x in group if x['engine'].startswith(role) and x['round']==turn) for turn in range(8)] for role in ['parent','candidate']}
   ratios=[c/p for p,c in zip(values['parent'],values['candidate'])]
   rec={'study':name,'case':case,'metric':metric,'parent_median_ms':statistics.median(values['parent'])/1e6,'candidate_median_ms':statistics.median(values['candidate'])/1e6,'paired_median_ratio':statistics.median(ratios),'positive_pairs':sum(r>1 for r in ratios)}
   declared=next(c for c in decision['cases'] if c['case']==case)['phases'][metric]
   for key in ['parent_median_ms','candidate_median_ms','paired_median_ratio','positive_pairs']:assert rec[key]==declared[key]
   tables.append(rec)
for label in ['parent','candidate']:
 receipt=json.loads((R/(label+'-operation-build.json')).read_text());assert receipt['source_sha256']==h(R/'OperationProbe.swift') and receipt['binary_sha256']==h(R/(label+'-operation'))
 module=A/'build' if label=='candidate' else Path('/private/tmp/swiftsci-csv-lazy-sort-cache-20261023/build');assert receipt['verified_module']==str(module/'SwiftDataFrame.swiftmodule')
 for kind in ['o','swiftmodule']:
  assert h(module/('SwiftDataFrame.'+kind))==json.loads((A/'comparator-provenance.json').read_text())['current' if label=='candidate' else 'prior']['object_sha256' if kind=='o' else 'module_sha256']
code=json.loads((R/'code-inspection.json').read_text());csv=[x for x in code['routines'] if 'CSV' in x['symbol']];assert len(csv)==428 and all(x['identical_after_normalizing_internal_branch_targets'] for x in csv)
for word in ['sortedDoubleRows','prepareNumericMatrix']:
 assert all(x['identical_after_normalizing_internal_branch_targets'] for x in code['routines'] if word in x['symbol'])
(R/'phase-comparisons.json').write_text(json.dumps(tables,indent=2)+'\n');(R/'release-heap.json').write_text(json.dumps(heap_rows,indent=2)+'\n')
result={'source_head':'940353d441c5b2b1bcec69344629452b4ac65b7c','parent_head':'b982028c59c89f615688882ee71be19a0eccd8f2','new_source_changes':False,'new_test_runs':False,'workers':counts,'total_workers':sum(counts.values()),'reused_public_operations':384,'exact_outputs_match':True,'balanced_orders_verified':True,'all_quality_flags':[],'csv_matched_normalized_bodies':428,'common_row_sorter_and_matrix_normalized_bodies_match':True,'code_change_warranted':False,'causal_diagnosis':'Earlier operation-level slowdown did not repeat consistently. No additional shared-kernel instructions or different post-release heap growth established. Small full-path CPU differences and linked-layout effects remain unresolved.','prior_full_panel_results_replaced':False}
(R/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
print('One worker post-release heap:',heap_rows[0]['post_release_bytes'])
