from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;A=Path('/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023');F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
prefix=(A/'WorkflowProbe.swift').read_text().split('@MainActor @main struct WorkflowProbe {')[0]
main='''@MainActor @main struct OperationProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: args[0])))
        let workflow = args[1], storage = args[3]
        var options = CSVReadOptions()
        options.doubleStorage = storage == "compact" ? .compact : .optional
        options.delimiter = Character(input.delimiter)
        options.nullValues = Set(input.null_tokens)
        options.columnConversionMode = .serial
        let types: [String: ColumnDType] = ["String": .utf8, "Double": .float64, "Int64": .int64]
        options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names, input.types).map { ($0.0, types[$0.1]!) })
        let source = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)
        let sourceCheck = validate(source, input: input, mode: "known")
        precondition(sourceCheck["passed"] as? Bool == true)
        let numeric = zip(input.names, input.types).filter { $0.1 == "Double" || $0.1 == "Int64" }.map { $0.0 }
        let column = source[column: "Global_active_power", as: Double.self]!
        let beforeHeap = heap()
        var samples = [[String: Int64]](), fingerprints = [String]()
        var finalFrame: [String: Any] = [:]
        var matrixContract = "absent", selectionContract = "absent"
        for iteration in 0..<6 {
            let c0 = cpu()
            var output: DataFrame?
            var matrix: PreparedNumericMatrix?
            var indices: [Int]?
            if workflow == "sort-matrix" {
                output = try source.sortBy("Global_active_power")
                matrix = try output!.prepareNumericMatrix(numeric)
            } else {
                indices = column.sortedIndices(ascending: true)
            }
            let c1 = cpu(), heldHeap = heap(), heldPeak = peak()
            let digest: String
            if let matrix {
                digest = matrix.values.withUnsafeBytes { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() }
            } else {
                digest = indices!.withUnsafeBytes { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() }
            }
            if iteration == 5 {
                finalFrame = fingerprint(output ?? source)
                if let matrix {
                    var d = Digest()
                    for value in matrix.values { d.append(Optional(value)) { $0.integer($1.bitPattern) } }
                    matrixContract = d.finish()
                }
                if let indices {
                    var d = Digest()
                    for value in indices { d.append(Optional(Int64(value))) { $0.integer($1) } }
                    selectionContract = d.finish()
                }
            }
            fingerprints.append(digest)
            let c2 = cpu()
            output = nil; matrix = nil; indices = nil
            let c3 = cpu()
            samples.append(["operations_cpu_ns": c1-c0, "total_cpu_ns": c1-c0+c3-c2,
                            "held_heap_bytes": heldHeap, "heap_after_release_bytes": heap(),
                            "process_peak_held_bytes": heldPeak])
        }
        withExtendedLifetime(source) {}
        precondition(Set(fingerprints).count == 1)
        let result: [String: Any] = ["frame": finalFrame, "fingerprints": fingerprints,
            "samples": samples, "matrix_sha256": matrixContract, "selection_sha256": selectionContract, "input_validated": true, "heap_before_bytes": beforeHeap,
            "scope": "Six public operations with caller-retained input. CSV load and input validation excluded. Complete numeric or index bytes verified each iteration, final dataframe verified in full. Release CPU included, verification excluded. Diagnostic reuse workload, not a full-path replacement."]
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    }
}
'''
source=R/'OperationProbe.swift';source.write_text(prefix+main)
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('parent',Path('/private/tmp/swiftsci-csv-lazy-sort-cache-20261023/build')),('candidate',A/'build')]:
 cmd=[x.replace(str(F),str(D)) for x in base]
 cmd=[str(source) if x.endswith('/ResourceProbe.swift') else str(R/(label+'-operation')) if x==str(D/'ResourceProbe') else x for x in cmd]+['-Rmodule-loading']
 with (R/(label+'-operation-build.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 text=(R/(label+'-operation-build.log')).read_text();loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",text));assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-operation-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((R/(label+'-operation')).read_bytes()).hexdigest()},indent=2)+'\n')
 print(label,'operation client built',flush=True)
