import Foundation
import SwiftDataFrame
import Darwin
import CryptoKit

struct Input: Decodable {
    let id: String, path: String, delimiter: String
    let rows: Int
    let names: [String], types: [String], hashes: [String]
    let null_tokens: [String]
    let integral: [Bool]
    let max_rows: Int?
    let date_formats: [String: String]?
}
func cpu() -> Int64 {
    var r = rusage(); getrusage(RUSAGE_SELF, &r)
    return Int64(r.ru_utime.tv_sec + r.ru_stime.tv_sec) * 1_000_000_000 + Int64(r.ru_utime.tv_usec + r.ru_stime.tv_usec) * 1_000
}
func resident() -> Int64 {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<integer_t>.size)
    let result = withUnsafeMutablePointer(to: &info) { pointer in
        pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    precondition(result == KERN_SUCCESS)
    return Int64(info.resident_size)
}
func heap() -> Int64 {
    var s = malloc_statistics_t(); malloc_zone_statistics(nil, &s)
    return Int64(s.size_in_use)
}
func peak() -> Int64 { var r = rusage(); getrusage(RUSAGE_SELF, &r); return Int64(r.ru_maxrss) }
struct Digest {
    var hash = SHA256(), buffer = Data(), nulls = 0
    mutating func integer<T: FixedWidthInteger>(_ value: T) {
        var value = value.littleEndian
        withUnsafeBytes(of: &value) { buffer.append(contentsOf: $0) }
    }
    mutating func append<T>(_ value: T?, encode: (inout Digest, T) -> Void) {
        if let value { buffer.append(1); encode(&self, value) }
        else { buffer.append(0); nulls += 1 }
        if buffer.count >= 65536 { hash.update(data: buffer); buffer.removeAll(keepingCapacity: true) }
    }
    mutating func finish() -> String {
        hash.update(data: buffer)
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
func validate(_ df: DataFrame, input: Input, mode: String) -> [String: Any] {
    var failures = [String](), details = [[String: Any]]()
    if df.shape.rows != input.rows { failures.append("row count") }
    if df.columnNames != input.names { failures.append("column names/order") }
    for (j, name) in input.names.enumerated() {
        let type = df.dtypes[name]?.description ?? "absent"
        let expected = input.types[j]
        let allowed = type == expected || (mode == "infer" && expected == "Double" && type == "Int64" && input.integral[j])
        if !allowed { failures.append("type: \(name): \(type), expected \(expected)") }
        var d = Digest()
        switch type {
        case "Double":
            let c = df[column: name, as: Double.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer($1.bitPattern) } }
        case "Int64":
            let c = df[column: name, as: Int64.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer(Double($1).bitPattern) } }
        case "String":
            let c = df[column: name, as: String.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { digest, value in
                digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
            } }
        case "Bool":
            let c = df[column: name, as: Bool.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer(UInt8($1 ? 1 : 0)) } }
        case "Date":
            let c = df[column: name, as: Date.self]!
            for i in 0..<df.shape.rows { d.append(c[i]) { $0.integer($1.timeIntervalSince1970.bitPattern) } }
        default: failures.append("unsupported output: \(name): \(type)")
        }
        let actual = d.finish()
        if actual != input.hashes[j] { failures.append("values/nulls: \(name)") }
        details.append(["name":name,"type":type,"nulls":d.nulls,"sha256":actual])
    }
    return ["passed":failures.isEmpty,"failures":failures,"columns":details]
}

func fingerprint(_ df: DataFrame) -> [String: Any] {
    var columns = [[String: Any]]()
    for name in df.columnNames {
        var d = Digest()
        let type = df.dtypes[name]!.description
        switch type {
        case "Double":
            let c = df[column: name, as: Double.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1.bitPattern) } }
        case "Int64":
            let c = df[column: name, as: Int64.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { $0.integer($1) } }
        case "String":
            let c = df[column: name, as: String.self]!
            for row in 0..<df.rowCount { d.append(c[row]) { digest, value in
                digest.integer(UInt32(value.utf8.count)); digest.buffer.append(contentsOf: value.utf8)
            } }
        default: preconditionFailure("Unsupported fixture type")
        }
        columns.append(["name": name, "type": type, "nulls": d.nulls, "sha256": d.finish()])
    }
    return ["rows": df.rowCount, "columns": columns]
}
@MainActor @main struct OperationProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: args[0])))
        let workflow = args[1], storage = args[3]
        var options = CSVReadOptions()
        options.doubleStorage = storage == "compact" ? .compact : .optional
        options.delimiter = Character(input.delimiter)
        options.nullValues = Set(input.null_tokens)
        options.columnConversionMode = .serial
        let types: [String: ColumnDType] = ["String": .utf8, "Double": .float64, "Int64": .int64]
        options.columnTypeOverrides = Dictionary(uniqueKeysWithValues: zip(input.names, input.types).map { ($0.0, types[$0.1]!) })
        let source = try await DataFrame(csv: URL(fileURLWithPath: input.path), options: options)
        let sourceCheck = validate(source, input: input, mode: "known")
        precondition(sourceCheck["passed"] as? Bool == true)
        let numeric = zip(input.names, input.types).filter { $0.1 == "Double" || $0.1 == "Int64" }.map { $0.0 }
        let column = source[column: "Global_active_power", as: Double.self]!
        let beforeHeap = heap()
        var samples = [[String: Int64]](), fingerprints = [String]()
        var finalFrame: [String: Any] = [:]
        var matrixContract = "absent", selectionContract = "absent"
        for iteration in 0..<6 {
            let c0 = cpu()
            var output: DataFrame?
            var matrix: PreparedNumericMatrix?
            var indices: [Int]?
            if workflow == "sort-matrix" {
                output = try source.sortBy("Global_active_power")
                matrix = try output!.prepareNumericMatrix(numeric)
            } else {
                indices = column.sortedIndices(ascending: true)
            }
            let c1 = cpu(), heldHeap = heap(), heldPeak = peak()
            let digest: String
            if let matrix {
                digest = matrix.values.withUnsafeBytes { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() }
            } else {
                digest = indices!.withUnsafeBytes { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() }
            }
            if iteration == 5 {
                finalFrame = fingerprint(output ?? source)
                if let matrix {
                    var d = Digest()
                    for value in matrix.values { d.append(Optional(value)) { $0.integer($1.bitPattern) } }
                    matrixContract = d.finish()
                }
                if let indices {
                    var d = Digest()
                    for value in indices { d.append(Optional(Int64(value))) { $0.integer($1) } }
                    selectionContract = d.finish()
                }
            }
            fingerprints.append(digest)
            let c2 = cpu()
            output = nil; matrix = nil; indices = nil
            let c3 = cpu()
            samples.append(["operations_cpu_ns": c1-c0, "total_cpu_ns": c1-c0+c3-c2,
                            "held_heap_bytes": heldHeap, "heap_after_release_bytes": heap(),
                            "process_peak_held_bytes": heldPeak])
        }
        withExtendedLifetime(source) {}
        precondition(Set(fingerprints).count == 1)
        let result: [String: Any] = ["frame": finalFrame, "fingerprints": fingerprints,
            "samples": samples, "matrix_sha256": matrixContract, "selection_sha256": selectionContract, "input_validated": true, "heap_before_bytes": beforeHeap,
            "scope": "Six public operations with caller-retained input. CSV load and input validation excluded. Complete numeric or index bytes verified each iteration, final dataframe verified in full. Release CPU included, verification excluded. Diagnostic reuse workload, not a full-path replacement."]
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    }
}
