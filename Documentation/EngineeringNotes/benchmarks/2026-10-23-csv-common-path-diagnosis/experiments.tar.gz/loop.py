from pathlib import Path
import argparse,hashlib,json,statistics,subprocess,time
R=Path(__file__).resolve().parent
A=Path('/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023')
I=Path('/private/tmp/swiftsci-csv-external-20261023/inputs/energy-common.json')
p=argparse.ArgumentParser();p.add_argument('mode',choices=['replay','run']);p.add_argument('--label',default='live-1');a=p.parse_args()
keys=['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if a.mode=='replay':
 rows=[json.loads(x) for x in (A/'measurement/workers.jsonl').read_text().splitlines()]
 rows=[x for x in rows if x['case'] in ['energy-common/serial/optional/sort-matrix','energy-common/serial/compact/sort-indices'] and x['engine'] in ['prior','current','twin']]
 labels=['prior','current','twin'];parent=['prior'];candidate=['current','twin'];D=R/'replay';D.mkdir(exist_ok=True)
else:
 D=R/a.label;D.mkdir(exist_ok=False);labels=['parent','parent_twin','candidate','candidate_twin'];parent=labels[:2];candidate=labels[2:]
 binaries={label:A/('prior-workflow' if label in parent else 'current-workflow') for label in labels}
 base=[0,1,3,2];first=[[labels[(x+shift)%4] for x in base] for shift in range(4)];orders=first+[list(reversed(x)) for x in reversed(first)]
 cases=[('optional','sort-matrix'),('compact','sort-indices')]
 plan={'controller_sha256':h(Path(__file__)),'binaries':{k:h(v) for k,v in binaries.items()},'input_contract_sha256':h(I),'orders':orders,'cases':cases,'quality_policy':{'cpu_twin_deviation':.10,'peak_twin_relative':1.05,'peak_twin_slack_bytes':8*2**20},'role':'diagnostic confirmation, not replacement of the full panel'}
 (D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power.txt').open('w'),check=True);assert 'AC Power' in (D/'power.txt').read_text()
 rows=[]
 with (D/'workers.jsonl').open('w') as out:
  for storage,workflow in cases:
   expected=None;case=f'energy-common/serial/{storage}/{workflow}'
   for turn,order in enumerate(orders):
    for position,label in enumerate(order):
     start=time.time();x=json.loads(subprocess.check_output([str(binaries[label]),str(I),workflow,'serial',storage],text=True,timeout=45));fp={k:x[k] for k in keys}
     if expected is None:expected=fp
     assert fp==expected
     x.update(case=case,engine=label,round=turn,position=position,worker_seconds=time.time()-start)
     out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();rows.append(x)
    print(case,'round',turn+1,'/ 8',flush=True)
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power-end.txt').open('w'),check=True);assert 'AC Power' in (D/'power-end.txt').read_text()
result=[];flags=[]
for case in sorted({x['case'] for x in rows}):
 group=[x for x in rows if x['case']==case]
 expected={k:group[0][k] for k in keys};assert all({k:x[k] for k in keys}==expected for x in group)
 med={label:{k:statistics.median(x['samples'][0][k] for x in group if x['engine']==label) for k in ['total_cpu_ns','read_cpu_ns','operations_cpu_ns','process_peak_held_bytes']} for label in labels}
 for left,right in ([('parent','parent_twin'),('candidate','candidate_twin')] if a.mode=='run' else [('current','twin')]):
  ratio=med[right]['total_cpu_ns']/med[left]['total_cpu_ns']
  if abs(ratio-1)>.10:flags.append({'case':case,'labels':[left,right],'reason':'identical-binary CPU','ratio':ratio})
  for x,y in [(med[left],med[right]),(med[right],med[left])]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':case,'labels':[left,right],'reason':'identical-binary peak'})
 phases={}
 for metric in ['total_cpu_ns','read_cpu_ns','operations_cpu_ns']:
  values={role:[statistics.median(x['samples'][0][metric] for x in group if x['engine'] in engines and x['round']==turn) for turn in range(8)] for role,engines in [('parent',parent),('candidate',candidate)]}
  ratios=[c/p for p,c in zip(values['parent'],values['candidate'])]
  phases[metric]={'parent_median_ms':statistics.median(values['parent'])/1e6,'candidate_median_ms':statistics.median(values['candidate'])/1e6,'paired_median_ratio':statistics.median(ratios),'positive_pairs':sum(x>1 for x in ratios),'adverse_direction_7_of_8':sum(x>1 for x in ratios)>=7}
 result.append({'case':case,'phases':phases,'per_label':med})
verdict={'mode':a.mode,'workers':len(rows),'all_outputs_match':True,'quality_flags':flags,'cases':result,'repeatable_cost_signal':not flags and any(x['phases'][metric]['adverse_direction_7_of_8'] for x in result for metric in ['total_cpu_ns','operations_cpu_ns']),'signal_definition':'At least seven of eight round-paired candidate medians exceed parent for total CPU or operation CPU. Diagnostic direction check, not a numerical or performance waiver.'}
(D/'decision.json').write_text(json.dumps(verdict,indent=2)+'\n')
print(json.dumps(verdict,indent=2),flush=True)
raise SystemExit(1 if verdict['repeatable_cost_signal'] else 0)
