from pathlib import Path
import hashlib,io,json,subprocess,tarfile
V=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-compact-integration-20261021')
N=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018')
D=N/'Documentation/EngineeringNotes/benchmarks/2026-10-21-csv-integration'
D.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='2be6fc01a80d520d637f85f9f4bbde0a855e309b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
files={}
for p in V.iterdir():
 if p.is_file() and (p.suffix in ['.json','.py','.log'] or p.name.endswith('.coverage.txt')):files[p.name]=p.read_bytes()
for folder in ['reference-final','tabular-smoke-complete']:
 for p in (V/folder).rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(V)
  if 'module-cache' in rel.parts:continue
  if p.suffix not in ['.json','.jsonl','.py','.swift','.log','.txt','.parquet']:continue
  files[str(rel)]=p.read_bytes()
receipt=V/'standard-worker-final/SwiftSciBenchmarkWorker.build.json'
if receipt.exists():files['standard-worker-build.json']=receipt.read_bytes()
files['production.patch']=subprocess.check_output(['git','diff','546510bb7df19fc87a664bded5947c738011ee1d...HEAD'],cwd=S)
files['production-commits.txt']=subprocess.check_output(['git','log','--format=fuller','546510bb7df19fc87a664bded5947c738011ee1d..HEAD'],cwd=S)
archive=D/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'production_head':head,'files':{k:hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())}}
(D/'evidence-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
print(len(files),'verified files;',archive.stat().st_size,'archive bytes')
