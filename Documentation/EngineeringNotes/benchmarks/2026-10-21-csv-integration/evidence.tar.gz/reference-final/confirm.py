from pathlib import Path
import hashlib,itertools,json,statistics,subprocess,sys
D=Path(__file__).resolve().parent
R=Path('/private/tmp/swiftsci-csv-reference-20261021')
sys.path.insert(0,'/private/tmp/swiftsci-csv-compact-integration-20261021/Benchmarks/Tools')
from runner import environment,power_state,verify_uninstrumented
from execution_policy import worker_environment,PRODUCTION_MODE
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
variants=['baseline','scoped','integrated']
binaries={v:R/'build'/v/'ReferenceProbe' for v in variants[:2]}
binaries['integrated']=D/'build/integrated/ResourceProbe'
builds={v:json.loads((R/'build'/v/'build.json').read_text()) for v in variants[:2]}
builds['integrated']=json.loads((D/'build/integrated/build.json').read_text())
for v in variants:
 verify_uninstrumented(binaries[v])
 assert h(binaries[v])==builds[v]['binary_sha256']
 if v!='integrated':
  assert builds[v]['probe_sha256']==builds['integrated']['harness_sha256']
  assert builds[v]['prior_module_build']['dependency_objects']==builds['integrated']['dependency_objects']
all_cases={c['id']:c for c in json.loads((R/'cases.json').read_text())}
cases=['energy','Aotizhongxin','Wanliu']
for name in cases:assert h(Path(all_cases[name]['path']))==all_cases[name]['sha256']
orders=list(itertools.permutations(variants))
power=power_state();assert power['source']=='AC',power
out=D/'confirmation';out.mkdir(exist_ok=False)
plan={'cases':{k:all_cases[k] for k in cases},'mode':'known','builds':builds,'binary_paths':{v:str(p) for v,p in binaries.items()},'timing_rounds':6,'timing_samples':3,'warmups_per_timing_worker':2,'memory_rounds':3,'orders':orders,'power_start':power,'environment':environment(),'purpose':'Bounded integration confirmation; original full-file comparison remains the broader evidence.'}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
records=[]
with (out/'workers.jsonl').open('x') as f:
 for ci,name in enumerate(cases):
  for phase,count in [('timing',6),('memory',3)]:
   for rnd in range(count):
    order=orders[(ci+rnd)%6] if phase=='timing' else variants[rnd:]+variants[:rnd]
    for pos,v in enumerate(order):
     p=subprocess.run([str(binaries[v]),str(R/'inputs'/(name+'.json')),'known',phase,'3'],env=worker_environment(PRODUCTION_MODE),capture_output=True,text=True,timeout=240)
     assert p.returncode==0,p.stderr
     r=json.loads(p.stdout);assert r['validated'] and r['checks']['passed']
     case=all_cases[name]
     for j,c in enumerate(r['checks']['columns']):assert c['sha256']==case['hashes'][j] and c['nulls']==case['null_counts'][j]
     r.update(variant=v,round=rnd,position=pos);records.append(r);f.write(json.dumps(r)+'\n');f.flush()
  print(name,'confirmation complete',flush=True)
power=power_state();assert power['source']=='AC';(out/'power-end.json').write_text(json.dumps(power,indent=2)+'\n')
rows=[]
for name in cases:
 row={'input':name,'variants':{},'comparisons':{}}
 for v in variants:
  timed=sorted([r for r in records if r['input']==name and r['variant']==v and r['phase']=='timing'],key=lambda r:r['round'])
  memory=sorted([r for r in records if r['input']==name and r['variant']==v and r['phase']=='memory'],key=lambda r:r['round'])
  row['variants'][v]={k:[statistics.median(s[k] for s in r['samples']) for r in timed] for k in ['total_ns','total_cpu_ns']}
  row['variants'][v]['memory_records']=memory
 for earlier in ['baseline','scoped']:
  row['comparisons'][earlier+'-to-integrated']={}
  for k in ['total_ns','total_cpu_ns']:
   ratios=[b/a for a,b in zip(row['variants'][earlier][k],row['variants']['integrated'][k])]
   row['comparisons'][earlier+'-to-integrated'][k]={'median_ratio':statistics.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
 rows.append(row)
summary={'workers':len(records),'timing_samples':sum(len(r['samples']) for r in records if r['phase']=='timing'),'memory_samples':sum(len(r['samples']) for r in records if r['phase']=='memory'),'records_sha256':h(out/'workers.jsonl'),'rows':rows}
assert (summary['workers'],summary['timing_samples'],summary['memory_samples'])==(81,162,27)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in rows:
 print(row['input'],{a:{k:round(100*(s['median_ratio']-1),2) for k,s in vals.items()} for a,vals in row['comparisons'].items()})
