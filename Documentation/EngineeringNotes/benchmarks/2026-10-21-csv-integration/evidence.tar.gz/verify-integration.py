from pathlib import Path
import hashlib,json,statistics as st,subprocess
V=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-compact-integration-20261021')
R=Path('/private/tmp/swiftsci-csv-reference-20261021')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='2be6fc01a80d520d637f85f9f4bbde0a855e309b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
for name in ['complete-debug-coverage','complete-release','address']:
 c=json.loads((V/(name+'-command.json')).read_text());r=json.loads((V/(name+'-summary.json')).read_text())
 assert c['exit_code']==0 and r['passedTests']==339 and r['failedTests']==r['skippedTests']==0
 for f,digest in c['source_sha256'].items():assert h(S/f)==digest,f
coverage=json.loads((V/'patch-coverage.json').read_text())
assert sum(r['covered'] for r in coverage['results'])==sum(r['added_executable'] for r in coverage['results'])==129
for r in coverage['results']:
 assert not r['uncovered'] and h(S/'Sources/SwiftDataFrame/IO'/r['file'])==r['source_sha256']
 assert h(V/(r['file']+'.coverage.txt'))==r['coverage_sha256']
assert h(V/'coverage.profdata')==coverage['profile_sha256']
cert=json.loads((V/'tabular-smoke-complete/certificate.json').read_text());run=json.loads((V/'tabular-smoke-complete/run.json').read_text())
assert cert['status']==run['status']=='passed' and cert['source']['commit']==head
assert cert['validated_samples']==len(run['events'])==190 and h(V/'tabular-smoke-complete/run.json')==cert['run_sha256']
audit=[json.loads(line) for line in (V/'reference-final/audit.jsonl').read_text().splitlines()]
prior=[json.loads(line) for line in (R/'audit.jsonl').read_text().splitlines() if json.loads(line)['variant']=='scoped']
assert len(audit)==len(prior)==26 and sum(r['validated'] for r in audit)==14
for r in audit:
 p=next(x for x in prior if x['input']==r['input'] and x['mode']==r['mode'])
 assert p['checks']==r['checks'] and p['validated']==r['validated']
D=V/'reference-final/confirmation'
plan=json.loads((D/'plan.json').read_text());summary=json.loads((D/'summary.json').read_text())
records=[json.loads(line) for line in (D/'workers.jsonl').read_text().splitlines()]
assert plan['power_start']['source']==json.loads((D/'power-end.json').read_text())['source']=='AC'
expected={(case,v,phase,rnd) for case in plan['cases'] for v in plan['builds'] for phase,n in [('timing',6),('memory',3)] for rnd in range(n)}
assert len(records)==len(expected)==81
assert {(r['input'],r['variant'],r['phase'],r['round']) for r in records}==expected
for c in plan['cases'].values():assert h(Path(c['path']))==c['sha256']
for v,b in plan['builds'].items():assert h(Path(plan['binary_paths'][v]))==b['binary_sha256']
for r in records:
 assert r['validated'] and r['checks']['passed'] and r['mode']=='known'
 assert len(r['samples'])==(3 if r['phase']=='timing' else 1)
 c=plan['cases'][r['input']]
 for j,col in enumerate(r['checks']['columns']):assert col['sha256']==c['hashes'][j] and col['nulls']==c['null_counts'][j]
 for sample in r['samples']:
  assert sample['total_ns']==sample['call_ns']+sample['release_ns']>0
  assert sample['total_cpu_ns']==sample['call_cpu_ns']+sample['release_cpu_ns']>0
assert summary['records_sha256']==h(D/'workers.jsonl')
for row in summary['rows']:
 for name,metrics in row['comparisons'].items():
  a,b=name.split('-to-')
  for k,metric in metrics.items():
   ratios=[y/x for x,y in zip(row['variants'][a][k],row['variants'][b][k])]
   assert metric=={'median_ratio':st.median(ratios),'range':[min(ratios),max(ratios)],'ratios':ratios}
result={'passed':True,'head':head,'tests_per_configuration':339,'configurations':['Debug with coverage','Release','Debug with Address Sanitizer'],'added_executable_lines_covered':129,'standard_validated_samples':190,'original_valid_cases':14,'known_station_inference_failures_unchanged':12,'confirmation_workers':81,'confirmation_timing_samples':162,'confirmation_memory_samples':27,'confirmation_summary_sha256':h(D/'summary.json'),'source_and_receipts_verified':True}
(V/'integration-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
