#!/usr/bin/env python3
"""Compare complete SwiftSci and external-engine CPU queues with identical contracts."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Benchmarks.CPUThroughput import run
from Benchmarks.CPUThroughput.audit import control_flags
from Benchmarks.CPUThroughput.budget import jobs_for
from runner import power_state

LIMITS = dict(twin_cpu_deviation=.10,twin_wall_deviation=.10,
              twin_peak_relative=1.05,twin_peak_slack_per_caller_bytes=8*2**20)


def conditions(swift, python):
    worker = ROOT/'Benchmarks/CPUThroughput/external_worker.py'
    return {
        'swiftsci_optional':dict(engine='swiftsci',command=[str(swift)],mode='optional'),
        'swiftsci_compact':dict(engine='swiftsci',command=[str(swift)],mode='compact'),
        **{engine:dict(engine=engine,command=[str(python),str(worker)],mode=engine)
           for engine in ('pandas','polars','duckdb')},
    }


def preflight(configurations, cases, expected, directory):
    directory.mkdir()
    checks=[];ready={}
    for label,config in configurations.items():
        worker=run.Worker(config['command'],config['mode'],directory/(label+'.log'))
        try:
            ready[label]=worker.ready
            for case in cases:
                result=worker.ask({k:v for k,v in case.items() if k!='input'} | {'verify':True})
                checks.append(dict(label=label,**result))
                run.save(directory/'checks.json',checks)
                if result['check'] != expected[case['input']+'/'+case['workflow']]:
                    raise ValueError('Native output differs: '+label+'/'+case['input']+'/'+case['workflow'])
        finally:
            worker.close()
    run.save(directory/'ready.json',ready)
    return ready


def report(root, decision):
    records=json.loads((root/'records.json').read_text());plan=json.loads((root/'plan.json').read_text())
    lines=['# Equivalent external-engine CPU queues','',
        'Smoke validation only.' if plan['smoke'] else 'Fixed reference queues with native CPU parallelism.',
        '',f"Controls passed: {decision['controls_passed']}. Performance qualified: {decision['performance_qualified']}.",
        '', '| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |',
        '| --- | ---: | ---: | ---: | ---: |']
    for name in plan['conditions']:
        rows=[r['summary'] for r in records if r['label'].removesuffix('_twin')==name]
        m={metric:statistics.median(x[metric] for x in rows) for metric in
            ['completed_per_minute','charged_cpu_ns','sampled_peak_rss_bytes','sampled_resident_byte_seconds']}
        lines.append(f'| {name} | {m["completed_per_minute"]:.1f} | {m["charged_cpu_ns"]/decision["jobs_per_queue"]/1e6:.2f} | {m["sampled_peak_rss_bytes"]/2**20:.1f} | {m["sampled_resident_byte_seconds"]/2**20:.1f} |')
    lines+=['','CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.',
        '', 'DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.',
        '', 'Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.']
    return '\n'.join(lines)+'\n'


def audit(root):
    plan=json.loads((root/'plan.json').read_text());records=json.loads((root/'records.json').read_text())
    expected=json.loads((root/'expected.json').read_text())
    if (root/'failure.json').exists() or not (root/'end.json').exists():
        raise ValueError('Incomplete or failed comparison')
    wanted={(i,label) for i,order in enumerate(plan['orders']) for label in order}
    actual={(x['round'],x['label']) for x in records}
    if actual != wanted or len(records)!=len(wanted):
        raise ValueError('Incomplete or duplicate queues')
    if run.digest(root/'expected.json')!=plan['expected_sha256']:
        raise ValueError('Expected-output contract changed')
    jobs=0
    for row in records:
        raw=json.loads((root/f"r{row['round']}-{row['label']}"/'result.json').read_text())
        tasks=jobs_for(plan['cases'],plan['copies_per_case'],row['round'])
        summary=raw['summary']
        if summary!=row['summary'] or len(raw['before'])!=plan['callers'] or len(raw['after'])!=plan['callers']:
            raise ValueError('Queue receipt mismatch')
        calculated=run.summarize(raw['jobs'],summary['elapsed_ns'],raw['memory_samples'],tasks)
        if any(summary[k]!=v for k,v in calculated.items()):
            raise ValueError('Raw measurements differ from summary')
        cpu=sum(b['cpu_ns']-a['cpu_ns'] for a,b in zip(raw['before'],raw['after']))
        if cpu!=summary['worker_cpu_ns'] or cpu+summary['controller_cpu_ns']!=summary['charged_cpu_ns']:
            raise ValueError('Incorrect CPU accounting')
        mode=plan['conditions'][row['label'].removesuffix('_twin')]['mode']
        if any(x['storage']!=mode for x in raw['jobs']):
            raise ValueError('Wrong worker condition')
        jobs+=len(raw['jobs'])
    checks=0
    for phase in ['preflight','postflight']:
        rows=json.loads((root/phase/'checks.json').read_text())
        wanted_checks={(name,c['input'],c['workflow']) for name in plan['conditions'] for c in plan['cases']}
        if len(rows)!=len(wanted_checks) or {(x['label'],x['input'],x['workflow']) for x in rows}!=wanted_checks:
            raise ValueError('Missing full-output check')
        if any(x['check']!=expected[x['input']+'/'+x['workflow']] for x in rows):
            raise ValueError('Wrong native output')
        checks+=len(rows)
    metrics=['charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes']
    medians={label:{key:statistics.median(r['summary'][key] for r in records if r['label']==label)
                    for key in metrics} for label in plan['orders'][0]}
    flags=control_flags(medians,plan['quality_policy'],{label:plan['callers'] for label in medians})
    decision=dict(queues=len(records),jobs=jobs,jobs_per_queue=len(plan['cases'])*plan['copies_per_case'],
                  full_output_checks=checks,controls_passed=not flags,
                  performance_qualified=not flags and not plan['smoke'],flags=flags)
    run.save(root/'audit.json',decision)
    (root/'report.md').write_text(report(root,decision))
    return decision


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--swift-worker',type=Path);p.add_argument('--python',type=Path)
    p.add_argument('--air-contract',type=Path);p.add_argument('--energy-contract',type=Path)
    p.add_argument('--expected',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--smoke',action='store_true');p.add_argument('--audit',action='store_true')
    args=p.parse_args();root=args.output
    if args.audit:
        print(json.dumps(audit(root),indent=2));return
    if any(getattr(args,name) is None for name in ['swift_worker','python','air_contract','energy_contract','expected']):
        p.error('Worker, Python, contracts, and expected fingerprints are required')
    configs=conditions(args.swift_worker,args.python)
    run.verify_uninstrumented(args.swift_worker)
    receipt=json.loads(args.swift_worker.with_name('build.json').read_text())
    if run.digest(args.swift_worker)!=receipt['binary_sha256']:
        raise ValueError('Swift worker differs from its receipt')
    for name,sha in receipt['sources'].items():
        if run.digest(ROOT/name)!=sha:raise ValueError('Measured Swift source changed: '+name)
    cases=[];contracts={}
    for path,key in [(args.air_contract,'PM2.5'),(args.energy_contract,'Global_active_power')]:
        contract=json.loads(path.read_text());contracts[str(path)]=contract
        if run.digest(Path(contract['path']))!=contract['sha256']:raise ValueError('Input bytes changed')
        for flow in ['read','sort-matrix']:
            cases.append(dict(id=len(cases),contract=str(path.resolve()),workflow=flow,input=contract['id'],key=key,verify=False))
    labels=list(configs)+[name+'_twin' for name in configs]
    orders=[labels[i:]+labels[:i] for i in range(2 if args.smoke else len(labels))]
    sources=[Path(__file__),Path(__file__).with_name('run.py'),Path(__file__).with_name('audit.py'),
             Path(__file__).with_name('budget.py'),Path(__file__).with_name('external_worker.py'),
             Path(__file__).with_name('external_workflows.py'),ROOT/'Benchmarks/Tools/execution_policy.py',
             ROOT/'Benchmarks/Tools/runner.py']
    source_hashes={str(path.relative_to(ROOT)):run.digest(path) for path in sources}
    root.mkdir(parents=True,exist_ok=False)
    expected=json.loads(args.expected.read_text());run.save(root/'expected.json',expected)
    plan=dict(conditions=configs,cases=cases,contracts=contracts,orders=orders,callers=4,
        copies_per_case=2 if args.smoke else 32,rss_limit_bytes=8*2**30,smoke=args.smoke,
        quality_policy=LIMITS,expected_sha256=run.digest(root/'expected.json'),swift_build=receipt,
        source_hashes=source_hashes,python_sha256=run.digest(args.python),power=run.power(),
        power_settings=power_state(),environment=run.environment(),state=run.system_state())
    run.save(root/'plan.json',plan);records=[]
    try:
        ready=preflight(configs,cases,expected,root/'preflight');run.save(root/'runtime.json',ready)
        for i,order in enumerate(orders):
            for label in order:
                run.power();config=configs[label.removesuffix('_twin')]
                summary=run.batch(config['command'],config['mode'],jobs_for(cases,plan['copies_per_case'],i),
                    plan['callers'],root/f'r{i}-{label}',rss_limit_bytes=plan['rss_limit_bytes'])
                records.append(dict(round=i,label=label,summary=summary));run.save(root/'records.json',records)
            print(f'round {i+1}/{len(orders)}',flush=True)
        preflight(configs,cases,expected,root/'postflight')
        end=dict(power=run.power(),power_settings=power_state(),state=run.system_state())
        if end['power_settings']!=plan['power_settings']:raise ValueError('Power policy changed')
        for name,sha in source_hashes.items():
            if run.digest(ROOT/name)!=sha:raise ValueError('Controller changed during measurement')
        if run.digest(args.swift_worker)!=receipt['binary_sha256']:raise ValueError('Worker changed during measurement')
        run.save(root/'end.json',end)
    except BaseException as error:
        run.save(root/'failure.json',dict(type=type(error).__name__,error=str(error)));raise
    print(json.dumps(audit(root),indent=2))


if __name__=='__main__':
    main()
