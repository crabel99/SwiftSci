"""Complete eager reference workflows shared by persistent comparison workers."""
import ctypes
import hashlib
import importlib
import json
from pathlib import Path
import resource
import struct
import sys
import time
import numpy as np

lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
class MachInfo(ctypes.Structure):
 _fields_=[('virtual_size',ctypes.c_uint64),('resident_size',ctypes.c_uint64),('resident_size_max',ctypes.c_uint64),('user_sec',ctypes.c_int32),('user_micro',ctypes.c_int32),('sys_sec',ctypes.c_int32),('sys_micro',ctypes.c_int32),('policy',ctypes.c_int32),('suspend',ctypes.c_int32)]
self_task=ctypes.c_uint.in_dll(lib,'mach_task_self_').value
lib.task_info.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)]
def rss():
 info=MachInfo();count=ctypes.c_uint(ctypes.sizeof(info)//4)
 assert lib.task_info(self_task,20,ctypes.byref(info),ctypes.byref(count))==0
 return info.resident_size
def peak():return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
def cpu():
 r=resource.getrusage(resource.RUSAGE_SELF);return round((r.ru_utime+r.ru_stime)*1e9)

def fingerprint(frame, engine, case, modules):
 pd,pl,pa = (modules.get(name) for name in ("pandas","polars","pyarrow"))
 names=list(frame.columns) if engine!='duckdb' else frame.schema.names
 assert names==case['names'] and len(frame)==case['rows']
 columns=[]
 for name,kind in zip(case['names'],case['types']):
  col=frame[name]
  if engine=='pandas':matches={'Double':pd.api.types.is_float_dtype(col) and col.dtype.itemsize==8,'Int64':pd.api.types.is_integer_dtype(col) and col.dtype.itemsize==8,'String':pd.api.types.is_string_dtype(col)}[kind]
  elif engine=='polars':matches=col.dtype=={'Double':pl.Float64,'Int64':pl.Int64,'String':pl.String}[kind]
  else:matches=col.type=={'Double':pa.float64(),'Int64':pa.int64(),'String':pa.string()}[kind]
  assert matches,(name,kind,str(col.dtype if engine!='duckdb' else col.type))
  digest=hashlib.sha256();nulls=0
  for start in range(0,len(frame),65536):
   if engine=='pandas':
    part=col.iloc[start:start+65536];valid=~part.isna().to_numpy();values=part.tolist() if kind=='String' else part.to_numpy()
   elif engine=='polars':
    part=col.slice(start,65536);valid=part.is_not_null().to_numpy();values=part.to_list() if kind=='String' else part.to_numpy()
   else:
    part=col.slice(start,65536);valid=part.is_valid().to_numpy(zero_copy_only=False);values=part.to_pylist() if kind=='String' else part.to_numpy(zero_copy_only=False)
   nulls+=int((~valid).sum())
   if kind=='String':
    buf=bytearray()
    for value,ok in zip(values,valid):
     if ok:
      encoded=value.encode('utf-8');buf+=b'\1'+struct.pack('<I',len(encoded))+encoded
     else:buf+=b'\0'
    digest.update(buf)
   else:
    numbers=np.ascontiguousarray(values,dtype='<i8' if kind=='Int64' else '<f8')
    packed=np.empty((len(valid),9),dtype=np.uint8);packed[:,0]=valid;packed[:,1:]=numbers.view(np.uint8).reshape(-1,8)
    keep=np.ones(packed.shape,dtype=bool);keep[~valid,1:]=False;digest.update(packed[keep].tobytes())
  assert nulls==case['null_counts'][case['names'].index(name)]
  columns.append(dict(name=name,type=kind,nulls=nulls,sha256=digest.hexdigest()))
 return dict(rows=len(frame),columns=columns)

def matrix_fingerprint(values, case):
 numeric=[n for n,t in zip(case["names"],case["types"]) if t!="String"]
 assert values.shape==(case['rows'],len(numeric)) and values.dtype==np.float64 and values.flags.c_contiguous
 digest=hashlib.sha256();flat=values.reshape(-1)
 for start in range(0,len(flat),65536):
  numbers=np.ascontiguousarray(flat[start:start+65536],dtype='<f8')
  packed=np.empty((len(numbers),9),dtype=np.uint8);packed[:,0]=1;packed[:,1:]=numbers.view(np.uint8).reshape(-1,8);digest.update(packed.tobytes())
 return digest.hexdigest()


class ExternalWorkflow:
    def __init__(self, engine):
        if engine not in ("pandas", "polars", "duckdb"):
            raise ValueError("Unknown comparison engine: " + engine)
        self.engine = engine
        self.modules = {engine: importlib.import_module(engine)}
        self.connection = None
        self.pools = {}
        if engine == "polars":
            self.pools[engine] = self.modules[engine].thread_pool_size()
        if engine == "duckdb":
            # Arrow's deferred pandas import belongs to startup, outside queue timing.
            self.modules.update({name: importlib.import_module(name) for name in ("pyarrow", "pandas")})
            self.connection = self.modules[engine].connect()
            self.pools[engine] = self.connection.sql("select current_setting('threads')").fetchone()[0]
            assert self.connection.sql("select current_setting('preserve_insertion_order')").fetchone()[0]
        self.versions = {name: module.__version__ for name, module in self.modules.items()}
        self.versions.update(python=sys.version, numpy=np.__version__)

    def close(self):
        if self.connection is not None:
            self.connection.close()

    def read(self, case):
        if self.engine == "pandas":
            pd = self.modules["pandas"]
            kinds = {"String": "str", "Double": "float64", "Int64": "int64"}
            return pd.read_csv(case["path"], sep=case["delimiter"], header=0,
                dtype={n: kinds[t] for n,t in zip(case["names"],case["types"])},
                na_values=case["null_tokens"], keep_default_na=False,
                encoding="utf-8", engine="c", float_precision="round_trip")
        if self.engine == "polars":
            pl = self.modules["polars"]
            kinds = {"String": pl.String, "Double": pl.Float64, "Int64": pl.Int64}
            return pl.read_csv(case["path"], separator=case["delimiter"], has_header=True,
                schema={n: kinds[t] for n,t in zip(case["names"],case["types"])},
                null_values=case["null_tokens"], try_parse_dates=False)
        kinds = {"String": "VARCHAR", "Double": "DOUBLE", "Int64": "BIGINT"}
        return self.connection.read_csv(case["path"], delimiter=case["delimiter"], header=True,
            columns={n: kinds[t] for n,t in zip(case["names"],case["types"])},
            na_values=case["null_tokens"], auto_detect=False).to_arrow_table()

    def sort(self, frame, case, key):
        if self.engine == "pandas":
            return frame.sort_values(key, kind="stable", na_position="last", ignore_index=True)
        if self.engine == "polars":
            return frame.sort(key, nulls_last=True, maintain_order=True)
        pa = self.modules["pyarrow"]
        indexed = frame.append_column("__source_row__", pa.array(np.arange(len(frame),dtype=np.int64)))
        def quote(name):
            return '"' + name.replace('"','""') + '"'
        self.connection.register("_sort_input", indexed)
        try:
            order = self.connection.sql('SELECT __source_row__ FROM _sort_input ORDER BY '+
                quote(key)+' ASC NULLS LAST, __source_row__ ASC').to_arrow_table()
            return frame.take(order.column(0))
        finally:
            self.connection.unregister("_sort_input")

    def matrix(self, frame, case):
        numeric = [n for n,t in zip(case["names"],case["types"]) if t != "String"]
        if self.engine == "pandas":
            return np.ascontiguousarray(frame[numeric].to_numpy(dtype=np.float64,na_value=np.nan,copy=True))
        if self.engine == "polars":
            return np.ascontiguousarray(frame.select(numeric).to_numpy(order="c",writable=True))
        return np.ascontiguousarray(np.column_stack([
            frame[name].to_numpy(zero_copy_only=False) for name in numeric]),dtype=np.float64)

    def validate_shape(self, frame, matrix, case):
        names = frame.schema.names if self.engine == "duckdb" else list(frame.columns)
        if names != case["names"] or len(frame) != case["rows"]:
            raise ValueError("Wrong frame shape or column order")
        for name,kind in zip(case["names"],case["types"]):
            col = frame[name]
            if self.engine == "pandas":
                pd = self.modules["pandas"]
                match = (pd.api.types.is_string_dtype(col) if kind == "String" else
                    pd.api.types.is_integer_dtype(col) and col.dtype.itemsize == 8 if kind == "Int64" else
                    pd.api.types.is_float_dtype(col) and col.dtype.itemsize == 8)
            elif self.engine == "polars":
                pl = self.modules["polars"]
                match = col.dtype == {"String":pl.String,"Int64":pl.Int64,"Double":pl.Float64}[kind]
            else:
                pa = self.modules["pyarrow"]
                match = col.type == {"String":pa.string(),"Int64":pa.int64(),"Double":pa.float64()}[kind]
            if not match:
                raise ValueError("Wrong column type: " + name)
        if matrix is not None:
            count = sum(t != "String" for t in case["types"])
            if (matrix.shape != (case["rows"],count) or matrix.dtype != np.float64
                    or not matrix.flags.c_contiguous or not matrix.flags.writeable):
                raise ValueError("Matrix must be writable contiguous row-major Float64")

    def execute(self, request):
        case = json.loads(Path(request["contract"]).read_text())
        workflow = request["workflow"]
        if workflow not in ("read", "sort-matrix") or request["key"] not in case["names"]:
            raise ValueError("Unsupported reference workflow")
        if not set(case["types"]) <= {"String", "Double", "Int64"}:
            raise ValueError("Unsupported reference schema")
        c0,t0 = cpu(),time.perf_counter_ns()
        frame = self.read(case)
        matrix = None
        if workflow == "sort-matrix":
            frame = self.sort(frame,case,request["key"])
            matrix = self.matrix(frame,case)
        self.validate_shape(frame,matrix,case)
        held,held_peak = rss(),peak()
        t1,c1 = time.perf_counter_ns(),cpu()
        check = {}
        if request["verify"]:
            check = dict(frame=fingerprint(frame,self.engine,case,self.modules),
                matrix_sha256="absent" if matrix is None else matrix_fingerprint(matrix,case))
        c2,t2 = cpu(),time.perf_counter_ns()
        del frame,matrix
        t3,c3 = time.perf_counter_ns(),cpu()
        return dict(id=request["id"],input=case["id"],workflow=workflow,storage=self.engine,
            cpu_ns=c1-c0+c3-c2,wall_ns=t1-t0+t3-t2,held_rss_bytes=held,
            process_peak_bytes=held_peak,released_rss_bytes=rss(),check=check)
