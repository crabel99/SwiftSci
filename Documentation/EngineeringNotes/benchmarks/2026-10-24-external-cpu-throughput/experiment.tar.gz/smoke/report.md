# Equivalent external-engine CPU queues

Smoke validation only.

Controls passed: False. Performance qualified: False.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 960.5 | 288.68 | 2136.9 | 694.8 |
| swiftsci_compact | 858.9 | 274.95 | 1432.8 | 537.0 |
| pandas | 227.0 | 897.62 | 2726.3 | 2372.7 |
| polars | 1174.8 | 348.97 | 1645.3 | 474.2 |
| duckdb | 642.6 | 609.87 | 2242.4 | 1190.6 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.
