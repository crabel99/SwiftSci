# Equivalent external-engine CPU queues

Fixed reference queues with native CPU parallelism.

Controls passed: True. Performance qualified: True.

| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Resident MiB-seconds |
| --- | ---: | ---: | ---: | ---: |
| swiftsci_optional | 1768.8 | 231.79 | 3489.7 | 6292.6 |
| swiftsci_compact | 1725.6 | 231.69 | 2506.3 | 4549.1 |
| pandas | 317.2 | 717.52 | 4468.4 | 40986.4 |
| polars | 1979.8 | 323.83 | 2839.8 | 4428.0 |
| duckdb | 1142.8 | 556.44 | 4251.0 | 11268.4 |

CPU includes summed worker user and system time and measured controller work. Process startup and full hashes are outside queue timing. Shape checks and output release remain inside. RSS includes runtime and allocator residency and may double-count shared pages.

DuckDB computes a stable row permutation and Arrow gathers the original rows. This preserves signed-zero bits that direct ordered projection can canonicalize. The gathering cost is timed.

Every primary condition has its own identical-binary twin. Unqualified results remain visible in audit.json. A smoke run cannot establish comparative performance.
