"""Direct ordered projection can canonicalize signed zero; preserve the reproducer."""
import duckdb,pyarrow as pa,struct,json
c=duckdb.connect()
t=pa.table({'x':pa.array([-0.0,1.0]),'row':pa.array([0,1])});c.register('input',t)
try:
 direct=c.sql('select x from input order by x,row').to_arrow_table()['x'][0].as_py()
 order=c.sql('select row from input order by x,row').to_arrow_table()
 gathered=t.take(order.column(0))['x'][0].as_py()
 print(json.dumps(dict(duckdb=duckdb.__version__,input_bits=struct.pack('<d',-0.0).hex(),direct_bits=struct.pack('<d',direct).hex(),gathered_bits=struct.pack('<d',gathered).hex())))
 assert struct.pack('<d',gathered)==struct.pack('<d',-0.0)
finally:c.close()
