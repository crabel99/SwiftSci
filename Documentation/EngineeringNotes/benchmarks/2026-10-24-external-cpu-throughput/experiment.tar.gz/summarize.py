"""Audit and describe the first equivalent external-engine CPU queue panel."""
from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import sys

S=Path('/private/tmp/swiftsci-csv-compact-construction-20261024')
R=Path(__file__).parent;D=R/'full';sys.path.insert(0,str(S))
from Benchmarks.CPUThroughput.compare import audit
from Benchmarks.CPUThroughput.run import digest, save

plan=json.loads((D/'plan.json').read_text());decision=audit(D)
assert decision['performance_qualified'], 'Do not issue a qualifying conclusion for failed controls'
records=json.loads((D/'records.json').read_text())
assert decision['jobs']==6400 and decision['full_output_checks']==40 and decision['queues']==100
for path,contract in plan['contracts'].items():
 assert digest(Path(contract['path']))==contract['sha256']
 assert json.loads(Path(path).read_text())==contract
ready=json.loads((D/'preflight/ready.json').read_text())
post=json.loads((D/'postflight/ready.json').read_text())
for name in plan['conditions']:
 for key in ['engine','versions','execution']:
  assert ready[name].get(key)==post[name].get(key)
for row in records:
 raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
 name=row['label'].removesuffix('_twin')
 for runtime in raw['runtime']:
  for key in ['engine','versions','execution']:
   assert runtime.get(key)==ready[name].get(key)
rows={};case_cpu={};kernel=[]
metrics=['completed_per_minute','charged_cpu_ns','elapsed_ns','sampled_peak_rss_bytes',
         'retained_rss_bytes','sampled_resident_byte_seconds']
for name in plan['conditions']:
 group=[row for row in records if row['label'].removesuffix('_twin')==name]
 rows[name]={key:statistics.median(row['summary'][key] for row in group) for key in metrics}
 queues=[]
 for row in group:
  raw=json.loads((D/f"r{row['round']}-{row['label']}"/'result.json').read_text())
  queues.append({case['input']+'/'+case['workflow']:statistics.mean(job['cpu_ns'] for job in raw['jobs']
                 if (job['input'],job['workflow'])==(case['input'],case['workflow'])) for case in plan['cases']})
  kernel.append(dict(round=row['round'],label=row['label'],sum_peak_bytes=sum(x['peak_bytes'] for x in raw['after'])))
 case_cpu[name]={key:statistics.median(q[key] for q in queues) for key in queues[0]}
comparisons=[]
for swift in ['swiftsci_optional','swiftsci_compact']:
 for other in ['pandas','polars','duckdb']:
  paired={key:[] for key in metrics}
  for iteration in range(10):
   values={name:{key:statistics.median(row['summary'][key] for row in records
            if row['round']==iteration and row['label'].removesuffix('_twin')==name)
            for key in metrics} for name in [swift,other]}
   for key in metrics:paired[key].append(values[swift][key]/values[other][key])
  comparisons.append(dict(swift=swift,reference=other,paired_ratios=paired,
                         paired_medians={k:statistics.median(v) for k,v in paired.items()},
                         rounds_lower_cpu=sum(v<1 for v in paired['charged_cpu_ns'])))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head==plan['source_head']
for name,sha in plan['source_hashes'].items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=S)
 assert hashlib.sha256(data).hexdigest()==sha
 dest=R/'measured-sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
for name,sha in plan['swift_build']['sources'].items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=S)
 assert hashlib.sha256(data).hexdigest()==sha
 dest=R/'measured-sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
summary=dict(source_commit=head,qualification=decision,conditions=rows,case_operation_cpu_ns=case_cpu,
             comparisons=comparisons,runtime=ready,max_sum_kernel_peak_bytes=max(x['sum_peak_bytes'] for x in kernel),
             contracts_unchanged=True,runtime_versions_unchanged=True,
             validation=dict(focused_tests=21,new_native_swift_tests=False,
                 reason='All 51 measured Swift source hashes are unchanged from the previously validated integer-fix head.'))
summary['validation']['controller_suite']=json.loads((R/'validation.json').read_text())
save(R/'summary.json',summary);save(R/'comparisons.json',comparisons);save(R/'kernel-bounds.json',kernel)
save(R/'provenance.json',dict(source_commit=head,swift_build=plan['swift_build'],controller_sources=plan['source_hashes'],
    interpreter_sha256=plan['python_sha256'],all_source_hashes_match_commit=True,
    all_contracts_unchanged=True,runtime_versions_match_every_worker=True))
lines=['# Equivalent CPU queues across dataframe libraries','',
 f'Benchmark source is `{head}` on local branch `codex/external-cpu-throughput`, based on Swift library head `58db37c4b3c97b287186c377f76f89abcbbb0b0d`. No Swift production code changes and nothing is pushed. Engineering evidence remains on `codex/engineering-notes`.','',
 f"Performance qualified: {decision['performance_qualified']}. Controls passed: {decision['controls_passed']}. The full panel completes 100 queues, 6,400 timed jobs, and 40 full-output checks.",'',
'## Complete queue resource costs','',
'Every condition uses four persistent caller processes with native internal parallelism. Each queue contains 16 copies of each reference read or read-sort-matrix case, for 64 jobs. Imports, session setup, and process readiness finish before timing. The first public CSV call remains timed. Output release, queue dispatch, sampling, and measured controller CPU are charged.','',
'| Condition | Jobs/min | CPU ms/job | Sampled peak MiB | Retained MiB | Resident MiB-seconds |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for name,m in rows.items():
 lines.append(f'| {name} | {m["completed_per_minute"]:.1f} | {m["charged_cpu_ns"]/64e6:.2f} | {m["sampled_peak_rss_bytes"]/2**20:.1f} | {m["retained_rss_bytes"]/2**20:.1f} | {m["sampled_resident_byte_seconds"]/2**20:.1f} |')
lines+=['','These are medians pooling each primary condition with its twin. CPU is summed user and system time across worker threads, plus measured controller work. It is not FLOPs, energy, or normalized performance-core and efficiency-core work. RSS can count shared pages more than once. It is not unique physical memory.','',
'## Paired comparisons','',
'Ratios below are SwiftSci divided by the reference library within the same round. Less than 1 means less CPU or sampled RSS. Greater than 1 means higher throughput.','',
'| SwiftSci storage | Reference | CPU ratio | Throughput ratio | Peak RSS ratio | Rounds with less CPU |',
'| --- | --- | ---: | ---: | ---: | ---: |']
for c in comparisons:
 m=c['paired_medians'];lines.append(f'| {c["swift"]} | {c["reference"]} | {m["charged_cpu_ns"]:.3f} | {m["completed_per_minute"]:.3f} | {m["sampled_peak_rss_bytes"]:.3f} | {c["rounds_lower_cpu"]}/10 |')
lines+=['','Paired medians can differ from ratios of pooled medians. Rounds are not independent statistical samples, and counts are not confidence intervals. A control pass does not certify every small difference. If the full panel is unqualified, these remain observations rather than a validated ranking.','',
'## Operation CPU by complete reference path','',
'| Input and workflow | Swift optional ms | Swift compact ms | pandas ms | Polars ms | DuckDB plus Arrow ms |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for case in case_cpu['pandas']:
 lines.append('| '+case+' | '+' | '.join(f'{case_cpu[name][case]/1e6:.2f}' for name in plan['conditions'])+' |')
lines+=['','These measure complete public paths. Read-sort-matrix includes reading, stable full-frame sorting, and owned row-major Float64 output. Subtracting these medians would not establish an isolated sort cost. Shape and type checks and output release are included. Native-bit hashing is outside timing.','',
'## Equivalent work and adapter choices','',
'The inputs contain 35,064 Aotizhongxin air-quality observations and 2,075,259 household-electricity rows. Every engine receives the same CSV bytes, complete ordered schema, declared null list, and native Int64, Float64, and String output contract. Sorting is stable, ascending, and missing-last. Matrices contain the same numeric columns in owned writable C order. Independent output fingerprints match every column and matrix before and after timing.','',
'Pandas uses its C CSV reader with round-trip float conversion. Polars receives a complete schema and requests stable sorting and writable C-order NumPy output. DuckDB materializes Arrow output through a persistent connection. Its stable SQL ordering uses the original row number as a tie breaker, followed by Arrow gathering of the original rows. Every conversion and gather remains in the measured work.','',
'The DuckDB adapter needs this gather to preserve native signed-zero bits. A small live-process conformance fixture fails with direct ordered projection: the input is negative zero, while the ordered value is positive zero. The isolated dependency reproducer and failed-first test log remain archived. Gathering the original row values restores the expected bit pattern. This branch changes the benchmark adapter, not DuckDB production code.','',
'Pandas ordinary Int64 columns do not support missing integers, and its ordinary Float64 null model cannot distinguish valid NaNs from missing values. These reference contracts require neither representation. Inputs needing those semantics must receive new equivalent adapters before comparison. No mismatch is waived.','',
'Official API context: [pandas CSV options](https://pandas.pydata.org/docs/user_guide/io.html), [Polars writable C-order conversion](https://docs.pola.rs/py-polars/html/reference/dataframe/index.html), and [DuckDB ordering](https://duckdb.org/docs/stable/sql/dialect/order_preservation.html). Runtime behavior is checked against the installed versions below.','',
'## Runtime identity and controls','']
for name,meta in ready.items():
 if 'versions' in meta:
  versions=', '.join(f'{k} {v.splitlines()[0]}' for k,v in meta['versions'].items())
  lines.append(f'- {name}: {versions}. Configured pools: {meta["execution"]["configured_pool_sizes"]}.')
lines+=['','Every worker has the production-default execution policy with inherited thread overrides cleared. Configured pool size is not measured active core use. The full plan uses ten rotated rounds with a separate identical-binary twin for all five conditions. Each primary and twin occupies every order position.','',
'All conditions use the same 8 GiB sampled worker-RSS ceiling. It excludes controller memory and is not an OS-enforced physical-memory limit. Source, interpreter, executable, contract, and runtime identities are checked independently after the panel. The audit recomputes every queue and job, raw CPU accounting, memory summaries, runtime identity, output hashes, and control result.','',
'Qualification limits remain 10% for twin CPU and elapsed-time drift, plus 5% and 8 MiB per caller for sampled peak RSS.','',
'| Control label | Metric | Twin ratio |','| --- | --- | ---: |']
if decision['flags']:
 for flag in decision['flags']:lines.append(f'| {flag["label"]} | {flag["metric"]} | {flag.get("ratio",0):.4f} |')
else:lines.append('| All conditions | All controls pass | |')
lines+=['','## Validation and planning history','',
'The 21 focused CPU benchmark tests pass with no skips. The full CI-style controller command passes 243 tests and skips four explicit Metal opt-ins. Running those four separately with `SWIFTSCI_MLX_TEST_GPU=1` passes all four without skips. Thus all 247 controller tests execute successfully across the two configurations. GPU checks run only after CPU timing. The reused Swift source previously passed 447 Debug and 447 Release dataframe tests. No new native Swift run or hosted CI result is claimed.','',
'The initial two-round smoke completes all reference checks. Its DuckDB elapsed control fails at short queue length. Smoke is explicitly unable to qualify performance. The initial smoke source is preserved at all eight original file hashes. A forecast is recorded before the full run and freezes 64 jobs per queue with the original thresholds. No full-run work count, caller count, schema, or tolerance is retuned after observing results.','',
'These are finite bursts after preflight and repeated fixture reads, not cold-disk or sustained-service measurements. They do not measure GPU or Neural Engine work, energy, unique physical memory, or all scientific workloads. Rates cannot be compared directly with the earlier 128-job queue study.','',
'## Evidence and reproduction','',
'[Summary](summary.json), [paired comparisons](comparisons.json), [source provenance](provenance.json), and the [experiment archive](experiment.tar.gz) preserve the evidence. The source branch contains only the reusable benchmark feature and its tests. Engineering decisions and measured results stay on the notes branch.','',
'Rebuild or restore the recorded uninstrumented Swift worker, matching interpreter and comparison dependencies, and the two reference files by SHA256. Run the documented `Benchmarks/CPUThroughput/compare.py` command into a fresh directory without `--smoke`, then its `--audit` command and this archived `summarize.py`. Raw CSVs, executables, object files, caches, and xcresult bundles are excluded from the archive.']
compact=[c for c in comparisons if c['swift']=='swiftsci_compact']
headline=['The panel supports the resource-efficiency goal within these complete reference workflows.','']
for c in compact:
 m=c['paired_medians'];name='pandas C/round-trip' if c['reference']=='pandas' else 'DuckDB plus Arrow' if c['reference']=='duckdb' else 'Polars'
 headline.append(f'- Against {name}, SwiftSci compact uses {100*(1-m["charged_cpu_ns"]):.1f}% less CPU and {100*(1-m["sampled_peak_rss_bytes"]):.1f}% less sampled peak RSS. Throughput ratio is {m["completed_per_minute"]:.2f} times the reference.')
headline+=['','Polars completes this queue faster than SwiftSci while using more CPU. Integrated resident byte-seconds are close, nominally 1.6% higher for SwiftSci compact in paired rounds. Lower peak RSS does not establish lower memory occupancy over time. The figures describe these API paths and reference files, not every operation or the best possible configuration of each library. Alternative readers, including pandas with Arrow, need separate equivalent qualification.','']
index=lines.index('## Complete queue resource costs');lines[index:index]=headline
(R/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(qualification=decision,conditions=rows),indent=2))
