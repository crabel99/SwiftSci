from pathlib import Path
import hashlib,json,statistics,subprocess
R=Path(__file__).resolve().parent;A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023');D=R/'precision-32';D.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();labels=['parent','parent_twin','candidate','candidate_twin']
native={f"{c['kind']}/{c['count']}":c for c in json.loads((A/'native-contracts.json').read_text())}
items=[{'scope':'native','case':k,**native[k]} for k in ['Double/1000000','Float/1000000','Date/1000000','Double/8000000','Int64/1000000','String/1000000']]
for fixture,storage in [('valid-2-distributed-32768','compact'),('half-plus-one-1000000','compact')]:items.append({'scope':'shape','case':f'{fixture}/serial/{storage}/sort-indices','fixture':fixture,'storage':storage,'contract':json.loads((A/'shape-inputs'/(fixture+'.json')).read_text())})
base=[0,1,3,2];first=[[labels[(x+shift)%4] for x in base] for shift in range(4)];orders=first+[list(reversed(x)) for x in reversed(first)]
def binary(label,scope):return A/(('prior' if label.startswith('parent') else 'current')+('-native' if scope=='native' else '-shape'))
plan={'controller_sha256':h(Path(__file__)),'scope':'Independent precision confirmation. Same first public call, constructor excluded, caller retains input, release included. Original failed qualifications remain unchanged.','replicates_per_label':32,'blocks':4,'orders':orders,'cases':items,'binaries':{scope:{label:h(binary(label,scope)) for label in labels} for scope in ['native','shape']},'quality_policy':{'cpu_twin_deviation':.10,'peak_twin_relative':1.05,'peak_twin_slack_bytes':8*2**20},'block_case_order':'Rotate case order once per block'}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');subprocess.run(['pmset','-g','batt'],stdout=(D/'power.txt').open('w'),check=True);assert 'AC Power' in (D/'power.txt').read_text()
rows=[]
with (D/'workers.jsonl').open('w') as out:
 for block in range(4):
  for item in items[block:]+items[:block]:
   expected=None
   for rnd,order in enumerate(orders):
    for pos,label in enumerate(order):
     if item['scope']=='native':args=[item['kind'],str(item['count']),item['path']]
     else:args=[str(A/'shape-inputs'/(item['fixture']+'.json')),'sort-indices','serial',item['storage']]
     x=json.loads(subprocess.check_output([str(binary(label,item['scope'])),*args],text=True,timeout=60))
     if item['scope']=='native':
      assert x['validated_identity'] and x['indices_sha256']==item['indices_sha256'] and x['rows']==x['nulls']==item['count'] and x['dtype']==item['dtype'];sample={k:x[k] for k in ['total_cpu_ns','process_peak_held_bytes']}
     else:
      c=item['contract'];assert x['selection_sha256']==c['expected_index_sha256'];fp={k:x[k] for k in ['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']}
      if expected is None:expected=fp
      assert fp==expected;sample=x['samples'][0]
     x.update(case=item['case'],scope=item['scope'],engine=label,block=block,round=rnd,position=pos,diagnostic_sample=sample);out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();rows.append(x)
   print('block',block+1,'/ 4',item['case'],flush=True)
subprocess.run(['pmset','-g','batt'],stdout=(D/'power-end.txt').open('w'),check=True);assert 'AC Power' in (D/'power-end.txt').read_text()
summary=[];flags=[]
for item in items:
 group=[x for x in rows if x['case']==item['case']];med={label:{metric:statistics.median(x['diagnostic_sample'][metric] for x in group if x['engine']==label) for metric in ['total_cpu_ns','process_peak_held_bytes']} for label in labels}
 for left,right in [('parent','parent_twin'),('candidate','candidate_twin')]:
  ratio=med[right]['total_cpu_ns']/med[left]['total_cpu_ns']
  if abs(ratio-1)>.10:flags.append({'case':item['case'],'labels':[left,right],'reason':'identical-binary CPU','ratio':ratio})
  for x,y in [(med[left],med[right]),(med[right],med[left])]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':item['case'],'labels':[left,right],'reason':'identical-binary peak'})
 paired=[]
 for block in range(4):
  for rnd in range(8):
   vals={role:statistics.median(x['diagnostic_sample']['total_cpu_ns'] for x in group if x['engine'].startswith(role) and x['block']==block and x['round']==rnd) for role in ['parent','candidate']};paired.append(vals['candidate']/vals['parent'])
 summary.append({'case':item['case'],'per_label':med,'paired_median_cpu_ratio':statistics.median(paired),'positive_pairs':sum(r>1 for r in paired),'pairs':32})
result={'workers':len(rows),'all_outputs_match':True,'replicates_per_label':32,'quality_flags':flags,'quality_passed':not flags,'cases':summary,'original_results_replaced':False};(D/'decision.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
