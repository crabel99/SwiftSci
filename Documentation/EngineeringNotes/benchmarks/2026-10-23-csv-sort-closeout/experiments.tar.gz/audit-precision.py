from pathlib import Path
import json,statistics,collections
R=Path(__file__).resolve().parent;D=R/'precision-32';plan=json.loads((D/'plan.json').read_text());decision=json.loads((D/'decision.json').read_text());rows=[json.loads(x) for x in (D/'workers.jsonl').read_text().splitlines()];assert len(rows)==1024
assert len({(x['case'],x['block'],x['round'],x['engine']) for x in rows})==1024
labels=['parent','parent_twin','candidate','candidate_twin'];flags=[]
for item in plan['cases']:
 group=[x for x in rows if x['case']==item['case']];assert len(group)==128
 expected=None
 for x in group:
  assert x['engine']==plan['orders'][x['round']][x['position']]
  if item['scope']=='native':
   assert x['indices_sha256']==item['indices_sha256'] and x['validated_identity'] and x['rows']==x['nulls']==item['count'] and x['dtype']==item['dtype']
   assert x['diagnostic_sample']['total_cpu_ns']==x['total_cpu_ns']
  else:
   assert x['selection_sha256']==item['contract']['expected_index_sha256']
   fp={k:x[k] for k in ['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256']}
   if expected is None:expected=fp
   assert fp==expected
   assert x['diagnostic_sample']==x['samples'][0]
 med={label:{metric:statistics.median(x['diagnostic_sample'][metric] for x in group if x['engine']==label) for metric in ['total_cpu_ns','process_peak_held_bytes']} for label in labels}
 recorded=next(x for x in decision['cases'] if x['case']==item['case']);assert med==recorded['per_label']
 for left,right in [('parent','parent_twin'),('candidate','candidate_twin')]:
  if abs(med[right]['total_cpu_ns']/med[left]['total_cpu_ns']-1)>.10:flags.append((item['case'],'CPU'))
  if any(med[y]['process_peak_held_bytes']>med[x]['process_peak_held_bytes']*1.05+8*2**20 for x,y in [(left,right),(right,left)]):flags.append((item['case'],'peak'))
 ratios=[]
 for block in range(4):
  for rnd in range(8):
   values={role:statistics.median(x['diagnostic_sample']['total_cpu_ns'] for x in group if x['engine'].startswith(role) and x['block']==block and x['round']==rnd) for role in ['parent','candidate']};ratios.append(values['candidate']/values['parent'])
 assert statistics.median(ratios)==recorded['paired_median_cpu_ratio']
 assert sum(x>1 for x in ratios)==recorded['positive_pairs']
assert flags==decision['quality_flags']==[]
result={'passed':True,'raw_workers':1024,'cases':8,'exact_outputs':True,'balanced_label_orders':True,'recomputed_medians_and_paired_ratios':True,'qualification_limits_unchanged':True,'quality_flags':flags,'original_qualifications_replaced':False}
(R/'precision-independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
