from pathlib import Path
import argparse,collections,hashlib,json,os,statistics,subprocess,sys
R=Path(__file__).resolve().parent
S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023')
I=Path('/private/tmp/swiftsci-csv-external-20261023/inputs')
sys.path.insert(0,str(S/'Benchmarks/Tools'))
from execution_policy import worker_environment,policy,PRODUCTION_MODE
p=argparse.ArgumentParser();p.add_argument('mode',choices=['preflight','measure','audit']);a=p.parse_args()
labels=['baseline','optional','compact','pandas','polars','duckdb','optional_twin','compact_twin']
cases=[{'input':name,'workflow':flow,'contract':str(I/(name+'.json'))} for name in ['Aotizhongxin-default','energy-common'] for flow in ['read','sort-matrix']]
base=[0,1,7,2,6,3,5,4];first=[[labels[(i+offset)%8] for i in base] for offset in range(8)];orders=first+[list(reversed(x)) for x in reversed(first)]
assert all(collections.Counter(order[pos] for order in orders)=={label:2 for label in labels} for pos in range(8))
assert set(collections.Counter((x,y) for order in orders for x,y in zip(order,order[1:])).values())=={2}
python='/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python'
env=worker_environment(PRODUCTION_MODE)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def case_id(case):return case['input']+'/'+case['workflow']
def command(label,case):
 if label=='baseline':return [str(R/'baseline-workflow'),case['contract'],case['workflow'],'parallel','optional']
 if label.startswith('optional') or label.startswith('compact'):return [str(A/'current-workflow'),case['contract'],case['workflow'],'parallel','compact' if label.startswith('compact') else 'optional']
 return [python,str(R/'python-workflow.py'),label,case['contract'],case['workflow']]
def fp(x):return {k:x[k] for k in ['frame','matrix_sha256']}
def run(label,case):
 cmd=command(label,case);done=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,timeout=180)
 if done.returncode:raise RuntimeError(json.dumps({'command':cmd,'exit':done.returncode,'stderr':done.stderr[-8000:],'stdout':done.stdout[-2000:]}))
 x=json.loads(done.stdout);x.update(engine_label=label,case=case_id(case));return x
if a.mode=='preflight':
 assert not (R/'preflight.jsonl').exists()
 receipts={'scope':'Eager complete-schema CSV read; optionally stable nulls-last full-frame sort and owned C-order float64 matrix; output release included. Hash validation excluded. Native CPU parallelism, no thread caps.','policy':policy(PRODUCTION_MODE),'orders':orders,'cases':cases,'compiler_sources':json.loads((R.parent/'historical-source-check.json').read_text()),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'controller_sha256':digest(Path(__file__)),'python_worker_sha256':digest(R/'python-workflow.py'),'binaries':{label:digest(Path(command(label,cases[0])[0])) for label in labels},'datasets':{case['input']:json.loads(Path(case['contract']).read_text()) for case in cases},'replicates_per_label':16,'quality_policy':{'cpu_twin_deviation':.10,'peak_twin_relative':1.05,'peak_twin_slack_bytes':8*2**20},'runtime_thread_environment':{k:v for k,v in env.items() if k in policy(PRODUCTION_MODE)['cleared_environment'] or any(k.startswith(prefix) for prefix in policy(PRODUCTION_MODE)['cleared_prefixes'])}}
 assert receipts['runtime_thread_environment']=={}
 for dataset in receipts['datasets'].values():assert digest(Path(dataset['path']))==dataset['sha256']
 (R/'plan.json').write_text(json.dumps(receipts,indent=2)+'\n');expected={}
 with (R/'preflight.jsonl').open('w') as out:
  for case in cases:
   for label in labels:
    x=run(label,case);fingerprint=fp(x)
    if case_id(case) not in expected:expected[case_id(case)]=fingerprint
    assert fingerprint==expected[case_id(case)],(case_id(case),label,fingerprint,expected[case_id(case)])
    out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();print('preflight',case_id(case),label,flush=True)
 (R/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
elif a.mode=='measure':
 assert not (R/'workers.jsonl').exists();expected=json.loads((R/'expected.json').read_text());plan=json.loads((R/'plan.json').read_text());assert plan['controller_sha256']==digest(Path(__file__)) and plan['python_worker_sha256']==digest(R/'python-workflow.py')
 for label in labels:assert digest(Path(command(label,cases[0])[0]))==plan['binaries'][label]
 subprocess.run(['pmset','-g','batt'],stdout=(R/'power-start.txt').open('w'),check=True);assert 'AC Power' in (R/'power-start.txt').read_text()
 with (R/'workers.jsonl').open('w') as out:
  for round,order in enumerate(orders):
   case_order=cases[round%4:]+cases[:round%4]
   for case in case_order:
    for position,label in enumerate(order):
     x=run(label,case);assert fp(x)==expected[case_id(case)],(case_id(case),label)
     x.update(round=round,position=position);out.write(json.dumps(x,sort_keys=True)+'\n');out.flush()
    print('round',round+1,'/16',case_id(case),'complete',flush=True)
 subprocess.run(['pmset','-g','batt'],stdout=(R/'power-end.txt').open('w'),check=True);assert 'AC Power' in (R/'power-end.txt').read_text()
else:
 rows=[json.loads(line) for line in (R/'workers.jsonl').read_text().splitlines()];assert len(rows)==512
 expected=json.loads((R/'expected.json').read_text());assert all(fp(x)==expected[x['case']] for x in rows)
 metrics=['total_cpu_ns','total_ns','read_cpu_ns','operations_cpu_ns','rss_before_bytes','rss_held_bytes','process_peak_before_bytes','process_peak_held_bytes'];results=[];flags=[]
 for case in cases:
  group=[x for x in rows if x['case']==case_id(case)]
  med={label:{metric:statistics.median(x['samples'][0][metric] for x in group if x['engine_label']==label) for metric in metrics} for label in labels}
  for label in labels:
   assert len([x for x in group if x['engine_label']==label])==16
   med[label]['peak_above_baseline_bytes']=statistics.median(max(0,x['samples'][0]['process_peak_held_bytes']-x['samples'][0]['process_peak_before_bytes']) for x in group if x['engine_label']==label)
  case_flags=[]
  for left,right in [('optional','optional_twin'),('compact','compact_twin')]:
   ratio=med[right]['total_cpu_ns']/med[left]['total_cpu_ns']
   if abs(ratio-1)>.10:case_flags.append(dict(case=case_id(case),reason='identical-binary CPU',labels=[left,right],ratio=ratio))
   for x,y in [(med[left],med[right]),(med[right],med[left])]:
    if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:case_flags.append(dict(case=case_id(case),reason='identical-binary peak',labels=[left,right]))
  flags+=case_flags
  results.append(dict(case=case_id(case),qualified=not case_flags,per_label=med))
 report=dict(measured_workers=len(rows),preflight_workers=len((R/'preflight.jsonl').read_text().splitlines()),all_outputs_match=True,quality_flags=flags,cases=results)
 (R/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
