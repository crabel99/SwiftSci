import Foundation
import SwiftDataFrame
import Darwin
import CryptoKit

func cpu() -> Int64 {
    var usage = rusage(); getrusage(RUSAGE_SELF, &usage)
    return Int64(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) * 1_000_000_000
        + Int64(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) * 1_000
}
func heap() -> Int64 {
    var stats = malloc_statistics_t(); malloc_zone_statistics(nil, &stats)
    return Int64(stats.size_in_use)
}
func peak() -> Int64 { var usage = rusage(); getrusage(RUSAGE_SELF, &usage); return Int64(usage.ru_maxrss) }
func make<T: SupportedType>(_ type: T.Type, count: Int) -> any AnyColumn {
    TypedColumn<T>(name: "x", values: Array<T?>(repeating: nil, count: count))
}
@MainActor @main struct AllMissingProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        let kind = args[0], count = Int(args[1])!
        let input: any AnyColumn
        switch kind {
        case "Double": input = make(Double.self, count: count)
        case "Float": input = make(Float.self, count: count)
        case "Int64": input = make(Int64.self, count: count)
        case "Int32": input = make(Int32.self, count: count)
        case "Int": input = make(Int.self, count: count)
        case "String": input = make(String.self, count: count)
        case "Date": input = make(Date.self, count: count)
        case "Bool": input = make(Bool.self, count: count)
        case "CompactDouble":
            var options = CSVReadOptions()
            options.doubleStorage = .compact
            options.columnTypeOverrides = ["x": .float64]
            input = try await DataFrame(csv: URL(fileURLWithPath: args[2]), options: options)[column: "x"]!
        default: preconditionFailure("Unknown fixture type")
        }
        precondition(input.count == count && input.nullCount == count && MemoryLayout<Int>.size == 8)
        let h0 = heap(), p0 = peak(), c0 = cpu()
        var indices: [Int]? = input.sortedIndices(ascending: true)
        let c1 = cpu(), h1 = heap(), p1 = peak()
        precondition(indices!.count == count)
        for (row, index) in indices!.enumerated() { precondition(row == index) }
        let digest = indices!.withUnsafeBytes { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() }
        let c2 = cpu()
        indices = nil
        let c3 = cpu()
        withExtendedLifetime(input) {}
        let result: [String: Any] = ["kind": kind, "rows": count, "dtype": input.dtype.description,
            "nulls": input.nullCount, "indices_sha256": digest, "validated_identity": true,
            "operations_cpu_ns": c1 - c0, "total_cpu_ns": c1 - c0 + c3 - c2,
            "heap_before_bytes": h0, "held_heap_bytes": h1, "heap_after_release_bytes": heap(),
            "process_peak_before_bytes": p0, "process_peak_held_bytes": p1,
            "scope": "Public index sorting and result release with input retained. Constructor and complete identity validation excluded. Process peak may include construction." ]
        print(String(decoding: try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]), as: UTF8.self))
    }
}
