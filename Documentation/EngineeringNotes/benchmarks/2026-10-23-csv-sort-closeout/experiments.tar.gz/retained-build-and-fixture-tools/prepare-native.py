from pathlib import Path
import hashlib,json,re,struct,subprocess
R=Path(__file__).resolve().parent;F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();contracts=[]
for count in [1000000,8000000]:
 p=R/f'all-missing-{count}.csv';p.write_text('x\n'+'""\n'*count)
 d=hashlib.sha256()
 for start in range(0,count,10000):
  stop=min(start+10000,count);d.update(struct.pack('<'+'q'*(stop-start),*range(start,stop)))
 for kind in ['Double','Float','Int64','Int32','Int','String','Date','Bool','CompactDouble']:
  contracts.append({'kind':kind,'count':count,'nulls':count,'dtype':'Double' if kind=='CompactDouble' else 'Int64' if kind=='Int' else kind,'indices_sha256':d.hexdigest(),'path':str(p),'csv_sha256':h(p)})
(R/'native-contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('original',Path('/private/tmp/swiftsci-csv-lazy-sort-cache-20261023/build')),('prior',Path('/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023/build')),('current',R/'build')]:
 cmd=[x.replace(str(F),str(D)) for x in base];cmd=[str(R/'AllMissingProbe.swift') if x.endswith('/ResourceProbe.swift') else str(R/(label+'-native')) if x==str(D/'ResourceProbe') else x for x in cmd]+['-Rmodule-loading']
 with (R/(label+'-native-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'-native-build.log')).read_text()[-2500:]);raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-native-build.log')).read_text()));assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-native-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':h(R/'AllMissingProbe.swift'),'binary_sha256':h(R/(label+'-native'))},indent=2)+'\n');print(label,'native client built',flush=True)
