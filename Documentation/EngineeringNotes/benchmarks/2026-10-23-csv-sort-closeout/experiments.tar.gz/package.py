from pathlib import Path
import ast,gzip,hashlib,json,re,shutil,subprocess,tarfile
R=Path(__file__).resolve().parent;S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021');A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023');W=Path('/Users/crabel/Library/Caches/SwiftSci/engineering-evaluation-20261018');N=W/'Documentation/EngineeringNotes/benchmarks/2026-10-23-csv-sort-closeout'
assert subprocess.check_output(['git','branch','--show-current'],cwd=W,text=True).strip()=='codex/engineering-notes'
assert json.loads((R/'comparison-initialized-independent-audit.json').read_text())['passed']
subprocess.run(['python3',str(R/'report.py')],check=True)
checks=[json.loads((R/name).read_text()) for name in ['comparison-independent-audit.json','comparison-initialized-independent-audit.json','precision-independent-audit.json']]
assert all(x['passed'] for x in checks)
combined={'passed':True,'panels':checks,'reference_panels_kept_separate':True,'source_head':'a74f5c3b5e0e511bf5bb69886a40cbae48b28d99','original_failed_qualifications_replaced':False,'source_push_or_PR':False}
(N/'independent-audit.json').write_text(json.dumps(combined,indent=2)+'\n')
patch=(R/'focused-source.patch').read_bytes();subprocess.run(['git','apply','--reverse','--check','-'],cwd=S,input=patch,check=True)
with gzip.GzipFile(filename=str(N/'focused-source.patch.gz'),mode='wb',mtime=0) as out:out.write(patch)
review='''# Review draft: stable identity for fully missing sort keys

This is prepared text for the isolated `a74f5c3` change against `940353d`. It is not a submitted PR or a claim that the full source stack is ready for production.

## Proposed title

Avoid sort preparation when every key is missing

## Proposed description

A stable sort of an entirely missing key must preserve source row order in both directions. `TypedColumn.sortedIndices` now returns that identity permutation from its existing immutable null count, avoiding key scans and temporary sort storage. The change applies to every supported native key type and compact Double. Valid NaNs remain distinct from missing values and retain their comparison path.

Two test functions cover empty inputs, validity boundaries, both directions, public dataframe sorting, native Int64 identities above 2^53, and compact inputs containing valid NaNs. Both tests pass before the optimization because this is a resource improvement, not a correctness repair. The test type is 60 lines.

All 431 dataframe test functions pass in Release, Debug, and Address Sanitizer with no failures or skips. Those receipts match the exact retained source and test files. The complete MLX-dependent package and hosted required checks remain separate prerequisites.

The original exceptional-case panel has 14 qualified cases out of 18. Qualified CPU reductions range from 67.5% to 99.0%. Eight-million-row compact Double uses 18.867 to 6.076 ms CPU and 191.828 to 130.797 MiB peak RSS. Four original native timings and one original common-shape timing remain unqualified. A separate 32-replicate confirmation passes unchanged quality controls on the four selected native cases without replacing their original records.

The shortcut has a small measured common-input cost. The higher-replication distributed 32,768-row compact control uses about 4.4% more paired CPU, a few microseconds. The earlier 10% million-row observation does not repeat consistently. A refactor that moved the shortcut into type-specific algorithms was rejected after it added about 7.5 MiB peak memory to million-row compact sorts.

The engineering evidence and readable comparison remain on the fork's `codex/engineering-notes` branch. The separate complete-schema reference panel evaluates the accumulated compact-storage and sorting stack, so its gains must not be attributed to this one-line shortcut. Its primary scope completes the DuckDB Arrow bridge pandas import before timing. The original first-use panel remains separate. Engineering notes, fixture archives, profiles, and rejected experiments are excluded from the source patch.

## Before submission

Confirm the intended parent after upstream synchronization. Rerun required package checks on the combined branch and obtain passing hosted checks. Link a published, sanitized engineering-note revision if benchmark evidence is requested. The current report is local and no push is authorized here.
'''
(N/'review-draft.md').write_text(review)
allowed={'.py','.swift','.json','.jsonl','.log','.txt','.md','.patch'}
with tarfile.open(N/'experiments.tar.gz','w:gz') as tar:
 for p in sorted(R.rglob('*')):
  parts=p.relative_to(R).parts
  if p.is_file() and p.suffix in allowed and not any(x.endswith('.xcresult') or x=='__pycache__' for x in parts):tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
 for folder in ['Sources/SwiftDataFrame','Tests/SwiftDataFrameTests']:
  for p in sorted((S/folder).rglob('*.swift')):tar.add(p,arcname='retained-source/'+str(p.relative_to(S)),recursive=False)
 for p in sorted(A.glob('*')):
  if p.is_file() and (p.suffix=='.swift' or p.name in ['native-contracts.json','prepare-native.py','prepare-shapes.py','build.py','module-build.json','current-workflow-build.json','current-shape-build.json','current-native-build.json'] or p.name.startswith('final-') and p.suffix=='.json'):tar.add(p,arcname='retained-build-and-fixture-tools/'+p.name,recursive=False)
 for p in sorted((A/'shape-inputs').glob('*.json')):tar.add(p,arcname='shape-contracts/'+p.name,recursive=False)
 f=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata/build.json');tar.add(f,arcname='historical-build-template.json')
 for p in Path('/private/tmp/swiftsci-csv-external-20261023/inputs').glob('*.json'):tar.add(p,arcname='reference-input-contracts/'+p.name)
with tarfile.open(N/'experiments.tar.gz') as tar:
 members=tar.getmembers();assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts and not m.issym() for m in members)
 assert not any(m.name.endswith(('.csv','.o')) or '.xcresult/' in m.name for m in members)
for p in R.rglob('*.py'):ast.parse(p.read_text())
for p in N.glob('*.md'):
 text=p.read_text();assert '—' not in text
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if '://' not in link and link!='artifact-sha256.json':assert (N/link).exists(),link
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={p.name:h(p) for p in sorted(N.iterdir()) if p.is_file() and p.name!='artifact-sha256.json'};(N/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n');assert all(h(N/k)==v for k,v in manifest.items())
print('Verified exact patch, source separation, safe archive paths, links, script syntax and artifact hashes')
print('Archive files:',len(members),'compressed bytes:',(N/'experiments.tar.gz').stat().st_size)
