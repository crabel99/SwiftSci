from pathlib import Path
import ast,collections,hashlib,json,statistics,subprocess,sys
R=Path(__file__).resolve().parent;panel=sys.argv[1] if len(sys.argv)>1 else 'comparison';assert panel in ['comparison','comparison-initialized'];D=R/panel;B=R/'comparison';S=Path('/private/tmp/swiftsci-csv-count-only-scan-20261021')
load=lambda p:json.loads(p.read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=load(D/'plan.json');expected=load(D/'expected.json');rows=[json.loads(x) for x in (D/'workers.jsonl').read_text().splitlines()];preflight=[json.loads(x) for x in (D/'preflight.jsonl').read_text().splitlines()];summary=load(D/'audit.json')
assert len(rows)==512 and len(preflight)==32
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==plan['source_head']=='a74f5c3b5e0e511bf5bb69886a40cbae48b28d99'
assert h(D/'run.py')==plan['controller_sha256'] and h(D/'python-workflow.py')==plan['python_worker_sha256']
labels=list(plan['binaries']);cases=sorted(expected);assert len(labels)==8 and len(cases)==4
A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023')
module=load(A/'module-build.json');assert h(A/'build/SwiftDataFrame.o')==module['object_sha256']
assert all(h(S/name)==digest for name,digest in module['sources'].items())
for label,digest in plan['binaries'].items():
 binary=B/'baseline-workflow' if label=='baseline' else A/'current-workflow' if label in ['optional','compact','optional_twin','compact_twin'] else Path('/Users/crabel/Documents/src/SwiftSci/Benchmarks/.venv-standardized/bin/python')
 assert h(binary)==digest
historical=load(B/'historical-build-command.json')
assert all(h(B/'historical-source'/name)==digest for name,digest in historical['sources'].items())
assert h(B/'historical-build/SwiftDataFrame.o')==load(B/'historical-object.json')['sha256']

assert all(collections.Counter(order[position] for order in plan['orders'])=={label:2 for label in labels} for position in range(8))
adj=collections.Counter((a,b) for order in plan['orders'] for a,b in zip(order,order[1:]));assert len(adj)==56 and set(adj.values())=={2}
assert len({(x['case'],x['round'],x['engine_label']) for x in rows})==512
for case in cases:
 for turn,order in enumerate(plan['orders']):
  group=sorted([x for x in rows if x['case']==case and x['round']==turn],key=lambda x:x['position']);assert [x['engine_label'] for x in group]==order
for x in rows+preflight:
 assert {k:x[k] for k in ['frame','matrix_sha256']}==expected[x['case']]
 assert x['frame']['rows']==plan['datasets'][x['input']]['rows']
 if x['engine_label'] in ['baseline','optional','compact','optional_twin','compact_twin']:assert x['policy']=='parallel'
 else:
  options=x['options'];assert x['versions']['numpy']=='2.5.3'
  if x['engine_label']=='pandas':assert options['keep_default_na'] is False and options['float_precision']=='round_trip' and len(options['dtype'])==len(x['frame']['columns'])
  if x['engine_label']=='polars':assert len(options['schema'])==len(x['frame']['columns']) and x['pools']['polars']>0
  if x['engine_label']=='duckdb':assert options['auto_detect'] is False and len(options['columns'])==len(x['frame']['columns']) and x['pools']['duckdb']>0
 sample=x['samples'][0];assert sample['total_cpu_ns']>0 and sample['total_ns']>0 and sample['process_peak_held_bytes']>=sample['process_peak_before_bytes']
flags=[]
for c in summary['cases']:
 group=[x for x in rows if x['case']==c['case']];med=c['per_label']
 for label in labels:
  selected=[x for x in group if x['engine_label']==label];assert len(selected)==16
  for metric,value in med[label].items():
   vals=[max(0,x['samples'][0]['process_peak_held_bytes']-x['samples'][0]['process_peak_before_bytes']) for x in selected] if metric=='peak_above_baseline_bytes' else [x['samples'][0][metric] for x in selected]
   assert value==statistics.median(vals),(c['case'],label,metric)
 for left,right in [('optional','optional_twin'),('compact','compact_twin')]:
  ratio=med[right]['total_cpu_ns']/med[left]['total_cpu_ns']
  if abs(ratio-1)>.1:flags.append((c['case'],'identical-binary CPU',(left,right)))
  if any(med[y]['process_peak_held_bytes']>med[x]['process_peak_held_bytes']*1.05+8*2**20 for x,y in [(left,right),(right,left)]):flags.append((c['case'],'identical-binary peak',(left,right)))
 assert c['qualified']==(not any(x[0]==c['case'] for x in flags))
assert sorted(flags)==sorted((x['case'],x['reason'],tuple(x['labels'])) for x in summary['quality_flags'])
for dataset in plan['datasets'].values():assert h(Path(dataset['path']))==dataset['sha256']
assert 'AC Power' in (D/'power-start.txt').read_text() and 'AC Power' in (D/'power-end.txt').read_text()
code=load(R/'code-inspection.json');matched=[x for x in code['routines'] if 'CSV' in x['symbol'] and x['parent'] and x['candidate']];assert len(matched)==428 and all(x['identical_after_normalizing_internal_branch_targets'] for x in matched)
precision=load(R/'precision-32/decision.json');assert precision['workers']==1024 and not precision['quality_flags']
assert load(R/'retained-checkpoint-validation.json')['release']['summary']['passedTests']==431
for p in R.rglob('*.py'):ast.parse(p.read_text())
result={'passed':True,'source_head':plan['source_head'],'panel':panel,'reference_measured_workers':512,'reference_preflight_workers':32,'every_output_matches':True,'balanced_positions_and_adjacencies':True,'exact_native_integer_and_matrix_hashes':True,'source_and_binary_provenance_verified':True,'independently_recomputed_reference_statistics':True,'quality_flags':summary['quality_flags'],'precision_measured_workers':1024,'original_failed_qualifications_replaced':False,'source_promotion_or_push':False}
(R/(panel+'-independent-audit.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
