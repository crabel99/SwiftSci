from pathlib import Path
import argparse,hashlib,json,statistics,subprocess
R=Path(__file__).resolve().parent;A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023')
p=argparse.ArgumentParser();p.add_argument('mode',choices=['replay','run']);p.add_argument('--label',default='live-1');a=p.parse_args()
fixtures=[('half-plus-one-1000000','compact'),('ascending-1000000','optional'),('random-1000000','compact'),('half-minus-one-32768','optional')]
keys=['frame','matrix_sha256','export_sha256','scalar_bits','batch_sha256','selection_sha256'];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if a.mode=='replay':
 D=R/'replay';D.mkdir(exist_ok=True);parent=['prior'];candidate=['current','twin'];labels=parent+candidate
 wanted={f'{i}/serial/{s}/sort-indices' for i,s in fixtures}
 rows=[json.loads(x) for x in (A/'shape-measurement/workers.jsonl').read_text().splitlines()];rows=[x for x in rows if x['case'] in wanted and x['engine'] in labels]
else:
 D=R/a.label;D.mkdir(exist_ok=False);labels=['parent','parent_twin','candidate','candidate_twin'];parent=labels[:2];candidate=labels[2:]
 binaries={k:A/('prior-shape' if k in parent else 'current-shape') for k in labels}
 base=[0,1,3,2];first=[[labels[(x+shift)%4] for x in base] for shift in range(4)];orders=first+[list(reversed(x)) for x in reversed(first)]
 contracts={i:json.loads((A/'shape-inputs'/(i+'.json')).read_text()) for i,s in fixtures}
 plan={'controller_sha256':h(Path(__file__)),'binaries':{k:h(v) for k,v in binaries.items()},'orders':orders,'fixtures':fixtures,'contracts':contracts,'quality_policy':{'cpu_twin_deviation':.10,'peak_twin_relative':1.05,'peak_twin_slack_bytes':8*2**20}}
 (D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');subprocess.run(['pmset','-g','batt'],stdout=(D/'power.txt').open('w'),check=True);assert 'AC Power' in (D/'power.txt').read_text()
 rows=[]
 with (D/'workers.jsonl').open('w') as out:
  for fixture,storage in fixtures:
   case=f'{fixture}/serial/{storage}/sort-indices';expected=None;c=contracts[fixture]
   for turn,order in enumerate(orders):
    for position,label in enumerate(order):
     x=json.loads(subprocess.check_output([str(binaries[label]),str(A/'shape-inputs'/(fixture+'.json')),'sort-indices','serial',storage],text=True,timeout=45));fp={k:x[k] for k in keys}
     assert x['selection_sha256']==c['expected_index_sha256']
     if expected is None:expected=fp
     assert fp==expected
     x.update(case=case,engine=label,round=turn,position=position);out.write(json.dumps(x,sort_keys=True)+'\n');out.flush();rows.append(x)
   print(case,'8 balanced rounds completed',flush=True)
 subprocess.run(['pmset','-g','batt'],stdout=(D/'power-end.txt').open('w'),check=True);assert 'AC Power' in (D/'power-end.txt').read_text()
flags=[];result=[]
for case in sorted({x['case'] for x in rows}):
 group=[x for x in rows if x['case']==case];expected={k:group[0][k] for k in keys};assert all({k:x[k] for k in keys}==expected for x in group)
 med={label:{metric:statistics.median(x['samples'][0][metric] for x in group if x['engine']==label) for metric in ['total_cpu_ns','process_peak_held_bytes']} for label in labels}
 for left,right in ([('parent','parent_twin'),('candidate','candidate_twin')] if a.mode=='run' else [('current','twin')]):
  ratio=med[right]['total_cpu_ns']/med[left]['total_cpu_ns']
  if abs(ratio-1)>.10:flags.append({'case':case,'labels':[left,right],'reason':'identical-binary CPU','ratio':ratio})
  for x,y in [(med[left],med[right]),(med[right],med[left])]:
   if y['process_peak_held_bytes']>x['process_peak_held_bytes']*1.05+8*2**20:flags.append({'case':case,'labels':[left,right],'reason':'identical-binary peak'})
 values={role:[statistics.median(x['samples'][0]['total_cpu_ns'] for x in group if x['engine'] in engines and x['round']==turn) for turn in range(8)] for role,engines in [('parent',parent),('candidate',candidate)]}
 ratios=[c/p for p,c in zip(values['parent'],values['candidate'])]
 result.append({'case':case,'parent_median_ms':statistics.median(values['parent'])/1e6,'candidate_median_ms':statistics.median(values['candidate'])/1e6,'paired_median_ratio':statistics.median(ratios),'positive_pairs':sum(x>1 for x in ratios),'cost_alert':sum(x>1 for x in ratios)>=7,'per_label':med})
verdict={'mode':a.mode,'workers':len(rows),'all_outputs_match':True,'quality_flags':flags,'cases':result,'repeatable_cost_signal':not flags and any(x['cost_alert'] for x in result),'signal_definition':'Seven of eight paired-round CPU increases is a diagnostic alert, not an acceptance rule or causal proof.'}
(D/'decision.json').write_text(json.dumps(verdict,indent=2)+'\n');print(json.dumps(verdict,indent=2),flush=True);raise SystemExit(1 if verdict['repeatable_cost_signal'] else 0)
