from pathlib import Path
import sys,json,time,resource,ctypes,hashlib,struct
import numpy as np
engine,contract,workflow=sys.argv[1:];case=json.loads(Path(contract).read_text())
assert workflow in ['read','sort-matrix']
assert set(case['types'])<={'String','Double','Int64'}
numeric=[n for n,t in zip(case['names'],case['types']) if t!='String']
key='Global_active_power' if case['id'].startswith('energy') else 'PM2.5'
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
class MachInfo(ctypes.Structure):
 _fields_=[('virtual_size',ctypes.c_uint64),('resident_size',ctypes.c_uint64),('resident_size_max',ctypes.c_uint64),('user_sec',ctypes.c_int32),('user_micro',ctypes.c_int32),('sys_sec',ctypes.c_int32),('sys_micro',ctypes.c_int32),('policy',ctypes.c_int32),('suspend',ctypes.c_int32)]
self_task=ctypes.c_uint.in_dll(lib,'mach_task_self_').value
lib.task_info.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)]
def rss():
 info=MachInfo();count=ctypes.c_uint(ctypes.sizeof(info)//4)
 assert lib.task_info(self_task,20,ctypes.byref(info),ctypes.byref(count))==0
 return info.resident_size
def peak():return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
def cpu():
 r=resource.getrusage(resource.RUSAGE_SELF);return round((r.ru_utime+r.ru_stime)*1e9)
versions={'python':sys.version,'numpy':np.__version__};pools={}
if engine=='pandas':
 import pandas as pd
 versions['pandas']=pd.__version__;types={'String':'str','Double':'float64','Int64':'int64'}
 kwargs=dict(sep=case['delimiter'],header=0,dtype={n:types[t] for n,t in zip(case['names'],case['types'])},na_values=case['null_tokens'],keep_default_na=False,encoding='utf-8',engine='c',float_precision='round_trip')
 def read():return pd.read_csv(case['path'],**kwargs)
 def sort(frame):return frame.sort_values(key,kind='stable',na_position='last',ignore_index=True)
 def matrix(frame):return np.ascontiguousarray(frame[numeric].to_numpy(dtype=np.float64,na_value=np.nan,copy=True))
elif engine=='polars':
 import polars as pl
 versions['polars']=pl.__version__;pools['polars']=pl.thread_pool_size()
 types={'String':pl.String,'Double':pl.Float64,'Int64':pl.Int64}
 kwargs=dict(separator=case['delimiter'],has_header=True,schema={n:types[t] for n,t in zip(case['names'],case['types'])},null_values=case['null_tokens'],try_parse_dates=False)
 def read():return pl.read_csv(case['path'],**kwargs)
 def sort(frame):return frame.sort(key,nulls_last=True,maintain_order=True)
 def matrix(frame):return np.ascontiguousarray(frame.select(numeric).to_numpy(order='c',writable=True))
elif engine=='duckdb':
 import duckdb,pyarrow as pa
 versions.update(duckdb=duckdb.__version__,pyarrow=pa.__version__)
 if workflow=='sort-matrix':
  import pandas as pd
  versions['pandas']=pd.__version__
 connection=duckdb.connect();pools['duckdb']=connection.sql("select current_setting('threads')").fetchone()[0]
 assert connection.sql("select current_setting('preserve_insertion_order')").fetchone()[0]
 types={'String':'VARCHAR','Double':'DOUBLE','Int64':'BIGINT'}
 kwargs=dict(delimiter=case['delimiter'],header=True,columns={n:types[t] for n,t in zip(case['names'],case['types'])},na_values=case['null_tokens'],auto_detect=False)
 def read():return connection.read_csv(case['path'],**kwargs).to_arrow_table()
 def quote(name):return '"'+name.replace('"','""')+'"'
 def sort(frame):
  indexed=frame.append_column('__source_row__',pa.array(np.arange(len(frame),dtype=np.int64)))
  connection.register('_sort_input',indexed)
  try:return connection.sql('SELECT '+','.join(map(quote,case['names']))+' FROM _sort_input ORDER BY '+quote(key)+' ASC NULLS LAST, __source_row__ ASC').to_arrow_table()
  finally:connection.unregister('_sort_input')
 def matrix(frame):return np.ascontiguousarray(np.column_stack([frame[name].to_numpy(zero_copy_only=False) for name in numeric]),dtype=np.float64)
else:raise ValueError(engine)

def fingerprint(frame):
 names=list(frame.columns) if engine!='duckdb' else frame.schema.names
 assert names==case['names'] and len(frame)==case['rows']
 columns=[]
 for name,kind in zip(case['names'],case['types']):
  col=frame[name]
  if engine=='pandas':matches={'Double':pd.api.types.is_float_dtype(col) and col.dtype.itemsize==8,'Int64':pd.api.types.is_integer_dtype(col) and col.dtype.itemsize==8,'String':pd.api.types.is_string_dtype(col)}[kind]
  elif engine=='polars':matches=col.dtype=={'Double':pl.Float64,'Int64':pl.Int64,'String':pl.String}[kind]
  else:matches=col.type=={'Double':pa.float64(),'Int64':pa.int64(),'String':pa.string()}[kind]
  assert matches,(name,kind,str(col.dtype if engine!='duckdb' else col.type))
  digest=hashlib.sha256();nulls=0
  for start in range(0,len(frame),65536):
   if engine=='pandas':
    part=col.iloc[start:start+65536];valid=~part.isna().to_numpy();values=part.tolist() if kind=='String' else part.to_numpy()
   elif engine=='polars':
    part=col.slice(start,65536);valid=part.is_not_null().to_numpy();values=part.to_list() if kind=='String' else part.to_numpy()
   else:
    part=col.slice(start,65536);valid=part.is_valid().to_numpy(zero_copy_only=False);values=part.to_pylist() if kind=='String' else part.to_numpy(zero_copy_only=False)
   nulls+=int((~valid).sum())
   if kind=='String':
    buf=bytearray()
    for value,ok in zip(values,valid):
     if ok:
      encoded=value.encode('utf-8');buf+=b'\1'+struct.pack('<I',len(encoded))+encoded
     else:buf+=b'\0'
    digest.update(buf)
   else:
    numbers=np.ascontiguousarray(values,dtype='<i8' if kind=='Int64' else '<f8')
    packed=np.empty((len(valid),9),dtype=np.uint8);packed[:,0]=valid;packed[:,1:]=numbers.view(np.uint8).reshape(-1,8)
    keep=np.ones(packed.shape,dtype=bool);keep[~valid,1:]=False;digest.update(packed[keep].tobytes())
  assert nulls==case['null_counts'][case['names'].index(name)]
  columns.append(dict(name=name,type=kind,nulls=nulls,sha256=digest.hexdigest()))
 return dict(rows=len(frame),columns=columns)

def matrix_fingerprint(values):
 assert values.shape==(case['rows'],len(numeric)) and values.dtype==np.float64 and values.flags.c_contiguous
 digest=hashlib.sha256();flat=values.reshape(-1)
 for start in range(0,len(flat),65536):
  numbers=np.ascontiguousarray(flat[start:start+65536],dtype='<f8')
  packed=np.empty((len(numbers),9),dtype=np.uint8);packed[:,0]=1;packed[:,1:]=numbers.view(np.uint8).reshape(-1,8);digest.update(packed.tobytes())
 return digest.hexdigest()

r0,p0,c0,t0=rss(),peak(),cpu(),time.perf_counter_ns()
output=read();c_read,t_read=cpu(),time.perf_counter_ns();values=None
if workflow=='sort-matrix':output=sort(output);values=matrix(output)
t1,c1,r1,p1=time.perf_counter_ns(),cpu(),rss(),peak()
frame_check=fingerprint(output);matrix_check='absent' if values is None else matrix_fingerprint(values)
c2,t2=cpu(),time.perf_counter_ns();del output,values;t3,c3=time.perf_counter_ns(),cpu()
sample=dict(total_ns=t1-t0+t3-t2,total_cpu_ns=c1-c0+c3-c2,read_cpu_ns=c_read-c0,read_ns=t_read-t0,operations_cpu_ns=c1-c_read,rss_before_bytes=r0,rss_held_bytes=r1,rss_after_release_bytes=rss(),process_peak_before_bytes=p0,process_peak_held_bytes=p1)
if engine=='duckdb':connection.close()
print(json.dumps(dict(frame=frame_check,matrix_sha256=matrix_check,engine=engine,input=case['id'],workflow=workflow,samples=[sample],versions=versions,pools=pools,options=kwargs,scope='Complete schema CSV construction, stable nulls-last full-frame sort and C-order float64 matrix if requested, output release. Hash verification excluded.'),default=str))
