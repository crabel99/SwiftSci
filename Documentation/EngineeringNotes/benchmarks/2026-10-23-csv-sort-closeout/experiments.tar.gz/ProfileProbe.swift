import Foundation
import SwiftDataFrame
import Darwin
@MainActor @main struct ProfileProbe {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        var options = CSVReadOptions()
        options.doubleStorage = args[1] == "compact" ? .compact : .optional
        options.columnTypeOverrides = ["x": .float64]
        options.columnConversionMode = .serial
        let frame = try await DataFrame(csv: URL(fileURLWithPath: args[0]), options: options)
        let column = frame[column: "x", as: Double.self]!
        FileHandle.standardOutput.write(Data("READY\n".utf8))
        _ = try FileHandle.standardInput.read(upToCount: 1)
        var checksum: UInt64 = 0
        for _ in 0..<Int(args[2])! {
            let rows = column.sortedIndices(ascending: true)
            checksum &+= UInt64(rows.first!) &+ UInt64(rows.last!)
        }
        withExtendedLifetime(frame) {}
        print(checksum)
    }
}
