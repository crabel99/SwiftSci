from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023');F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata');base=json.loads((F/'build.json').read_text())['commands'][1]
for label,D in [('parent',Path('/private/tmp/swiftsci-csv-shared-keys-sparse-admission-20261023/build')),('candidate',A/'build')]:
 cmd=[x.replace(str(F),str(D)) for x in base];cmd=[str(R/'ProfileProbe.swift') if x.endswith('/ResourceProbe.swift') else str(R/(label+'-profile')) if x==str(D/'ResourceProbe') else x for x in cmd]+['-Rmodule-loading']
 with (R/(label+'-profile-build.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-profile-build.log')).read_text()));assert loaded['SwiftDataFrame']==str(D/'SwiftDataFrame.swiftmodule')
 (R/(label+'-profile-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'binary_sha256':hashlib.sha256((R/(label+'-profile')).read_bytes()).hexdigest()},indent=2)+'\n')
 p=subprocess.Popen([str(R/(label+'-profile')),str(A/'shape-inputs/valid-2-distributed-32768.csv'),'compact','100000'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert p.stdout.readline()==b'READY\n'
 with (R/(label+'-sample.log')).open('w') as log:
  sampler=subprocess.Popen(['sample',str(p.pid),'3','1','-file',str(R/(label+'-sample.txt'))],stdout=log,stderr=subprocess.STDOUT)
  out,err=p.communicate(b'G',timeout=120);status=sampler.wait(timeout=30)
 (R/(label+'-profile-result.json')).write_text(json.dumps({'profiled_timing_is_not_benchmark_evidence':True,'worker_exit':p.returncode,'sample_exit':status,'stdout':out.decode(),'stderr':err.decode(),'repeated_public_calls':100000},indent=2)+'\n')
 assert p.returncode==0
 print(label,'profile complete',status,flush=True)
