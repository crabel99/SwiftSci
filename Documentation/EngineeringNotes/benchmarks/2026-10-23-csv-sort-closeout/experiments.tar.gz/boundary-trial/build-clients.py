from pathlib import Path
import subprocess,json,re,hashlib
R=Path(__file__).resolve().parent
F=Path('/private/tmp/swiftsci-csv-fallback-isolation-20261022/build/metadata')
A=Path('/private/tmp/swiftsci-csv-all-missing-sort-20261023')
base=json.loads((F/'build.json').read_text())['commands'][1]
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,source,defines in [('shape',A/'ShapeProbe.swift',[]),('native',A/'AllMissingProbe.swift',[]),('workflow',A/'WorkflowProbe.swift',['-D','CSV_STORAGE_CHOICE'])]:
 cmd=[x.replace(str(F),str(R/'build')) for x in base]
 cmd=[str(source) if x.endswith('/ResourceProbe.swift') else str(R/label) if x==str(R/'build/ResourceProbe') else x for x in cmd]+defines+['-Rmodule-loading']
 with (R/(label+'-build.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:print((R/(label+'-build.log')).read_text()[-4000:]);raise SystemExit(p.returncode)
 loaded=dict(re.findall(r"remark: loaded module '([^']+)'; source: '([^']+)'",(R/(label+'-build.log')).read_text()));assert loaded['SwiftDataFrame']==str(R/'build/SwiftDataFrame.swiftmodule')
 (R/(label+'-build.json')).write_text(json.dumps({'command':cmd,'verified_module':loaded['SwiftDataFrame'],'source_sha256':h(source),'binary_sha256':h(R/label)},indent=2)+'\n')
 print(label,'built',flush=True)
