import subprocess,json
from pathlib import Path
r=Path(__file__).resolve().parent
c=json.loads((r/"build-command.json").read_text())["command"]
with (r/"module-build.log").open("w") as out:p=subprocess.run(c,stdout=out,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)
